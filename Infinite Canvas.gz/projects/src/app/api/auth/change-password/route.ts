import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { SESSION_COOKIE_NAME } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { AuthService } from "@/server/domains/auth/services/authService"
import { changeCurrentUserPassword } from "@/server/domains/auth/services/changeCurrentUserPasswordService"
import { ServiceError } from "@/server/shared/errors"

export const runtime = "nodejs"

const bodySchema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(1).max(200),
  confirmNewPassword: z.string().min(1).max(200)
})

/**
 * 当前登录用户自助修改密码。
 * 路由层仅负责鉴权、参数校验与响应映射，真正改密逻辑下沉到服务层。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)

  logger.info({
    event: "auth_change_password_request_start",
    module: "auth",
    traceId,
    message: "开始处理当前用户修改密码请求"
  })

  const parsed = bodySchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  if (parsed.data.newPassword !== parsed.data.confirmNewPassword) {
    return NextResponse.json(makeApiErr(traceId, "AUTH_PASSWORD_CONFIRM_MISMATCH", "两次输入的新密码不一致"), { status: 400 })
  }

  const cookieHeader = req.headers.get("cookie") ?? ""
  const token = cookieHeader
    .split(";")
    .map((value) => value.trim())
    .find((value) => value.startsWith(`${SESSION_COOKIE_NAME}=`))
    ?.slice(`${SESSION_COOKIE_NAME}=`.length)

  try {
    const user = await AuthService.getCurrentUser(token, true, traceId)
    await changeCurrentUserPassword({
      userId: user.id,
      currentPassword: parsed.data.currentPassword,
      newPassword: parsed.data.newPassword,
      traceId
    })
    return NextResponse.json(makeApiOk(traceId, { ok: true, reauthRequired: true }))
  } catch (error) {
    if (error instanceof ServiceError) {
      const status = ["AUTH_UNAUTHENTICATED", "AUTH_INVALID_SESSION", "AUTH_USER_NOT_FOUND", "AUTH_DISABLED"].includes(error.code)
        ? 401
        : error.code === "AUTH_INVALID_CREDENTIALS" || error.code === "AUTH_PASSWORD_UNCHANGED"
          ? 400
          : 500
      return NextResponse.json(makeApiErr(traceId, error.code, error.message), { status })
    }

    const anyErr = error as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "auth_change_password_request_failed",
      module: "auth",
      traceId,
      message: "当前用户修改密码请求失败",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "AUTH_CHANGE_PASSWORD_FAILED", "修改密码失败，请稍后重试"), { status: 500 })
  }
}
