"use client"

import { useEffect, useMemo, useState } from "react"
import type { BillingFilter, BillingOverview, BillingUserSummaryItem } from "@/shared/contracts/billing"
import { BillingDetailsModal } from "./BillingDetailsModal"
import { BillingTaskQueryModal } from "./BillingTaskQueryModal"
import { BillingUserSelect } from "./BillingUserSelect"
import { buildBillingSearchParams, downloadFileResponse, getDefaultBillingDateRange, type OverviewResponse, readApiJson } from "./billingApi"
import { formatBillingDateRange, formatTokenMillions } from "./billingPresentation"
import styles from "./BillingPage.module.css"

type DetailTarget = {
  scopeType: "group" | "user"
  scopeId: string
  scopeName: string
}

/**
 * 账单统计页面。
 * 说明：页面负责总览与任务搜索，团队/个人明细筛选放到独立弹窗中，避免总览状态互相干扰。
 */
export function BillingPage({ roleKey }: { roleKey: string }) {
  const defaultDateRange = useMemo(() => getDefaultBillingDateRange(), [])
  const [from, setFrom] = useState(defaultDateRange.from ?? "")
  const [to, setTo] = useState(defaultDateRange.to ?? "")
  const [groupId, setGroupId] = useState("")
  const [userId, setUserId] = useState("")
  const [overview, setOverview] = useState<BillingOverview | null>(null)
  const [loading, setLoading] = useState(true)
  const [exporting, setExporting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({})
  const [detailTarget, setDetailTarget] = useState<DetailTarget | null>(null)
  const [taskQueryOpen, setTaskQueryOpen] = useState(false)

  const currentFilter = useMemo<BillingFilter>(
    () => ({
      from,
      to,
      groupId,
      userId
    }),
    [from, groupId, to, userId]
  )

  const usersByGroup = useMemo(() => {
    const map = new Map<string, BillingUserSummaryItem[]>()
    for (const user of overview?.users ?? []) {
      const key = user.groupId ?? "__ungrouped__"
      const current = map.get(key) ?? []
      current.push(user)
      map.set(key, current)
    }
    return map
  }, [overview?.users])

  const availableUsers = useMemo(() => {
    const options = (overview?.availableUsers ?? []).filter((item) => {
      if (!groupId) return true
      if (groupId === "__ungrouped__") return !item.groupId
      return item.groupId === groupId
    })
    return options.sort((a, b) => a.name.localeCompare(b.name, "zh-CN"))
  }, [groupId, overview?.availableUsers])

  const currentDateRange = useMemo(() => formatBillingDateRange(from, to), [from, to])

  async function loadOverview(filter: BillingFilter) {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/billing/overview?${buildBillingSearchParams(filter)}`)
      const json = await readApiJson<OverviewResponse>(res, "加载账单总览失败")
      if (!json.ok) throw new Error(json.error.message)
      setOverview(json.data)
      setCollapsedGroups((prev) => {
        const next: Record<string, boolean> = {}
        for (const item of json.data.groups) next[item.id] = prev[item.id] ?? true
        return next
      })
    } catch (e: any) {
      setError(e?.message ?? "加载账单总览失败")
    } finally {
      setLoading(false)
    }
  }

  async function exportBilling() {
    setExporting(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/billing/export?${buildBillingSearchParams(currentFilter)}`)
      if (!res.ok) {
        const raw = await res.text()
        let message = raw.trim() || "导出账单失败"
        try {
          const json = JSON.parse(raw) as { error?: { message?: string } }
          message = json.error?.message ?? message
        } catch {}
        throw new Error(message)
      }
      await downloadFileResponse(res, "billing-export.csv")
    } catch (e: any) {
      setError(e?.message ?? "导出账单失败")
    } finally {
      setExporting(false)
    }
  }

  function handleResetFilters() {
    const resetFilter: BillingFilter = {
      from: defaultDateRange.from ?? "",
      to: defaultDateRange.to ?? "",
      groupId: "",
      userId: ""
    }
    setFrom(resetFilter.from ?? "")
    setTo(resetFilter.to ?? "")
    setGroupId("")
    setUserId("")
    void loadOverview(resetFilter)
  }

  function toggleGroup(groupId: string) {
    setCollapsedGroups((prev) => ({ ...prev, [groupId]: !prev[groupId] }))
  }

  useEffect(() => {
    void loadOverview({
      from: defaultDateRange.from ?? "",
      to: defaultDateRange.to ?? "",
      groupId: "",
      userId: ""
    })
  }, [defaultDateRange.from, defaultDateRange.to])

  useEffect(() => {
    if (!userId) return
    if (availableUsers.some((item) => item.id === userId)) return
    setUserId("")
  }, [availableUsers, userId])

  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <div>
          <div className={styles.topTitle}>账单统计</div>
          <div className={styles.topMeta}>{roleKey === "super_admin" ? "查看全部组与成员的正式账单" : "查看当前组与组内成员的正式账单"}</div>
        </div>
        <div className={styles.topBarActions}>
          <button className={styles.btnSecondary} onClick={() => void exportBilling()} disabled={exporting || loading}>
            {exporting ? "导出中..." : "导出账单"}
          </button>
          <button className={styles.btn} onClick={() => setTaskQueryOpen(true)}>
            查询任务
          </button>
        </div>
      </div>

      <section className={styles.filters}>
        <input type="date" className={styles.input} value={from} onChange={(e) => setFrom(e.target.value)} />
        <input type="date" className={styles.input} value={to} onChange={(e) => setTo(e.target.value)} />
        <select className={styles.input} value={groupId} onChange={(e) => setGroupId(e.target.value)}>
          <option value="">全部组</option>
          {overview?.availableGroups.map((group) => (
            <option key={group.id} value={group.id}>
              {group.name}
            </option>
          ))}
        </select>
        <BillingUserSelect value={userId} options={availableUsers} onChange={setUserId} />
        <button className={styles.btn} onClick={() => void loadOverview(currentFilter)} disabled={loading}>
          查询
        </button>
        <button className={styles.btnSecondary} onClick={handleResetFilters} disabled={loading}>
          重置条件
        </button>
      </section>

      {error ? <div className={styles.error}>{error}</div> : null}

      <section className={styles.summaryGrid}>
        <div className={styles.summaryCard}><div className={styles.summaryLabel}>总花费</div><div className={styles.summaryValue}>{overview?.totals.totalCost ?? "0.0000"}</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryLabel}>完成任务数</div><div className={styles.summaryValue}>{overview?.totals.completedTaskCount ?? 0}</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryLabel}>总 Token（单位百万）</div><div className={styles.summaryValue}>{formatTokenMillions(overview?.totals.totalTokens ?? 0)}</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryLabel}>覆盖范围</div><div className={styles.summaryValue}>{overview ? `${overview.totals.groupCount} 组 / ${overview.totals.userCount} 人` : "-"}</div></div>
      </section>

      <section className={styles.tableContainer}>
        <div className={styles.thead}>
          <div>组 / 成员</div>
          <div>日期范围</div>
          <div>完成任务数</div>
          <div>总 Token（单位百万）</div>
          <div>总花费</div>
          <div>操作</div>
        </div>
        <div className={styles.tbody}>
          {loading ? <div className={styles.empty}>加载中...</div> : null}
          {!loading && (overview?.groups.length ?? 0) === 0 ? <div className={styles.empty}>暂无账单记录</div> : null}
          {overview?.groups.map((group) => {
            const collapsed = collapsedGroups[group.id] ?? true
            const members = usersByGroup.get(group.id) ?? []
            return (
              <div key={group.id} className={styles.groupSection}>
                <div className={styles.groupHeader} onClick={() => toggleGroup(group.id)} role="button" tabIndex={0}>
                  <div className={styles.groupHeaderLeft}>
                    <span className={styles.groupChevron}>{collapsed ? "▸" : "▾"}</span>
                    <span className={styles.groupName}>{group.name}</span>
                    <span className={styles.groupMeta}>{group.memberCount} 人</span>
                  </div>
                  <div>{currentDateRange}</div>
                  <div>{group.completedTaskCount}</div>
                  <div>{formatTokenMillions(group.totalTokens)}</div>
                  <div>{group.totalCost}</div>
                  <div className={styles.actions} onClick={(e) => e.stopPropagation()}>
                    <button className={styles.btn} onClick={() => setDetailTarget({ scopeType: "group", scopeId: group.id, scopeName: group.name })}>
                      查看详情
                    </button>
                  </div>
                </div>
                {!collapsed ? (
                  <div className={styles.groupBody}>
                    {members.length === 0 ? <div className={styles.empty}>当前组暂无成员账单</div> : null}
                    {members.map((user) => (
                      <div key={user.id} className={styles.userRow}>
                        <div className={styles.userName}>{user.name}</div>
                        <div>{currentDateRange}</div>
                        <div>{user.completedTaskCount}</div>
                        <div>{formatTokenMillions(user.totalTokens)}</div>
                        <div>{user.totalCost}</div>
                        <div className={styles.actions}>
                          <button className={styles.btn} onClick={() => setDetailTarget({ scopeType: "user", scopeId: user.id, scopeName: user.name })}>
                            查看详情
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            )
          })}
        </div>
      </section>

      {detailTarget ? (
        <BillingDetailsModal
          scopeType={detailTarget.scopeType}
          scopeId={detailTarget.scopeId}
          scopeName={detailTarget.scopeName}
          initialFilter={currentFilter}
          onClose={() => setDetailTarget(null)}
        />
      ) : null}

      {taskQueryOpen ? <BillingTaskQueryModal initialFilter={{ from, to }} onClose={() => setTaskQueryOpen(false)} /> : null}
    </div>
  )
}
