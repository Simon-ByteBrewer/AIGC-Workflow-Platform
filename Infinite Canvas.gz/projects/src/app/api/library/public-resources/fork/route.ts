import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { generatedImages, publicResources, sharedResources, stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const inputSchema = z.object({
  scope: z.enum(["library", "shared", "generated"]),
  id: z.string().trim().min(1).max(200)
})

function mapGeneratedCategoryToPublicType(category: string): "character" | "background" | "props" {
  if (category === "role") return "character"
  if (category === "item") return "props"
  return "background"
}

/**
 * Fork 资源：创建一条新的 public_resources 根资源（originId=null），用于画布节点隔离版本链。
 * - scope=library：从 public_resources 复制
 * - scope=shared：从 shared_resources 复制
 * - scope=generated：从 generated_images 复制（通过 stories.user_id 鉴权）
 *
 * 该接口不会做 storageKey 去重；每次都会创建新根资源。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "入参格式不正确"), { status: 400 })

  await ensurePublicSchema()

  const db = await getDb({ publicResources, sharedResources, generatedImages, stories })

  const makeStable = (id: string) => ({
    previewUrl: `/api/library/public-resources/file/${id}?kind=preview`,
    originalUrl: `/api/library/public-resources/file/${id}?kind=original`
  })

  if (parsed.data.scope === "library") {
    const rows = await db
      .select({
        id: publicResources.id,
        userId: publicResources.userId,
        type: publicResources.type,
        source: publicResources.source,
        name: publicResources.name,
        description: publicResources.description,
        previewUrl: publicResources.previewUrl,
        previewStorageKey: publicResources.previewStorageKey,
        originalUrl: publicResources.originalUrl,
        originalStorageKey: publicResources.originalStorageKey,
        tags: publicResources.tags,
        applicableScenes: publicResources.applicableScenes
      })
      .from(publicResources)
      .where(eq(publicResources.id, parsed.data.id))
      .limit(1)

    const src = rows[0] ?? null
    if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
    if (src.userId !== userId) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

    const [created] = await db
      .insert(publicResources)
      .values({
        userId,
        originId: null,
        type: src.type,
        source: src.source,
        name: src.name,
        description: src.description ?? "",
        previewUrl: src.previewUrl,
        previewStorageKey: src.previewStorageKey,
        originalUrl: src.originalUrl,
        originalStorageKey: src.originalStorageKey,
        durationMs: null,
        tags: (src.tags as any) ?? [],
        applicableScenes: (src.applicableScenes as any) ?? []
      } as any)
      .returning({ id: publicResources.id })

    const id = created?.id ?? null
    if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
    await db.update(publicResources).set(makeStable(id)).where(eq(publicResources.id, id))
    return NextResponse.json(makeApiOk(traceId, { id, url: makeStable(id).originalUrl }), { status: 200 })
  }

  if (parsed.data.scope === "shared") {
    const rows = await db
      .select({
        id: sharedResources.id,
        type: sharedResources.type,
        source: sharedResources.source,
        name: sharedResources.name,
        description: sharedResources.description,
        previewUrl: sharedResources.previewUrl,
        previewStorageKey: sharedResources.previewStorageKey,
        originalUrl: sharedResources.originalUrl,
        originalStorageKey: sharedResources.originalStorageKey,
        tags: sharedResources.tags,
        applicableScenes: sharedResources.applicableScenes
      })
      .from(sharedResources)
      .where(eq(sharedResources.id, parsed.data.id))
      .limit(1)

    const src = rows[0] ?? null
    if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

    const [created] = await db
      .insert(publicResources)
      .values({
        userId,
        originId: null,
        type: src.type,
        source: src.source,
        name: src.name,
        description: src.description ?? "",
        previewUrl: src.previewUrl,
        previewStorageKey: src.previewStorageKey,
        originalUrl: src.originalUrl ?? src.previewUrl,
        originalStorageKey: src.originalStorageKey ?? src.previewStorageKey,
        durationMs: null,
        tags: (src.tags as any) ?? [],
        applicableScenes: (src.applicableScenes as any) ?? []
      } as any)
      .returning({ id: publicResources.id })

    const id = created?.id ?? null
    if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
    await db.update(publicResources).set(makeStable(id)).where(eq(publicResources.id, id))
    return NextResponse.json(makeApiOk(traceId, { id, url: makeStable(id).originalUrl }), { status: 200 })
  }

  const rows = await db
    .select({
      id: generatedImages.id,
      storyId: generatedImages.storyId,
      name: generatedImages.name,
      description: generatedImages.description,
      storageKey: generatedImages.storageKey,
      thumbnailStorageKey: generatedImages.thumbnailStorageKey,
      category: generatedImages.category
    })
    .from(generatedImages)
    .innerJoin(stories, eq(generatedImages.storyId, stories.id))
    .where(and(eq(generatedImages.id, parsed.data.id), eq(stories.userId, userId)))
    .limit(1)

  const img = rows[0] ?? null
  if (!img) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到图片或无权限"), { status: 404 })

  const type = mapGeneratedCategoryToPublicType(img.category)
  const previewKey = img.thumbnailStorageKey ?? img.storageKey
  const originalKey = img.storageKey

  const [created] = await db
    .insert(publicResources)
    .values({
      userId,
      originId: null,
      type,
      source: "ai",
      name: img.name,
      description: img.description ?? "",
      previewUrl: makeStable("tmp").previewUrl,
      previewStorageKey: previewKey,
      originalUrl: makeStable("tmp").originalUrl,
      originalStorageKey: originalKey,
      durationMs: null,
      tags: [],
      applicableScenes: []
    } as any)
    .returning({ id: publicResources.id })

  const id = created?.id ?? null
  if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
  await db.update(publicResources).set(makeStable(id)).where(eq(publicResources.id, id))
  return NextResponse.json(makeApiOk(traceId, { id, url: makeStable(id).originalUrl }), { status: 200 })
}

