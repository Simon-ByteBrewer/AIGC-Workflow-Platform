import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { publicResources, sharedResources } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const inputSchema = z.object({
  sharedResourceId: z.string().trim().min(1).max(200)
})

/**
 * 将 shared_resources 的一条资源转换为当前用户的 public_resources 条目（不下载、不转存）。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "入参格式不正确"), { status: 400 })

  await ensurePublicSchema()

  const db = await getDb({ publicResources, sharedResources })
  const rows = await db
    .select({
      id: sharedResources.id,
      type: sharedResources.type,
      source: sharedResources.source,
      name: sharedResources.name,
      description: sharedResources.description,
      previewUrl: sharedResources.previewUrl,
      previewStorageKey: sharedResources.previewStorageKey,
      originalUrl: sharedResources.originalUrl,
      originalStorageKey: sharedResources.originalStorageKey
    })
    .from(sharedResources)
    .where(and(eq(sharedResources.id, parsed.data.sharedResourceId)))
    .limit(1)

  const src = rows[0]
  if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

  const originalKey = src.originalStorageKey ?? src.previewStorageKey ?? null
  if (!originalKey) return NextResponse.json(makeApiErr(traceId, "INVALID_RESOURCE", "资源缺少存储信息"), { status: 400 })

  const existed = await db
    .select({ id: publicResources.id })
    .from(publicResources)
    .where(and(eq(publicResources.userId, userId), eq(publicResources.originalStorageKey, originalKey), eq(publicResources.type, src.type)))
    .limit(1)

  const existedId = existed[0]?.id ?? null
  if (existedId) {
    return NextResponse.json(makeApiOk(traceId, { ok: true, id: existedId, skipped: true, url: `/api/library/public-resources/file/${existedId}?kind=original` }))
  }

  const [created] = await db
    .insert(publicResources)
    .values({
      userId,
      type: src.type,
      source: src.source,
      name: src.name,
      description: src.description ?? "",
      previewUrl: src.previewUrl,
      previewStorageKey: src.previewStorageKey,
      originalUrl: src.originalUrl ?? src.previewUrl,
      originalStorageKey: src.originalStorageKey ?? src.previewStorageKey,
      durationMs: null,
      tags: [],
      applicableScenes: []
    } as any)
    .returning({ id: publicResources.id })

  const id = created?.id ?? null
  if (id) {
    await db
      .update(publicResources)
      .set({
        previewUrl: `/api/library/public-resources/file/${id}?kind=preview`,
        originalUrl: `/api/library/public-resources/file/${id}?kind=original`
      })
      .where(eq(publicResources.id, id))
  }

  return NextResponse.json(makeApiOk(traceId, { ok: true, id, skipped: false, url: id ? `/api/library/public-resources/file/${id}?kind=original` : null }))
}

