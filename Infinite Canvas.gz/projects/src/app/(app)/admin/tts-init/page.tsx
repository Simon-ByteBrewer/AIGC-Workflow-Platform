import { Suspense, type ReactElement } from "react"
import { TtsInitSamplesPage } from "@/features/admin/TtsInitSamplesPage"

export default function AdminTtsInitRoute(): ReactElement {
  return (
    <Suspense fallback={null}>
      <TtsInitSamplesPage />
    </Suspense>
  )
}

