"use client"

import { useMemo, useState, useSyncExternalStore, type ReactElement } from "react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/shared/ui/shadcn/dropdown-menu"
import type { PromptManagementGroup, PromptManagementUser, PromptType } from "./types"
import styles from "./PromptManagementPage.module.css"

/**
 * 提示词编辑弹窗。
 * 负责维护提示词基础信息，以及组内成员的勾选授权。
 */
type PromptDraft = {
  name: string
  content: string
  promptType: PromptType
  assignmentMode: "group" | "user"
  ownerGroupId: string
  groupIds: string[]
  userIds: string[]
}

type Props = {
  open: boolean
  title: string
  saving: boolean
  isEdit: boolean
  actorRoleKey: string
  draft: PromptDraft
  groups: PromptManagementGroup[]
  users: PromptManagementUser[]
  onClose: () => void
  onSave: () => void
  onDraftChange: (patch: Partial<PromptDraft>) => void
  onGroupChange: (groupId: string) => void
  onGroupIdsChange: (groupIds: string[]) => void
}

function buildGroupLabel(group: PromptManagementGroup): string {
  return group.code ? `${group.name} (${group.code})` : group.name
}

function toggleUserId(current: string[], userId: string, checked: boolean): string[] {
  if (checked) return Array.from(new Set([...current, userId]))
  return current.filter((item) => item !== userId)
}

function toggleGroupId(current: string[], groupId: string, checked: boolean): string[] {
  if (checked) return Array.from(new Set([...current, groupId]))
  return current.filter((item) => item !== groupId)
}

type PromptUiPreset = {
  typeLabel: string
  suggestion: string
  systemDefault: string
}

const PROMPT_UI_PRESETS: Record<PromptType, PromptUiPreset> = {
  storyboard: {
    typeLabel: "拆分镜提示词",
    suggestion:
      "占位建议：这里后续展示拆分镜提示词的编写建议，例如结构顺序、时间拆分要求、镜头颗粒度限制等说明内容。",
    systemDefault:
      "系统默认提示词占位内容：拆分镜提示词默认模板。\n\n这里后续会替换为正式的系统默认提示词内容，当前仅用于前端布局和交互占位。"
  },
  video: {
    typeLabel: "视频提示词",
    suggestion:
      "占位建议：这里后续展示视频提示词的编写建议，例如镜头运动、主体动作、风格锁定、负向约束等说明内容。",
    systemDefault:
      "系统默认提示词占位内容：视频提示词默认模板。\n\n这里后续会替换为正式的系统默认提示词内容，当前仅用于前端布局和交互占位。"
  },
  storyboard_panel: {
    typeLabel: "分镜板提示词",
    suggestion:
      "占位建议：这里后续展示分镜板提示词的编写建议，例如画面构图、角色站位、关键动作描述、格内信息密度等说明内容。",
    systemDefault:
      "系统默认提示词占位内容：分镜板提示词默认模板。\n\n这里后续会替换为正式的系统默认提示词内容，当前仅用于前端布局和交互占位。"
  }
}

export function PromptEditorModal(props: Props): ReactElement | null {
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  )
  const [userPickerOpen, setUserPickerOpen] = useState(false)
  const [groupPickerOpen, setGroupPickerOpen] = useState(false)
  const [userQuery, setUserQuery] = useState("")
  const [groupQuery, setGroupQuery] = useState("")
  const [showSelectedOnly, setShowSelectedOnly] = useState(false)
  const [showSelectedGroupsOnly, setShowSelectedGroupsOnly] = useState(false)
  const [suggestionOpen, setSuggestionOpen] = useState(false)
  const [copyFeedback, setCopyFeedback] = useState<"idle" | "success" | "failed">("idle")
  const editingGroups = props.actorRoleKey === "admin" && props.draft.assignmentMode === "group"
  const editingUsers = props.actorRoleKey === "group_admin"
  const selectedCount = props.draft.userIds.length
  const allUserIds = props.users.map((item) => item.id)
  const allSelected = allUserIds.length > 0 && allUserIds.every((userId) => props.draft.userIds.includes(userId))
  const selectedGroupCount = props.draft.groupIds.length
  const allGroupIds = props.groups.map((item) => item.id)
  const allGroupsSelected = allGroupIds.length > 0 && allGroupIds.every((groupId) => props.draft.groupIds.includes(groupId))
  const currentGroup = props.groups.find((item) => item.id === props.draft.ownerGroupId) ?? null
  const filteredUsers = useMemo(() => {
    const keyword = userQuery.trim().toLowerCase()
    const baseUsers = showSelectedOnly ? props.users.filter((user) => props.draft.userIds.includes(user.id)) : props.users
    if (!keyword) return baseUsers
    return baseUsers.filter((user) => user.account.toLowerCase().includes(keyword) || user.id.toLowerCase().includes(keyword))
  }, [props.draft.userIds, props.users, showSelectedOnly, userQuery])
  const filteredGroups = useMemo(() => {
    const keyword = groupQuery.trim().toLowerCase()
    const baseGroups = showSelectedGroupsOnly ? props.groups.filter((group) => props.draft.groupIds.includes(group.id)) : props.groups
    if (!keyword) return baseGroups
    return baseGroups.filter((group) => buildGroupLabel(group).toLowerCase().includes(keyword) || group.id.toLowerCase().includes(keyword))
  }, [groupQuery, props.draft.groupIds, props.groups, showSelectedGroupsOnly])
  const selectedAccounts = useMemo(
    () => props.users.filter((user) => props.draft.userIds.includes(user.id)).map((user) => user.account),
    [props.draft.userIds, props.users]
  )
  const selectedGroupLabels = useMemo(
    () => props.groups.filter((group) => props.draft.groupIds.includes(group.id)).map((group) => buildGroupLabel(group)),
    [props.draft.groupIds, props.groups]
  )
  const currentPreset = PROMPT_UI_PRESETS[props.draft.promptType]

  const triggerText =
    allUserIds.length === 0 ? "当前组暂无可选成员" : allSelected ? `已全选 ${allUserIds.length} 人` : `已选 ${selectedCount} / ${allUserIds.length} 人`

  const pickerTrigger = (
    <button type="button" className={styles.memberPickerTrigger} disabled={props.saving || allUserIds.length === 0}>
      <span className={styles.memberPickerTriggerBody}>
        <span className={styles.memberPickerSummary}>{triggerText}</span>
        <span className={styles.memberPickerHint}>
          {selectedAccounts.length > 0 ? selectedAccounts.slice(0, 3).join("、") + (selectedAccounts.length > 3 ? ` 等 ${selectedAccounts.length} 人` : "") : "点击选择组内成员"}
        </span>
      </span>
      <span className={styles.memberPickerChevron}>{userPickerOpen ? "▲" : "▼"}</span>
    </button>
  )

  const groupTriggerText =
    allGroupIds.length === 0 ? "暂无可选分组" : allGroupsSelected ? `已全选 ${allGroupIds.length} 个分组` : `已选 ${selectedGroupCount} / ${allGroupIds.length} 个分组`

  const groupPickerTrigger = (
    <button type="button" className={styles.memberPickerTrigger} disabled={props.saving || allGroupIds.length === 0}>
      <span className={styles.memberPickerTriggerBody}>
        <span className={styles.memberPickerSummary}>{groupTriggerText}</span>
        <span className={styles.memberPickerHint}>
          {selectedGroupLabels.length > 0
            ? selectedGroupLabels.slice(0, 3).join("、") + (selectedGroupLabels.length > 3 ? ` 等 ${selectedGroupLabels.length} 组` : "")
            : "点击选择应用分组"}
        </span>
      </span>
      <span className={styles.memberPickerChevron}>{groupPickerOpen ? "▲" : "▼"}</span>
    </button>
  )

  if (!props.open) return null

  async function handleCopySystemDefault(): Promise<void> {
    try {
      await navigator.clipboard.writeText(currentPreset.systemDefault)
      setCopyFeedback("success")
    } catch {
      setCopyFeedback("failed")
    } finally {
      window.setTimeout(() => setCopyFeedback("idle"), 1600)
    }
  }

  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-label={props.title} onMouseDown={props.onClose}>
      <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>{props.title}</div>
          <button type="button" className={styles.modalClose} onClick={props.onClose} aria-label="关闭" disabled={props.saving}>
            ×
          </button>
        </div>

        <div className={styles.modalBody}>
          <label className={styles.field}>
            <div className={styles.label}>提示词名称</div>
            <input
              className={styles.input}
              value={props.draft.name}
              onChange={(e) => props.onDraftChange({ name: e.target.value })}
              placeholder="例如：国风古风"
              disabled={props.saving}
            />
          </label>

          <label className={styles.field}>
            <div className={styles.label}>提示词类型</div>
            <select
              className={styles.select}
              value={props.draft.promptType}
              onChange={(e) => props.onDraftChange({ promptType: e.target.value as PromptType })}
              disabled={props.saving}
            >
              <option value="storyboard">拆分镜提示词</option>
              <option value="video">视频提示词</option>
              <option value="storyboard_panel">分镜板提示词</option>
            </select>
          </label>

          {editingGroups ? (
            <div className={styles.field}>
              <div className={styles.inlineHeader}>
                <div className={styles.label}>应用分组范围</div>
              </div>
              <div className={styles.groupHint}>超管分配到组后，默认当前组全部启用账号都会拥有该提示词，新建账号也会自动继承。</div>
              {mounted ? (
                <DropdownMenu open={groupPickerOpen} onOpenChange={setGroupPickerOpen}>
                  <DropdownMenuTrigger asChild>{groupPickerTrigger}</DropdownMenuTrigger>
                  <DropdownMenuContent className={styles.memberPickerContent} align="start" side="bottom" sideOffset={6}>
                    <input
                      className={styles.memberPickerSearch}
                      value={groupQuery}
                      onChange={(e) => setGroupQuery(e.target.value)}
                      placeholder="搜索用户组"
                    />
                    <div className={styles.memberPickerActions}>
                      <button type="button" className={styles.topBtn} onClick={() => props.onGroupIdsChange(allGroupIds)} disabled={props.saving || allGroupIds.length === 0}>
                        全选
                      </button>
                      <button
                        type="button"
                        className={styles.topBtn}
                        onClick={() => props.onGroupIdsChange(allGroupIds.filter((groupId) => !props.draft.groupIds.includes(groupId)))}
                        disabled={props.saving || allGroupIds.length === 0}
                      >
                        反选
                      </button>
                      <button type="button" className={styles.topBtn} onClick={() => props.onGroupIdsChange([])} disabled={props.saving || selectedGroupCount === 0}>
                        全不选
                      </button>
                      <button
                        type="button"
                        className={styles.topBtn}
                        onClick={() => setShowSelectedGroupsOnly((current) => !current)}
                        disabled={props.saving || allGroupIds.length === 0}
                      >
                        {showSelectedGroupsOnly ? "显示全部" : "仅显示已选"}
                      </button>
                    </div>
                    <div className={styles.memberPickerList}>
                      {filteredGroups.length === 0 ? <div className={styles.muted}>没有匹配分组</div> : null}
                      {filteredGroups.map((group) => {
                        const checked = props.draft.groupIds.includes(group.id)
                        return (
                          <button
                            key={group.id}
                            type="button"
                            className={`${styles.memberPickerItem} ${checked ? styles.memberPickerItemChecked : ""}`}
                            aria-pressed={checked}
                            onClick={() => props.onGroupIdsChange(toggleGroupId(props.draft.groupIds, group.id, !checked))}
                            disabled={props.saving}
                          >
                            <span className={`${styles.memberPickerCheckbox} ${checked ? styles.memberPickerCheckboxChecked : ""}`} aria-hidden="true">
                              {checked ? "✓" : ""}
                            </span>
                            <span className={styles.memberPickerItemText}>
                              <span className={styles.memberPickerItemLabel}>{buildGroupLabel(group)}</span>
                            </span>
                          </button>
                        )
                      })}
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                groupPickerTrigger
              )}
            </div>
          ) : (
            <label className={styles.field}>
              <div className={styles.label}>{props.actorRoleKey === "group_admin" ? "当前用户组" : "所属用户组"}</div>
              <div className={styles.readonlyValue}>{currentGroup ? buildGroupLabel(currentGroup) : "-"}</div>
            </label>
          )}

          <div className={styles.field}>
            <div className={styles.inlineHeader}>
              <div className={styles.label}>提示词内容</div>
              <div
                className={styles.suggestionWrap}
                onMouseEnter={() => setSuggestionOpen(true)}
                onMouseLeave={() => setSuggestionOpen(false)}
              >
                <button
                  type="button"
                  className={styles.topBtn}
                  aria-label={`查看${currentPreset.typeLabel}建议`}
                  onFocus={() => setSuggestionOpen(true)}
                  onBlur={() => setSuggestionOpen(false)}
                >
                  建议
                </button>
                {suggestionOpen ? (
                  <div className={styles.suggestionPopover} role="tooltip">
                    <div className={styles.suggestionTitle}>{currentPreset.typeLabel}建议</div>
                    <div className={styles.suggestionText}>{currentPreset.suggestion}</div>
                  </div>
                ) : null}
              </div>
            </div>
            <div className={styles.promptEditorGrid}>
              <div className={styles.promptPane}>
                <div className={styles.inlineHeader}>
                  <div className={styles.label}>系统默认提示词</div>
                  <button type="button" className={styles.topBtn} onClick={() => void handleCopySystemDefault()}>
                    {copyFeedback === "success" ? "已复制" : copyFeedback === "failed" ? "复制失败" : "复制"}
                  </button>
                </div>
                <div className={styles.groupHint}>系统默认提示词仅供查看与复制，当前不可编辑。</div>
                <textarea
                  className={`${styles.input} ${styles.textarea} ${styles.readonlyTextarea}`}
                  value={currentPreset.systemDefault}
                  readOnly
                  aria-label="系统默认提示词"
                />
              </div>
              <label className={styles.promptPane}>
                <div className={styles.label}>自定义提示词</div>
                <div className={styles.groupHint}>可在系统默认提示词基础上按当前类型补充或覆盖自定义内容。</div>
                <textarea
                  className={`${styles.input} ${styles.textarea}`}
                  value={props.draft.content}
                  onChange={(e) => props.onDraftChange({ content: e.target.value })}
                  placeholder={`输入${currentPreset.typeLabel}的自定义提示词内容`}
                  maxLength={50000}
                  disabled={props.saving}
                />
              </label>
            </div>
          </div>

          {editingUsers ? (
            <div className={styles.field}>
              <div className={styles.inlineHeader}>
                <div className={styles.label}>组内使用人</div>
              </div>
              <div className={styles.groupHint}>默认勾选当前组内全部启用账号，可按需取消，也支持反选。当前已选 {selectedCount} 人。</div>
              {mounted ? (
                <DropdownMenu open={userPickerOpen} onOpenChange={setUserPickerOpen}>
                  <DropdownMenuTrigger asChild>{pickerTrigger}</DropdownMenuTrigger>
                  <DropdownMenuContent className={styles.memberPickerContent} align="start" side="bottom" sideOffset={6}>
                    <input
                      className={styles.memberPickerSearch}
                      value={userQuery}
                      onChange={(e) => setUserQuery(e.target.value)}
                      placeholder="搜索组内成员"
                    />
                    <div className={styles.memberPickerActions}>
                      <button type="button" className={styles.topBtn} onClick={() => props.onDraftChange({ userIds: allUserIds })} disabled={props.saving || allUserIds.length === 0}>
                        全选
                      </button>
                      <button
                        type="button"
                        className={styles.topBtn}
                        onClick={() =>
                          props.onDraftChange({
                            userIds: allUserIds.filter((userId) => !props.draft.userIds.includes(userId))
                          })
                        }
                        disabled={props.saving || allUserIds.length === 0}
                      >
                        反选
                      </button>
                      <button type="button" className={styles.topBtn} onClick={() => props.onDraftChange({ userIds: [] })} disabled={props.saving || selectedCount === 0}>
                        全不选
                      </button>
                      <button
                        type="button"
                        className={styles.topBtn}
                        onClick={() => setShowSelectedOnly((current) => !current)}
                        disabled={props.saving || allUserIds.length === 0}
                      >
                        {showSelectedOnly ? "显示全部" : "仅显示已选"}
                      </button>
                    </div>
                    <div className={styles.memberPickerList}>
                      {filteredUsers.length === 0 ? <div className={styles.muted}>没有匹配成员</div> : null}
                      {filteredUsers.map((user) => {
                        const checked = props.draft.userIds.includes(user.id)
                        return (
                          <button
                            key={user.id}
                            type="button"
                            className={`${styles.memberPickerItem} ${checked ? styles.memberPickerItemChecked : ""}`}
                            aria-pressed={checked}
                            onClick={() =>
                              props.onDraftChange({
                                userIds: toggleUserId(props.draft.userIds, user.id, !checked)
                              })
                            }
                            disabled={props.saving}
                          >
                            <span className={`${styles.memberPickerCheckbox} ${checked ? styles.memberPickerCheckboxChecked : ""}`} aria-hidden="true">
                              {checked ? "✓" : ""}
                            </span>
                            <span className={styles.memberPickerItemText}>
                              <span className={styles.memberPickerItemLabel}>{user.account}</span>
                            </span>
                          </button>
                        )
                      })}
                    </div>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                pickerTrigger
              )}
            </div>
          ) : null}

          <div className={styles.modalActions}>
            <button type="button" className={styles.topBtn} onClick={props.onClose} disabled={props.saving}>
              取消
            </button>
            <button
              type="button"
              className={styles.topBtnPrimary}
              onClick={props.onSave}
              disabled={
                props.saving ||
                !props.draft.name.trim() ||
                !props.draft.content.trim() ||
                (editingGroups ? props.draft.groupIds.length === 0 : !props.draft.ownerGroupId.trim())
              }
            >
              {props.saving ? "保存中…" : "保存并关闭"}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
