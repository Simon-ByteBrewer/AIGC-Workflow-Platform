import { NextResponse, type NextRequest } from "next/server"
import { getDb } from "coze-coding-dev-sdk"
import { inArray, eq } from "drizzle-orm"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { quickGenerateMaterials } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { queryAssetReviewStatus } from "@/server/domains/assets/assetReviewService"

export const runtime = "nodejs"

const requestSchema = z.object({
  materialIds: z.array(z.string().trim().min(1)).min(1)
})

export async function POST(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  try {
    const session = await getSessionFromRequest(req)
    if (!session?.userId) {
      return NextResponse.json(makeApiErr(traceId, "UNAUTHORIZED", "未登录"), { status: 401 })
    }

    const body = await req.json().catch(() => ({}))
    const parsed = requestSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "参数错误"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ quickGenerateMaterials })
    const rows = await db
      .select({
        id: quickGenerateMaterials.id,
        assetId: quickGenerateMaterials.assetId
      })
      .from(quickGenerateMaterials)
      .where(inArray(quickGenerateMaterials.id, parsed.data.materialIds))

    const out: Array<{
      id: string
      assetId: string | null
      assetStatus: string
      assetErrorMessage: string | null
    }> = []

    for (const row of rows) {
      const assetId = (row.assetId ?? "").trim()
      if (!assetId) continue
      const status = await queryAssetReviewStatus({ traceId, userId: session.userId, assetId })
      await db
        .update(quickGenerateMaterials)
        .set({
          assetStatus: status.status,
          assetErrorMessage: status.errorMessage,
          updatedAt: new Date()
        })
        .where(eq(quickGenerateMaterials.id, row.id))
      out.push({
        id: row.id,
        assetId,
        assetStatus: status.status,
        assetErrorMessage: status.errorMessage
      })
    }

    return NextResponse.json(makeApiOk(traceId, { items: out }))
  } catch (error) {
    const message = error instanceof Error ? error.message : "查询审核状态失败"
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", message), { status: 500 })
  }
}
