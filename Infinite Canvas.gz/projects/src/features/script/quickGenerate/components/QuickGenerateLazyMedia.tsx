"use client"

import { memo, useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react"

/**
 * quick-generate 媒体懒加载与稳定 URL 缓存。
 *
 * 背景：
 * 1. 轮询完成后页面会触发 refresh，服务端会重新生成新的签名 URL；
 * 2. 同一个 storageKey 如果每次都换 src，浏览器会把它当成新媒体重新加载；
 * 3. 这里按稳定 cacheKey 复用首次可用 URL，并结合 IntersectionObserver 做按需挂载。
 */
const quickGenerateMediaSrcCache = new Map<string, string>()

function normalizeString(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

function buildMediaCacheKey(cacheKey: string | undefined, src: string): string {
  const normalizedCacheKey = normalizeString(cacheKey)
  if (normalizedCacheKey) return normalizedCacheKey
  return normalizeString(src)
}

export function getQuickGenerateStableMediaSrc(input: { cacheKey?: string; src: string }): string {
  const normalizedSrc = normalizeString(input.src)
  if (!normalizedSrc) return ""

  const key = buildMediaCacheKey(input.cacheKey, normalizedSrc)
  if (!key) return normalizedSrc

  const cached = quickGenerateMediaSrcCache.get(key)
  if (cached) return cached
  quickGenerateMediaSrcCache.set(key, normalizedSrc)
  return normalizedSrc
}

function useLazyMediaSource(input: { cacheKey?: string; src: string; rootMargin?: string }) {
  const normalizedSrc = normalizeString(input.src)
  const stableKey = useMemo(
    () => buildMediaCacheKey(input.cacheKey, normalizedSrc),
    [input.cacheKey, normalizedSrc]
  )
  const hostRef = useRef<HTMLDivElement | null>(null)
  const supportsIntersectionObserver =
    typeof window !== "undefined" && typeof window.IntersectionObserver !== "undefined"
  const hasCachedSource = Boolean(stableKey && quickGenerateMediaSrcCache.has(stableKey))
  // 为了避免 SSR 与客户端首帧因为浏览器能力或内存缓存差异而 hydration mismatch，
  // 首次 render 一律只输出占位，等挂载后再决定是否立即加载媒体。
  const [hasIntersected, setHasIntersected] = useState(false)
  const [fallbackSrc, setFallbackSrc] = useState("")
  const shouldLoad = Boolean(normalizedSrc) && (hasCachedSource || !supportsIntersectionObserver || hasIntersected)

  useEffect(() => {
    if (!normalizedSrc || shouldLoad) return

    const target = hostRef.current
    if (!target) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (!entries[0]?.isIntersecting) return
        setHasIntersected(true)
        observer.disconnect()
      },
      { rootMargin: input.rootMargin ?? "240px 0px" }
    )
    observer.observe(target)
    return () => observer.disconnect()
  }, [input.rootMargin, normalizedSrc, shouldLoad])

  useEffect(() => {
    if (!shouldLoad || !normalizedSrc || !stableKey) return
    if (!quickGenerateMediaSrcCache.has(stableKey)) {
      quickGenerateMediaSrcCache.set(stableKey, normalizedSrc)
    }
  }, [normalizedSrc, shouldLoad, stableKey])

  const resolvedSrc = shouldLoad
    ? fallbackSrc || getQuickGenerateStableMediaSrc({ cacheKey: stableKey, src: normalizedSrc })
    : ""

  const handleError = useCallback(() => {
    if (!normalizedSrc || !stableKey) return
    const latestSrc = normalizeString(normalizedSrc)
    if (!latestSrc) return
    const cached = quickGenerateMediaSrcCache.get(stableKey)
    if (cached === latestSrc && fallbackSrc === latestSrc) return
    quickGenerateMediaSrcCache.set(stableKey, latestSrc)
    setFallbackSrc(latestSrc)
  }, [fallbackSrc, normalizedSrc, stableKey])

  return {
    hostRef,
    resolvedSrc,
    shouldLoad,
    handleError
  }
}

type QuickGenerateLazyVideoProps = {
  src: string
  cacheKey?: string
  className?: string
  placeholderClassName?: string
  controls?: boolean
  autoPlay?: boolean
  playsInline?: boolean
  preload?: "none" | "metadata" | "auto"
  muted?: boolean
  loop?: boolean
}

function QuickGenerateLazyVideoInner(props: QuickGenerateLazyVideoProps): ReactElement {
  const { hostRef, resolvedSrc, shouldLoad, handleError } = useLazyMediaSource({
    cacheKey: props.cacheKey,
    src: props.src,
    rootMargin: "280px 0px"
  })

  return (
    <div ref={hostRef} className={props.placeholderClassName}>
      {shouldLoad && resolvedSrc ? (
        <video
          className={props.className}
          src={resolvedSrc}
          controls={props.controls}
          autoPlay={props.autoPlay}
          playsInline={props.playsInline}
          preload={props.preload ?? "metadata"}
          muted={props.muted}
          loop={props.loop}
          onError={handleError}
        />
      ) : null}
    </div>
  )
}

type QuickGenerateLazyImageProps = {
  src: string
  cacheKey?: string
  alt: string
  className?: string
  placeholderClassName?: string
}

function QuickGenerateLazyImageInner(props: QuickGenerateLazyImageProps): ReactElement {
  const { hostRef, resolvedSrc, shouldLoad, handleError } = useLazyMediaSource({
    cacheKey: props.cacheKey,
    src: props.src
  })

  return (
    <div ref={hostRef} className={props.placeholderClassName}>
      {shouldLoad && resolvedSrc ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={resolvedSrc}
          alt={props.alt}
          className={props.className}
          loading="lazy"
          decoding="async"
          onError={handleError}
        />
      ) : null}
    </div>
  )
}

function QuickGenerateLazyVideoWithReset(props: QuickGenerateLazyVideoProps): ReactElement {
  const resetKey = buildMediaCacheKey(props.cacheKey, props.src)
  return <QuickGenerateLazyVideoInner key={resetKey} {...props} />
}

function QuickGenerateLazyImageWithReset(props: QuickGenerateLazyImageProps): ReactElement {
  const resetKey = buildMediaCacheKey(props.cacheKey, props.src)
  return <QuickGenerateLazyImageInner key={resetKey} {...props} />
}

export const QuickGenerateLazyVideo = memo(QuickGenerateLazyVideoWithReset)
export const QuickGenerateLazyImage = memo(QuickGenerateLazyImageWithReset)
