"use client"

import { useCallback, useEffect, useState } from "react"
import type { MouseEvent, ReactElement } from "react"
import { X } from "lucide-react"
import { useRouter } from "next/navigation"
import type { ApiErr, ApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import styles from "./ScriptCreationDialog.module.css"

type CanvasCreationDialogProps = {
  open: boolean
  onClose: () => void
}

export function CanvasCreationDialog({ open, onClose }: CanvasCreationDialogProps): ReactElement | null {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errorText, setErrorText] = useState<string | null>(null)

  useEffect(() => {
    if (!open) return
    setTitle("")
    setIsSubmitting(false)
    setErrorText(null)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    return () => {
      document.body.style.overflow = prevOverflow
    }
  }, [open])

  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent): void => {
      if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [open, onClose])

  const onBackdropClick = useCallback(
    (e: MouseEvent<HTMLDivElement>): void => {
      if (e.target === e.currentTarget) onClose()
    },
    [onClose]
  )

  const canConfirm = title.trim().length > 0

  const onConfirmClick = useCallback(async () => {
    if (!canConfirm) return
    if (isSubmitting) return

    const projectTitle = title.trim()
    setIsSubmitting(true)
    setErrorText(null)

    const start = performance.now()
    logger.info({
      event: "canvas_project_create_start",
      module: "canvas",
      traceId: "client",
      message: "开始创建无限画布项目"
    })

    try {
      const res = await fetch("/api/video/canvas/stories", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ title: projectTitle })
      })

      const durationMs = Math.round(performance.now() - start)
      const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
      if (!res.ok || !json || (json as ApiErr).ok === false) {
        const errJson = (json as ApiErr | null) ?? null
        logger.warn({
          event: "canvas_project_create_failed",
          module: "canvas",
          traceId: "client",
          message: "创建无限画布项目失败",
          status: res.status,
          durationMs,
          code: errJson?.error?.code
        })
        setErrorText(errJson?.error?.message ?? "创建失败，请稍后重试")
        return
      }

      const okJson = json as ApiOk<unknown>
      const data = okJson.data as unknown
      const storyId =
        typeof data === "object" && data !== null && "storyId" in data && typeof (data as { storyId?: unknown }).storyId === "string"
          ? String((data as { storyId: string }).storyId)
          : ""
      const outlineId =
        typeof data === "object" && data !== null && "outlineId" in data && typeof (data as { outlineId?: unknown }).outlineId === "string"
          ? String((data as { outlineId: string }).outlineId)
          : ""

      if (!storyId || !outlineId) {
        setErrorText("创建成功但未返回必要信息，请稍后重试")
        return
      }

      logger.info({
        event: "canvas_project_create_success",
        module: "canvas",
        traceId: "client",
        message: "创建无限画布项目成功",
        durationMs
      })

      router.push(`/video/canvas?storyId=${encodeURIComponent(storyId)}&outlineId=${encodeURIComponent(outlineId)}`)
      onClose()
    } catch (err) {
      const durationMs = Math.round(performance.now() - start)
      const anyErr = err as { name?: string; message?: string }
      logger.error({
        event: "canvas_project_create_error",
        module: "canvas",
        traceId: "client",
        message: "创建无限画布项目异常",
        durationMs,
        errorName: anyErr?.name,
        errorMessage: anyErr?.message
      })
      setErrorText(anyErr?.message?.trim() ? String(anyErr.message) : "网络异常，请检查网络或稍后重试")
    } finally {
      setIsSubmitting(false)
    }
  }, [canConfirm, isSubmitting, onClose, router, title])

  if (!open) return null

  const titleCount = title.length

  return (
    <div className={styles.backdrop} role="presentation" onMouseDown={onBackdropClick}>
      <div className={styles.dialog} role="dialog" aria-modal="true">
        <div className={styles.header}>
          <div className={styles.headerTitle}>新建无限画布</div>
          <button type="button" className={styles.closeBtn} onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>

        <div className={styles.grid}>
          <div className={styles.field}>
            <div className={styles.labelRow}>
              <div className={styles.label}>项目名称</div>
              <div className={styles.counter}>{titleCount}/100</div>
            </div>
            <input
              className={styles.input}
              value={title}
              onChange={(e) => setTitle(e.target.value.slice(0, 100))}
              placeholder="例如：人物设定画布"
            />
            <div className={styles.hint}>建议 2–20 字，方便后续管理</div>
          </div>
        </div>

        <div className={styles.actions}>
          <button type="button" className={styles.btnSecondary} onClick={onClose}>
            取消
          </button>
          <button
            type="button"
            className={styles.btnPrimary}
            onClick={onConfirmClick}
            disabled={!canConfirm || isSubmitting}
          >
            {isSubmitting ? "创建中…" : "创建并进入 →"}
          </button>
        </div>
        {errorText ? <div className={styles.errorText}>{errorText}</div> : null}
      </div>
    </div>
  )
}

