import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, inArray, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { publicResources } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"

export const runtime = "nodejs"

const querySchema = z.object({
  ids: z.string().trim().min(1).max(10_000)
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({ ids: req.nextUrl.searchParams.get("ids") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const ids = parsed.data.ids
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 50)
  if (ids.length === 0) return NextResponse.json(makeApiOk(traceId, { items: [] as any[] }), { status: 200 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const db = await getDb({ publicResources })
  const rows = await db
    .select({
      id: publicResources.id,
      userId: publicResources.userId,
      voiceSpeakerId: publicResources.voiceSpeakerId,
      voiceSpeakerName: publicResources.voiceSpeakerName,
      voiceAudioStorageKey: publicResources.voiceAudioStorageKey
    })
    .from(publicResources)
    .where(and(eq(publicResources.userId, userId), inArray(publicResources.id, ids)))

  const storage = getS3Storage()
  const items = await Promise.all(
    rows.map(async (r) => {
      const id = String(r.id ?? "").trim()
      const key = String(r.voiceAudioStorageKey ?? "").trim()
      const voiceAudioUrl = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
      return {
        id,
        voiceSpeakerId: typeof r.voiceSpeakerId === "string" ? String(r.voiceSpeakerId).trim() : "",
        voiceSpeakerName: typeof r.voiceSpeakerName === "string" ? String(r.voiceSpeakerName).trim() : "",
        voiceAudioStorageKey: key,
        voiceAudioUrl: voiceAudioUrl || ""
      }
    })
  )

  return NextResponse.json(makeApiOk(traceId, { items: items.filter((it) => it.id) }), { status: 200 })
}

