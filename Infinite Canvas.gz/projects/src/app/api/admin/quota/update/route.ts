import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { updateQuota } from "@/server/domains/admin/quotaAdmin"

export const runtime = "nodejs"

const quotaUpdateRequestSchema = z
  .object({
    id: z.string().trim().min(1).max(200),
    type: z.enum(["group", "user"]),
    mode: z.enum(["set", "add"]),
    amount: z.number().finite().nullable()
  })
  .strict()
  .superRefine((value, ctx) => {
    if (value.mode === "set" && value.amount !== null && value.amount < 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "修改余额不能小于 0",
        path: ["amount"]
      })
    }

    if (value.mode === "add" && value.amount === null) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "增加余额不能为空",
        path: ["amount"]
      })
    }

    if (value.mode === "add" && value.amount !== null && value.amount < 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "增加余额不能小于 0",
        path: ["amount"]
      })
    }
  })
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    const body = await req.json()
    await updateQuota(actor.userId, actor.roleKey === "admin" ? "super_admin" : "group_admin", body)
    return NextResponse.json(makeApiOk(traceId, { success: true }))
  } catch (error: any) {
    logger.error({
      event: "quota_update_request_failed",
      module: "admin/quota",
      traceId,
      message: "更新额度失败",
      errorName: error?.name,
      errorMessage: error?.message,
      stack: error?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "QUOTA_UPDATE_FAILED", error?.message ?? "额度更新失败"), { status: 500 })
  }
}
