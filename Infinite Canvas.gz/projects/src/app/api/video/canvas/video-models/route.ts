import { NextResponse, type NextRequest } from "next/server"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { listEnabledVideoModelsForUser } from "@/server/domains/video/videoModelResolver"

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  try {
    const items = await listEnabledVideoModelsForUser(userId)
    return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
  } catch (err) {
    const message = err instanceof Error ? err.message : "unknown"
    return NextResponse.json(makeApiErr(traceId, "VIDEO_MODELS_FAILED", message), { status: 500 })
  }
}

