import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { stories } from "@/shared/schema/story"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { enqueueCanvasVideoGenerateJob } from "@/server/domains/video/canvas/jobs/canvasVideoGenerateWorker"
import { listEnabledVideoModelsForUser } from "@/server/domains/video/videoModelResolver"
import { videoFileLogger } from "@/server/domains/video/logging/videoFileLogger"
import { QuotaReservationError } from "@/server/domains/quota/quotaReservationService"
import { CANVAS_PROMPT_MAX_LENGTH } from "@/shared/contracts/video/canvas"

export const runtime = "nodejs"

const bodySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200),
    outlineId: z.string().trim().min(1).max(200),
    nodeId: z.string().trim().min(1).max(200),
    prompt: z.string().trim().min(1).max(CANVAS_PROMPT_MAX_LENGTH),
    model: z.string().trim().min(1).max(100),
    reference_images: z.array(z.string().trim().min(1).max(5000)).max(9).optional(),
    reference_videos: z.array(z.string().trim().min(1).max(5000)).max(3).optional(),
    reference_audios: z.array(z.string().trim().min(1).max(5000)).max(3).optional(),
    generate_audio: z.boolean().optional(),
    ratio: z.enum(["16:9", "9:16", "1:1", "4:3", "3:4", "21:9", "adaptive"]).optional(),
    resolution: z.enum(["480p", "720p", "1080p"]).optional(),
    duration: z.number().int().min(2).max(15).optional(),
    watermark: z.boolean().optional()
  })
  .strict()

/**
 * 创建 Canvas 视频生成异步任务。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) {
    videoFileLogger.warn({
      module: "video/canvas-api",
      event: "canvas_video_generate_request_denied",
      message: "视频生成请求被拒绝：未登录",
      traceId
    })
    return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    videoFileLogger.warn({
      module: "video/canvas-api",
      event: "canvas_video_generate_invalid_json",
      message: "视频生成请求体不是合法 JSON",
      traceId,
      userId
    })
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) {
    videoFileLogger.warn({
      module: "video/canvas-api",
      event: "canvas_video_generate_validation_failed",
      message: "视频生成请求参数校验失败",
      traceId,
      userId,
      errors: parsed.error.flatten()
    })
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  }

  logger.info({
    event: "canvas_api_request",
    module: "video/canvas",
    traceId,
    message: "POST /api/video/canvas/video-generate",
    body: {
      ...parsed.data,
      prompt: `[len=${parsed.data.prompt.length}]`
    }
  })
  videoFileLogger.info({
    module: "video/canvas-api",
    event: "canvas_video_generate_requested",
    message: "收到视频生成请求",
    traceId,
    userId,
    storyId: parsed.data.storyId,
    outlineId: parsed.data.outlineId,
    nodeId: parsed.data.nodeId,
    modelName: parsed.data.model,
    request: {
      ...parsed.data,
      prompt: `[len=${parsed.data.prompt.length}]`
    }
  })

  try {
    await ensurePublicSchema()
    const db = await getDb({ stories })
    const allowed = await db
      .select({ id: stories.id })
      .from(stories)
      .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
      .limit(1)
    if (allowed.length === 0) {
      videoFileLogger.warn({
        module: "video/canvas-api",
        event: "canvas_video_generate_story_not_found",
        message: "视频生成请求失败：未找到可用剧本",
        traceId,
        userId,
        storyId: parsed.data.storyId
      })
      return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })
    }

    const availableModels = await listEnabledVideoModelsForUser(userId)
    const model = parsed.data.model.trim()
    if (!availableModels.some((item) => item.modelName === model)) {
      videoFileLogger.warn({
        module: "video/canvas-api",
        event: "canvas_video_generate_model_denied",
        message: "视频生成请求失败：当前账号不可使用该视频模型",
        traceId,
        userId,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId,
        nodeId: parsed.data.nodeId,
        modelName: model
      })
      return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号不可使用该视频模型"), { status: 400 })
    }
    const ratio = parsed.data.ratio ?? "9:16"
    const resolution = parsed.data.resolution ?? "720p"
    const duration = parsed.data.duration ?? 8
    const watermark = parsed.data.watermark ?? false
    const generateAudio = parsed.data.generate_audio ?? true
    const referenceImages = (parsed.data.reference_images ?? []).slice(0, 9)
    const referenceVideos = (parsed.data.reference_videos ?? []).slice(0, 3)
    const referenceAudios = (parsed.data.reference_audios ?? []).slice(0, 3)

    const { jobId, snapshot } = await enqueueCanvasVideoGenerateJob({
      userId,
      traceId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      nodeId: parsed.data.nodeId,
      prompt: parsed.data.prompt,
      modelName: model,
      mode: "reference",
      referenceImages,
      referenceVideos,
      referenceAudios,
      generateAudio,
      ratio,
      resolution,
      duration,
      watermark
    })

    kickAllWorkers()
    logger.info({
      event: "canvas_api_response",
      module: "video/canvas",
      traceId,
      message: "POST /api/video/canvas/video-generate accepted",
      jobId
    })
    videoFileLogger.info({
      module: "video/canvas-api",
      event: "canvas_video_generate_enqueued",
      message: "视频生成任务已入队",
      traceId,
      jobId,
      userId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      nodeId: parsed.data.nodeId,
      modelName: model,
      snapshot
    })
    return NextResponse.json(makeApiOk(traceId, { jobId, snapshot }), { status: 202 })
  } catch (err) {
    const msg = err instanceof Error ? err.message : "unknown"
    const errCode = typeof err === "object" && err !== null && "code" in err ? String((err as { code?: unknown }).code ?? "").trim() : ""
    logger.error({ event: "canvas_video_generate_api_failed", module: "video/canvas", traceId, message: "POST /api/video/canvas/video-generate failed", errorMessage: msg })
    videoFileLogger.error({
      module: "video/canvas-api",
      event: "canvas_video_generate_failed",
      message: "视频生成请求处理失败",
      traceId,
      userId,
      errorMessage: msg
    })
    if (err instanceof QuotaReservationError || errCode === "QUOTA_NOT_ALLOWED" || msg.includes("额度") || msg.includes("余额不足")) {
      return NextResponse.json(makeApiErr(traceId, "QUOTA_NOT_ALLOWED", msg), { status: 400 })
    }
    return NextResponse.json(makeApiErr(traceId, "DB_ERROR", "数据库不可用，请稍后重试"), { status: 500 })
  }
}
