import { Suspense, type ReactElement } from "react"
import { GroupsPage } from "@/features/admin/groups"

export default function AdminGroupsRoute(): ReactElement {
  return (
    <Suspense fallback={null}>
      <GroupsPage />
    </Suspense>
  )
}

