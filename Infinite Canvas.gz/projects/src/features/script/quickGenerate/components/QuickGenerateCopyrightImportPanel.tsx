"use client"

import { useEffect, useMemo, useState, type ReactElement } from "react"
import { Film, Image as ImageIcon, Music2 } from "lucide-react"
import type { CopyrightLibraryProject, CopyrightLibraryReviewFilter } from "@/shared/contracts/library/copyrightLibrary"
import {
  importQuickGenerateMaterialsFromCopyrightLibrary,
  listQuickGenerateCopyrightImportProjects
} from "../api-client"
import styles from "./QuickGenerateCopyrightImportPanel.module.css"

const CATEGORY_OPTIONS = [
  { id: "all", label: "全部" },
  { id: "scene", label: "场景" },
  { id: "character", label: "人物" },
  { id: "prop", label: "物品" },
  { id: "video", label: "视频" },
  { id: "audio", label: "音频" }
] as const

const REVIEW_FILTERS: Array<{ id: CopyrightLibraryReviewFilter; label: string }> = [
  { id: "all", label: "全部" },
  { id: "reviewed", label: "已通过" },
  { id: "unreviewed", label: "未审核" },
  { id: "processing", label: "审核中" },
  { id: "failed", label: "审核失败" }
]

type QuickGenerateCopyrightImportPanelProps = {
  open: boolean
  storyId: string
  onImported: (importedCount: number) => Promise<void> | void
}

function getProjectTypeLabel(projectType: CopyrightLibraryProject["projectType"]): string {
  return projectType === "canvas" ? "画布" : "快速开始"
}

function getMaterialTypeLabel(materialType: string): string {
  if (materialType === "scene") return "场景"
  if (materialType === "character") return "人物"
  if (materialType === "prop") return "物品"
  if (materialType === "video") return "视频"
  if (materialType === "audio") return "音频"
  return "素材"
}

function getReviewLabel(assetStatus?: string | null): string {
  const status = String(assetStatus ?? "").trim()
  if (status === "Active") return "已通过"
  if (status === "Processing") return "审核中"
  if (status === "Failed") return "审核失败"
  return "未审核"
}

export function QuickGenerateCopyrightImportPanel({
  open,
  storyId,
  onImported
}: QuickGenerateCopyrightImportPanelProps): ReactElement {
  const [projects, setProjects] = useState<CopyrightLibraryProject[]>([])
  const [loading, setLoading] = useState(false)
  const [importing, setImporting] = useState(false)
  const [search, setSearch] = useState("")
  const [category, setCategory] = useState<string>("all")
  const [reviewFilter, setReviewFilter] = useState<CopyrightLibraryReviewFilter>("all")
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null)
  const [selectedMap, setSelectedMap] = useState<Record<string, { projectType: "quick_generate" | "canvas"; sourceMaterialId: string }>>({})

  useEffect(() => {
    if (!open) return
    let cancelled = false
    setLoading(true)
    void listQuickGenerateCopyrightImportProjects({
      excludeStoryId: storyId,
      category,
      reviewFilter,
      search
    })
      .then((nextProjects) => {
        if (cancelled) return
        setProjects(nextProjects)
        setActiveProjectId((prev) => (prev && nextProjects.some((project) => project.storyId === prev) ? prev : nextProjects[0]?.storyId ?? null))
      })
      .catch((error) => {
        if (cancelled) return
        setProjects([])
        setActiveProjectId(null)
        alert(error instanceof Error ? error.message : "加载版权库素材失败")
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [category, open, reviewFilter, search, storyId])

  const activeProject = useMemo(
    () => projects.find((project) => project.storyId === activeProjectId) ?? projects[0] ?? null,
    [activeProjectId, projects]
  )

  const selectedCount = Object.keys(selectedMap).length

  const handleToggleMaterial = (payload: { key: string; projectType: "quick_generate" | "canvas"; sourceMaterialId: string }) => {
    setSelectedMap((prev) => {
      const next = { ...prev }
      if (next[payload.key]) delete next[payload.key]
      else next[payload.key] = { projectType: payload.projectType, sourceMaterialId: payload.sourceMaterialId }
      return next
    })
  }

  const handleImport = async () => {
    const items = Object.values(selectedMap)
    if (items.length === 0) {
      alert("请先选择要导入的版权素材")
      return
    }
    try {
      setImporting(true)
      const result = await importQuickGenerateMaterialsFromCopyrightLibrary({ storyId, items })
      await onImported(result.importedCount)
      setSelectedMap({})
    } catch (error) {
      alert(error instanceof Error ? error.message : "从版权库导入素材失败")
    } finally {
      setImporting(false)
    }
  }

  return (
    <div className={styles.panel}>
      <div className={styles.toolbar}>
        <div className={styles.toolbarMain}>
          <input
            className={styles.searchInput}
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="搜索剧集名、素材名、assetId"
          />
          <button type="button" className={styles.primaryBtn} disabled={importing || selectedCount === 0} onClick={() => void handleImport()}>
            {importing ? "导入中..." : `导入已选素材${selectedCount > 0 ? `（${selectedCount}）` : ""}`}
          </button>
        </div>
        <div className={styles.toolbarHint}>仅展示其他剧集的版权素材，导入后会复制到当前剧本</div>
      </div>
      <div className={styles.filterRow}>
        {CATEGORY_OPTIONS.map((option) => (
          <button
            key={option.id}
            type="button"
            className={`${styles.filterBtn} ${category === option.id ? styles.filterBtnActive : ""}`}
            onClick={() => setCategory(option.id)}
          >
            {option.label}
          </button>
        ))}
      </div>
      <div className={styles.filterRow}>
        {REVIEW_FILTERS.map((filter) => (
          <button
            key={filter.id}
            type="button"
            className={`${styles.filterBtn} ${reviewFilter === filter.id ? styles.filterBtnActive : ""}`}
            onClick={() => setReviewFilter(filter.id)}
          >
            {filter.label}
          </button>
        ))}
      </div>
      <div className={styles.layout}>
        <div className={styles.projectList}>
          {loading ? (
            <div className={styles.empty}>版权库加载中...</div>
          ) : projects.length === 0 ? (
            <div className={styles.empty}>当前暂无可导入的其他剧集素材</div>
          ) : (
            projects.map((project) => (
              <button
                key={project.storyId}
                type="button"
                className={`${styles.projectBtn} ${activeProject?.storyId === project.storyId ? styles.projectBtnActive : ""}`}
                onClick={() => setActiveProjectId(project.storyId)}
              >
                <div className={styles.projectTitle}>{project.title}</div>
                <div className={styles.projectMeta}>
                  {getProjectTypeLabel(project.projectType)} · {project.items.length} 个素材
                </div>
              </button>
            ))
          )}
        </div>
        <div className={styles.materialsWrap}>
          <div className={styles.materialsHeader}>
            <div>
              <div className={styles.materialsTitle}>{activeProject?.title ?? "请选择剧集"}</div>
              <div className={styles.materialsMeta}>
                {activeProject ? `${getProjectTypeLabel(activeProject.projectType)} · ${activeProject.items.length} 个可导入素材` : "选择左侧剧集后查看素材"}
              </div>
            </div>
            <div className={styles.materialsMeta}>已选 {selectedCount} 个</div>
          </div>
          {!activeProject ? (
            <div className={styles.empty}>请选择左侧剧集后查看素材</div>
          ) : activeProject.items.length === 0 ? (
            <div className={styles.empty}>当前剧集下暂无符合条件的版权素材</div>
          ) : (
            <div className={styles.materialsScroll}>
              <div className={styles.materialsGrid}>
                {activeProject.items.map((item) => {
                  const key = `${item.projectType}:${item.id}`
                  const isSelected = Boolean(selectedMap[key])
                  const mediaType = item.materialType === "video" ? "video" : item.materialType === "audio" ? "audio" : "image"
                  return (
                    <button
                      key={key}
                      type="button"
                      className={`${styles.materialCard} ${isSelected ? styles.materialCardSelected : ""}`}
                      onClick={() => handleToggleMaterial({ key, projectType: item.projectType ?? activeProject.projectType, sourceMaterialId: item.id })}
                    >
                      <div className={styles.preview}>
                        {mediaType === "image" && item.sourceUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={item.sourceUrl} alt={item.title} className={styles.previewImage} />
                        ) : mediaType === "video" && item.sourceUrl ? (
                          <video src={item.sourceUrl} className={styles.previewVideo} muted />
                        ) : (
                          <div className={styles.previewPlaceholder}>
                            {mediaType === "video" ? <Film size={24} /> : mediaType === "audio" ? <Music2 size={24} /> : <ImageIcon size={24} />}
                          </div>
                        )}
                      </div>
                      <div className={styles.materialInfo}>
                        <div className={styles.materialTitle}>{item.title}</div>
                        <div className={styles.tags}>
                          <span className={styles.tag}>{getMaterialTypeLabel(item.materialType)}</span>
                          <span className={styles.tag}>{getReviewLabel(item.assetStatus)}</span>
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
