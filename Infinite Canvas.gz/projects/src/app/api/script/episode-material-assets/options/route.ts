import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, like, or } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import {
  publicCharacterCostumes,
  publicCharacterLooks,
  publicResources,
  sharedCharacterCostumes,
  sharedCharacterLooks,
  sharedResources
} from "@/shared/schema/library"
import { generatedImages } from "@/shared/schema/generation"

const querySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200),
    roleName: z.string().trim().max(100).optional(),
    characterId: z.string().trim().max(200).optional()
  })
  .refine((v) => Boolean((v.characterId ?? "").trim() || (v.roleName ?? "").trim()), {
    message: "roleName 或 characterId 至少提供一个"
  })

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    roleName: url.searchParams.get("roleName") ?? undefined,
    characterId: url.searchParams.get("characterId") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({
    stories,
    publicResources,
    sharedResources,
    publicCharacterLooks,
    publicCharacterCostumes,
    sharedCharacterLooks,
    sharedCharacterCostumes,
    generatedImages
  })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const directCharacterId = (parsed.data.characterId ?? "").trim()
  if (directCharacterId) {
    const looksPub = await db
      .select({ name: publicCharacterLooks.name })
      .from(publicCharacterLooks)
      .where(eq(publicCharacterLooks.characterResourceId, directCharacterId))
    const looksShared = await db
      .select({ name: sharedCharacterLooks.name })
      .from(sharedCharacterLooks)
      .where(eq(sharedCharacterLooks.characterResourceId, directCharacterId))
    const costumesPub = await db
      .select({ name: publicCharacterCostumes.name })
      .from(publicCharacterCostumes)
      .where(eq(publicCharacterCostumes.characterResourceId, directCharacterId))
    const costumesShared = await db
      .select({ name: sharedCharacterCostumes.name })
      .from(sharedCharacterCostumes)
      .where(eq(sharedCharacterCostumes.characterResourceId, directCharacterId))

    const makeup = Array.from(
      new Set([...looksPub, ...looksShared].map((r) => String(r.name ?? "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b))
    const costume = Array.from(
      new Set([...costumesPub, ...costumesShared].map((r) => String(r.name ?? "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b))
    return NextResponse.json(makeApiOk(traceId, { makeup, costume }), { status: 200 })
  }

  const roleName = (parsed.data.roleName ?? "").trim()
  const characterPub = (
    await db
      .select({ id: publicResources.id })
      .from(publicResources)
      .where(and(eq(publicResources.userId, userId), eq(publicResources.type, "character"), eq(publicResources.name, roleName)))
      .limit(1)
  )[0]
  const characterShared =
    !characterPub
      ? (
          await db
            .select({ id: sharedResources.id })
            .from(sharedResources)
            .where(and(eq(sharedResources.type, "character"), eq(sharedResources.name, roleName)))
            .limit(1)
        )[0]
      : null
  const characterId = characterPub?.id ?? characterShared?.id ?? ""

  if (characterId) {
    const looksPub = await db
      .select({ name: publicCharacterLooks.name })
      .from(publicCharacterLooks)
      .where(eq(publicCharacterLooks.characterResourceId, characterId))
    const looksShared = await db
      .select({ name: sharedCharacterLooks.name })
      .from(sharedCharacterLooks)
      .where(eq(sharedCharacterLooks.characterResourceId, characterId))
    const costumesPub = await db
      .select({ name: publicCharacterCostumes.name })
      .from(publicCharacterCostumes)
      .where(eq(publicCharacterCostumes.characterResourceId, characterId))
    const costumesShared = await db
      .select({ name: sharedCharacterCostumes.name })
      .from(sharedCharacterCostumes)
      .where(eq(sharedCharacterCostumes.characterResourceId, characterId))

    const makeup = Array.from(
      new Set([...looksPub, ...looksShared].map((r) => String(r.name ?? "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b))
    const costume = Array.from(
      new Set([...costumesPub, ...costumesShared].map((r) => String(r.name ?? "").trim()).filter(Boolean))
    ).sort((a, b) => a.localeCompare(b))
    return NextResponse.json(makeApiOk(traceId, { makeup, costume }), { status: 200 })
  }

  const prefixMakeup = `${parsed.data.roleName}/妆容/`
  const prefixCostume = `${parsed.data.roleName}/服装/`

  const pub = await db
    .select({ name: publicResources.name })
    .from(publicResources)
    .where(or(like(publicResources.name, `${prefixMakeup}%`), like(publicResources.name, `${prefixCostume}%`)))

  const shared = await db
    .select({ name: sharedResources.name })
    .from(sharedResources)
    .where(or(like(sharedResources.name, `${prefixMakeup}%`), like(sharedResources.name, `${prefixCostume}%`)))

  const gen = await db
    .select({ name: generatedImages.name })
    .from(generatedImages)
    .where(and(eq(generatedImages.storyId, parsed.data.storyId), or(like(generatedImages.name, `${prefixMakeup}%`), like(generatedImages.name, `${prefixCostume}%`))))

  const makeup = new Set<string>()
  const costume = new Set<string>()
  for (const r of [...pub, ...shared, ...gen]) {
    const n = String(r.name ?? "").trim()
    if (n.startsWith(prefixMakeup)) {
      const val = n.slice(prefixMakeup.length).trim()
      if (val) makeup.add(val)
    } else if (n.startsWith(prefixCostume)) {
      const val = n.slice(prefixCostume.length).trim()
      if (val) costume.add(val)
    }
  }

  return NextResponse.json(makeApiOk(traceId, { makeup: Array.from(makeup), costume: Array.from(costume) }), { status: 200 })
}
