import { NextResponse, type NextRequest } from "next/server"
import { eq, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { auditLogs, groupModelBindings, groupModelCredentials, userGroups } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { getGroupModelAccess, groupModelAccessUpdateSchema, updateGroupModelAccess } from "@/server/domains/admin/groupModelAccess"

export const runtime = "nodejs"

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })

    await ensurePublicSchema()
    const db = await getDb({ userGroups, groupModelCredentials, groupModelBindings })
    const rows = await db
      .select({ id: userGroups.id, name: userGroups.name, code: userGroups.code, isActive: userGroups.isActive })
      .from(userGroups)
      .where(eq(userGroups.id, id))
      .limit(1)
    const group = rows[0]
    if (!group?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

    const modelAccess = await getGroupModelAccess(db, id, { revealApiKey: true })
    return NextResponse.json(makeApiOk(traceId, { group, modelAccess }), { status: 200 })
  } catch (err) {
    const anyErr = err as { name?: string; message?: string; stack?: string }
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", anyErr?.message || "获取组模型配置失败，请稍后重试"), { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
    const parsed = groupModelAccessUpdateSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ userGroups, auditLogs, groupModelCredentials, groupModelBindings })
    const rows = await db.select({ id: userGroups.id, name: userGroups.name }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
    const group = rows[0]
    if (!group?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

    const result = await updateGroupModelAccess({
      db,
      groupId: id,
      actorUserId: actor.userId,
      traceId,
      data: parsed.data
    })

    await db.execute(sql`
      insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
      values (
        ${actor.userId},
        'user_group.model_access.update',
        'user_group',
        ${id},
        null,
        ${JSON.stringify({ id, modelAccess: result.before })}::jsonb,
        ${JSON.stringify({ id, modelAccess: result.after })}::jsonb,
        ${actor.ip},
        ${actor.userAgent},
        ${traceId}
      )
    `)

    return NextResponse.json(makeApiOk(traceId, { group: { id: group.id, name: group.name }, modelAccess: result.modelAccess }), { status: 200 })
  } catch (err) {
    const anyErr = err as { name?: string; message?: string; stack?: string }
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", anyErr?.message || "更新组模型配置失败，请稍后重试"), { status: 500 })
  }
}

