import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, asc, eq, or } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { publicResources } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const querySchema = z.object({
  resourceId: z.string().trim().min(1).max(200)
})

/**
 * 获取 public_resources 的版本列表：
 * - 先将任意 resourceId 归一到根 originId（如果自身无 originId，则根为自身 id）
 * - 返回根资源 + 所有 originId=根 的派生资源，按 createdAt 升序排列
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ resourceId: url.searchParams.get("resourceId") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const db = await getDb({ publicResources })
  const baseRows = await db
    .select({
      id: publicResources.id,
      userId: publicResources.userId,
      originId: publicResources.originId
    })
    .from(publicResources)
    .where(eq(publicResources.id, parsed.data.resourceId))
    .limit(1)

  const base = baseRows[0] ?? null
  if (!base) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
  if (base.userId !== userId) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

  const rootId = (base.originId ?? base.id).trim()

  const items = await db
    .select({
      id: publicResources.id,
      originId: publicResources.originId,
      type: publicResources.type,
      name: publicResources.name,
      previewUrl: publicResources.previewUrl,
      originalUrl: publicResources.originalUrl,
      previewStorageKey: publicResources.previewStorageKey,
      originalStorageKey: publicResources.originalStorageKey,
      createdAt: publicResources.createdAt
    })
    .from(publicResources)
    .where(
      and(
        eq(publicResources.userId, userId),
        or(eq(publicResources.id, rootId), eq(publicResources.originId, rootId))
      )
    )
    .orderBy(asc(publicResources.createdAt))

  return NextResponse.json(makeApiOk(traceId, { rootId, items }), { status: 200 })
}
