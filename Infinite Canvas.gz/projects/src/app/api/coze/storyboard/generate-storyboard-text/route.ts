import { NextResponse } from "next/server"
import { z } from "zod"
import { readEnv } from "@/features/coze/env"
import { CozeRunEndpointError } from "@/features/coze/runEndpointClient"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { getSessionFromRequest } from "@/shared/session"
import type { NextRequest } from "next/server"
import { and, desc, eq, sql } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"
import { clipText } from "@/server/domains/storyboard/utils/storyboardTextInput"
import { episodeMaterialAssets, episodeMaterialImages } from "@/shared/schema/generation"
import { jobs } from "@/shared/schema/jobs"

const inputSchema = z.object({
  outlineId: z.string().trim().min(1).max(200),
  outline: z.string().min(1).max(200_000),
  original: z.string().min(1).max(200_000),
  world_setting: z.unknown().optional(),
  character_settings: z.unknown().optional(),
  async: z.boolean().optional(),
  force: z.boolean().optional()
})

import {
  COZE_GENERATE_STORYBOARD_TEXT_JOB_TYPE,
  enqueueCozeGenerateStoryboardTextJob,
  kickCozeStoryboardWorker
} from "@/server/domains/storyboard/jobs/cozeStoryboardWorker"

export async function POST(req: Request): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()

  logger.info({
    event: "storyboard_text_start",
    module: "coze",
    traceId,
    message: "开始生成分镜文本"
  })

  let json: unknown
  try {
    json = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "COZE_INVALID_JSON", "请求体不是合法 JSON"), {
      status: 400
    })
  }

  const parsed = inputSchema.safeParse(json)
  if (!parsed.success) {
    logger.warn({
      event: "storyboard_text_validation_failed",
      module: "coze",
      traceId,
      message: "分镜文本生成入参校验失败"
    })
    return NextResponse.json(makeApiErr(traceId, "COZE_VALIDATION_FAILED", "入参格式不正确"), {
      status: 400
    })
  }

  const url = readEnv("CREATE_STORYBOARD_TEXT_URL")
  const token = readEnv("CREATE_STORYBOARD_TEXT_TOKEN")
  if (!url || !token) {
    return NextResponse.json(
      makeApiErr(
        traceId,
        "COZE_NOT_CONFIGURED",
        "Coze 未配置，请设置 CREATE_STORYBOARD_TEXT_URL 与 CREATE_STORYBOARD_TEXT_TOKEN"
      ),
      { status: 500 }
    )
  }

  try {
    const session = await getSessionFromRequest(req as unknown as NextRequest)
    const userId = session?.userId
    if (!userId) {
      return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), {
        status: 401
      })
    }

    const clippedOutline = clipText(parsed.data.outline, 49_000)
    const clippedOriginal = clipText(parsed.data.original, 49_000)
    if (!clippedOutline || !clippedOriginal) {
      return NextResponse.json(makeApiErr(traceId, "COZE_VALIDATION_FAILED", "入参格式不正确"), { status: 400 })
    }

    const db = await getDb({ stories, storyOutlines, storyboards, episodeMaterialImages, episodeMaterialAssets, jobs })
    const [row] = await db
      .select({ storyId: storyOutlines.storyId, outlineSequence: storyOutlines.sequence })
      .from(storyOutlines)
      .innerJoin(stories, eq(storyOutlines.storyId, stories.id))
      .where(and(eq(storyOutlines.id, parsed.data.outlineId), eq(stories.userId, userId)))
      .limit(1)
    if (!row?.storyId) {
      return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "大纲章节不存在或无权限"), { status: 404 })
    }

    const materialBatches = await db
      .select({ id: episodeMaterialImages.id, meta: episodeMaterialImages.meta, createdAt: episodeMaterialImages.createdAt })
      .from(episodeMaterialImages)
      .where(eq(episodeMaterialImages.storyId, row.storyId))
      .orderBy(desc(episodeMaterialImages.createdAt))
      .limit(20)

    const pickObject = (v: unknown): Record<string, unknown> | null => {
      if (!v || typeof v !== "object" || Array.isArray(v)) return null
      return v as Record<string, unknown>
    }
    const pickBatch = () => {
      for (const b of materialBatches) {
        const m = pickObject(b?.meta)
        const status = String((m as any)?.status ?? "").trim().toLowerCase()
        const pr = m ? pickObject((m as any).parseResult) : null
        if (status === "done" && pr) return b
      }
      for (const b of materialBatches) {
        const m = pickObject(b?.meta)
        const pr = m ? pickObject((m as any).parseResult) : null
        if (pr) return b
      }
      return materialBatches[0] ?? null
    }

    const pickedBatch = pickBatch()
    const materialId = pickedBatch?.id ?? null
    const materialMeta = pickedBatch?.meta as unknown
    const materialRows = materialId
      ? await db
          .select({ kind: episodeMaterialAssets.kind, name: episodeMaterialAssets.name })
          .from(episodeMaterialAssets)
          .where(and(eq(episodeMaterialAssets.storyId, row.storyId), eq(episodeMaterialAssets.materialId, materialId)))
          .limit(2000)
      : []

    const outlineSequence =
      typeof row.outlineSequence === "number" && Number.isFinite(row.outlineSequence) ? Math.trunc(row.outlineSequence) : 0
    const filterByShotNumber = (arr: unknown[]) => arr
    const parsedBackgroundsRaw = (() => {
      const m =
        materialMeta && typeof materialMeta === "object" && materialMeta !== null && !Array.isArray(materialMeta) ? (materialMeta as any) : null
      const pr = m && typeof m.parseResult === "object" && m.parseResult !== null && !Array.isArray(m.parseResult) ? (m.parseResult as any) : null
      const arr = pr?.backgrounds
      const list = Array.isArray(arr) ? (arr as unknown[]) : []
      return filterByShotNumber(list).slice(0, 200)
    })()
    const parsedItemsRaw = (() => {
      const m =
        materialMeta && typeof materialMeta === "object" && materialMeta !== null && !Array.isArray(materialMeta) ? (materialMeta as any) : null
      const pr = m && typeof m.parseResult === "object" && m.parseResult !== null && !Array.isArray(m.parseResult) ? (m.parseResult as any) : null
      const arr = pr?.items
      const list = Array.isArray(arr) ? (arr as unknown[]) : []
      return filterByShotNumber(list).slice(0, 200)
    })()
    const parsedCharactersRaw = (() => {
      const m =
        materialMeta && typeof materialMeta === "object" && materialMeta !== null && !Array.isArray(materialMeta) ? (materialMeta as any) : null
      const pr = m && typeof m.parseResult === "object" && m.parseResult !== null && !Array.isArray(m.parseResult) ? (m.parseResult as any) : null
      const arr = pr?.roles ?? pr?.characters
      const list = Array.isArray(arr) ? (arr as unknown[]) : []
      return filterByShotNumber(list).slice(0, 200)
    })()
    const mergedBackgrounds =
      Array.isArray(parsedBackgroundsRaw) && parsedBackgroundsRaw.length > 0
        ? parsedBackgroundsRaw
        : materialRows
            .filter((r) => String(r.kind ?? "").trim().toLowerCase() === "scene")
            .map((r) => ({ name: String(r.name ?? "").trim() }))
            .filter((r) => r.name)
            .slice(0, 200)
    const mergedItems =
      Array.isArray(parsedItemsRaw) && parsedItemsRaw.length > 0
        ? parsedItemsRaw
        : materialRows
            .filter((r) => String(r.kind ?? "").trim().toLowerCase() === "item")
            .map((r) => ({ name: String(r.name ?? "").trim() }))
            .filter((r) => r.name)
            .slice(0, 200)
    const mergedCharacters = Array.isArray(parsedCharactersRaw) && parsedCharactersRaw.length > 0 ? parsedCharactersRaw : []

    const force = parsed.data.force === true
    if (!force) {
      // 无论是否有分镜数据，都检查 queued、running、done 三种状态
      // 避免删除分镜后重复创建任务
      const statusFilter = sql`${jobs.status} in ('queued','running','done')`
      const materialFilter = materialId ? sql`(${jobs.payload}->>'materialBatchId') = ${materialId}` : sql`true`
      const existing = await db
        .select({ id: jobs.id, status: jobs.status })
        .from(jobs)
        .where(
          and(
            eq(jobs.userId, userId),
            eq(jobs.storyId, row.storyId),
            eq(jobs.type, COZE_GENERATE_STORYBOARD_TEXT_JOB_TYPE),
            statusFilter,
            sql`${jobs.payload}->>'outlineId' = ${parsed.data.outlineId}`,
            materialFilter
          )
        )
        .orderBy(desc(jobs.createdAt))
        .limit(1)
      const existingJobId = existing[0]?.id ?? null
      if (existingJobId) {
        kickCozeStoryboardWorker()
        return NextResponse.json(makeApiOk(traceId, { jobId: existingJobId, status: String(existing[0]?.status ?? "queued") }), {
          status: 202
        })
      }
    }

    const { jobId, snapshot } = await enqueueCozeGenerateStoryboardTextJob({
      userId,
      traceId,
      storyId: row.storyId,
      outlineId: parsed.data.outlineId,
      materialBatchId: materialId,
      outline: clippedOutline,
      original: clippedOriginal,
      world_setting: parsed.data.world_setting,
      character_settings: parsed.data.character_settings,
      backgrounds: mergedBackgrounds,
      items: mergedItems,
      characters: mergedCharacters,
      force
    })
    kickCozeStoryboardWorker()
    logger.info({
      event: "storyboard_text_async_queued",
      module: "coze",
      traceId,
      message: "分镜文本生成任务已入队",
      jobId,
      outlineId: parsed.data.outlineId
    })
    return NextResponse.json(makeApiOk(traceId, { jobId, status: snapshot.status }), { status: 202 })
  } catch (err) {
    const durationMs = Date.now() - start
    if (err instanceof CozeRunEndpointError) {
      // 3. Mark Storyboard Text Failed (Coze Error)
      // We have outlineId, so we can find storyId (already queried above as storyRow, but variable scope issue)
      // Re-query storyId or use if available.
      // In this function scope, we don't have storyId in the catch block easily unless we move logic.
      // However, we can use updateStoryStatus with error info if we could access storyId.
      // Given constraints, we skip detailed status update on failure here or need refactor.
      // To keep it simple and safe: just log error as before.
      
      logger.error({
        event: "storyboard_text_failed",
        module: "coze",
        traceId,
        message: "分镜文本生成失败（Coze 调用失败）",
        durationMs,
        status: err.status
      })
      return NextResponse.json(
        makeApiErr(traceId, "COZE_REQUEST_FAILED", "Coze 调用失败，请稍后重试"),
        { status: 502 }
      )
    }

    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "storyboard_text_error",
      module: "coze",
      traceId,
      message: "分镜文本生成异常",
      durationMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })

    return NextResponse.json(makeApiErr(traceId, "COZE_UNKNOWN", "生成失败，请稍后重试"), {
      status: 500
    })
  }
}
