import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, isNull, sql } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories, storyOutlines } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const bodySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200)
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, storyOutlines })

  const storyRows = await db
    .select({ id: stories.id, storyType: stories.storyType })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)

  const story = storyRows[0]
  if (!story) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的项目"), { status: 404 })
  if (story.storyType !== "canvas") return NextResponse.json(makeApiErr(traceId, "INVALID_STORY_TYPE", "该项目不是无限画布类型"), { status: 400 })

  const maxSeqRows = await db
    .select({ maxSeq: sql<number>`coalesce(max(${storyOutlines.sequence}), 0)` })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.storyId, parsed.data.storyId), isNull(storyOutlines.deletedAt)))

  const nextSequence = Number(maxSeqRows[0]?.maxSeq ?? 0) + 1

  const createdRows = await db
    .insert(storyOutlines)
    .values({
      storyId: parsed.data.storyId,
      sequence: nextSequence,
      outlineText: "",
      originalText: ""
    })
    .returning({ id: storyOutlines.id })

  const outlineId = createdRows[0]?.id
  if (!outlineId) return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "创建失败，请稍后重试"), { status: 500 })

  return NextResponse.json(makeApiOk(traceId, { outlineId, sequence: nextSequence }), { status: 200 })
}

