import type { ApiErr, ApiOk } from "@/shared/api"
import type { CopyrightLibraryProject, CopyrightLibraryReviewFilter } from "@/shared/contracts/library/copyrightLibrary"
import type {
  QuickGenerateCollaboratorsResponse,
  QuickGenerateCollaboratorsUpdateRequest
} from "@/shared/contracts/quickGenerateCollaboration"
import type { QuickGenerateMaterial } from "@/shared/schema/quickGenerate"
import type { QuickGenerateVideoModel } from "./videoModel"

type CreateQuickGenerateProjectInput = {
  title: string
  ratio: string
  resolution: string
  style: string
  videoCategory: "premium" | "commentary"
}

/**
 * 将批量删除的 id 列表编码到 query string，规避 DELETE body 被代理剥离的问题。
 */
function buildDeleteIdsQuery(ids: string[]): string {
  const searchParams = new URLSearchParams()
  searchParams.set("ids", JSON.stringify(ids))
  return searchParams.toString()
}

type CreateQuickGenerateProjectResult = {
  storyId: string
  projectId: string
  groupId: string | null
}

async function readApiJson<T>(res: Response, fallbackMessage: string): Promise<T> {
  const json = (await res.json().catch(() => null)) as T | ApiErr | null
  if (!res.ok || !json || ((json as ApiErr).ok === false)) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? fallbackMessage)
  }
  return json as T
}

type CreateQuickGenerateEpisodeInput = {
  storyId: string
  episodeNo: number
  videoModel: QuickGenerateVideoModel
  storyboardPanelModel: string
  storyboardPromptPresetId?: string
  videoPromptPresetId?: string
  storyboardPanelPromptPresetId?: string
} & (
  | {
      type: "outline"
      content: string
      minDurationMinutes: number
      maxDurationMinutes: number
      shotsNum?: number
    }
  | {
      type: "storyboard"
      content: string
    }
  | {
      type: "drama"
      prompt: string
    }
)


type CreateQuickGenerateEpisodeResult = {
  episodeId: string
  projectId: string
  jobId: string
}

type ImportQuickGenerateEpisodeTextResult = {
  content: string
  fileName: string
  sourceKind: "pdf" | "docx" | "txt" | "excel"
  charCount: number
}

type UpdateQuickGenerateEpisodeShotsInput = {
  episodeId: string
} & (
  | {
      shots: Array<{
        persistedShotNo?: number
        shotText: string
        roles: string[]
        scenes: string[]
        items: string[]
        optimizedText: string
        speakerList: string[]
        refAudioNames: string[]
        mutedAutoAudioNames: string[]
        refVideoIds: string[]
        duration: number
        generateAudio: boolean
        watermark: boolean
        aspectRatio: string
        resolution: string
        videoModel: QuickGenerateVideoModel
        storyboardPanelPrompt?: string
        storyboardPanelModel?: string
        storyboardPanelImages?: string[]
        storyboardPanelImageStorageKeys?: string[]
        selectedStoryboardPanelImage?: string
        selectedStoryboardPanelImageStorageKey?: string
      }>
    }
  | {
      shotNo: number
      shot: {
        persistedShotNo?: number
        shotText: string
        roles: string[]
        scenes: string[]
        items: string[]
        optimizedText: string
        speakerList: string[]
        refAudioNames: string[]
        mutedAutoAudioNames: string[]
        refVideoIds: string[]
        duration: number
        generateAudio: boolean
        watermark: boolean
        aspectRatio: string
        resolution: string
        videoModel: QuickGenerateVideoModel
        storyboardPanelPrompt?: string
        storyboardPanelModel?: string
        storyboardPanelImages?: string[]
        storyboardPanelImageStorageKeys?: string[]
        selectedStoryboardPanelImage?: string
        selectedStoryboardPanelImageStorageKey?: string
      }
    }
)

type GenerateQuickGenerateEpisodeVideoPromptsInput = {
  episodeId: string
  shots: Array<{
    shotNo: number
    shotText: string
    roles: string[]
    scenes: string[]
    items: string[]
    fenjingban_prompt?: string
  }>
}

type GenerateQuickGenerateEpisodePanelPromptsInput = {
  episodeId: string
  personalPrompt?: string
  shots: Array<{
    shotNo: number
    shotText: string
    roles: string[]
    scenes: string[]
    items: string[]
  }>
}

type GenerateQuickGenerateEpisodeVideoPromptsResult = {
  jobId: string
  queuedCount: number
  skippedCount: number
}

type GenerateQuickGenerateEpisodePanelImagesInput = {
  episodeId: string
  shots: Array<{
    shotNo: number
    shotText: string
    roles: string[]
    roleMaterialIdsByName: Record<string, string>
    scenes: string[]
    sceneMaterialIdsByName: Record<string, string>
    items: string[]
    itemMaterialIdsByName: Record<string, string>
    optimizedText: string
    speakerList: string[]
    refAudioNames: string[]
    mutedAutoAudioNames: string[]
    refVideoIds: string[]
    duration: number
    generateAudio: boolean
    watermark: boolean
    aspectRatio: string
    resolution: string
    videoModel: QuickGenerateVideoModel
    storyboardPanelPrompt: string
    storyboardPanelModel: string
    storyboardPanelImageStorageKeys?: string[]
    selectedStoryboardPanelImage?: string
    selectedStoryboardPanelImageStorageKey?: string
  }>
}

type GenerateQuickGenerateEpisodeVideosInput = {
  episodeId: string
  shots: Array<{
    shotNo: number
    shotText: string
    roles: string[]
    roleMaterialIdsByName: Record<string, string>
    scenes: string[]
    sceneMaterialIdsByName: Record<string, string>
    items: string[]
    itemMaterialIdsByName: Record<string, string>
    optimizedText: string
    speakerList: string[]
    refAudioNames: string[]
    mutedAutoAudioNames: string[]
    refVideoIds: string[]
    duration: number
    generateAudio: boolean
    watermark: boolean
    aspectRatio: string
    resolution: string
    videoModel: QuickGenerateVideoModel
    storyboardPanelImageStorageKeys?: string[]
    selectedStoryboardPanelImage?: string
    selectedStoryboardPanelImageStorageKey?: string
  }>
}

type GenerateQuickGenerateEpisodeVideosResult = {
  queuedCount: number
  processingCount: number
  skippedCount: number
  results: Array<{
    shotNo: number
    ok: boolean
    status: "queued" | "processing" | "failed"
    jobId?: string
    errorMessage?: string
  }>
}

type SelectQuickGenerateShotVideoInput = {
  episodeId: string
  shotNo: number
  selectedJobId: string
}

type EraseQuickGenerateShotVideoSubtitleInput = {
  episodeId: string
  shotNo: number
  jobId: string
}

type ExportQuickGenerateEpisodeToJianyingInput = {
  episodeId: string
  storyId: string
  userId: string
}

type ExportQuickGenerateEpisodeToJianyingResult = {
  jobId: string
  status: string
}

/**
 * 创建快速生成项目，并初始化独立项目记录。
 */
export async function createQuickGenerateProject(
  input: CreateQuickGenerateProjectInput
): Promise<CreateQuickGenerateProjectResult> {
  const res = await fetch("/api/quick-generate/projects", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "创建快速生成项目失败")
  }
  const data = (json as ApiOk<unknown>).data as { storyId?: unknown; projectId?: unknown; groupId?: unknown } | null
  const storyId = typeof data?.storyId === "string" ? data.storyId.trim() : ""
  const projectId = typeof data?.projectId === "string" ? data.projectId.trim() : ""
  const groupId = typeof data?.groupId === "string" ? data.groupId.trim() : null
  if (!storyId || !projectId) throw new Error("创建快速生成项目失败：返回数据不完整")
  return { storyId, projectId, groupId: groupId?.trim() ? groupId : null }
}

export async function getQuickGenerateCollaborators(projectId: string): Promise<QuickGenerateCollaboratorsResponse> {
  const res = await fetch(`/api/quick-generate/projects/${encodeURIComponent(projectId)}/collaborators`, {
    cache: "no-store"
  })
  const json = await readApiJson<ApiOk<QuickGenerateCollaboratorsResponse>>(
    res,
    "获取协同成员失败"
  )
  return json.data
}

export async function updateQuickGenerateCollaborators(
  projectId: string,
  input: QuickGenerateCollaboratorsUpdateRequest
): Promise<QuickGenerateCollaboratorsResponse> {
  const res = await fetch(`/api/quick-generate/projects/${encodeURIComponent(projectId)}/collaborators`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = await readApiJson<ApiOk<QuickGenerateCollaboratorsResponse>>(
    res,
    "保存协同成员失败"
  )
  return json.data
}

/**
 * 创建剧集并提交“剧集创作”任务（进入任务中心）。
 */
export async function createQuickGenerateEpisode(input: CreateQuickGenerateEpisodeInput): Promise<CreateQuickGenerateEpisodeResult> {
  const res = await fetch("/api/quick-generate/episodes", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "创建剧集失败")
  }
  const data = (json as ApiOk<unknown>).data as { episodeId?: unknown; projectId?: unknown; jobId?: unknown } | null
  const episodeId = typeof data?.episodeId === "string" ? data.episodeId.trim() : ""
  const projectId = typeof data?.projectId === "string" ? data.projectId.trim() : ""
  const jobId = typeof data?.jobId === "string" ? data.jobId.trim() : ""
  if (!episodeId || !projectId || !jobId) throw new Error("创建剧集失败：返回数据不完整")
  return { episodeId, projectId, jobId }
}

export async function updateQuickGenerateEpisodeNo(input: {
  episodeId: string
  episodeNo: number
}): Promise<{ episodeId: string; episodeNo: number }> {
  const res = await fetch(`/api/quick-generate/episodes/${encodeURIComponent(input.episodeId)}`, {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ episodeNo: input.episodeNo })
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "更新剧集编号失败")
  }
  const data = (json as ApiOk<unknown>).data as { episodeId?: unknown; episodeNo?: unknown } | null
  const episodeId = typeof data?.episodeId === "string" ? data.episodeId.trim() : ""
  const episodeNo = typeof data?.episodeNo === "number" && Number.isFinite(data.episodeNo) ? Math.trunc(data.episodeNo) : 0
  if (!episodeId || episodeNo <= 0) throw new Error("更新剧集编号失败：返回数据不完整")
  return { episodeId, episodeNo }
}

/**
 * 上传剧集源文件并提取纯文本，供“新增剧集”弹窗复用现有解析链路。
 */
export async function importQuickGenerateEpisodeText(file: File): Promise<ImportQuickGenerateEpisodeTextResult> {
  const formData = new FormData()
  formData.append("file", file)

  const res = await fetch("/api/quick-generate/episodes/import-text", {
    method: "POST",
    body: formData
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "导入文件失败")
  }

  const data = (json as ApiOk<unknown>).data as
    | { content?: unknown; fileName?: unknown; sourceKind?: unknown; charCount?: unknown }
    | null
  const content = typeof data?.content === "string" ? data.content : ""
  const fileName = typeof data?.fileName === "string" ? data.fileName.trim() : ""
  const sourceKind = data?.sourceKind
  const charCount = typeof data?.charCount === "number" && Number.isFinite(data.charCount) ? Math.trunc(data.charCount) : 0
  if (
    !content ||
    !fileName ||
    (sourceKind !== "pdf" && sourceKind !== "docx" && sourceKind !== "txt" && sourceKind !== "excel") ||
    charCount <= 0
  ) {
    throw new Error("导入文件失败：返回数据不完整")
  }

  return { content, fileName, sourceKind, charCount }
}

export async function deleteQuickGenerateEpisodes(episodeIds: string[]): Promise<void> {
  const res = await fetch(`/api/quick-generate/episodes?${buildDeleteIdsQuery(episodeIds)}`, {
    method: "DELETE"
  })

  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "删除剧集失败")
  }

  const json = await res.json().catch(() => null)
  if (!json?.ok) {
    throw new Error(json?.error?.message || "删除剧集失败")
  }
}

export async function updateQuickGenerateEpisodeShots(input: UpdateQuickGenerateEpisodeShotsInput): Promise<void> {
  const res = await fetch("/api/quick-generate/episodes", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })

  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "更新分镜失败")
  }

  const json = await res.json().catch(() => null)
  if (!json?.ok) {
    throw new Error(json?.error?.message || "更新分镜失败")
  }
}

export async function generateQuickGenerateEpisodeVideoPrompts(
  input: GenerateQuickGenerateEpisodeVideoPromptsInput
): Promise<GenerateQuickGenerateEpisodeVideoPromptsResult> {
  const res = await fetch("/api/quick-generate/episodes/video-prompts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })

  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "生成视频提示词失败")
  }

  const data = (json as ApiOk<unknown>).data as {
    jobId?: unknown
    queuedCount?: unknown
    skippedCount?: unknown
  } | null
  const jobId = String(data?.jobId ?? "").trim()
  if (!jobId) throw new Error("生成视频提示词失败：未返回 jobId")
  return {
    jobId,
    queuedCount: Number(data?.queuedCount ?? 0) || 0,
    skippedCount: Number(data?.skippedCount ?? 0) || 0
  }
}

export async function generateQuickGenerateEpisodePanelPrompts(
  input: GenerateQuickGenerateEpisodePanelPromptsInput
): Promise<GenerateQuickGenerateEpisodeVideoPromptsResult> {
  const res = await fetch("/api/quick-generate/episodes/panel-prompts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })

  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "生成分镜板提示词失败")
  }

  const data = (json as ApiOk<unknown>).data as {
    jobId?: unknown
    queuedCount?: unknown
    skippedCount?: unknown
  } | null
  const jobId = String(data?.jobId ?? "").trim()
  if (!jobId) throw new Error("生成分镜板提示词失败：未返回 jobId")
  return {
    jobId,
    queuedCount: Number(data?.queuedCount ?? 0) || 0,
    skippedCount: Number(data?.skippedCount ?? 0) || 0
  }
}

export async function generateQuickGenerateEpisodePanelImages(
  input: GenerateQuickGenerateEpisodePanelImagesInput
): Promise<GenerateQuickGenerateEpisodeVideoPromptsResult> {
  const res = await fetch("/api/quick-generate/episodes/panel-images", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })

  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "生成分镜板图片失败")
  }

  const data = (json as ApiOk<unknown>).data as {
    jobId?: unknown
    queuedCount?: unknown
    skippedCount?: unknown
    results?: Array<{ shotNo?: unknown; ok?: unknown; jobId?: unknown; errorMessage?: unknown }>
  } | null
  const fallbackJobId =
    Array.isArray(data?.results)
      ? data.results
          .map((item) => (typeof item?.jobId === "string" ? item.jobId.trim() : ""))
          .find(Boolean) ?? ""
      : ""
  const jobId = String(data?.jobId ?? "").trim() || fallbackJobId
  if (!jobId) throw new Error("生成分镜板图片失败：未返回 jobId")
  return {
    jobId,
    queuedCount: Number(data?.queuedCount ?? 0) || 0,
    skippedCount: Number(data?.skippedCount ?? 0) || 0
  }
}

export async function generateQuickGenerateEpisodeVideos(
  input: GenerateQuickGenerateEpisodeVideosInput
): Promise<GenerateQuickGenerateEpisodeVideosResult> {
  const res = await fetch("/api/quick-generate/episodes/video-generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })

  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "批量生成当前剧集视频失败")
  }

  const data = (json as ApiOk<unknown>).data as {
    queuedCount?: unknown
    processingCount?: unknown
    skippedCount?: unknown
    results?: Array<{ shotNo?: unknown; ok?: unknown; status?: unknown; jobId?: unknown; errorMessage?: unknown }>
  } | null

  return {
    queuedCount: Number(data?.queuedCount ?? 0) || 0,
    processingCount: Number(data?.processingCount ?? 0) || 0,
    skippedCount: Number(data?.skippedCount ?? 0) || 0,
    results: Array.isArray(data?.results)
      ? data.results.map((item) => ({
          shotNo: Number(item?.shotNo ?? 0) || 0,
          ok: Boolean(item?.ok),
          status: item?.status === "processing" ? "processing" : item?.status === "failed" ? "failed" : "queued",
          jobId: typeof item?.jobId === "string" ? item.jobId.trim() : undefined,
          errorMessage: typeof item?.errorMessage === "string" ? item.errorMessage.trim() : undefined
        }))
      : []
  }
}

export async function selectQuickGenerateShotVideo(input: SelectQuickGenerateShotVideoInput): Promise<void> {
  const res = await fetch("/api/quick-generate/episodes/video-selection", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "确认当前视频失败")
  }
}

export async function eraseQuickGenerateShotVideoSubtitle(input: EraseQuickGenerateShotVideoSubtitleInput): Promise<void> {
  const res = await fetch("/api/quick-generate/episodes/video-subtitle-erasure", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "提交字幕擦除任务失败")
  }
}

export async function exportQuickGenerateEpisodeToJianying(
  input: ExportQuickGenerateEpisodeToJianyingInput
): Promise<ExportQuickGenerateEpisodeToJianyingResult> {
  const res = await fetch("/api/quick-generate/episodes/exports/jianying", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...input, async: true })
  })
  const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "导出剪映工程失败")
  }

  const data = (json as ApiOk<unknown>).data as { jobId?: unknown; status?: unknown } | null
  const jobId = typeof data?.jobId === "string" ? data.jobId.trim() : ""
  const status = typeof data?.status === "string" ? data.status.trim() : ""
  if (!jobId) throw new Error("导出剪映工程失败：未返回 jobId")
  return { jobId, status }
}

export async function deleteQuickGenerateMaterials(ids: string[]): Promise<void> {
  const res = await fetch(`/api/quick-generate/materials?${buildDeleteIdsQuery(ids)}`, {
    method: "DELETE"
  })

  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "删除素材失败")
  }

  const json = await res.json()
  if (!json.ok) {
    throw new Error(json.error?.message || "删除素材失败")
  }
}
export async function updateQuickGenerateMaterialTitle(
  id: string,
  title: string
): Promise<QuickGenerateMaterial> {
  const res = await fetch("/api/quick-generate/materials", {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id, title })
  })

  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "更新素材名称失败")
  }

  const json = await res.json()
  if (!json.ok) {
    throw new Error(json.error?.message || "更新素材名称失败")
  }

 return json.data as QuickGenerateMaterial
}

export async function batchUpdateQuickGenerateMaterials(
  items: Array<{
    id: string
    title?: string | null
    materialType?: string
    voiceSpeakerId?: string | null
    voiceSpeakerName?: string | null
    assetId?: string | null
  }>
): Promise<void> {
  const res = await fetch("/api/quick-generate/materials/batch-update", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ items })
  })

  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "批量更新失败")
  }

  const json = await res.json()
  if (!json.ok) {
    throw new Error(json.error?.message || "批量更新失败")
  }
}

export async function batchReviewQuickGenerateMaterials(materialIds: string[]): Promise<void> {
  const res = await fetch("/api/quick-generate/materials/batch-review", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ materialIds })
  })
  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "批量提交审核失败")
  }
  const json = await res.json().catch(() => null)
  if (!json?.ok) throw new Error(json?.error?.message || "批量提交审核失败")
}

export async function batchRefreshQuickGenerateMaterialReviewStatus(materialIds: string[]): Promise<void> {
  const res = await fetch("/api/quick-generate/materials/batch-review-status", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ materialIds })
  })
  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "刷新审核状态失败")
  }
  const json = await res.json().catch(() => null)
  if (!json?.ok) throw new Error(json?.error?.message || "刷新审核状态失败")
}

export async function uploadQuickGenerateMaterial(
  storyId: string,
  materialType: string,
  file: File
): Promise<QuickGenerateMaterial> {
  const formData = new FormData()
  formData.append("storyId", storyId)
  formData.append("materialType", materialType)
  formData.append("file", file)

  const res = await fetch("/api/quick-generate/materials/upload", {
    method: "POST",
    body: formData
  })

  if (!res.ok) {
    const errorJson = await res.json().catch(() => ({}))
    throw new Error(errorJson?.error?.message || "上传素材失败")
  }

  const json = await res.json()
  if (!json.ok) {
    throw new Error(json.error?.message || "上传素材失败")
  }

  return json.data as QuickGenerateMaterial
}

type ListQuickGenerateCopyrightImportProjectsInput = {
  excludeStoryId: string
  category?: string
  reviewFilter?: CopyrightLibraryReviewFilter
  search?: string
}

export async function listQuickGenerateCopyrightImportProjects(
  input: ListQuickGenerateCopyrightImportProjectsInput
): Promise<CopyrightLibraryProject[]> {
  const qs = new URLSearchParams()
  qs.set("excludeStoryId", input.excludeStoryId)
  qs.set("includeEmpty", "false")
  qs.set("category", input.category?.trim() || "all")
  qs.set("reviewFilter", input.reviewFilter ?? "all")
  if (input.search?.trim()) qs.set("search", input.search.trim())

  const res = await fetch(`/api/library/copyright-projects?${qs.toString()}`, {
    cache: "no-store"
  })
  const json = (await res.json().catch(() => null)) as
    | ApiOk<{ projects?: CopyrightLibraryProject[] }>
    | ApiErr
    | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "加载版权库素材失败")
  }
  return Array.isArray((json as ApiOk<{ projects?: CopyrightLibraryProject[] }>).data?.projects)
    ? ((json as ApiOk<{ projects?: CopyrightLibraryProject[] }>).data.projects as CopyrightLibraryProject[])
    : []
}

export async function importQuickGenerateMaterialsFromCopyrightLibrary(input: {
  storyId: string
  items: Array<{ projectType: "quick_generate" | "canvas"; sourceMaterialId: string }>
}): Promise<{ importedCount: number }> {
  const res = await fetch("/api/quick-generate/materials/import-copyright-library", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = (await res.json().catch(() => null)) as ApiOk<{ importedCount?: number }> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "从版权库导入素材失败")
  }
  return {
    importedCount: Number((json as ApiOk<{ importedCount?: number }>).data?.importedCount ?? 0) || 0
  }
}

export async function aiGenerateQuickGenerateMaterials(input: {
  storyId: string
  materialType: "scene" | "character" | "prop"
  name: string
  prompt: string
  style?: string
}): Promise<{ createdCount: number }> {
  const res = await fetch("/api/quick-generate/materials/ai-generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(input)
  })
  const json = (await res.json().catch(() => null)) as ApiOk<{ createdCount?: number }> | ApiErr | null
  if (!res.ok || !json || (json as ApiErr).ok === false) {
    const errJson = (json as ApiErr | null) ?? null
    throw new Error(errJson?.error?.message ?? "AI 生成素材失败")
  }
  return {
    createdCount: Number((json as ApiOk<{ createdCount?: number }>).data?.createdCount ?? 0) || 0
  }
}
