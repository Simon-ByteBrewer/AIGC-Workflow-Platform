import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { importQuickGenerateMaterialsFromCopyrightLibrary } from "@/server/domains/quick-generate/usecases/importQuickGenerateMaterialsFromCopyrightLibrary"

export const runtime = "nodejs"

const postSchema = z
  .object({
    storyId: z.string().trim().min(1),
    items: z
      .array(
        z
          .object({
            projectType: z.enum(["quick_generate", "canvas"]),
            sourceMaterialId: z.string().trim().min(1)
          })
          .strict()
      )
      .min(1)
      .max(100)
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const result = await importQuickGenerateMaterialsFromCopyrightLibrary({
      traceId,
      userId,
      storyId: parsed.data.storyId,
      items: parsed.data.items
    })
    return NextResponse.json(makeApiOk(traceId, result), { status: 200 })
  } catch (error) {
    const anyErr = error as { message?: string; name?: string; stack?: string }
    const status =
      typeof (anyErr as { status?: unknown })?.status === "number" ? Number((anyErr as { status?: unknown }).status) : 500
    const code = String((anyErr as { code?: unknown })?.code ?? "").trim() || "UNKNOWN"
    logger.error({
      event: "quick_generate_materials_import_copyright_failed",
      module: "quick_generate",
      traceId,
      message: "从版权库导入素材失败",
      durationMs: Date.now() - start,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, code, anyErr?.message?.trim() || "从版权库导入素材失败"), { status })
  }
}
