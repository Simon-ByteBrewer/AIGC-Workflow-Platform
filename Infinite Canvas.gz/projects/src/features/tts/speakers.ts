import { TTS_SPEAKER_CATALOG, type TtsSpeaker } from "@/features/tts/speakerCatalog"

/**
 * 对外暴露的系统音色清单。
 * 初始化样音与前台列表都以该静态表为唯一可信源。
 */
export const TTS_SPEAKERS: TtsSpeaker[] = TTS_SPEAKER_CATALOG

/**
 * 初始化音色样音的固定文案。
 * 需要保证样音时长超过 1.8s，因此使用更长的口播文本。
 */
export const DEFAULT_TTS_TEST_TEXT = "你好，这是我的音色，这是我初始化的样音"

/**
 * 根据音色 ID 获取展示名称。
 * @param speakerId 音色 ID
 * @returns 命中的音色名称；未命中时返回 null
 */
export function getSpeakerName(speakerId: string): string | null {
  const hit = TTS_SPEAKERS.find((s) => s.id === speakerId)
  return hit?.name ?? null
}
