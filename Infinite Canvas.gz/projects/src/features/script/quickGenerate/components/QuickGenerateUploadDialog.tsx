"use client"

import { useEffect, useRef, useState, type ReactElement } from "react"
import { ArrowLeft } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/shared/ui/shadcn/dialog"
import { QuickGenerateAiGeneratePanel } from "./QuickGenerateAiGeneratePanel"
import { QuickGenerateCopyrightImportPanel } from "./QuickGenerateCopyrightImportPanel"
import styles from "./QuickGenerateUploadDialog.module.css"

type QuickGenerateUploadDialogProps = {
  open: boolean
  storyId: string
  onOpenChange: (open: boolean) => void
  onUpload: (files: File[], materialType: string) => Promise<void>
  onImported: (importedCount: number) => Promise<void> | void
  onAiGenerated: (createdCount: number) => Promise<void> | void
}

const MATERIAL_TYPES = [
  { id: "scene", name: "场景" },
  { id: "character", name: "人物" },
  { id: "prop", name: "物品" },
  { id: "video", name: "视频" },
  { id: "audio", name: "音频" },
]

export function QuickGenerateUploadDialog({
  open,
  storyId,
  onOpenChange,
  onUpload,
  onImported,
  onAiGenerated
}: QuickGenerateUploadDialogProps): ReactElement | null {
  const [selectedType, setSelectedType] = useState<string>("scene")
  const [uploading, setUploading] = useState(false)
  const [mode, setMode] = useState<"upload" | "copyrightImport" | "aiGenerate">("upload")
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!open) {
      setMode("upload")
    }
  }, [open])

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (files.length === 0) return

    try {
      setUploading(true)
      await onUpload(files, selectedType)
      onOpenChange(false)
    } catch (err) {
      alert(err instanceof Error ? err.message : "上传失败")
    } finally {
      setUploading(false)
      if (fileInputRef.current) {
        fileInputRef.current.value = ""
      }
    }
  }

  return (
    <Dialog open={open} onOpenChange={(val) => {
      if (uploading) return
      onOpenChange(val)
    }}>
      <DialogContent
        className={`${styles.dialog} ${mode === "copyrightImport" ? styles.dialogWide : mode === "aiGenerate" ? styles.dialogMedium : ""}`}
        overlayClassName={styles.overlay}
      >
        <DialogHeader className={styles.header}>
          <div className={styles.headerRow}>
            {mode !== "upload" ? (
              <button type="button" className={styles.backBtn} onClick={() => setMode("upload")} disabled={uploading}>
                <ArrowLeft size={16} />
                返回上传
              </button>
            ) : null}
            <DialogTitle className={styles.title}>
              {mode === "upload" ? "上传素材" : mode === "copyrightImport" ? "从版权库导入" : "AI生成素材"}
            </DialogTitle>
          </div>
        </DialogHeader>

        {mode === "upload" ? (
          <>
            <div className={styles.body}>
              <div className={styles.label}>选择上传分类</div>
              <div className={styles.typeGrid}>
                {MATERIAL_TYPES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    className={`${styles.typeBtn} ${selectedType === t.id ? styles.typeBtnActive : ""}`}
                    onClick={() => setSelectedType(t.id)}
                    disabled={uploading}
                  >
                    {t.name}
                  </button>
                ))}
              </div>

              <input
                type="file"
                multiple
                ref={fileInputRef}
                style={{ display: "none" }}
                onChange={handleFileChange}
                accept={selectedType === "video" ? "video/*" : selectedType === "audio" ? "audio/*" : "image/*"}
              />
            </div>

            <DialogFooter className={styles.footer}>
              <div className={styles.footerLeft}>
                <button type="button" className={styles.btnSecondary} disabled={uploading} onClick={() => setMode("copyrightImport")}>
                  从版权库导入
                </button>
                <button type="button" className={styles.btnSecondary} disabled={uploading} onClick={() => setMode("aiGenerate")}>
                  AI生成
                </button>
              </div>
              <div className={styles.footerRight}>
                <DialogClose asChild>
                  <button type="button" className={styles.btnSecondary} disabled={uploading}>
                    取消
                  </button>
                </DialogClose>
                <button
                  type="button"
                  className={styles.btnPrimary}
                  disabled={uploading}
                  onClick={() => fileInputRef.current?.click()}
                >
                  {uploading ? "上传中..." : "选择文件并上传"}
                </button>
              </div>
            </DialogFooter>
          </>
        ) : mode === "copyrightImport" ? (
          <QuickGenerateCopyrightImportPanel
            open={open}
            storyId={storyId}
            onImported={async (importedCount) => {
              await onImported(importedCount)
              onOpenChange(false)
            }}
          />
        ) : (
          <QuickGenerateAiGeneratePanel
            storyId={storyId}
            onGenerated={async (createdCount) => {
              await onAiGenerated(createdCount)
              onOpenChange(false)
            }}
          />
        )}
      </DialogContent>
    </Dialog>
  )
}
