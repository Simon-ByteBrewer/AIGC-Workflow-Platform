import { logger } from "@/shared/logger"
import { readEnvInt, readEnv } from "@/shared/env"

type CallCozeRunEndpointInput = {
  traceId: string
  url: string
  token: string
  body: unknown
  module: string
  timeoutMs?: number
}

export class CozeRunEndpointError extends Error {
  status?: number
  bodySnippet?: string
  errorCode?: string
  requestId?: string
  cozeMessage?: string

  constructor(message: string, input?: { status?: number; bodySnippet?: string; errorCode?: string; requestId?: string; cozeMessage?: string }) {
    super(message)
    this.name = "CozeRunEndpointError"
    this.status = input?.status
    this.bodySnippet = input?.bodySnippet
    this.errorCode = input?.errorCode
    this.requestId = input?.requestId
    this.cozeMessage = input?.cozeMessage
  }
}

type GateState = { inFlight: number; queue: Array<() => void> }

function getGateStore(): Map<string, GateState> {
  const g = globalThis as { __cozeRunGateStore?: Map<string, GateState> }
  if (!g.__cozeRunGateStore) g.__cozeRunGateStore = new Map()
  return g.__cozeRunGateStore
}

function getGateState(key: string): GateState {
  const store = getGateStore()
  let state = store.get(key)
  if (!state) {
    state = { inFlight: 0, queue: [] }
    store.set(key, state)
  }
  return state
}

function releaseGate(key: string): void {
  const state = getGateState(key)
  state.inFlight = Math.max(0, state.inFlight - 1)
  const next = state.queue.shift()
  if (next) next()
}

async function acquireGate(key: string, limit: number): Promise<() => void> {
  if (!Number.isFinite(limit) || limit <= 0) return () => {}
  const state = getGateState(key)
  if (state.inFlight < limit) {
    state.inFlight += 1
    return () => releaseGate(key)
  }
  return new Promise((resolve) => {
    state.queue.push(() => {
      state.inFlight += 1
      resolve(() => releaseGate(key))
    })
  })
}

function truncateForLog(text: string, limit: number): string {
  if (text.length <= limit) return text
  return `${text.slice(0, limit)}...`
}

function pickString(value: unknown): string | null {
  return typeof value === "string" && value.trim() ? value.trim() : null
}

function pickRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null
  return value as Record<string, unknown>
}

function normalizeCozeErrorPayload(payload: unknown): { message?: string; code?: string; requestId?: string } {
  const root = pickRecord(payload)
  if (!root) return {}

  const directMessage = pickString(root["message"]) ?? pickString(root["msg"]) ?? pickString(root["error_message"])
  const directCode = pickString(root["code"]) ?? pickString(root["error_code"]) ?? pickString(root["err_code"])
  const directRequestId = pickString(root["request_id"]) ?? pickString(root["requestId"]) ?? pickString(root["req_id"])

  const errorObj = pickRecord(root["error"])
  const errorMessage =
    pickString(errorObj?.["message"]) ??
    pickString(errorObj?.["msg"]) ??
    pickString(errorObj?.["error_message"]) ??
    pickString(errorObj?.["detail"])
  const errorCode = pickString(errorObj?.["code"]) ?? pickString(errorObj?.["error_code"]) ?? pickString(errorObj?.["err_code"])
  const errorRequestId = pickString(errorObj?.["request_id"]) ?? pickString(errorObj?.["requestId"]) ?? pickString(errorObj?.["req_id"])

  const dataObj = pickRecord(root["data"])
  const dataError = pickRecord(dataObj?.["error"])
  const dataMessage =
    pickString(dataObj?.["message"]) ??
    pickString(dataObj?.["msg"]) ??
    pickString(dataError?.["message"]) ??
    pickString(dataError?.["msg"]) ??
    pickString(dataError?.["error_message"])
  const dataCode = pickString(dataObj?.["code"]) ?? pickString(dataError?.["code"]) ?? pickString(dataError?.["error_code"])
  const dataRequestId = pickString(dataObj?.["request_id"]) ?? pickString(dataError?.["request_id"]) ?? pickString(dataObj?.["requestId"])

  const normalizedMessage = errorMessage ?? dataMessage ?? directMessage
  const normalizedCode = errorCode ?? dataCode ?? directCode
  const normalizedRequestId = errorRequestId ?? dataRequestId ?? directRequestId

  return { message: normalizedMessage ?? undefined, code: normalizedCode ?? undefined, requestId: normalizedRequestId ?? undefined }
}

function buildDisplayMessage(base: string, input: { status?: number; code?: string; requestId?: string; cozeMessage?: string; bodySnippet?: string }): string {
  const pieces: string[] = [base]
  if (typeof input.status === "number" && Number.isFinite(input.status)) pieces.push(`HTTP ${input.status}`)
  if (typeof input.code === "string" && input.code.trim()) pieces.push(`code=${input.code.trim()}`)
  if (typeof input.requestId === "string" && input.requestId.trim()) pieces.push(`requestId=${input.requestId.trim()}`)
  if (typeof input.cozeMessage === "string" && input.cozeMessage.trim()) pieces.push(input.cozeMessage.trim())
  const joined = pieces.join(" | ")
  if (joined.length <= 520) return joined
  return `${joined.slice(0, 520)}...`
}

function summarizeBodyForLog(body: unknown): { bodyType: string; bodyBytes?: number; topKeys?: string[] } {
  const bodyType = Array.isArray(body) ? "array" : body === null ? "null" : typeof body
  let bodyBytes: number | undefined
  let topKeys: string[] | undefined
  if (body && typeof body === "object" && !Array.isArray(body)) {
    topKeys = Object.keys(body as Record<string, unknown>).slice(0, 12)
  }
  try {
    const s = JSON.stringify(body)
    bodyBytes = Buffer.byteLength(s, "utf8")
  } catch {}
  return { bodyType, bodyBytes, topKeys }
}

function toStreamRunUrl(url: string): string {
  const trimmed = url.trim()
  if (!trimmed) return trimmed
  if (/\/stream_run$/u.test(trimmed)) return trimmed
  if (/\/run$/u.test(trimmed)) return trimmed.replace(/\/run$/u, "/stream_run")
  return trimmed
}

function normalizeStreamEventPayload(item: unknown): Record<string, unknown> | null {
  if (!item || typeof item !== "object" || Array.isArray(item)) return null
  const root = item as Record<string, unknown>
  const nested = root["data"]
  if (nested && typeof nested === "object" && !Array.isArray(nested)) {
    const nestedRecord = nested as Record<string, unknown>
    if (typeof nestedRecord["type"] === "string") return nestedRecord
  }
  if (typeof root["type"] === "string") return root
  return null
}

function pickWorkflowOutput(output: unknown): unknown {
  if (!output || typeof output !== "object" || Array.isArray(output)) return output
  const record = output as Record<string, unknown>
  if ("value" in record) return record["value"]
  return output
}

function parseSsePayload(rawText: string): unknown[] {
  const items: unknown[] = []
  const blocks = rawText.split("\n\n")
  for (const block of blocks) {
    const lines = block.split("\n")
    for (const line of lines) {
      const trimmed = line.trim()
      if (!trimmed.startsWith("data:")) continue
      const dataPart = trimmed.slice("data:".length).trim()
      if (!dataPart || dataPart === "[DONE]") continue
      try {
        items.push(JSON.parse(dataPart))
      } catch {}
    }
  }
  return items
}

function extractSseResult(items: unknown[]): { ok: true; data: unknown } | { ok: false; error: unknown } | null {
  if (items.length === 0) return null

  let errorPayload: unknown | undefined
  for (const item of items) {
    const payload = normalizeStreamEventPayload(item)
    if (!payload) continue
    const type = payload["type"]
    const content = payload["content"]

    if (type === "error") {
      const err =
        content && typeof content === "object" ? (content as Record<string, unknown>)["error"] : undefined
      errorPayload = err ?? payload
      break
    }

    if (content && typeof content === "object") {
      const err = (content as Record<string, unknown>)["error"]
      if (err) {
        errorPayload = err
        break
      }
    }
  }

  if (errorPayload) return { ok: false, error: errorPayload }

  // 优先查找 workflow_end 事件的 output 字段（Coze 分镜文本生成使用此格式）
  for (const item of items) {
    const payload = normalizeStreamEventPayload(item)
    if (!payload) continue
    if (payload["type"] === "workflow_end") {
      const output = pickWorkflowOutput(payload["output"])
      if (output && typeof output === "object") {
        return { ok: true, data: output }
      }
      if (typeof output === "string" && output.trim()) {
        try {
          const parsed = JSON.parse(output.trim())
          return { ok: true, data: parsed }
        } catch {}
      }
    }
  }

  // 查找 message_end 事件的 output 或 answer 字段
  let lastMessageEndError: unknown | undefined
  for (const item of items) {
    const payload = normalizeStreamEventPayload(item)
    if (!payload) continue
    if (payload["type"] === "message_end") {
      const content = payload["content"]
      if (content && typeof content === "object") {
        const messageEnd = (content as any)?.message_end
        if (messageEnd && typeof messageEnd === "object" && messageEnd.code === "500") {
          // 这是一个错误的 message_end，记录错误信息
          lastMessageEndError = messageEnd
          continue
        }
        // 优先尝试 output 字段
        const output = (content as any)?.output
        if (output && typeof output === "object") {
          return { ok: true, data: output }
        }
        if (typeof output === "string" && output.trim()) {
          try {
            const parsed = JSON.parse(output.trim())
            return { ok: true, data: parsed }
          } catch {}
        }
        // 如果没有 output 字段，尝试 answer 字段
        const answer = (content as any)?.answer
        if (typeof answer === "string" && answer.trim()) {
          try {
            const parsed = JSON.parse(answer.trim())
            return { ok: true, data: parsed }
          } catch {}
        }
      }
    }
  }

  // 兼容旧逻辑：拼接 answer 类型的文本
  let answerText = ""
  for (const item of items) {
    const payload = normalizeStreamEventPayload(item)
    if (!payload) continue
    if (payload["type"] !== "answer") continue
    const content = payload["content"]
    if (!content || typeof content !== "object") continue
    const chunk = (content as Record<string, unknown>)["answer"]
    if (typeof chunk === "string") answerText += chunk
  }

  const trimmed = answerText.trim()
  if (trimmed) {
    try {
      const parsed = JSON.parse(trimmed)
      return { ok: true, data: parsed }
    } catch {
      return { ok: true, data: trimmed }
    }
  }

  // 如果有 message_end 错误，返回错误而不是 fallback
  if (lastMessageEndError) {
    return { ok: false, error: lastMessageEndError }
  }

  const last = items[items.length - 1]
  return { ok: true, data: last }
}

export async function callCozeRunEndpoint(input: CallCozeRunEndpointInput): Promise<{
  status: number
  data: unknown
  durationMs: number
}> {
  const timeoutFromEnv = readEnvInt("REQUEST_TIMEOUT_MS")
  const resolvedTimeoutMs = input.timeoutMs ?? timeoutFromEnv ?? 60_000
  const maxAttemptsFromEnv = readEnvInt("COZE_RUN_RETRY_MAX_ATTEMPTS")
  const concurrencyLimit = readEnvInt("COZE_RUN_MAX_CONCURRENCY") ?? 0
  const jitterMaxMs = readEnvInt("COZE_RUN_JITTER_MAX_MS") ?? 0
  
  // 分镜文本生成需要重试，因为 Coze 网关可能超时
  // 分镜脚本生成不进行重试
  const resolvedMaxAttempts = (() => {
    const raw = typeof maxAttemptsFromEnv === "number" && Number.isFinite(maxAttemptsFromEnv) ? Math.trunc(maxAttemptsFromEnv) : 3
    const defaultMax = Math.max(1, Math.min(5, raw))

    // 分镜文本生成任务（CREATE_STORYBOARD_TEXT_URL）强制重试至少 3 次
    const storyboardTextUrl = readEnv("CREATE_STORYBOARD_TEXT_URL")
    const isStoryboardTextTask = input.module === "coze" && storyboardTextUrl && input.url === storyboardTextUrl

    if (isStoryboardTextTask) {
      return Math.max(3, defaultMax)
    }

    return defaultMax
  })()
  
  const { traceId, url, token, body, module } = input
  const start = Date.now()

  // 需要使用流式接口的任务：分镜文本生成、分镜脚本生成、素材规划、素材渲染、首帧图合成、ROLE_API文本解析、ROLE_IMG_API生成
  const storyboardTextUrl = readEnv("CREATE_STORYBOARD_TEXT_URL")
  const scriptApiUrl = readEnv("SCRIPT_API_URL")
  const materialPlanUrl = readEnv("EPISODE_MATERIAL_PLAN_API_URL")
  const materialRenderUrl = readEnv("EPISODE_MATERIAL_RENDER_API_URL")
  const imageComposeUrl = readEnv("IMAGE_COMPOSE_API_URL")
  const roleApiUrl = readEnv("ROLE_API_URL")
  const roleImgApiUrl = readEnv("ROLE_IMG_API_URL")
  const roleImageApiUrl = readEnv("ROLE_IMAGE_API_URL")
  const promptApiUrl = readEnv("PROMPT_API_URL")

  const isStoryboardTextTask = Boolean(storyboardTextUrl && url === storyboardTextUrl)
  const isScriptTask = module === "coze_script" && scriptApiUrl && url === scriptApiUrl
  const isMaterialPlanTask = Boolean(materialPlanUrl && url === materialPlanUrl)
  const isMaterialRenderTask = Boolean(materialRenderUrl && url === materialRenderUrl)
  const isImageComposeTask = Boolean(imageComposeUrl && url === imageComposeUrl)
  const isRoleApiTask = Boolean(roleApiUrl && url === roleApiUrl)
  const isRoleImgApiTask = Boolean((roleImgApiUrl && url === roleImgApiUrl) || (roleImageApiUrl && url === roleImageApiUrl))
  const isPromptApiTask = module === "coze" && promptApiUrl && url === promptApiUrl

  // 对支持流式接口的任务启用流式：分镜文本、素材规划、素材渲染、首帧图合成、ROLE_API文本解析、ROLE_IMG_API/ROLE_IMAGE_API生成
  // 分镜脚本生成（SCRIPT_API_URL）暂时不支持流式接口，使用普通接口
  // 提示词生成（PROMPT_API_URL）暂时不支持流式接口，因为返回的是markdown格式文本而非JSON对象
  const shouldUseStream = isStoryboardTextTask || isMaterialPlanTask || isMaterialRenderTask || isImageComposeTask || isRoleApiTask || isRoleImgApiTask // || isPromptApiTask
  const effectiveUrl = shouldUseStream ? toStreamRunUrl(url) : url

  let host = "unknown"
  let pathname = ""
  try {
    const u = new URL(effectiveUrl)
    host = u.host
    pathname = u.pathname
  } catch {}

  logger.info({
    event: "coze_run_request_start",
    module,
    traceId,
    message: shouldUseStream ? "开始请求 Coze run endpoint（流式）" : "开始请求 Coze run endpoint",
    host,
    path: pathname,
    isStream: shouldUseStream,
    originalUrl: url,
    effectiveUrl: effectiveUrl,
    ...summarizeBodyForLog(body),
    timeoutMs: resolvedTimeoutMs,
    bodyPreview: typeof body === "object" && body !== null ? JSON.stringify(body).slice(0, 2000) : String(body).slice(0, 200)
  })

  try {
    const gateKey = "coze_run_global"
    const shouldRetryStatus = (status: number) => status === 429 || status === 502 || status === 503 || status === 504
    const computeDelayMs = (attempt: number) => {
      const base = 450
      const cap = 2000
      const exp = Math.min(cap, Math.trunc(base * Math.pow(2, Math.max(0, attempt - 1))))
      const jitter = Math.trunc(Math.random() * 160)
      return Math.max(0, exp + jitter)
    }
    const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms))

    let lastError: unknown = null
    for (let attempt = 1; attempt <= resolvedMaxAttempts; attempt += 1) {
      const controller = new AbortController()
      const timer = setTimeout(() => controller.abort(), resolvedTimeoutMs)
      let release: (() => void) | null = null
      try {
        release = await acquireGate(gateKey, concurrencyLimit)
        if (jitterMaxMs > 0) {
          const jitterMs = Math.trunc(Math.random() * jitterMaxMs)
          if (jitterMs > 0) await sleep(jitterMs)
        }
        const resp = await fetch(effectiveUrl, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            ...(shouldUseStream ? { accept: "text/event-stream" } : {}),
            authorization: `Bearer ${token}`
          },
          body: JSON.stringify(body),
          signal: controller.signal
        })

        const durationMs = Date.now() - start
        const contentType = resp.headers.get("content-type") ?? ""
        
        // 流式读取 SSE 响应，避免长时间等待导致的超时问题
        let rawText: string
        if (contentType.includes("text/event-stream")) {
          if (!resp.body) {
            throw new Error("Response body is empty")
          }
          const reader = resp.body.getReader()
          const decoder = new TextDecoder()
          rawText = ""
          
          // 逐块读取所有数据
          while (true) {
            const { done, value } = await reader.read()
            if (done) break
            rawText += decoder.decode(value, { stream: true })
          }
        } else {
          rawText = await resp.text()
        }

        if (!resp.ok) {
          let parsed: unknown = rawText
          try {
            parsed = JSON.parse(rawText)
          } catch {
            parsed = rawText
          }

          const bodySnippet =
            typeof parsed === "string" ? truncateForLog(parsed, 1200) : truncateForLog(JSON.stringify(parsed), 1200)
          const normalized = normalizeCozeErrorPayload(parsed)
          const err = new CozeRunEndpointError(buildDisplayMessage("Coze run endpoint 请求失败", {
            status: resp.status,
            code: normalized.code,
            requestId: normalized.requestId,
            cozeMessage: normalized.message,
            bodySnippet
          }), {
            status: resp.status,
            bodySnippet,
            errorCode: normalized.code,
            requestId: normalized.requestId,
            cozeMessage: normalized.message
          })

          if (attempt < resolvedMaxAttempts && shouldRetryStatus(resp.status)) {
            lastError = err
            const waitMs = computeDelayMs(attempt)
            logger.warn({
              event: "coze_run_request_retry",
              module,
              traceId,
              message: "Coze run endpoint 将重试（非 2xx）",
              host,
              path: pathname,
              status: resp.status,
              durationMs,
              attempt,
              maxAttempts: resolvedMaxAttempts,
              waitMs,
              cozeErrorCode: normalized.code,
              cozeErrorMessage: normalized.message,
              cozeRequestId: normalized.requestId
            })
            await sleep(waitMs)
            continue
          }

          logger.error({
            event: "coze_run_request_failed",
            module,
            traceId,
            message: "Coze run endpoint 请求失败",
            host,
            path: pathname,
            status: resp.status,
            durationMs,
            bodySnippet,
            cozeErrorCode: normalized.code,
            cozeErrorMessage: normalized.message,
            cozeRequestId: normalized.requestId
          })

          throw err
        }

        // 解析 SSE 数据并继续原有路径
        if (contentType.includes("text/event-stream")) {
          const items = parseSsePayload(rawText)
          const extracted = extractSseResult(items)

          if (!extracted) {
            const bodySnippet = truncateForLog(rawText, 1200)
            const err = new CozeRunEndpointError("Coze SSE 回包解析失败", {
              status: resp.status,
              bodySnippet
            })
            lastError = err
            logger.error({
              event: "coze_run_request_failed",
              module,
              traceId,
              message: "Coze SSE 回包解析失败",
              host,
              path: pathname,
              status: resp.status,
              durationMs,
              bodySnippet
            })
            throw err
          }

          if (!extracted.ok) {
            const normalized = normalizeCozeErrorPayload(extracted.error)
            const bodySnippet = truncateForLog(JSON.stringify(extracted.error), 1200)
            const err = new CozeRunEndpointError(buildDisplayMessage("Coze run endpoint 返回错误", {
              status: resp.status,
              code: normalized.code,
              requestId: normalized.requestId,
              cozeMessage: normalized.message,
              bodySnippet
            }), {
              status: resp.status,
              bodySnippet,
              errorCode: normalized.code,
              requestId: normalized.requestId,
              cozeMessage: normalized.message
            })
            lastError = err
            logger.error({
              event: "coze_run_request_failed",
              module,
              traceId,
              message: "Coze SSE 返回错误",
              host,
              path: pathname,
              status: resp.status,
              durationMs,
              bodySnippet,
              cozeErrorCode: normalized.code,
              cozeErrorMessage: normalized.message,
              cozeRequestId: normalized.requestId
            })
            throw err
          }

          logger.info({
            event: "coze_run_request_success",
            module,
            traceId,
            message: "Coze run endpoint 请求成功（流式）",
            host,
            path: pathname,
            status: resp.status,
            durationMs,
            attempt,
            maxAttempts: resolvedMaxAttempts,
            itemsCount: items.length,
            dataType: typeof extracted.data,
            dataPreview: typeof extracted.data === "object" && extracted.data !== null ? JSON.stringify(extracted.data).slice(0, 200) : String(extracted.data).slice(0, 200)
          })

          return { status: resp.status, data: extracted.data, durationMs }
        }

        let parsed: unknown = rawText
        try {
          parsed = JSON.parse(rawText)
        } catch {
          parsed = rawText
        }

        logger.info({
          event: "coze_run_request_success",
          module,
          traceId,
          message: "Coze run endpoint 请求成功",
          host,
          path: pathname,
          status: resp.status,
          durationMs,
          attempt,
          maxAttempts: resolvedMaxAttempts
        })

        return { status: resp.status, data: parsed, durationMs }
      } catch (err) {
        const durationMs = Date.now() - start
        const anyErr = err as { name?: string; message?: string; stack?: string }
        const isAbort = anyErr?.name === "AbortError"

        if (attempt < resolvedMaxAttempts && !isAbort && !(err instanceof CozeRunEndpointError)) {
          lastError = err
          const waitMs = computeDelayMs(attempt)
          logger.warn({
            event: "coze_run_request_retry",
            module,
            traceId,
            message: "Coze run endpoint 将重试（请求异常）",
            host,
            path: pathname,
            durationMs,
            attempt,
            maxAttempts: resolvedMaxAttempts,
            waitMs,
            errorName: anyErr?.name,
            errorMessage: anyErr?.message
          })
          await sleep(waitMs)
          continue
        }

        logger.error({
          event: "coze_run_request_error",
          module,
          traceId,
          message: isAbort ? "Coze run endpoint 请求超时" : "Coze run endpoint 请求异常",
          host,
          path: pathname,
          durationMs,
          timeoutMs: resolvedTimeoutMs,
          attempt,
          maxAttempts: resolvedMaxAttempts,
          errorName: anyErr?.name,
          errorMessage: anyErr?.message,
          stack: anyErr?.stack
        })

        if (err instanceof CozeRunEndpointError) throw err
        
        // 构建更详细的错误信息
        const userFriendlyMessage = isAbort 
          ? "生成超时，请稍后重试" 
          : anyErr?.message?.toLowerCase().includes("idle timeout")
            ? "服务处理超时，请稍后重试"
            : anyErr?.message?.toLowerCase().includes("connection")
              ? "网络连接失败，请检查网络后重试"
              : "生成失败，请稍后重试"
        
        throw new CozeRunEndpointError(userFriendlyMessage)
      } finally {
        if (release) release()
        clearTimeout(timer)
      }
    }

    const durationMs = Date.now() - start
    logger.error({
      event: "coze_run_request_error",
      module,
      traceId,
      message: "Coze run endpoint 请求失败（达到最大重试次数）",
      host,
      path: pathname,
      durationMs,
      timeoutMs: resolvedTimeoutMs,
      maxAttempts: resolvedMaxAttempts
    })
    if (lastError instanceof CozeRunEndpointError) throw lastError
    throw new CozeRunEndpointError("Coze run endpoint 请求失败（达到最大重试次数）")
  } catch (err) {
    if (err instanceof CozeRunEndpointError) throw err
    const durationMs = Date.now() - start
    const anyErr = err as { name?: string; message?: string; stack?: string }
    const isAbort = anyErr?.name === "AbortError"

    logger.error({
      event: "coze_run_request_error",
      module,
      traceId,
      message: isAbort ? "Coze run endpoint 请求超时" : "Coze run endpoint 请求异常",
      host,
      path: pathname,
      durationMs,
      timeoutMs: resolvedTimeoutMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })

    // 构建更详细的错误信息
    const userFriendlyMessage = isAbort 
      ? "生成超时，请稍后重试" 
      : anyErr?.message?.toLowerCase().includes("idle timeout")
        ? "服务处理超时，请稍后重试"
        : anyErr?.message?.toLowerCase().includes("connection")
          ? "网络连接失败，请检查网络后重试"
          : "生成失败，请稍后重试"
    
    throw new CozeRunEndpointError(userFriendlyMessage)
  }
}
