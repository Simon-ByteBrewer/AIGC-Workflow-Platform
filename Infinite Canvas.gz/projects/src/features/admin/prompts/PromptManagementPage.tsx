"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import { PromptEditorModal } from "./PromptEditorModal"
import type { PromptManagementGroup, PromptManagementItem, PromptManagementUser, PromptType } from "./types"
import styles from "./PromptManagementPage.module.css"

/**
 * 组内提示词管理页。
 * admin 可跨组查看与创建，group_admin 仅能管理自己组内的提示词与成员勾选。
 */
type ApiOk<T> = { ok: true; data: T; traceId: string }
type ApiErr = { ok: false; error: { code: string; message: string }; traceId: string }

type PromptManagementResult = ApiOk<{
  actor: { roleKey: string; groupId: string | null }
  groups: PromptManagementGroup[]
  usersByGroupId: Record<string, PromptManagementUser[]>
  items: PromptManagementItem[]
}> | ApiErr

type PromptDraft = {
  id?: string
  name: string
  content: string
  promptType: PromptType
  assignmentMode: "group" | "user"
  ownerGroupId: string
  groupIds: string[]
  userIds: string[]
}

type PromptFilters = {
  promptType: "all" | PromptType
  status: "all" | "active" | "inactive"
  maintainer: string
  updatedFrom: string
  updatedTo: string
}

const RAW_ERROR_PATTERNS = [/failed query:/i, /\binsert into\b/i, /\bupdate\b[\s\S]*\bset\b/i, /\bconstraint\b/i, /\bviolates\b/i]

function toSafePageErrorMessage(input: unknown, fallback: string): string {
  const message = input instanceof Error ? input.message : String(input ?? "").trim()
  if (!message) return fallback
  if (RAW_ERROR_PATTERNS.some((pattern) => pattern.test(message))) return fallback
  return message
}

function fmtTime(value: string): string {
  const date = new Date(value)
  if (!Number.isFinite(date.getTime())) return value
  return date.toLocaleString()
}

function isWithinDateRange(value: string, from: string, to: string): boolean {
  const target = new Date(value)
  if (!Number.isFinite(target.getTime())) return false

  if (from) {
    const fromDate = new Date(`${from}T00:00:00`)
    if (Number.isFinite(fromDate.getTime()) && target < fromDate) return false
  }
  if (to) {
    const toDate = new Date(`${to}T23:59:59.999`)
    if (Number.isFinite(toDate.getTime()) && target > toDate) return false
  }
  return true
}

function makeCreateDraft(roleKey: string, groupId: string | null, groups: PromptManagementGroup[], usersByGroupId: Record<string, PromptManagementUser[]>): PromptDraft {
  const defaultGroupId = groupId ?? groups[0]?.id ?? ""
  const defaultUsers = (usersByGroupId[defaultGroupId] ?? []).map((item) => item.id)
  return {
    name: "",
    content: "",
    promptType: "storyboard",
    assignmentMode: roleKey === "admin" ? "group" : "user",
    ownerGroupId: defaultGroupId,
    groupIds: roleKey === "admin" ? groups.map((item) => item.id) : [defaultGroupId].filter(Boolean),
    userIds: defaultUsers
  }
}

export function PromptManagementPage(): ReactElement {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [actorRoleKey, setActorRoleKey] = useState<string>("user")
  const [actorGroupId, setActorGroupId] = useState<string | null>(null)
  const [groups, setGroups] = useState<PromptManagementGroup[]>([])
  const [usersByGroupId, setUsersByGroupId] = useState<Record<string, PromptManagementUser[]>>({})
  const [items, setItems] = useState<PromptManagementItem[]>([])
  const [editorOpen, setEditorOpen] = useState(false)
  const [draft, setDraft] = useState<PromptDraft | null>(null)
  const [filters, setFilters] = useState<PromptFilters>({
    promptType: "all",
    status: "all",
    maintainer: "",
    updatedFrom: "",
    updatedTo: ""
  })

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/admin/prompts", { method: "GET" })
      const json = (await res.json()) as PromptManagementResult
      if (!json.ok) throw new Error(json.error.message)
      setActorRoleKey(json.data.actor.roleKey)
      setActorGroupId(json.data.actor.groupId)
      setGroups(json.data.groups ?? [])
      setUsersByGroupId(json.data.usersByGroupId ?? {})
      setItems(json.data.items ?? [])
    } catch (e) {
      setError(toSafePageErrorMessage(e, "加载提示词管理数据失败"))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const filteredItems = useMemo(() => {
    const maintainerKeyword = filters.maintainer.trim().toLowerCase()
    return items.filter((item) => {
      if (filters.promptType !== "all" && item.promptType !== filters.promptType) return false
      if (filters.status === "active" && !item.isActive) return false
      if (filters.status === "inactive" && item.isActive) return false
      if (maintainerKeyword && !(item.updatedByAccount ?? "").toLowerCase().includes(maintainerKeyword)) return false
      if (!isWithinDateRange(item.updatedAt, filters.updatedFrom, filters.updatedTo)) return false
      return true
    })
  }, [filters, items])

  const title = useMemo(() => `提示词管理（${filteredItems.length}）`, [filteredItems.length])
  const showAdminColumns = actorRoleKey === "admin"
  const currentUsers = draft?.ownerGroupId ? usersByGroupId[draft.ownerGroupId] ?? [] : []
  const hasActiveFilters = Boolean(
    filters.promptType !== "all" || filters.status !== "all" || filters.maintainer.trim() || filters.updatedFrom || filters.updatedTo
  )

  const openCreate = useCallback(() => {
    setDraft(makeCreateDraft(actorRoleKey, actorGroupId, groups, usersByGroupId))
    setEditorOpen(true)
  }, [actorGroupId, actorRoleKey, groups, usersByGroupId])

  const openEdit = useCallback((item: PromptManagementItem) => {
    setDraft({
      id: item.id,
      name: item.name,
      content: item.content,
      promptType: item.promptType,
      assignmentMode: item.assignmentMode,
      ownerGroupId: item.ownerGroupId ?? actorGroupId ?? "",
      groupIds: item.assignedGroupIds,
      userIds: item.assignedUserIds
    })
    setEditorOpen(true)
  }, [actorGroupId])

  const closeEditor = useCallback(() => {
    if (saving) return
    setEditorOpen(false)
    setDraft(null)
  }, [saving])

  const updateDraft = useCallback((patch: Partial<PromptDraft>) => {
    setDraft((current) => (current ? { ...current, ...patch } : current))
  }, [])

  const changeDraftOwnerGroup = useCallback(
    (groupId: string) => {
      const nextUsers = (usersByGroupId[groupId] ?? []).map((item) => item.id)
      setDraft((current) => (current ? { ...current, ownerGroupId: groupId, userIds: nextUsers } : current))
    },
    [usersByGroupId]
  )

  const changeDraftGroupIds = useCallback((groupIds: string[]) => {
    setDraft((current) => (current ? { ...current, groupIds } : current))
  }, [])

  const updateFilters = useCallback((patch: Partial<PromptFilters>) => {
    setFilters((current) => ({ ...current, ...patch }))
  }, [])

  const resetFilters = useCallback(() => {
    setFilters({
      promptType: "all",
      status: "all",
      maintainer: "",
      updatedFrom: "",
      updatedTo: ""
    })
  }, [])

  const saveDraft = useCallback(async () => {
    if (!draft || saving) return
    setSaving(true)
    setError(null)
    try {
      const payload: Record<string, unknown> = {
        name: draft.name.trim(),
        content: draft.content.trim(),
        promptType: draft.promptType
      }
      if (actorRoleKey === "admin" && draft.assignmentMode === "group") payload.groupIds = Array.from(new Set(draft.groupIds))
      if (actorRoleKey === "group_admin") payload.userIds = Array.from(new Set(draft.userIds))
      const res = await fetch(draft.id ? `/api/admin/prompts/${encodeURIComponent(draft.id)}` : "/api/admin/prompts", {
        method: draft.id ? "PATCH" : "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      })
      const json = (await res.json()) as PromptManagementResult
      if (!json.ok) throw new Error(json.error.message)
      setActorRoleKey(json.data.actor.roleKey)
      setActorGroupId(json.data.actor.groupId)
      setGroups(json.data.groups ?? [])
      setUsersByGroupId(json.data.usersByGroupId ?? {})
      setItems(json.data.items ?? [])
      setEditorOpen(false)
      setDraft(null)
    } catch (e) {
      setError(toSafePageErrorMessage(e, "保存提示词失败，请稍后重试"))
    } finally {
      setSaving(false)
    }
  }, [actorRoleKey, draft, saving])

  const toggleStatus = useCallback(
    async (item: PromptManagementItem) => {
      if (saving) return
      setSaving(true)
      setError(null)
      try {
        const res = await fetch(`/api/admin/prompts/${encodeURIComponent(item.id)}`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ isActive: !item.isActive })
        })
        const json = (await res.json()) as PromptManagementResult
        if (!json.ok) throw new Error(json.error.message)
        setActorRoleKey(json.data.actor.roleKey)
        setActorGroupId(json.data.actor.groupId)
        setGroups(json.data.groups ?? [])
        setUsersByGroupId(json.data.usersByGroupId ?? {})
        setItems(json.data.items ?? [])
      } catch (e) {
        setError(toSafePageErrorMessage(e, "更新提示词状态失败，请稍后重试"))
      } finally {
        setSaving(false)
      }
    },
    [saving]
  )

  return (
    <main className={styles.page}>
      <div className={styles.topBar}>
        <div className={styles.topTitle}>{title}</div>
        <div className={styles.topActions}>
          <button type="button" className={styles.topBtn} onClick={() => void load()} disabled={loading || saving}>
            刷新
          </button>
          <button type="button" className={styles.topBtnPrimary} onClick={openCreate} disabled={loading || saving || groups.length === 0}>
            新增提示词
          </button>
        </div>
      </div>

      {error ? <div className={styles.error}>{error}</div> : null}

      <section className={styles.panel} aria-label="提示词列表">
        <div className={styles.filterBar}>
          <label className={styles.filterField}>
            <span className={styles.filterLabel}>提示词类型</span>
            <select className={styles.filterInput} value={filters.promptType} onChange={(e) => updateFilters({ promptType: e.target.value as PromptFilters["promptType"] })}>
              <option value="all">全部</option>
              <option value="storyboard">拆分镜提示词</option>
              <option value="video">视频提示词</option>
              <option value="storyboard_panel">分镜板提示词</option>
            </select>
          </label>

          <label className={styles.filterField}>
            <span className={styles.filterLabel}>状态</span>
            <select className={styles.filterInput} value={filters.status} onChange={(e) => updateFilters({ status: e.target.value as PromptFilters["status"] })}>
              <option value="all">全部</option>
              <option value="active">启用</option>
              <option value="inactive">禁用</option>
            </select>
          </label>

          <label className={styles.filterField}>
            <span className={styles.filterLabel}>维护人</span>
            <input
              className={styles.filterInput}
              value={filters.maintainer}
              onChange={(e) => updateFilters({ maintainer: e.target.value })}
              placeholder="输入维护人账号"
            />
          </label>

          <label className={styles.filterField}>
            <span className={styles.filterLabel}>维护时间起</span>
            <input className={styles.filterInput} type="date" value={filters.updatedFrom} onChange={(e) => updateFilters({ updatedFrom: e.target.value })} />
          </label>

          <label className={styles.filterField}>
            <span className={styles.filterLabel}>维护时间止</span>
            <input className={styles.filterInput} type="date" value={filters.updatedTo} onChange={(e) => updateFilters({ updatedTo: e.target.value })} />
          </label>

          <div className={styles.filterActions}>
            <button type="button" className={styles.topBtn} onClick={resetFilters} disabled={!hasActiveFilters}>
              重置筛选
            </button>
          </div>
        </div>

        <div className={styles.table}>
          <div className={`${styles.tr} ${styles.th} ${showAdminColumns ? styles.promptGridAdmin : styles.promptGridGroup}`}>
            {showAdminColumns ? <div>来源</div> : null}
            <div>提示词类型</div>
            <div>提示词名称</div>
            {showAdminColumns ? <div>应用分组范围</div> : <div>组内使用人</div>}
            <div>维护人</div>
            <div>维护时间</div>
            <div>状态</div>
            <div>操作</div>
          </div>

          {filteredItems.map((item) => (
            <div key={item.id} className={`${styles.tr} ${styles.row} ${showAdminColumns ? styles.promptGridAdmin : styles.promptGridGroup}`}>
              {showAdminColumns ? <div className={styles.muted}>{item.sourceLabel}</div> : null}
              <div>{item.promptType === "storyboard" ? "拆分镜提示词" : item.promptType === "storyboard_panel" ? "分镜板提示词" : "视频提示词"}</div>
              <div className={styles.strong}>{item.name}</div>
              {showAdminColumns ? (
                <div className={styles.userSummary} title={item.assignedGroupNames.join("、")}>
                  {item.assignedGroupNames.length > 0 ? item.assignedGroupNames.join("、") : "未分配"}
                </div>
              ) : (
                <div className={styles.userSummary} title={item.assignedUserAccounts.join("、")}>
                  {item.assignedUserAccounts.length > 0 ? item.assignedUserAccounts.join("、") : "未分配"}
                </div>
              )}
              <div className={styles.muted}>{item.updatedByAccount ?? "-"}</div>
              <div className={styles.muted}>{fmtTime(item.updatedAt)}</div>
              <div className={item.isActive ? styles.ok : styles.bad}>{item.isActive ? "启用" : "禁用"}</div>
              <div className={styles.rowActionButtons}>
                <button type="button" className={styles.topBtn} onClick={() => openEdit(item)} disabled={saving}>
                  编辑提示词
                </button>
                <button type="button" className={item.isActive ? styles.dangerBtn : styles.topBtnPrimary} onClick={() => void toggleStatus(item)} disabled={saving}>
                  {item.isActive ? "禁用" : "启用"}
                </button>
              </div>
            </div>
          ))}

          {!loading && items.length === 0 ? <div className={styles.muted}>暂无提示词，点击右上角新增一条。</div> : null}
          {!loading && items.length > 0 && filteredItems.length === 0 ? <div className={styles.muted}>没有符合当前筛选条件的提示词。</div> : null}
          {loading ? <div className={styles.muted}>加载中…</div> : null}
        </div>
      </section>

      <PromptEditorModal
        open={editorOpen}
        title={draft?.id ? "编辑提示词" : "新增提示词"}
        saving={saving}
        isEdit={Boolean(draft?.id)}
        actorRoleKey={actorRoleKey}
        draft={draft ?? makeCreateDraft(actorRoleKey, actorGroupId, groups, usersByGroupId)}
        groups={groups}
        users={currentUsers}
        onClose={closeEditor}
        onSave={() => void saveDraft()}
        onDraftChange={updateDraft}
        onGroupChange={changeDraftOwnerGroup}
        onGroupIdsChange={changeDraftGroupIds}
      />
    </main>
  )
}
