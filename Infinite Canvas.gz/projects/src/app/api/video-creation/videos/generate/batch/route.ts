import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq, inArray } from "drizzle-orm"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"
import { generateVideoCreationVideo } from "@/server/domains/video-creation/usecases/videos/generateVideo"
import { kickVideoGenerateWorker } from "@/server/domains/video-creation/jobs/videoGenerateWorker"
import { enqueueCanvasVideoGenerateJob } from "@/server/domains/video/canvas/jobs/canvasVideoGenerateWorker"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { listEnabledVideoModelsForUser } from "@/server/domains/video/videoModelResolver"
import { videoFileLogger } from "@/server/domains/video/logging/videoFileLogger"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  storyboardIds: z.array(z.string().trim().min(1).max(200)).min(1).max(200),
  count: z.coerce.number().int().min(1).max(3).optional(),
  overwrite: z.boolean().optional(),
  generate_audio: z.boolean().optional(),
  generateAudio: z.boolean().optional(),
  modelNameById: z.record(z.string(), z.string().trim().min(1).max(100)).optional(),
  modelNameDefault: z.string().trim().min(1).max(100).optional(),
  // Legacy fields kept for backward compatibility (ignored/migrated to first available).
  modelById: z.record(z.string(), z.enum(["seedance1.5", "seedance2.0"])).optional(),
  modelDefault: z.enum(["seedance1.5", "seedance2.0"]).optional(),
  modeById: z.record(z.string(), z.enum(["first_frame", "reference"])).optional(),
  modeDefault: z.enum(["first_frame", "reference"]).optional(),
  referencesById: z
    .record(
      z.string(),
      z.object({
        images: z.array(z.object({ url: z.string(), name: z.string() })),
        audios: z.array(z.object({ url: z.string(), name: z.string() })),
        videos: z.array(z.object({ url: z.string(), name: z.string() }))
      })
    )
    .optional()
})

function clampInt(n: unknown, min: number, max: number, fallback: number): number {
  const v = Number(n)
  if (!Number.isFinite(v)) return fallback
  return Math.max(min, Math.min(max, Math.floor(v)))
}

function normalizeModelName(raw: unknown, enabled: Set<string>, fallback: string): string {
  const s = typeof raw === "string" ? raw.trim() : ""
  if (!s) return fallback
  // Legacy "seedanceX.Y" selection is no longer supported; migrate to first available.
  if (s === "seedance1.5" || s === "seedance2.0") return fallback
  return enabled.has(s) ? s : fallback
}

function isSafeAssetId(id: string): boolean {
  const v = (id ?? "").toString().trim()
  if (!v) return false
  return v.startsWith("asset-") && /^[a-zA-Z0-9._-]{1,200}$/u.test(v)
}

function normalizeAssetUrl(raw: unknown): string {
  const s = (raw ?? "").toString().trim()
  if (!s) return ""
  if (s.startsWith("asset://")) {
    const m = s.match(/^asset:\/\/(.+)$/u)
    const id = String(m?.[1] ?? "").trim()
    return isSafeAssetId(id) ? `asset://${id}` : ""
  }
  return isSafeAssetId(s) ? `asset://${s}` : ""
}

function toRolePrimaryName(raw: unknown): string {
  const name = typeof raw === "string" ? raw.trim() : ""
  if (!name) return ""
  return name.split("-")[0]?.trim() || name
}

function getRoleNamesFromScriptContent(scriptContent: unknown): string[] {
  const roles = (scriptContent as any)?.shot_content?.roles
  if (!Array.isArray(roles)) return []
  return roles
    .map((r: any) => (typeof r === "string" ? r : typeof r?.role_name === "string" ? r.role_name : ""))
    .map((n: string) => toRolePrimaryName(n))
    .filter(Boolean)
}

function isImageNameForRole(rolePrimary: string, imageName: string): boolean {
  const r = rolePrimary.trim()
  const n = imageName.trim()
  if (!r || !n) return false
  if (n === r) return true
  return n.startsWith(`${r}-`) || n.startsWith(`${r}（`) || n.startsWith(`${r}(`)
}

function getSelectedAssetIdForRole(roleImageDraws: Record<string, any> | null, rolePrimary: string): string {
  if (!roleImageDraws) return ""
  const direct = roleImageDraws[rolePrimary]
  const directId = typeof direct?.selectedAssetId === "string" ? direct.selectedAssetId.trim() : ""
  if (directId) return directId
  for (const [k, v] of Object.entries(roleImageDraws)) {
    if (toRolePrimaryName(k) !== rolePrimary) continue
    const id = typeof (v as any)?.selectedAssetId === "string" ? String((v as any).selectedAssetId).trim() : ""
    if (id) return id
  }
  return ""
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  videoFileLogger.info({
    module: "video/batch-api",
    event: "video_generate_batch_requested",
    message: "收到批量视频生成请求",
    traceId,
    userId,
    storyId: parsed.data.storyId,
    outlineId: parsed.data.outlineId,
    request: {
      storyboardIds: parsed.data.storyboardIds,
      count: parsed.data.count,
      overwrite: parsed.data.overwrite
    }
  })

  const { storyId, outlineId } = parsed.data
  const count = clampInt(parsed.data.count, 1, 3, 1)
  const overwrite = Boolean(parsed.data.overwrite)
  const generateAudioOverride = parsed.data.generate_audio ?? parsed.data.generateAudio
  const storyboardIds = Array.from(new Set(parsed.data.storyboardIds))
  const modelNameById = (parsed.data.modelNameById ?? {}) as Record<string, string>
  const modelNameDefaultRaw = parsed.data.modelNameDefault ?? ""
  const legacyModelById = (parsed.data.modelById ?? {}) as Record<string, "seedance1.5" | "seedance2.0">
  const legacyModelDefault = parsed.data.modelDefault ?? ""
  const modeById = (parsed.data.modeById ?? {}) as Record<string, "first_frame" | "reference">
  const modeDefault = parsed.data.modeDefault ?? null
  const referencesById = parsed.data.referencesById ?? {}

  const enabledModels = await listEnabledVideoModelsForUser(userId)
  const enabledModelNames = enabledModels.map((m) => m.modelName).filter(Boolean)
  if (enabledModelNames.length === 0) {
    videoFileLogger.warn({
      module: "video/batch-api",
      event: "video_generate_batch_model_denied",
      message: "批量视频生成失败：当前账号未配置可用的视频模型",
      traceId,
      userId,
      storyId,
      outlineId
    })
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号未配置可用的视频模型"), { status: 400 })
  }
  const enabledSet = new Set(enabledModelNames)
  const defaultModelName = normalizeModelName(modelNameDefaultRaw || legacyModelDefault, enabledSet, enabledModelNames[0]!)
  const db = await getDb({ stories, storyOutlines, storyboards })

  const allowed = await db
    .select({
      storyboardId: storyboards.id,
      storyboardText: storyboards.storyboardText,
      frames: storyboards.frames,
      videoInfo: storyboards.videoInfo,
      scriptContent: storyboards.scriptContent
    })
    .from(storyboards)
    .innerJoin(storyOutlines, eq(storyboards.outlineId, storyOutlines.id))
    .innerJoin(stories, eq(storyOutlines.storyId, stories.id))
    .where(and(eq(stories.userId, userId), eq(stories.id, storyId), eq(storyOutlines.id, outlineId), inArray(storyboards.id, storyboardIds)))

  const byId = new Map<string, (typeof allowed)[number]>()
  for (const row of allowed) byId.set(row.storyboardId, row)

  const storyMetaRow = await db
    .select({ metadata: stories.metadata })
    .from(stories)
    .where(and(eq(stories.id, storyId), eq(stories.userId, userId)))
    .limit(1)
  const metaRoot = storyMetaRow[0]?.metadata
  const shortDrama = metaRoot && typeof metaRoot === "object" && !Array.isArray(metaRoot) ? (metaRoot as any).shortDrama : null
  const roleImageDraws =
    shortDrama && typeof shortDrama === "object" && !Array.isArray(shortDrama) && shortDrama.roleImageDraws && typeof shortDrama.roleImageDraws === "object"
      ? (shortDrama.roleImageDraws as Record<string, any>)
      : null

  const results: Array<{ storyboardId: string; ok: boolean; jobId?: string; errorMessage?: string }> = []

  for (const storyboardId of storyboardIds) {
    const row = byId.get(storyboardId)
    if (!row) {
      results.push({ storyboardId, ok: false, errorMessage: "无权限或未找到分镜" })
      continue
    }
    const frames = (row.frames ?? {}) as any
    const firstUrl = (frames?.first?.url ?? frames?.first?.thumbnailUrl ?? "").trim()
    if (!firstUrl) {
      results.push({ storyboardId, ok: false, errorMessage: "缺少首帧主图，无法生成视频" })
      continue
    }
    const videoInfo = (row.videoInfo ?? {}) as any
    const settings = (videoInfo?.settings ?? {}) as any
    const storedModelName = typeof settings?.creationModel === "string" ? settings.creationModel : ""
    const selectedModelName = normalizeModelName(
      modelNameById[storyboardId] ?? legacyModelById[storyboardId] ?? modelNameDefaultRaw ?? legacyModelDefault ?? storedModelName,
      enabledSet,
      defaultModelName
    )
    const selectedMode = modeById[storyboardId] ?? modeDefault ?? settings?.creationMode ?? "first_frame"
    const promptBase = (typeof videoInfo?.prompt === "string" ? videoInfo.prompt : (row.storyboardText ?? "")).trim()
    if (!promptBase) {
      results.push({ storyboardId, ok: false, errorMessage: "缺少视频提示词，无法生成视频" })
      continue
    }
    const rawDurationSeconds = Number(videoInfo?.durationSeconds)
    const duration = rawDurationSeconds === -1 ? -1 : clampInt(rawDurationSeconds, 4, 12, 12)
    const generateAudio = typeof generateAudioOverride === "boolean" ? generateAudioOverride : Boolean(videoInfo?.settings?.generateAudio)

    if (overwrite) {
      await db
        .update(storyboards)
        .set({
          isVideoGenerated: false,
          videoInfo: {
            ...(row.videoInfo ?? {}),
            url: null,
            storageKey: null,
            videos: []
          } as any
        })
        .where(eq(storyboards.id, storyboardId))
    }

    for (let i = 0; i < count; i++) {
      let finalPrompt = promptBase
      try {
        let referenceImages: string[] = []
        let referenceImageNames: string[] = []
        let referenceAudios: string[] = []
        let referenceAudioNames: string[] = []
        let referenceVideos: string[] = []
        let referenceVideoNames: string[] = []

        const providedRefs = referencesById[storyboardId] ?? { images: [], audios: [], videos: [] }

        if (selectedMode === "reference") {
          // 1. 收集参考图（分镜素材 + 用户上传图）
          for (const ref of providedRefs.images) {
            const url = String(ref.url || "").trim()
            const name = String(ref.name || "").trim()
            if (url.startsWith("http") || url.startsWith("asset://") || url.startsWith("/api/")) {
              referenceImages.push(url)
              referenceImageNames.push(name)
            }
          }

          const roleNames = getRoleNamesFromScriptContent(row.scriptContent)
          const virtualRoleAssets = roleNames
            .map((roleName) => {
              const assetId = getSelectedAssetIdForRole(roleImageDraws, roleName)
              return { roleName, assetUrl: normalizeAssetUrl(assetId) }
            })
            .filter((x) => x.roleName && x.assetUrl)

          if (virtualRoleAssets.length) {
            const zipped = referenceImages.map((url, i) => ({ url, name: referenceImageNames[i] ?? "" }))
            const filtered = zipped.filter((it) => !virtualRoleAssets.some((v) => isImageNameForRole(v.roleName, it.name)))
            referenceImages = filtered.map((x) => x.url)
            referenceImageNames = filtered.map((x) => x.name)

            for (const v of virtualRoleAssets) {
              referenceImages.unshift(v.assetUrl)
              referenceImageNames.unshift(`${v.roleName}·虚拟形象`)
            }
          }

          const seen = new Set<string>()
          const dedup: Array<{ url: string; name: string }> = []
          for (let i = 0; i < referenceImages.length; i += 1) {
            const url = referenceImages[i] ?? ""
            if (!url || seen.has(url)) continue
            seen.add(url)
            dedup.push({ url, name: referenceImageNames[i] ?? "" })
          }
          referenceImages = dedup.map((x) => x.url).slice(0, 9)
          referenceImageNames = dedup.map((x) => x.name).slice(0, 9)
        } else {
          // 首帧图模式
          if (firstUrl.startsWith("http") || firstUrl.startsWith("asset://") || firstUrl.startsWith("/api/")) {
            referenceImages = [firstUrl]
            referenceImageNames = ["首帧图"]
          }
        }

        // 2. 收集音频和视频（包含角色配音和用户上传）
        for (const ref of providedRefs.audios) {
          const url = String(ref.url || "").trim()
          const name = String(ref.name || "").trim()
          if (url.startsWith("http") || url.startsWith("asset://") || url.startsWith("/api/")) {
            referenceAudios.push(url)
            referenceAudioNames.push(name)
          }
        }
        referenceAudios = referenceAudios.slice(0, 3)
        referenceAudioNames = referenceAudioNames.slice(0, 3)

        for (const ref of providedRefs.videos) {
          const url = String(ref.url || "").trim()
          const name = String(ref.name || "").trim()
          if (url.startsWith("http") || url.startsWith("asset://") || url.startsWith("/api/")) {
            referenceVideos.push(url)
            referenceVideoNames.push(name)
          }
        }
        referenceVideos = referenceVideos.slice(0, 3)
        referenceVideoNames = referenceVideoNames.slice(0, 3)

        const refPrompts: string[] = []
        if (referenceImageNames.length > 0) {
          refPrompts.push(referenceImageNames.map((name, idx) => `参考图${idx + 1}是${name}`).join("，"))
        }
        if (referenceAudioNames.length > 0) {
          refPrompts.push(referenceAudioNames.map((name, idx) => `参考音频${idx + 1}是${name}`).join("，"))
        }
        if (referenceVideoNames.length > 0) {
          refPrompts.push(referenceVideoNames.map((name, idx) => `参考视频${idx + 1}是${name}`).join("，"))
        }

        if (refPrompts.length > 0) {
          finalPrompt = `${promptBase}\n\n${refPrompts.join("\n")}`
        }

        const durationCanvas = clampInt(duration === -1 ? 8 : duration, 2, 15, 8)

        const { jobId } = await enqueueCanvasVideoGenerateJob({
          userId,
          traceId,
          storyId,
          outlineId,
          nodeId: storyboardId,
          prompt: finalPrompt,
          modelName: selectedModelName,
          mode: selectedMode as any,
          referenceImages,
          referenceVideos,
          referenceAudios,
          generateAudio,
          ratio: "adaptive",
          resolution: "720p",
          duration: durationCanvas,
          watermark: false
        })
          if (jobId) {
            videoFileLogger.info({
              module: "video/batch-api",
              event: "video_generate_batch_enqueued",
              message: "批量视频生成子任务已入队",
              traceId,
              jobId,
              userId,
              storyId,
              outlineId,
              nodeId: storyboardId,
              modelName: selectedModelName
            })
            results.push({ storyboardId, ok: true, jobId })
            continue
          }
        } catch (err) {
          const msg = (err as any)?.message ?? "视频生成失败"
          logger.error({
            event: "video_generate_canvas_failed",
            module: "video/creation",
            traceId,
            message: "视频生成失败",
            storyboardId,
            errorName: (err as any)?.name,
            errorMessage: msg,
            stack: (err as any)?.stack
          })
          videoFileLogger.error({
            module: "video/batch-api",
            event: "video_generate_batch_enqueue_failed",
            message: "批量视频生成子任务入队失败",
            traceId,
            userId,
            storyId,
            outlineId,
            nodeId: storyboardId,
            modelName: selectedModelName,
            errorMessage: msg
          })
          results.push({ storyboardId, ok: false, errorMessage: msg })
          continue
        }
      results.push({ storyboardId, ok: false, errorMessage: "视频任务提交失败" })
    }
  }

  kickVideoGenerateWorker()
  kickAllWorkers()
  return NextResponse.json(makeApiOk(traceId, { results }), { status: 200 })
}
