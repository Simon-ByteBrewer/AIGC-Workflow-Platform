import { NextResponse } from "next/server"
import { ZipFile } from "yazl"
import { and, eq, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { getSessionFromRequest } from "@/shared/session"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { generatedImages, publicResources, sharedResources, stories, videoCanvasAssets } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

type ResultItem = {
  kind: "image" | "video" | "audio"
  title: string
  url: string
  createdAt?: number
  assetId?: string
}

type ResultFolder = {
  name: string
  items: ResultItem[]
}

function safeFileBaseName(input: string): string {
  const trimmed = input.trim() || "file"
  return trimmed
    .replace(/[\\/]+/g, "-")
    .replace(/\s+/g, " ")
    .slice(0, 80)
    .trim() || "file"
}

function extFromKind(kind: ResultItem["kind"]): string {
  if (kind === "image") return ".png"
  if (kind === "video") return ".mp4"
  return ".mp3"
}

async function readRequestJson(req: Request): Promise<any> {
  try {
    return await req.json()
  } catch {
    return null
  }
}

function extractGeneratedImageIdFromUrl(rawUrl: string): string {
  try {
    const u = new URL(rawUrl)
    const m = u.pathname.match(/^\/api\/video-creation\/images\/file\/([^/?#]+)$/u)
    if (!m?.[1]) return ""
    return decodeURIComponent(String(m[1]))
  } catch {
    return ""
  }
}

async function tryFetchAsBuffer(url: string): Promise<Buffer | null> {
  const res = await fetch(url).catch(() => null)
  if (!res || !res.ok) return null
  const ab = await res.arrayBuffer().catch(() => null)
  if (!ab) return null
  return Buffer.from(ab)
}

function resolveFetchUrl(rawUrl: string, baseUrl: string): string {
  const trimmed = String(rawUrl ?? "").trim()
  if (!trimmed) return ""
  if (/^https?:\/\//i.test(trimmed)) return trimmed
  if (trimmed.startsWith("/")) {
    try {
      return new URL(trimmed, baseUrl).toString()
    } catch {
      return ""
    }
  }
  if (trimmed.startsWith("api/")) {
    try {
      return new URL(`/${trimmed}`, baseUrl).toString()
    } catch {
      return ""
    }
  }
  return ""
}

async function tryFetchExportItemAsBuffer(input: { url: string; baseUrl: string; cookieHeader: string }): Promise<Buffer | null> {
  const targetUrl = resolveFetchUrl(input.url, input.baseUrl)
  if (!targetUrl) return null
  const reqOrigin = (() => {
    try {
      return new URL(input.baseUrl).origin
    } catch {
      return ""
    }
  })()
  const targetOrigin = (() => {
    try {
      return new URL(targetUrl).origin
    } catch {
      return ""
    }
  })()
  const headers = new Headers()
  if (input.cookieHeader && reqOrigin && targetOrigin === reqOrigin) headers.set("cookie", input.cookieHeader)
  const res = await fetch(targetUrl, { headers }).catch(() => null)
  if (!res || !res.ok) return null
  const ab = await res.arrayBuffer().catch(() => null)
  if (!ab) return null
  return Buffer.from(ab)
}

async function resolveSignedUrlByAssetId(input: {
  userId: string
  assetId?: string
  fallbackGeneratedImageId?: string
}): Promise<string> {
  const assetId = typeof input.assetId === "string" ? input.assetId.trim() : ""
  const gid = typeof input.fallbackGeneratedImageId === "string" ? input.fallbackGeneratedImageId.trim() : ""
  const db = await getDb({ generatedImages, publicResources, sharedResources, stories, videoCanvasAssets })
  const storage = getS3Storage()

  if (assetId.startsWith("canvas:")) {
    const id = assetId.slice("canvas:".length).trim()
    if (!id) return ""
    const rows = await db
      .select({ storageKey: videoCanvasAssets.storageKey, previewStorageKey: videoCanvasAssets.previewStorageKey })
      .from(videoCanvasAssets)
      .innerJoin(stories, eq(stories.id, videoCanvasAssets.storyId))
      .where(and(eq(videoCanvasAssets.id, id), eq(stories.userId, input.userId)))
      .limit(1)
    const row = rows[0] ?? null
    const key = String(row?.storageKey ?? row?.previewStorageKey ?? "").trim()
    if (!key) return ""
    return await resolveStorageUrl(storage, key).catch(() => "")
  }

  if (assetId.startsWith("library:")) {
    const id = assetId.slice("library:".length).trim()
    if (!id) return ""
    const rows = await db
      .select({
        userId: publicResources.userId,
        originalStorageKey: publicResources.originalStorageKey,
        previewStorageKey: publicResources.previewStorageKey
      })
      .from(publicResources)
      .where(and(eq(publicResources.id, id), eq(publicResources.userId, input.userId)))
      .limit(1)
    const row = rows[0] ?? null
    if (!row || row.userId !== input.userId) return ""
    const key = String(row.originalStorageKey ?? row.previewStorageKey ?? "").trim()
    if (!key) return ""
    return await resolveStorageUrl(storage, key).catch(() => "")
  }

  if (assetId.startsWith("shared:")) {
    const id = assetId.slice("shared:".length).trim()
    if (!id) return ""
    const rows = await db
      .select({ originalStorageKey: sharedResources.originalStorageKey, previewStorageKey: sharedResources.previewStorageKey })
      .from(sharedResources)
      .where(eq(sharedResources.id, id))
      .limit(1)
    const row = rows[0] ?? null
    const key = String(row?.originalStorageKey ?? row?.previewStorageKey ?? "").trim()
    if (!key) return ""
    return await resolveStorageUrl(storage, key).catch(() => "")
  }

  const generatedId = (() => {
    if (assetId.startsWith("generated:image_db:")) return assetId.slice("generated:image_db:".length).trim()
    if (assetId.startsWith("generated_images:")) return assetId.slice("generated_images:".length).trim()
    return gid
  })()

  if (generatedId) {
    const rows = await db
      .select({ storageKey: generatedImages.storageKey })
      .from(generatedImages)
      .innerJoin(stories, eq(stories.id, generatedImages.storyId))
      .where(and(eq(generatedImages.id, generatedId), eq(stories.userId, input.userId), isNull(generatedImages.deletedAt)))
      .limit(1)
    const row = rows[0] ?? null
    const key = String(row?.storageKey ?? "").trim()
    if (!key) return ""
    return await resolveStorageUrl(storage, key).catch(() => "")
  }

  return ""
}

function compareItems(a: ResultItem, b: ResultItem): number {
  const order = (k: ResultItem["kind"]) => (k === "video" ? 0 : k === "image" ? 1 : 2)
  const ka = order(a.kind)
  const kb = order(b.kind)
  if (ka !== kb) return ka - kb
  const at = typeof a.createdAt === "number" ? a.createdAt : 0
  const bt = typeof b.createdAt === "number" ? b.createdAt : 0
  return bt - at
}

export async function POST(req: Request): Promise<Response> {
  const session = await getSessionFromRequest(req as any)
  const userId = session?.userId
  if (!userId) return NextResponse.json({ error: { message: "AUTH_REQUIRED" } }, { status: 401 })

  await ensurePublicSchema()

  const payload = await readRequestJson(req)
  const folders = (payload?.folders ?? []) as ResultFolder[]
  if (!Array.isArray(folders)) {
    return NextResponse.json({ error: { message: "Invalid payload" } }, { status: 400 })
  }

  const allItems: Array<{ folder: string; item: ResultItem; index: number }> = []
  for (const f of folders) {
    const folderName = typeof f?.name === "string" ? f.name : "folder"
    const items = Array.isArray(f?.items) ? f.items : []
    const sorted = items.slice().sort(compareItems)
    for (let i = 0; i < sorted.length; i++) {
      const it = sorted[i]
      if (!it || typeof it.url !== "string" || typeof it.title !== "string" || (it.kind !== "image" && it.kind !== "video" && it.kind !== "audio")) continue
      allItems.push({ folder: folderName, item: it, index: i })
    }
  }

  const MAX_FILES = 50
  const picked = allItems.slice(0, MAX_FILES)

  const zip = new ZipFile()
  let downloadedCount = 0
  const failures: Array<{ folder: string; title: string; url: string; assetId?: string }> = []
  const cookieHeader = String(req.headers.get("cookie") ?? "")

  for (const entry of picked) {
    const { folder, item, index } = entry
    try {
      const rawUrl = item.url.trim()
      const gid = extractGeneratedImageIdFromUrl(resolveFetchUrl(rawUrl, req.url))

      const buf =
        (await tryFetchExportItemAsBuffer({ url: rawUrl, baseUrl: req.url, cookieHeader })) ??
        (await (async () => {
          const signed = await resolveSignedUrlByAssetId({ userId, assetId: item.assetId, fallbackGeneratedImageId: gid })
          if (!signed || !/^https?:\/\//i.test(signed)) return null
          return await tryFetchAsBuffer(signed)
        })())

      if (!buf) {
        failures.push({ folder, title: item.title, url: rawUrl, assetId: item.assetId })
        continue
      }

      const name = safeFileBaseName(item.title)
      const ext = extFromKind(item.kind)
      const folderSafe = safeFileBaseName(folder)
      const filePath = `${folderSafe}/${String(index + 1).padStart(3, "0")}-${name}${ext}`
      zip.addBuffer(buf, filePath)
      downloadedCount += 1
    } catch {
      failures.push({ folder, title: item.title, url: item.url, assetId: item.assetId })
      continue
    }
  }

  const manifest = {
    exportedAt: new Date().toISOString(),
    requestedCount: picked.length,
    downloadedCount,
    failedCount: failures.length,
    failed: failures.slice(0, 50),
    folders: folders.map((f) => ({ name: f.name, count: Array.isArray(f.items) ? f.items.length : 0 }))
  }
  zip.addBuffer(Buffer.from(JSON.stringify(manifest, null, 2), "utf-8"), "manifest.json")

  const out = await new Promise<Buffer>((resolve, reject) => {
    const chunks: Buffer[] = []
    zip.outputStream
      .on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)))
      .on("error", reject)
      .on("end", () => resolve(Buffer.concat(chunks)))
    zip.end()
  })

  const zipBody = new Uint8Array(out)
  return new Response(zipBody, {
    status: 200,
    headers: {
      "content-type": "application/zip",
      "content-disposition": `attachment; filename="canvas-results.zip"`
    }
  })
}
