import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, asc, eq, inArray, isNull, sql } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { generatedImages, stories, storyOutlines, videoCanvasGraphs } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const paramsSchema = z
  .object({
    outlineId: z.string().trim().min(1).max(200)
  })
  .strict()

function extractGeneratedImageIdsFromGraph(graphJson: unknown): string[] {
  if (!graphJson || typeof graphJson !== "object") return []
  const nodes = (graphJson as any).nodes
  if (!Array.isArray(nodes)) return []
  const ids = new Set<string>()
  for (const n of nodes) {
    const params = n?.data?.params ?? n?.params
    const url = params?.url
    if (typeof url !== "string") continue
    const m = url.match(/\/api\/video-creation\/images\/file\/([^?/#]+)/)
    if (m?.[1]) ids.add(String(m[1]))
  }
  return Array.from(ids)
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ outlineId: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, storyOutlines, videoCanvasGraphs, generatedImages })

  const outlineRows = await db
    .select({
      outlineId: storyOutlines.id,
      storyId: storyOutlines.storyId,
      storyType: stories.storyType
    })
    .from(storyOutlines)
    .innerJoin(stories, eq(stories.id, storyOutlines.storyId))
    .where(and(eq(storyOutlines.id, parsedParams.data.outlineId), eq(stories.userId, userId), isNull(storyOutlines.deletedAt)))
    .limit(1)

  const outline = outlineRows[0]
  if (!outline) return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "剧集不存在"), { status: 404 })
  if (outline.storyType !== "canvas") return NextResponse.json(makeApiErr(traceId, "INVALID_STORY_TYPE", "该项目不是无限画布类型"), { status: 400 })

  const countRows = await db
    .select({ cnt: sql<number>`count(*)` })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.storyId, outline.storyId), isNull(storyOutlines.deletedAt)))
  const outlineCount = Number(countRows[0]?.cnt ?? 0)
  if (outlineCount <= 1) return NextResponse.json(makeApiErr(traceId, "CANNOT_DELETE_LAST_EPISODE", "至少保留 1 集"), { status: 400 })

  const graphRows = await db
    .select({ graphJson: videoCanvasGraphs.graphJson })
    .from(videoCanvasGraphs)
    .where(and(eq(videoCanvasGraphs.storyId, outline.storyId), eq(videoCanvasGraphs.outlineId, outline.outlineId), isNull(videoCanvasGraphs.deletedAt)))
    .limit(1)
  const graphJson = graphRows[0]?.graphJson
  const imageIds = extractGeneratedImageIdsFromGraph(graphJson)

  const now = new Date()

  if (imageIds.length > 0) {
    await db
      .update(generatedImages)
      .set({ deletedAt: now })
      .where(and(eq(generatedImages.storyId, outline.storyId), inArray(generatedImages.id, imageIds), isNull(generatedImages.deletedAt)))
  }

  await db
    .delete(videoCanvasGraphs)
    .where(and(eq(videoCanvasGraphs.storyId, outline.storyId), eq(videoCanvasGraphs.outlineId, outline.outlineId)))

  await db.update(storyOutlines).set({ deletedAt: now }).where(eq(storyOutlines.id, outline.outlineId))

  const remainingOutlines = await db
    .select({ id: storyOutlines.id })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.storyId, outline.storyId), isNull(storyOutlines.deletedAt)))
    .orderBy(asc(storyOutlines.sequence))

  for (let i = 0; i < remainingOutlines.length; i += 1) {
    await db.update(storyOutlines).set({ sequence: i + 1 }).where(eq(storyOutlines.id, remainingOutlines[i].id))
  }

  const nextOutlineId = remainingOutlines[0]?.id ?? ""
  return NextResponse.json(makeApiOk(traceId, { nextOutlineId }), { status: 200 })
}
