
"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import styles from "./PreviewPanel.module.css"
import type { RewriteState, OutlineItem } from "../utils"
import { deriveLiveRewrite } from "../utils"
import { EpisodeMaterialConfirmModal } from "@/features/script/materials/EpisodeMaterialConfirmModal"
import { VoiceoverAudioGenerateModal } from "@/features/script/voiceover/VoiceoverAudioGenerateModal"
import { callShortDramaSetupFromScriptBody, patchStoryShortDramaMetadata } from "../api/shortDrama"
import { EpisodeMaterialModelDialog } from "@/features/script/materials/EpisodeMaterialModelDialog"
import { readAcceptedJobIdFromStream } from "@/shared/readAcceptedJobIdFromStream"

type PreviewPanelProps = Readonly<{
  activeOutline: OutlineItem | null
  previewMode: "outline" | "rewrite" | "body"
  setPreviewMode: (mode: "outline" | "rewrite" | "body") => void
  canShowRewrite: boolean
  activeRewrite: RewriteState | undefined
  activeDraft: { content: string } | null
  generatingStoryboard: boolean
  handleGenerateStoryboardText: () => void
  handleOpenCanvasCreation: () => void
  storyId: string
  scriptBody: unknown | null
  scriptBodyRefExists: boolean
  voiceoverAudios: Record<string, unknown> | null
  voiceoverTts: Record<string, unknown> | null
  manualTexts: Record<string, unknown> | null
  refreshStoryMetadata: () => Promise<boolean>
  generatingScriptBody: boolean
  generatingScriptBodyStage: string | null
  handleGenerateScriptBody: () => void
  videoCategory: "premium" | "commentary"
}>

/**
 * 中间预览区组件
 * @param {PreviewPanelProps} props - 组件属性
 * @returns {JSX.Element} 组件内容
 */
export function PreviewPanel({
  activeOutline,
  previewMode,
  setPreviewMode,
  canShowRewrite,
  activeRewrite,
  activeDraft,
  generatingStoryboard,
  handleGenerateStoryboardText,
  handleOpenCanvasCreation,
  storyId,
  scriptBody,
  scriptBodyRefExists,
  voiceoverAudios,
  voiceoverTts,
  manualTexts,
  refreshStoryMetadata,
  generatingScriptBody,
  generatingScriptBodyStage,
  handleGenerateScriptBody,
  videoCategory
}: PreviewPanelProps) {
  const router = useRouter()
  const activeSequence = activeOutline?.sequence ?? null
  const [summaryOpenSequence, setSummaryOpenSequence] = useState<number | null>(null)
  const summaryOpen = summaryOpenSequence !== null && summaryOpenSequence === activeSequence
  const [shortDramaBusy, setShortDramaBusy] = useState(false)
  const [shortDramaNotice, setShortDramaNotice] = useState<string | null>(null)
  const [generatingMaterials, setGeneratingMaterials] = useState(false)
  const [materialsNotice, setMaterialsNotice] = useState<string | null>(null)
  const [latestMaterial, setLatestMaterial] = useState<{ id: string; name: string; url: string; createdAt: string } | null>(null)
  const [latestLoading, setLatestLoading] = useState(false)
  const [materialsPolling, setMaterialsPolling] = useState(false)
  const [materialsPollBaseId, setMaterialsPollBaseId] = useState<string | null>(null)
  const [materialsJobActive, setMaterialsJobActive] = useState(false)
  const [materialsJobId, setMaterialsJobId] = useState<string | null>(null)
  const [materialsJobStage, setMaterialsJobStage] = useState<string | null>(null)
  const [materialsJobProgress, setMaterialsJobProgress] = useState<{ done: number; total: number; currentName: string | null } | null>(null)
  const [materialsOpen, setMaterialsOpen] = useState(false)
  const [materialsModelDialogOpen, setMaterialsModelDialogOpen] = useState(false)
  const [materialsModelOptions, setMaterialsModelOptions] = useState<Array<{ label: string; value: string }>>([])
  const [materialsModelLoading, setMaterialsModelLoading] = useState(false)
  const [materialsModelSubmitting, setMaterialsModelSubmitting] = useState(false)
  const [materialsModelError, setMaterialsModelError] = useState<string | null>(null)
  const [materialsSceneModelName, setMaterialsSceneModelName] = useState("")
  const [materialsRoleModelName, setMaterialsRoleModelName] = useState("")
  const [materialsItemModelName, setMaterialsItemModelName] = useState("")
  const [quickStartBusy, setQuickStartBusy] = useState(false)
  const [quickStartNotice, setQuickStartNotice] = useState<string | null>(null)
  const [voiceoverModal, setVoiceoverModal] = useState<{ scope: "all" | "episode"; episodeNo?: number } | null>(null)
  const [voiceoverJobId, setVoiceoverJobId] = useState<string | null>(null)
  const [voiceoverJobSnapshot, setVoiceoverJobSnapshot] = useState<Record<string, unknown> | null>(null)
  const voiceoverBusy = Boolean(voiceoverJobId)
  const [voiceoverEditing, setVoiceoverEditing] = useState(false)
  const [voiceoverDraft, setVoiceoverDraft] = useState("")
  const [voiceoverSaving, setVoiceoverSaving] = useState(false)
  const [voiceoverSaveError, setVoiceoverSaveError] = useState<string | null>(null)
  const [bodyEditing, setBodyEditing] = useState(false)
  const [bodyDraft, setBodyDraft] = useState("")
  const [bodySaving, setBodySaving] = useState(false)
  const [bodySaveError, setBodySaveError] = useState<string | null>(null)
  const searchParams = useSearchParams()
  const normalizeLine = useCallback((line: string) => line.replace(/[\u200B-\u200D\uFEFF]/g, "").trim(), [])

  useEffect(() => {
    setVoiceoverEditing(false)
    setVoiceoverDraft("")
    setVoiceoverSaveError(null)
    setBodyEditing(false)
    setBodyDraft("")
    setBodySaveError(null)
  }, [activeSequence, previewMode])

  const parsedOriginal = useMemo(() => {
    const originalText = activeOutline?.originalText ?? ""
    if (!originalText.trim()) return { summary: null as null | Record<string, string>, episodeText: "" }
    const lines = originalText.replaceAll("\r\n", "\n").split("\n").map(normalizeLine)
    const isEpisodeLine = (l: string) => /^第\s*\d+\s*集/u.test(l)
    const headerKey = (l: string) => /^(剧名|主题|核心冲突|阶段|阶段目标)[:：]/u.test(l)
    const startIdx = lines.findIndex((l) => isEpisodeLine(l))
    const headerLines = startIdx >= 0 ? lines.slice(0, startIdx).filter(Boolean) : lines.filter(headerKey)
    const episodeLines =
      startIdx >= 0 ? lines.slice(startIdx + 1).filter(Boolean) : lines.filter((l) => !headerKey(l)).filter(Boolean)

    const pick = (key: string) => {
      const line = headerLines.find((l) => l.startsWith(`${key}：`) || l.startsWith(`${key}:`))
      if (!line) return ""
      return line.replace(/^.*[:：]\s*/u, "").trim()
    }

    const scriptName = pick("剧名")
    const theme = pick("主题")
    const conflict = pick("核心冲突")
    const stage = pick("阶段")
    const stageGoal = pick("阶段目标")

    const summary = (() => {
      const obj: Record<string, string> = {}
      if (scriptName) obj.scriptName = scriptName
      if (theme) obj.theme = theme
      if (conflict) obj.conflict = conflict
      if (stage) obj.stage = stage
      if (stageGoal) obj.stageGoal = stageGoal
      return Object.keys(obj).length ? obj : null
    })()

    const episodeText = episodeLines.join("\n").trim()
    return { summary, episodeText }
  }, [activeOutline?.originalText, normalizeLine])

  const parsedScriptBody = useMemo(() => {
    console.log('[PreviewPanel] scriptBody input:', scriptBody)

    const parseJsonIfNeeded = (v: unknown): unknown => {
      if (typeof v !== "string") return v
      const trimmed = v.trim()
      if (!trimmed) return v
      if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) return v
      try {
        return JSON.parse(trimmed)
      } catch {
        return v
      }
    }

    const pickObject = (v: unknown): Record<string, unknown> | null => {
      if (!v || typeof v !== "object" || Array.isArray(v)) return null
      return v as Record<string, unknown>
    }

    const normalized = parseJsonIfNeeded(scriptBody)
    console.log('[PreviewPanel] normalized:', normalized)

    const rootObj = pickObject(normalized)
    console.log('[PreviewPanel] rootObj:', rootObj)
    if (!rootObj) return null

    const bodyObj = (() => {
      const direct = pickObject((rootObj as any).script_body)
      console.log('[PreviewPanel] direct (script_body):', direct)
      if (direct) return direct
      const nested = pickObject((rootObj as any).data)
      const nestedBody = nested ? pickObject((nested as any).script_body) : null
      console.log('[PreviewPanel] nestedBody:', nestedBody)
      return nestedBody ?? rootObj
    })()

    console.log('[PreviewPanel] bodyObj:', bodyObj)

    const episodesRaw = (bodyObj as any)["episodes"]
    console.log('[PreviewPanel] episodesRaw:', episodesRaw)
    const episodes = Array.isArray(episodesRaw) ? (episodesRaw as Array<Record<string, unknown>>) : []
    console.log('[PreviewPanel] episodes count:', episodes.length)

    const result = {
      scriptName:
        typeof (bodyObj as any)["script_name"] === "string"
          ? String((bodyObj as any)["script_name"])
          : typeof (bodyObj as any)["scriptName"] === "string"
            ? String((bodyObj as any)["scriptName"])
            : null,
      episodes
    }
    console.log('[PreviewPanel] result:', result)
    return result
  }, [scriptBody])

  const rawScriptBodyText = useMemo(() => {
    const parseJsonIfNeeded = (v: unknown): unknown => {
      if (typeof v !== "string") return v
      const trimmed = v.trim()
      if (!trimmed) return v
      if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) return v
      try {
        return JSON.parse(trimmed)
      } catch {
        return v
      }
    }
    const pickObject = (v: unknown): Record<string, unknown> | null => {
      if (!v || typeof v !== "object" || Array.isArray(v)) return null
      return v as Record<string, unknown>
    }
    const normalized = parseJsonIfNeeded(scriptBody)
    if (typeof normalized === "string") {
      const t = normalized.replaceAll("\r\n", "\n").trim()
      return t ? t : null
    }
    const obj = pickObject(normalized)
    if (!obj) return null
    const t =
      typeof (obj as any).raw_text === "string"
        ? String((obj as any).raw_text)
        : typeof (obj as any).rawText === "string"
          ? String((obj as any).rawText)
          : typeof (obj as any).text === "string"
            ? String((obj as any).text)
            : null
    const trimmed = t ? t.replaceAll("\r\n", "\n").trim() : ""
    return trimmed ? trimmed : null
  }, [scriptBody])

  const openShortDrama = useCallback(() => {
    if (shortDramaBusy) return
    setShortDramaNotice(null)
    void (async () => {
      if (!rawScriptBodyText) {
        setShortDramaNotice("暂无剧本正文，请先生成剧本正文")
        return
      }
      setShortDramaBusy(true)
      try {
        const setup = await callShortDramaSetupFromScriptBody({
          storyId,
          videoType: videoCategory,
          scriptBody: rawScriptBodyText
        })
        await patchStoryShortDramaMetadata(storyId, {
          planningResult: setup.planningResult,
          worldSetting: setup.worldSetting,
          characterSetting: setup.characterSetting,
          planningConfirmedAt: Date.now()
        })
        void refreshStoryMetadata()

        const next = (() => {
          try {
            return `${window.location.pathname}${window.location.search}`
          } catch {
            return ""
          }
        })()
        const qs = next ? `?next=${encodeURIComponent(next)}` : ""
        router.push(`/script/short-drama/${encodeURIComponent(storyId)}${qs}`)
      } catch (e) {
        const anyErr = e as { message?: string }
        setShortDramaNotice(anyErr?.message ?? "生成失败，请稍后重试")
      } finally {
        setShortDramaBusy(false)
      }
    })()
  }, [rawScriptBodyText, refreshStoryMetadata, router, shortDramaBusy, storyId, videoCategory])

  const activeEpisode = useMemo(() => {
    if (!parsedScriptBody || activeSequence === null) return null
    const byNum = parsedScriptBody.episodes.find((e) => {
      const n = (e as any)?.episode
      if (typeof n === "number" && Number.isFinite(n)) return Math.trunc(n) === activeSequence
      const raw = String(n ?? "").trim()
      if (!raw) return false
      const matched = raw.match(/\d+/u)
      if (matched && matched[0]) return Number(matched[0]) === activeSequence
      return raw === String(activeSequence)
    })
    return byNum ?? parsedScriptBody.episodes[activeSequence - 1] ?? null
  }, [activeSequence, parsedScriptBody])

  // 获取实际的剧集号（用于手动文本的读写）
  const actualEpisodeNo = useMemo(() => {
    if (!activeEpisode) return null
    const n = (activeEpisode as any)?.episode
    if (typeof n === "number" && Number.isFinite(n)) return Math.trunc(n)
    if (typeof n === "string") {
      const matched = n.match(/\d+/u)
      if (matched?.[0]) return Number(matched[0])
    }
    return activeSequence
  }, [activeEpisode, activeSequence])

  const voiceoverText = useMemo(() => {
    if (!activeEpisode) return ""
    const raw = (activeEpisode as any).text
    return typeof raw === "string" ? raw.replaceAll("\r\n", "\n").trim() : ""
  }, [activeEpisode])

  const manualVoiceoverText = useMemo(() => {
    if (!manualTexts || actualEpisodeNo === null) return ""
    const manual = (manualTexts as any).voiceoverByEpisode
    if (!manual || typeof manual !== "object" || Array.isArray(manual)) return ""
    const v = (manual as any)[String(actualEpisodeNo)]
    return typeof v === "string" ? v.replaceAll("\r\n", "\n").trim() : ""
  }, [actualEpisodeNo, manualTexts])

  const manualBodyText = useMemo(() => {
    if (!manualTexts || actualEpisodeNo === null) return ""
    const manual = (manualTexts as any).bodyByEpisode
    if (!manual || typeof manual !== "object" || Array.isArray(manual)) return ""
    const v = (manual as any)[String(actualEpisodeNo)]
    return typeof v === "string" ? v.replaceAll("\r\n", "\n").trim() : ""
  }, [actualEpisodeNo, manualTexts])

  const saveManualText = useCallback(
    async (input: { kind: "voiceover" | "body"; content: string }) => {
      if (actualEpisodeNo === null) throw new Error("未选择剧集")
      const res = await fetch(`/api/library/stories/${encodeURIComponent(storyId)}/short-drama-texts`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ episodeNo: actualEpisodeNo, kind: input.kind, content: input.content })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      await refreshStoryMetadata()
    },
    [activeSequence, refreshStoryMetadata, storyId]
  )

  const voiceoverAudio = useMemo(() => {
    if (!voiceoverAudios || activeSequence === null) return null
    const raw = (voiceoverAudios as any)[String(activeSequence)]
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null
    const obj = raw as any
    const audioUrl = typeof obj.audioUrl === "string" ? obj.audioUrl.trim() : ""
    const audioId = typeof obj.audioId === "string" ? obj.audioId.trim() : ""
    const speakerId = typeof obj.speakerId === "string" ? obj.speakerId.trim() : ""
    const speed = typeof obj.speed === "number" && Number.isFinite(obj.speed) ? obj.speed : null
    return audioUrl || audioId ? { audioUrl, audioId, speakerId, speed } : null
  }, [activeSequence, voiceoverAudios])

  const defaultVoiceoverSpeakerId = useMemo(() => {
    const raw = (voiceoverTts as any)?.speakerId
    return typeof raw === "string" ? raw.trim() : ""
  }, [voiceoverTts])

  const defaultVoiceoverSpeed = useMemo(() => {
    const raw = (voiceoverTts as any)?.speed
    return typeof raw === "number" && Number.isFinite(raw) ? raw : 1
  }, [voiceoverTts])

  useEffect(() => {
    if (!voiceoverJobId) return
    let cancelled = false
    const tick = async () => {
      try {
        const res = await fetch(`/api/jobs/${encodeURIComponent(voiceoverJobId)}`, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { status?: string; snapshot?: unknown }; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        const status = String((json.data as any)?.status ?? "").trim()
        const snap = (json.data as any)?.snapshot ?? null
        if (cancelled) return
        if (snap && typeof snap === "object" && !Array.isArray(snap)) setVoiceoverJobSnapshot(snap as Record<string, unknown>)
        if (status === "done" || status === "error") {
          setVoiceoverJobId(null)
          await refreshStoryMetadata()
          return
        }
      } catch {
        if (cancelled) return
      }
      if (!cancelled) setTimeout(() => void tick(), 2000)
    }
    void tick()
    return () => {
      cancelled = true
    }
  }, [refreshStoryMetadata, voiceoverJobId])

  const loadMaterialsModelOptions = useCallback(async (): Promise<Array<{ label: string; value: string }>> => {
    const res = await fetch("/api/script/episode-material-images/models", { method: "GET", cache: "no-store" })
    const json = (await res.json().catch(() => null)) as { ok?: boolean; data?: { items?: Array<{ modelName?: string; label?: string }> }; error?: { message?: string } } | null
    if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
    return (Array.isArray(json.data?.items) ? json.data?.items : [])
      .map((item) => ({ label: String(item.label ?? item.modelName ?? ""), value: String(item.modelName ?? "").trim() }))
      .filter((item) => item.value)
  }, [])

  const submitGenerateMaterials = useCallback(async () => {
    if (!storyId) return
    if (generatingMaterials || materialsModelSubmitting) return
    setGeneratingMaterials(true)
    setMaterialsModelSubmitting(true)
    setMaterialsNotice(null)
    setMaterialsModelError(null)
    try {
      const res = await fetch("/api/script/episode-material-images/generate/stream", {
        method: "POST",
        headers: { "content-type": "application/json", accept: "text/event-stream" },
        body: JSON.stringify({
          storyId,
          outlineId: activeOutline?.outlineId ?? undefined,
          sceneModelName: materialsSceneModelName,
          roleModelName: materialsRoleModelName,
          itemModelName: materialsItemModelName
        })
      })
      if (!res.ok) {
        const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: { message?: string } } | null
        throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      }
      const jobId = await readAcceptedJobIdFromStream({ res })
      setMaterialsJobId(jobId || null)
      setMaterialsNotice(jobId ? `已加入任务队列（jobId: ${jobId}），可在任务中心查看进度` : "已加入任务队列，可在任务中心查看进度")
      setMaterialsModelDialogOpen(false)
      window.dispatchEvent(new Event("open_task_center"))
      setMaterialsPollBaseId(latestMaterial?.id ?? null)
      setMaterialsPolling(true)
    } catch (e) {
      const anyErr = e as { message?: string }
      setMaterialsModelError(anyErr?.message ?? "生成失败，请稍后重试")
      setMaterialsNotice(anyErr?.message ?? "生成失败，请稍后重试")
    } finally {
      setGeneratingMaterials(false)
      setMaterialsModelSubmitting(false)
    }
  }, [activeOutline, generatingMaterials, latestMaterial?.id, materialsItemModelName, materialsModelSubmitting, materialsRoleModelName, materialsSceneModelName, storyId])

  const handleGenerateMaterials = useCallback(async () => {
    if (!storyId) return
    if (generatingMaterials) return
    setMaterialsModelLoading(true)
    setMaterialsModelError(null)
    try {
      const options = await loadMaterialsModelOptions()
      setMaterialsModelOptions(options)
      const first = options[0]?.value ?? ""
      setMaterialsSceneModelName((prev) => (options.some((item) => item.value === prev) ? prev : first))
      setMaterialsRoleModelName((prev) => (options.some((item) => item.value === prev) ? prev : first))
      setMaterialsItemModelName((prev) => (options.some((item) => item.value === prev) ? prev : first))
      setMaterialsModelDialogOpen(true)
    } catch (e) {
      const anyErr = e as { message?: string }
      setMaterialsNotice(anyErr?.message ?? "加载模型失败，请稍后重试")
    } finally {
      setMaterialsModelLoading(false)
    }
  }, [generatingMaterials, loadMaterialsModelOptions, storyId])

  const fetchLatestMaterialRaw = useCallback(async (): Promise<{ id: string; name: string; url: string; createdAt: string } | null> => {
    if (!storyId) return null
    const res = await fetch(`/api/script/episode-material-images/latest?storyId=${encodeURIComponent(storyId)}`, { cache: "no-store" })
    const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { item?: any }; error?: { message?: string } } | null
    if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
    const item = json.data?.item ?? null
    const url = typeof item?.url === "string" ? item.url.trim() : ""
    const id = typeof item?.id === "string" ? item.id : ""
    const name = typeof item?.name === "string" ? item.name : ""
    const createdAt = item?.createdAt ? String(item.createdAt) : ""
    return id ? { id, name, url, createdAt } : null
  }, [storyId])

  const refreshLatestMaterial = useCallback(async () => {
    if (!storyId) return
    if (latestLoading) return
    setLatestLoading(true)
    try {
      const latest = await fetchLatestMaterialRaw()
      const url = latest?.url?.trim() ?? ""
      const okUrl = /^https?:\/\//u.test(url)
      setLatestMaterial((prev) => {
        if (latest?.id && okUrl) return { ...latest, url }
        return prev
      })
    } catch {
      setLatestMaterial((prev) => prev)
    } finally {
      setLatestLoading(false)
    }
  }, [fetchLatestMaterialRaw, latestLoading, storyId])

  const handleQuickStart = useCallback(async () => {
    if (!storyId) return
    if (quickStartBusy) return
    setQuickStartBusy(true)
    setQuickStartNotice(null)
    try {
      const res = await fetch("/api/quick-generate/projects/from-script", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ sourceStoryId: storyId })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { storyId?: string }; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const targetStoryId = json.data?.storyId
      if (!targetStoryId) throw new Error("创建失败：未返回项目ID")
      router.push(`/script/quick-generate/${encodeURIComponent(targetStoryId)}`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setQuickStartNotice(anyErr?.message ?? "快速开始创建失败，请稍后重试")
      setQuickStartBusy(false)
    }
  }, [quickStartBusy, router, storyId])

  const handleCancelMaterialsJobs = useCallback(async () => {
    const sid = storyId.trim()
    if (!sid) return
    setMaterialsNotice(null)
    try {
      const res = await fetch("/api/jobs/cancel-by-story", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ storyId: sid })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { canceled?: number }; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const canceled = Number((json as any)?.data?.canceled ?? 0)
      setMaterialsNotice(canceled > 0 ? `已终止 ${canceled} 个进行中的任务` : "未发现可终止的任务")
      setMaterialsPolling(false)
      setMaterialsPollBaseId(null)
      setMaterialsJobActive(false)
      setMaterialsJobId(null)
      setMaterialsJobStage(null)
      setMaterialsJobProgress(null)
      void refreshLatestMaterial()
    } catch (e) {
      const anyErr = e as { message?: string }
      setMaterialsNotice(anyErr?.message ?? "终止失败，请稍后重试")
    }
  }, [refreshLatestMaterial, storyId])

  useEffect(() => {
    void refreshLatestMaterial()
  }, [refreshLatestMaterial])

  useEffect(() => {
    const sid = storyId.trim()
    if (!sid) return
    let cancelled = false
    const tick = async () => {
      if (cancelled) return
      if (typeof document !== "undefined" && document.hidden) return
      try {
        const qs = new URLSearchParams({ storyId: sid, activeOnly: "true", limit: "20" })
        const res = await fetch(`/api/jobs?${qs.toString()}`, { method: "GET", cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { jobs?: any[] } } | null
        const jobs = Array.isArray(json?.data?.jobs) ? (json?.data?.jobs as any[]) : []
        const active = jobs.filter((j) => (j?.status === "queued" || j?.status === "running") && j?.type === "episode_material_generate")
        const jid = active.length ? String(active[0]?.jobId ?? "") : ""
        const snap = active.length && active[0] && typeof active[0] === "object" ? (active[0] as any).snapshot : null
        const stage = snap && typeof snap === "object" ? String((snap as any)?.stage ?? "").trim() : ""
        const done = snap && typeof snap === "object" ? Number((snap as any)?.done ?? 0) : 0
        const total = snap && typeof snap === "object" ? Number((snap as any)?.total ?? 0) : 0
        const currentName = snap && typeof snap === "object" && typeof (snap as any)?.currentName === "string" ? String((snap as any).currentName) : null
        setMaterialsJobActive(Boolean(active.length))
        setMaterialsJobId((prev) => (jid ? jid : prev))
        setMaterialsJobStage(stage || null)
        setMaterialsJobProgress(active.length ? { done: Number.isFinite(done) ? done : 0, total: Number.isFinite(total) ? total : 0, currentName } : null)
        if (active.length) setMaterialsPolling(true)
        if (!active.length) {
          setMaterialsPolling(false)
          setMaterialsPollBaseId(null)
          setMaterialsJobStage(null)
          setMaterialsJobProgress(null)
        }
      } catch {}
    }
    void tick()
    const interval = window.setInterval(() => void tick(), 1500)
    return () => {
      cancelled = true
      window.clearInterval(interval)
    }
  }, [storyId])

  useEffect(() => {
    if (!materialsPolling) return
    let cancelled = false
    const interval = window.setInterval(() => {
      if (cancelled) return
      void (async () => {
        try {
          const latest = await fetchLatestMaterialRaw()
          if (!latest?.id) return
          if (materialsPollBaseId && latest.id === materialsPollBaseId) return
          setLatestMaterial({ ...latest, url: (latest.url ?? "").trim() })
          setMaterialsPolling(false)
          setMaterialsPollBaseId(null)
        } catch {}
      })()
    }, 2000)
    const timeout = window.setTimeout(() => {
      if (cancelled) return
      setMaterialsPolling(false)
    }, 5 * 60 * 1000)
    return () => {
      cancelled = true
      window.clearInterval(interval)
      window.clearTimeout(timeout)
    }
  }, [fetchLatestMaterialRaw, materialsPollBaseId, materialsPolling])

  useEffect(() => {
    const open = searchParams?.get("materials") === "1"
    if (!open) return
    setMaterialsOpen(true)
    try {
      const url = new URL(window.location.href)
      url.searchParams.delete("materials")
      router.replace(url.pathname + (url.searchParams.toString() ? `?${url.searchParams.toString()}` : ""))
    } catch {}
  }, [router, searchParams])

  const materialsBusy = generatingMaterials || materialsJobActive
  const hasAnyScriptBodyText = useMemo(() => {
    if (parsedScriptBody?.episodes?.length) return true
    if (rawScriptBodyText) return true
    const bodyByEpisode = (manualTexts as any)?.bodyByEpisode
    if (!bodyByEpisode || typeof bodyByEpisode !== "object" || Array.isArray(bodyByEpisode)) return false
    return Object.values(bodyByEpisode as any).some((v) => typeof v === "string" && v.trim().length > 0)
  }, [manualTexts, parsedScriptBody?.episodes?.length, rawScriptBodyText])
  const hasAnyMaterials = Boolean(latestMaterial)

  return (
    <section className={styles.preview}>
      <div className={styles.previewHeader}>
        <div className={styles.previewTitle}>{activeOutline ? `剧本大纲 ${activeOutline.sequence}` : "暂无大纲"}</div>
        <div className={styles.previewActions}>
          {activeOutline ? (
            <>
              <button
                type="button"
                className={previewMode === "outline" ? `${styles.toggleButton} ${styles.toggleButtonActive}` : styles.toggleButton}
                onClick={() => setPreviewMode("outline")}
              >
                大纲
              </button>
              <button
                type="button"
                className={previewMode === "body" ? `${styles.toggleButton} ${styles.toggleButtonActive}` : styles.toggleButton}
                disabled={!hasAnyScriptBodyText}
                onClick={() => setPreviewMode("body")}
              >
                正文
              </button>
              <button
                type="button"
                className={previewMode === "rewrite" ? `${styles.toggleButton} ${styles.toggleButtonActive}` : styles.toggleButton}
                disabled={!canShowRewrite}
                onClick={() => setPreviewMode("rewrite")}
              >
                改写
              </button>
            </>
          ) : null}
          <button type="button" className={styles.toggleButton} onClick={openShortDrama} disabled={shortDramaBusy}>
            {shortDramaBusy ? "生成中…" : "前置：短剧信息"}
          </button>
          <div className={styles.previewHint}>可在此查看生成内容</div>
        </div>
      </div>

      <article className={styles.markdown}>
        {parsedOriginal.summary ? (
          <section className={styles.storySummary} aria-label="故事摘要">
            <button
              type="button"
              className={styles.storySummaryHeader}
              onClick={() => setSummaryOpenSequence((prev) => (prev === activeSequence ? null : activeSequence))}
            >
              <div className={styles.storySummaryTitleRow}>
                <div className={styles.storySummaryTitle}>故事摘要</div>
                <div className={styles.storySummaryToggle}>{summaryOpen ? "收起" : "展开"}</div>
              </div>
              <div className={styles.storySummaryHint}>
                {parsedOriginal.summary.stage
                  ? parsedOriginal.summary.stage
                  : parsedOriginal.summary.scriptName
                  ? parsedOriginal.summary.scriptName
                  : "查看阶段 / 阶段目标"}
              </div>
              {!summaryOpen && parsedOriginal.summary.stageGoal ? (
                <div className={styles.storySummaryHintSecondary}>目标：{parsedOriginal.summary.stageGoal}</div>
              ) : null}
            </button>
            {summaryOpen ? (
              <div className={styles.storySummaryBody}>
                {parsedOriginal.summary.scriptName ? (
                  <div className={styles.summaryRow}>
                    <div className={styles.summaryKey}>剧名</div>
                    <div className={styles.summaryVal}>{parsedOriginal.summary.scriptName}</div>
                  </div>
                ) : null}
                {parsedOriginal.summary.theme ? (
                  <div className={styles.summaryRow}>
                    <div className={styles.summaryKey}>主题</div>
                    <div className={styles.summaryVal}>{parsedOriginal.summary.theme}</div>
                  </div>
                ) : null}
                {parsedOriginal.summary.conflict ? (
                  <div className={styles.summaryRow}>
                    <div className={styles.summaryKey}>核心冲突</div>
                    <div className={styles.summaryVal}>{parsedOriginal.summary.conflict}</div>
                  </div>
                ) : null}
                {parsedOriginal.summary.stage ? (
                  <div className={styles.summaryRow}>
                    <div className={styles.summaryKey}>阶段</div>
                    <div className={styles.summaryVal}>{parsedOriginal.summary.stage}</div>
                  </div>
                ) : null}
                {parsedOriginal.summary.stageGoal ? (
                  <div className={styles.summaryRow}>
                    <div className={styles.summaryKey}>阶段目标</div>
                    <div className={styles.summaryVal}>{parsedOriginal.summary.stageGoal}</div>
                  </div>
                ) : null}
              </div>
            ) : null}
          </section>
        ) : null}
        {activeOutline ? (
          (() => {
            if (previewMode === "body") {
              if (!parsedScriptBody) {
                if (rawScriptBodyText) return <div className={styles.originalText}>{rawScriptBodyText}</div>
                if (scriptBodyRefExists) {
                  return (
                    <div className={styles.originalEmpty}>
                      正文已外置存储但尚未加载
                      <button
                        type="button"
                        className={styles.nextStepButtonSecondary}
                        onClick={() => void refreshStoryMetadata()}
                      >
                        重新加载
                      </button>
                    </div>
                  )
                }
                return <div className={styles.originalEmpty}>暂无正文内容</div>
              }
              if (!activeEpisode) {
                if (rawScriptBodyText) return <div className={styles.originalText}>{rawScriptBodyText}</div>
                return <div className={styles.originalEmpty}>未找到对应集的正文</div>
              }

              const corePlot = typeof (activeEpisode as any).core_plot === "string" ? String((activeEpisode as any).core_plot) : ""
              const scenesRaw = (activeEpisode as any).scenes
              const scenes = Array.isArray(scenesRaw) ? (scenesRaw as Array<Record<string, unknown>>) : []
              const showVoiceover = videoCategory === "commentary"
              const episodeFallbackBodyText = (() => {
                const candidates = [
                  (activeEpisode as any).body_text,
                  (activeEpisode as any).bodyText,
                  (activeEpisode as any).raw_text,
                  (activeEpisode as any).rawText,
                  (activeEpisode as any).content
                ]
                const picked = candidates.find((t) => typeof t === "string" && t.trim().length > 0)
                return typeof picked === "string" ? picked.replaceAll("\r\n", "\n").trim() : ""
              })()
              const computedBodyText = (() => {
                const core = corePlot ? `本集核心：${corePlot}\n\n` : ""
                const sceneText = scenes.length
                  ? scenes
                      .map((s) => {
                        const sceneId = typeof (s as any).scene_id === "string" ? String((s as any).scene_id) : ""
                        const title = typeof (s as any).scene_title === "string" ? String((s as any).scene_title) : ""
                        const timeLocation = typeof (s as any).time_location === "string" ? String((s as any).time_location) : ""
                        const durationRaw = (s as any).duration
                        const duration =
                          typeof durationRaw === "string"
                            ? durationRaw.trim()
                            : typeof durationRaw === "number" && Number.isFinite(durationRaw)
                              ? `${Math.trunc(durationRaw)}秒`
                              : ""
                        const charactersRaw = (s as any).characters
                        const characters = Array.isArray(charactersRaw)
                          ? (charactersRaw as unknown[]).map((c) => String(c ?? "").trim()).filter(Boolean)
                          : []
                        const contentRaw = (s as any).content
                        const lines = Array.isArray(contentRaw)
                          ? (contentRaw as unknown[]).map((l) => String(l ?? "").trim()).filter(Boolean)
                          : typeof contentRaw === "string"
                            ? [contentRaw.trim()].filter(Boolean)
                            : []
                        const timeDur = [timeLocation, duration].filter(Boolean).join("，")
                        const head = [sceneId ? `【${sceneId}】` : "", title || "场景", timeDur ? `（${timeDur}）` : ""].filter(Boolean).join("")
                        const roleLine = characters.length ? `人物：${characters.join("、")}` : ""
                        return [head, roleLine, ...lines, ""].filter(Boolean).join("\n")
                      })
                      .join("\n")
                  : episodeFallbackBodyText || "（本集暂无场景）"
                return `${core}${sceneText}`.trim()
              })()

              // 修复展示优先级问题：只有当手动文本是有效内容时才使用它，否则使用自动生成的文本
              // 避免 "1" 这样的标记值覆盖实际内容
              const isValidManualBodyText = manualBodyText.length > 10 && !/^[\d\s]+$/.test(manualBodyText)
              const isValidManualVoiceoverText = manualVoiceoverText.length > 5 && !/^[\d\s]+$/.test(manualVoiceoverText)

              const displayVoiceoverText = isValidManualVoiceoverText ? manualVoiceoverText : voiceoverText
              const displayBodyText = isValidManualBodyText ? manualBodyText : computedBodyText

              return (
                <>
                  {showVoiceover ? (
                    <div className={styles.voiceoverCard}>
                      <div className={styles.voiceoverTitle}>口播文案</div>
                      {voiceoverEditing ? (
                        <textarea
                          className={styles.manualEditTextarea}
                          value={voiceoverDraft}
                          onChange={(e) => setVoiceoverDraft(e.target.value)}
                          rows={8}
                        />
                      ) : (
                        <div className={styles.voiceoverBody}>
                          {displayVoiceoverText ? displayVoiceoverText : "生成正文后将展示本集口播文案"}
                        </div>
                      )}
                      <div className={styles.manualEditActions}>
                        {!voiceoverEditing ? (
                          <button
                            type="button"
                            className={styles.nextStepButtonSecondary}
                            onClick={() => {
                              setVoiceoverSaveError(null)
                              setVoiceoverDraft(displayVoiceoverText)
                              setVoiceoverEditing(true)
                            }}
                            disabled={activeSequence === null || voiceoverBusy}
                          >
                            编辑
                          </button>
                        ) : (
                          <>
                            <button
                              type="button"
                              className={styles.nextStepButtonSecondary}
                              onClick={() => {
                                setVoiceoverEditing(false)
                                setVoiceoverSaveError(null)
                                setVoiceoverDraft("")
                              }}
                              disabled={voiceoverSaving}
                            >
                              取消
                            </button>
                            <button
                              type="button"
                              className={styles.nextStepButton}
                              onClick={() => {
                                if (voiceoverSaving) return
                                setVoiceoverSaving(true)
                                setVoiceoverSaveError(null)
                                void (async () => {
                                  try {
                                    await saveManualText({ kind: "voiceover", content: voiceoverDraft })
                                    setVoiceoverEditing(false)
                                  } catch (e) {
                                    setVoiceoverSaveError(String((e as any)?.message ?? "保存失败"))
                                  } finally {
                                    setVoiceoverSaving(false)
                                  }
                                })()
                              }}
                              disabled={voiceoverSaving || actualEpisodeNo === null}
                            >
                              {voiceoverSaving ? "保存中…" : "保存"}
                            </button>
                          </>
                        )}
                      </div>
                      {voiceoverSaveError ? <div className={styles.nextStepError}>{voiceoverSaveError}</div> : null}
                      {displayVoiceoverText ? (
                        <div className={styles.nextStepAction}>
                          <button
                            type="button"
                            className={styles.nextStepButton}
                            onClick={() => {
                              if (actualEpisodeNo === null) return
                              setVoiceoverModal({ scope: "episode", episodeNo: actualEpisodeNo })
                            }}
                            disabled={voiceoverBusy || actualEpisodeNo === null}
                          >
                            {voiceoverAudio?.audioUrl ? "重制" : voiceoverBusy ? "生成中…" : "生成语音"}
                          </button>
                        </div>
                      ) : null}
                      {voiceoverAudio?.audioUrl ? <audio controls src={voiceoverAudio.audioUrl} /> : null}
                    </div>
                  ) : null}
                  <div className={styles.manualEditSection}>
                    <div className={styles.manualEditActions}>
                      {!bodyEditing ? (
                        <button
                          type="button"
                          className={styles.nextStepButtonSecondary}
                          onClick={() => {
                            setBodySaveError(null)
                            setBodyDraft(displayBodyText)
                            setBodyEditing(true)
                          }}
                          disabled={actualEpisodeNo === null}
                        >
                          编辑正文
                        </button>
                      ) : (
                        <>
                          <button
                            type="button"
                            className={styles.nextStepButtonSecondary}
                            onClick={() => {
                              setBodyEditing(false)
                              setBodySaveError(null)
                              setBodyDraft("")
                            }}
                            disabled={bodySaving}
                          >
                            取消
                          </button>
                          <button
                            type="button"
                            className={styles.nextStepButton}
                            onClick={() => {
                              if (bodySaving) return
                              setBodySaving(true)
                              setBodySaveError(null)
                              void (async () => {
                                try {
                                  await saveManualText({ kind: "body", content: bodyDraft })
                                  setBodyEditing(false)
                                } catch (e) {
                                  setBodySaveError(String((e as any)?.message ?? "保存失败"))
                                } finally {
                                  setBodySaving(false)
                                }
                              })()
                            }}
                            disabled={bodySaving || actualEpisodeNo === null}
                          >
                            {bodySaving ? "保存中…" : "保存"}
                          </button>
                        </>
                      )}
                    </div>
                    {bodySaveError ? <div className={styles.nextStepError}>{bodySaveError}</div> : null}
                    {bodyEditing ? (
                      <textarea
                        className={styles.manualEditTextarea}
                        value={bodyDraft}
                        onChange={(e) => setBodyDraft(e.target.value)}
                        rows={16}
                      />
                    ) : (
                      <div className={styles.originalText}>{displayBodyText}</div>
                    )}
                  </div>
                </>
              )
            }
            if (previewMode === "rewrite") {
              if (activeRewrite?.status === "streaming") {
                if (activeRewrite?.raw) {
                  const live = deriveLiveRewrite(activeRewrite.raw)
                  return <div className={styles.streamText}>{live.content ?? activeRewrite.raw}</div>
                }
                return <div className={styles.originalEmpty}>改写中…</div>
              }
              const content = activeDraft?.content?.trim() || activeRewrite?.result?.new_content?.trim() || ""
              return content ? <div className={styles.streamText}>{content}</div> : <div className={styles.originalEmpty}>暂无改写内容</div>
            }
            const baseText = (parsedOriginal.episodeText || activeOutline.originalText).replaceAll("\r\n", "\n")
            const text = baseText.replace(/^第\s*\d+\s*集\s*\n?/u, "")
            return <div className={styles.originalText}>{text}</div>
          })()
        ) : (
          <div className={styles.originalEmpty}>暂无可展示内容</div>
        )}
      </article>

      <div className={styles.nextStep}>
        <div className={styles.nextStepCard}>
          <div className={styles.nextStepText}>
            <div className={styles.nextStepTitle}>生成剧本正文</div>
            <div className={styles.nextStepDesc}>基于短剧信息与大纲生成可直接拍摄的分集/分场正文，并在中间预览区展示。</div>
          </div>
          <div className={styles.nextStepAction}>
            <button
              type="button"
              className={styles.nextStepButton}
              onClick={handleGenerateScriptBody}
              disabled={!activeOutline || generatingScriptBody}
            >
              {generatingScriptBody ? (generatingScriptBodyStage ? `生成中…（${generatingScriptBodyStage}）` : "生成中…") : "一键生成"}
            </button>
            {videoCategory === "commentary" && voiceoverText ? (
              <button
                type="button"
                className={styles.nextStepButton}
                onClick={() => setVoiceoverModal({ scope: "all" })}
                disabled={voiceoverBusy}
              >
                {voiceoverBusy ? "生成中…" : "一键生成口播语音"}
              </button>
            ) : null}
          </div>
          {(() => {
            const snap = voiceoverJobSnapshot as any
            if (!snap || typeof snap !== "object") return null
            const status = String(snap.status ?? "").trim()
            if (status !== "error") return null
            const failedRaw = snap.failedEpisodes
            const failed = Array.isArray(failedRaw) ? failedRaw : []
            const msg = typeof snap.errorMessage === "string" ? snap.errorMessage.trim() : ""
            const pick = failed
              .map((e: any) => {
                const n = typeof e?.episodeNo === "number" && Number.isFinite(e.episodeNo) ? Math.trunc(e.episodeNo) : 0
                const m = typeof e?.message === "string" ? e.message.trim() : ""
                if (!n) return ""
                return m ? `第${n}集：${m}` : `第${n}集失败`
              })
              .filter(Boolean)
            const detail = pick.length > 10 ? `${pick.slice(0, 10).join("；")}…（共${pick.length}集失败）` : pick.join("；")
            const text = detail || msg
            return text ? <div className={styles.nextStepError}>{text}</div> : null
          })()}
        </div>
        <div className={styles.nextStepCard}>
          <div className={styles.nextStepText}>
            <div className={styles.nextStepTitle}>生成图片素材</div>
            <div className={styles.nextStepDesc}>基于全剧正文与人物妆造信息生成图片素材，并自动入库供后续视频创作使用。</div>
          </div>
          <div className={styles.nextStepAction}>
            <button
              type="button"
              className={styles.nextStepButton}
              onClick={() => void handleGenerateMaterials()}
              disabled={!activeOutline || materialsBusy || !hasAnyScriptBodyText}
            >
              {materialsBusy ? (materialsJobStage ? `生成中…（${materialsJobStage}）` : "生成中…") : "一键生成"}
            </button>
            {latestMaterial || materialsBusy ? (
              <button type="button" className={styles.nextStepButton} onClick={() => setMaterialsOpen(true)}>
                查看图片素材
              </button>
            ) : null}
            {materialsBusy ? (
              <button type="button" className={styles.nextStepButton} onClick={() => void handleCancelMaterialsJobs()}>
                终止任务
              </button>
            ) : null}
          </div>
        </div>
        <div className={styles.nextStepCard}>
          <div className={styles.nextStepText}>
            <div className={styles.nextStepTitle}>下一步：生成分镜文本</div>
            <div className={styles.nextStepDesc}>基于剧本正文生成更细的场景描述与镜头文本，准备进入视频创作。</div>
          </div>
          <div className={styles.nextStepAction}>
            <button
              type="button"
              className={styles.nextStepButton}
              onClick={handleGenerateStoryboardText}
              disabled={!activeOutline || generatingStoryboard || materialsBusy || !hasAnyScriptBodyText || !hasAnyMaterials}
            >
              {generatingStoryboard ? "生成中…" : "分镜创作"}
            </button>
            <button
              type="button"
              className={styles.nextStepButtonSecondary}
              onClick={handleOpenCanvasCreation}
              disabled={!activeOutline || materialsBusy || !hasAnyScriptBodyText || !hasAnyMaterials}
            >
              画布创作
            </button>
            <button
              type="button"
              className={styles.nextStepButtonSecondary}
              onClick={handleQuickStart}
              disabled={!activeOutline || materialsBusy || !hasAnyScriptBodyText || !hasAnyMaterials || quickStartBusy}
            >
              {quickStartBusy ? "创建中…" : "快速开始"}
            </button>
          </div>
        </div>
      </div>
      {shortDramaNotice ? <div className={styles.previewHint}>{shortDramaNotice}</div> : null}
      {materialsNotice ? <div className={styles.previewHint}>{materialsNotice}</div> : null}
      {quickStartNotice ? <div className={styles.previewHint}>{quickStartNotice}</div> : null}
      {materialsBusy && materialsJobId ? (
        <div className={styles.previewHint}>
          {materialsJobProgress?.total
            ? `${materialsJobProgress.currentName ? `${materialsJobProgress.currentName}：` : ""}${materialsJobProgress.done}/${materialsJobProgress.total}`
            : ""}
          {`（jobId: ${materialsJobId}）`}
        </div>
      ) : null}
      {materialsOpen ? <EpisodeMaterialConfirmModal storyId={storyId} onClose={() => setMaterialsOpen(false)} /> : null}
      <EpisodeMaterialModelDialog
        open={materialsModelDialogOpen}
        loading={materialsModelLoading}
        submitting={materialsModelSubmitting}
        errorText={materialsModelError}
        options={materialsModelOptions}
        sceneModelName={materialsSceneModelName}
        roleModelName={materialsRoleModelName}
        itemModelName={materialsItemModelName}
        onOpenChange={(open) => {
          setMaterialsModelDialogOpen(open)
          if (!open) setMaterialsModelError(null)
        }}
        onChangeSceneModelName={setMaterialsSceneModelName}
        onChangeRoleModelName={setMaterialsRoleModelName}
        onChangeItemModelName={setMaterialsItemModelName}
        onConfirm={() => {
          void submitGenerateMaterials()
        }}
      />
      {voiceoverModal ? (
        <VoiceoverAudioGenerateModal
          storyId={storyId}
          scope={voiceoverModal.scope}
          episodeNo={voiceoverModal.episodeNo}
          initialSpeakerId={defaultVoiceoverSpeakerId || voiceoverAudio?.speakerId || undefined}
          initialSpeed={defaultVoiceoverSpeed}
          onClose={() => setVoiceoverModal(null)}
          onSubmitted={(jobId) => {
            setVoiceoverJobSnapshot(null)
            setVoiceoverJobId(jobId)
          }}
        />
      ) : null}
    </section>
  )
}
