"use client"

import { useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import { createPortal } from "react-dom"
import styles from "./QuickGenerateMaterialCard.module.css"
import type { QuickGenerateMaterial } from "@/shared/schema/quickGenerate"

type Speaker = { id: string; name: string; sampleUrl?: string }
type AudioMaterial = { id: string; title: string; assetId: string; assetStatus: string; sourceUrl: string }

const CUSTOM_VOICE_ID = "__custom_audio__"
const VOICE_DROPDOWN_GAP = 6
const VOICE_DROPDOWN_WIDTH = 220

type VoiceDropdownPosition = {
  left: number
  top: number
  width: number
  maxHeight: number
}

function getVoiceSelectionLabel(input: { voiceSelection: string; speakers: Speaker[] }) {
  if (!input.voiceSelection) return "未绑定音色"
  return input.speakers.find((speaker) => speaker.id === input.voiceSelection)?.name ?? "未绑定音色"
}

function buildVoiceUpdate(input: {
  materialType: string
  voiceSelection: string
  customAudioId: string
  speakers: Speaker[]
  audioMaterials: AudioMaterial[]
}): { voiceSpeakerId: string | null; voiceSpeakerName: string | null } {
  if (input.materialType !== "character") {
    return { voiceSpeakerId: null, voiceSpeakerName: null }
  }

  if (!input.voiceSelection) {
    return { voiceSpeakerId: null, voiceSpeakerName: null }
  }

  if (input.voiceSelection === CUSTOM_VOICE_ID) {
    const selectedAudio = input.audioMaterials.find((a) => a.id === input.customAudioId) ?? null
    const assetId = String(selectedAudio?.assetId ?? "").trim()
    const name = String(selectedAudio?.title ?? "").trim()
    return {
      voiceSpeakerId: assetId ? assetId : null,
      voiceSpeakerName: name ? name : "自定义音色"
    }
  }

  const speakerName = input.speakers.find((s) => s.id === input.voiceSelection)?.name ?? null
  return { voiceSpeakerId: input.voiceSelection, voiceSpeakerName: speakerName }
}

export function QuickGenerateMaterialCardEditor({
  item,
  batchEditMode,
  singleEditing,
  onExitSingleEditing,
  onSave,
  onDraftChange,
  speakers,
  audioMaterials
}: {
  item: QuickGenerateMaterial
  batchEditMode: boolean
  singleEditing: boolean
  onExitSingleEditing: () => void
  onSave: (id: string, updates: Partial<QuickGenerateMaterial>) => Promise<void>
  onDraftChange: (id: string, draft: Partial<QuickGenerateMaterial>) => void
  speakers: Speaker[]
  audioMaterials: AudioMaterial[]
}): ReactElement {
  const [title, setTitle] = useState(item.title?.trim() || "")
  const [materialType, setMaterialType] = useState(item.materialType || "reference")
  const [voiceSelection, setVoiceSelection] = useState<string>("")
  const [customAudioId, setCustomAudioId] = useState<string>("")
  const [assetId, setAssetId] = useState(String((item as any).assetId ?? "").trim())
  const [saving, setSaving] = useState(false)
  const [errorText, setErrorText] = useState("")
  const inputRef = useRef<HTMLInputElement>(null)
  const voiceSearchInputRef = useRef<HTMLInputElement>(null)
  const voiceTriggerRef = useRef<HTMLButtonElement>(null)
  const voiceDropdownRef = useRef<HTMLDivElement>(null)
  const rootRef = useRef<HTMLDivElement>(null)
  const [speakerMenuOpen, setSpeakerMenuOpen] = useState(false)
  const [speakerSearch, setSpeakerSearch] = useState("")
  const [voiceDropdownPosition, setVoiceDropdownPosition] = useState<VoiceDropdownPosition | null>(null)

  /**
   * 进入单卡编辑态时自动聚焦并全选，允许用户直接输入覆盖旧名称。
   */
  useEffect(() => {
    if (!singleEditing || batchEditMode) return
    const input = inputRef.current
    if (!input) return
    const timer = window.setTimeout(() => {
      input.focus()
      input.select()
    }, 0)
    return () => window.clearTimeout(timer)
  }, [singleEditing, batchEditMode])

  const selectedCustomAudio = useMemo(() => {
    if (!customAudioId) return null
    return audioMaterials.find((a) => a.id === customAudioId) ?? null
  }, [audioMaterials, customAudioId])

  const resolveVoiceUpdate = useMemo(() => {
    return buildVoiceUpdate({
      materialType,
      voiceSelection,
      customAudioId,
      speakers,
      audioMaterials
    })
  }, [materialType, voiceSelection, customAudioId, speakers, audioMaterials])

  const updateDraft = (updates: Partial<QuickGenerateMaterial>) => {
    if (!batchEditMode) return
    const type = updates.materialType !== undefined ? updates.materialType : materialType
    const nextAssetId =
      updates.assetId !== undefined ? String(updates.assetId ?? "").trim() : assetId

    const voiceUpdate =
      type === "character"
        ? resolveVoiceUpdate
        : { voiceSpeakerId: null as string | null, voiceSpeakerName: null as string | null }

    onDraftChange(item.id, {
      title: updates.title !== undefined ? updates.title : title,
      materialType: type,
      voiceSpeakerId: voiceUpdate.voiceSpeakerId,
      voiceSpeakerName: voiceUpdate.voiceSpeakerName,
      assetId: nextAssetId ? nextAssetId : null
    })
  }

  // Reset local state when item changes or edit mode toggles
  useEffect(() => {
    setTitle(item.title?.trim() || "")
    setMaterialType(item.materialType || "reference")
    setAssetId(String((item as any).assetId ?? "").trim())
    setErrorText("")

    const rawVoiceId = String((item as any).voiceSpeakerId ?? "").trim()
    const isTtsSpeaker = rawVoiceId && speakers.some((s) => s.id === rawVoiceId)
    if (isTtsSpeaker) {
      setVoiceSelection(rawVoiceId)
      setCustomAudioId("")
      return
    }
    if (rawVoiceId.startsWith("asset-")) {
      setVoiceSelection(CUSTOM_VOICE_ID)
      const matchedAudio = audioMaterials.find((a) => a.assetId === rawVoiceId) ?? null
      setCustomAudioId(matchedAudio?.id ?? "")
      return
    }
    setVoiceSelection("")
    setCustomAudioId("")
  }, [item, singleEditing, batchEditMode, speakers, audioMaterials])

  useEffect(() => {
    if (materialType !== "character") return
    if (voiceSelection !== CUSTOM_VOICE_ID) return
    if (customAudioId) return
    if (audioMaterials.length === 0) return
    const preferred = audioMaterials.find((a) => String(a.assetId ?? "").trim()) ?? audioMaterials[0]
    setCustomAudioId(preferred?.id ?? "")
  }, [materialType, voiceSelection, customAudioId, audioMaterials])

  useEffect(() => {
    if (!speakerMenuOpen) return
    const updateDropdownPosition = () => {
      const trigger = voiceTriggerRef.current
      if (!trigger) return
      const rect = trigger.getBoundingClientRect()
      const width = Math.max(Math.ceil(rect.width), VOICE_DROPDOWN_WIDTH)
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight
      const left = Math.max(12, Math.min(rect.left, viewportWidth - width - 12))
      const top = rect.bottom + VOICE_DROPDOWN_GAP
      const maxHeight = Math.max(180, viewportHeight - top - 12)
      setVoiceDropdownPosition({ left, top, width, maxHeight })
    }

    updateDropdownPosition()
    const timer = window.setTimeout(() => {
      voiceSearchInputRef.current?.focus()
    }, 0)
    window.addEventListener("resize", updateDropdownPosition)
    window.addEventListener("scroll", updateDropdownPosition, true)
    return () => {
      window.clearTimeout(timer)
      window.removeEventListener("resize", updateDropdownPosition)
      window.removeEventListener("scroll", updateDropdownPosition, true)
    }
  }, [speakerMenuOpen])

  useEffect(() => {
    if (materialType === "character") return
    setSpeakerMenuOpen(false)
    setSpeakerSearch("")
  }, [materialType])

  const handleSave = async () => {
    const fallbackTitle = item.title?.trim() || ""
    const resolvedTitle = title.trim() || fallbackTitle
    const nextAssetId = assetId.trim()
    const fallbackAssetId = String((item as any).assetId ?? "").trim()
    const fallbackVoiceId = String((item as any).voiceSpeakerId ?? "").trim()

    const outgoingVoice =
      materialType === "character"
        ? resolveVoiceUpdate
        : { voiceSpeakerId: null as string | null, voiceSpeakerName: null as string | null }

    if (materialType === "character" && voiceSelection === CUSTOM_VOICE_ID) {
      if (!outgoingVoice.voiceSpeakerId) {
        alert("自定义音色选择的音频素材缺少 assetId，请先为该音频填写/生成 assetId 后再绑定。")
        return
      }
    }

    // If no changes, just exit single edit mode
    if (
      resolvedTitle === fallbackTitle &&
      materialType === item.materialType &&
      String(outgoingVoice.voiceSpeakerId ?? "") === fallbackVoiceId &&
      nextAssetId === fallbackAssetId
    ) {
      setErrorText("")
      onExitSingleEditing()
      return
    }

    try {
      setSaving(true)
      setErrorText("")
      await onSave(item.id, {
        title: resolvedTitle,
        materialType,
        voiceSpeakerId: outgoingVoice.voiceSpeakerId,
        voiceSpeakerName: outgoingVoice.voiceSpeakerName,
        assetId: nextAssetId ? nextAssetId : null
      })
      setTitle(resolvedTitle)
      setErrorText("")
      onExitSingleEditing()
    } catch (error) {
      setErrorText(error instanceof Error ? error.message : "保存失败")
    } finally {
      setSaving(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      void handleSave()
    } else if (e.key === "Escape") {
      setErrorText("")
      setTitle(item.title?.trim() || "")
      setMaterialType(item.materialType || "reference")
      setAssetId(String((item as any).assetId ?? "").trim())
      onExitSingleEditing()
    }
  }

  const selectedSpeaker = speakers.find((s) => s.id === voiceSelection)
  const voiceSelectionLabel = useMemo(() => {
    if (voiceSelection === CUSTOM_VOICE_ID) {
      return selectedCustomAudio?.title?.trim() || "自定义音色"
    }
    return getVoiceSelectionLabel({ voiceSelection, speakers })
  }, [selectedCustomAudio?.title, speakers, voiceSelection])
  const voiceStatusLabel = voiceSelectionLabel || "未绑定音色"
  const filteredSpeakers = useMemo(() => {
    const keyword = speakerSearch.trim().toLowerCase()
    if (!keyword) return speakers
    return speakers.filter((speaker) => speaker.name.toLowerCase().includes(keyword))
  }, [speakerSearch, speakers])

  const shouldSaveOnBlur = (relatedTarget: EventTarget | null) => {
    if (batchEditMode) return false
    const next = relatedTarget as Node | null
    const root = rootRef.current
    if (root && next && root.contains(next)) return false
    const dropdown = voiceDropdownRef.current
    if (dropdown && next && dropdown.contains(next)) return false
    return true
  }

  const handleVoiceSelectionChange = (next: string) => {
    setVoiceSelection(next)
    const nextCustomAudioId = next === CUSTOM_VOICE_ID ? customAudioId : ""
    if (next !== CUSTOM_VOICE_ID) setCustomAudioId("")
    setSpeakerMenuOpen(false)
    setSpeakerSearch("")
    if (batchEditMode) {
      const nextVoice = buildVoiceUpdate({
        materialType,
        voiceSelection: next,
        customAudioId: nextCustomAudioId,
        speakers,
        audioMaterials
      })
      onDraftChange(item.id, {
        title,
        materialType,
        voiceSpeakerId: nextVoice.voiceSpeakerId,
        voiceSpeakerName: nextVoice.voiceSpeakerName,
        assetId: assetId.trim() ? assetId.trim() : null
      })
    }
  }

  return (
    <div
      className={styles.editForm}
      onClick={(e) => e.stopPropagation()}
      onBlur={(e) => {
        if (shouldSaveOnBlur(e.relatedTarget)) {
          setSpeakerMenuOpen(false)
          setSpeakerSearch("")
          void handleSave()
        }
      }}
      ref={rootRef}
    >
      <input
        ref={inputRef}
        type="text"
        className={styles.editInput}
        value={title}
        onChange={(e) => {
          setTitle(e.target.value)
          if (errorText) setErrorText("")
          updateDraft({ title: e.target.value })
        }}
        onFocus={(e) => e.currentTarget.select()}
        onKeyDown={handleKeyDown}
        disabled={saving}
        placeholder="素材名称"
      />
      {errorText ? <div className={styles.editErrorText}>{errorText}</div> : null}
      <div className={styles.editRow}>
        <select
          className={styles.editSelect}
          value={materialType}
          onChange={(e) => {
            setMaterialType(e.target.value)
            if (errorText) setErrorText("")
            updateDraft({ materialType: e.target.value })
          }}
          disabled={saving}
        >
          <option value="scene">场景</option>
          <option value="character">人物</option>
          <option value="prop">物品</option>
          <option value="video">视频</option>
          <option value="audio">音频</option>
          <option value="reference">参考</option>
        </select>
      </div>

      {materialType === "character" && (
        <div className={styles.editRow}>
          <div className={styles.voiceSelect}>
            <button
              ref={voiceTriggerRef}
              type="button"
              className={styles.editSelectButton}
              onClick={() => {
                if (saving) return
                setSpeakerMenuOpen((open) => {
                  const nextOpen = !open
                  if (!nextOpen) setSpeakerSearch("")
                  return nextOpen
                })
              }}
              disabled={saving}
            >
              <span className={styles.editSelectLabel}>{voiceSelectionLabel}</span>
              <span className={styles.editSelectArrow}>{speakerMenuOpen ? "▴" : "▾"}</span>
            </button>
          </div>
          {selectedSpeaker?.sampleUrl && (
            <button
              className={styles.playBtn}
              onClick={() => {
                const audio = new Audio(selectedSpeaker.sampleUrl)
                void audio.play()
              }}
              title="试听"
              type="button"
              disabled={saving}
            >
              ▶
            </button>
          )}
        </div>
      )}

      {materialType === "character" && voiceSelection === CUSTOM_VOICE_ID && (
        <div className={styles.editRow}>
          <select
            className={styles.editSelect}
            value={customAudioId}
            onChange={(e) => {
              const nextId = e.target.value
              setCustomAudioId(nextId)
              if (!batchEditMode) return
              const nextVoice = buildVoiceUpdate({
                materialType,
                voiceSelection,
                customAudioId: nextId,
                speakers,
                audioMaterials
              })
              onDraftChange(item.id, {
                title,
                materialType,
                voiceSpeakerId: nextVoice.voiceSpeakerId,
                voiceSpeakerName: nextVoice.voiceSpeakerName,
                assetId: assetId.trim() ? assetId.trim() : null
              })
            }}
            disabled={saving || audioMaterials.length === 0}
          >
            {audioMaterials.length === 0 ? (
              <option value="">暂无音频素材</option>
            ) : (
              audioMaterials.map((a) => {
                const hasAssetId = Boolean(String(a.assetId ?? "").trim())
                const label = hasAssetId ? a.title : `${a.title}（无assetId）`
                return (
                  <option key={a.id} value={a.id}>
                    {label}
                  </option>
                )
              })
            )}
          </select>
          {selectedCustomAudio?.sourceUrl && (
            <button
              className={styles.playBtn}
              onClick={() => {
                const audio = new Audio(selectedCustomAudio.sourceUrl)
                void audio.play()
              }}
              title="试听音频素材"
              type="button"
              disabled={saving}
            >
              ▶
            </button>
          )}
        </div>
      )}

      <input
        type="text"
        className={styles.editInput}
        value={assetId}
        onChange={(e) => {
          setAssetId(e.target.value)
          updateDraft({ assetId: e.target.value })
        }}
        onFocus={(e) => e.currentTarget.select()}
        onKeyDown={handleKeyDown}
        disabled={saving}
        placeholder="assetId（可选）"
      />

      {!batchEditMode && (
        <div className={styles.editActions}>
          <button className={styles.saveBtn} onClick={() => void handleSave()} disabled={saving} type="button">
            {saving ? "保存中..." : "保存"}
          </button>
          <button
            className={styles.cancelBtn}
            onClick={() => {
              setErrorText("")
              onExitSingleEditing()
            }}
            disabled={saving}
            type="button"
          >
            取消
          </button>
        </div>
      )}

      {speakerMenuOpen && voiceDropdownPosition && createPortal(
        <>
          <button
            type="button"
            className={styles.voiceDropdownOverlay}
            aria-label="关闭音色菜单"
            onClick={() => {
              setSpeakerMenuOpen(false)
              setSpeakerSearch("")
            }}
          />
          <div
            ref={voiceDropdownRef}
            className={styles.voiceDropdown}
            style={{
              left: `${voiceDropdownPosition.left}px`,
              top: `${voiceDropdownPosition.top}px`,
              width: `${voiceDropdownPosition.width}px`,
              maxHeight: `${voiceDropdownPosition.maxHeight}px`
            }}
          >
            <div className={styles.voiceDropdownSticky}>
              <div className={`${styles.voiceOption} ${styles.voiceOptionActive}`}>
                {voiceStatusLabel}
              </div>
              <button
                type="button"
                className={`${styles.voiceOption} ${voiceSelection === CUSTOM_VOICE_ID ? styles.voiceOptionActive : ""}`}
                onClick={() => handleVoiceSelectionChange(CUSTOM_VOICE_ID)}
              >
                自定义音色
              </button>
              <div className={styles.voiceSearchRow}>
                <input
                  ref={voiceSearchInputRef}
                  type="text"
                  className={styles.voiceSearchInput}
                  value={speakerSearch}
                  onChange={(e) => setSpeakerSearch(e.target.value)}
                  placeholder="按音色名称搜索"
                />
              </div>
            </div>
            <div className={styles.voiceDropdownList}>
              {filteredSpeakers.length === 0 ? (
                <div className={styles.voiceDropdownEmpty}>暂无匹配音色</div>
              ) : (
                filteredSpeakers.map((speaker) => (
                  <button
                    key={speaker.id}
                    type="button"
                    className={`${styles.voiceOption} ${voiceSelection === speaker.id ? styles.voiceOptionActive : ""}`}
                    onClick={() => handleVoiceSelectionChange(speaker.id)}
                  >
                    {speaker.name}
                  </button>
                ))
              )}
            </div>
          </div>
        </>,
        document.body
      )}
    </div>
  )
}
