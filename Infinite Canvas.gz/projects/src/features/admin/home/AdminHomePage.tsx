"use client"

import { useMemo, type KeyboardEvent, type MouseEvent, type ReactElement, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import styles from "./AdminHomePage.module.css"

type AdminRole = "user" | "admin" | "group_admin"

type CardTextSegment = {
  type: "text"
  text: string
}

type CardLinkSegment = {
  type: "link"
  text: string
  href?: string
}

type CardSegment = CardTextSegment | CardLinkSegment

type AdminCardConfig = {
  key: string
  title: string
  href: string
  roles?: AdminRole[]
  description: CardSegment[][]
}

type AdminHomePageProps = {
  role: string
}

const PRICE_DOC_URL = "https://www.volcengine.com/docs/82379/1544106?lang=zh"
// 待业务补充最终地址后即可转为可点击蓝链，无需再改动卡片交互逻辑。
const QUOTA_GUIDE_URL: string | undefined = undefined
const BILLING_REASON_URL = "https://bytedance.larkoffice.com/wiki/TbjWwb1c1itqB5kLCsxc2gv3nFg"

/**
 * 管理员首页卡片区。
 * 负责根据角色展示可访问模块，并支持卡片整体跳转与卡片内说明链接独立打开。
 */
export function AdminHomePage({ role }: AdminHomePageProps): ReactElement {
  const router = useRouter()

  const cards = useMemo<AdminCardConfig[]>(() => {
    return [
      {
        key: "prompts",
        title: "提示词管理",
        href: "/admin/prompts",
        roles: ["admin", "group_admin"],
        description: [[{ type: "text", text: "维护组内提示词、设置提示词类型，并勾选可使用的组内成员" }]]
      },
      {
        key: "groups",
        title: "用户组管理",
        href: "/admin/groups",
        roles: ["admin"],
        description: [[{ type: "text", text: "创建用户组、为组配置管理员与员工" }]]
      },
      {
        key: "users",
        title: "账号管理",
        href: "/admin/users",
        description: [[{ type: "text", text: "账号列表、创建、启用禁用、重置密码、强制下线" }]]
      },
      {
        key: "pricing",
        title: "价格管理",
        href: "/admin/pricing",
        roles: ["admin"],
        description: [
          [{ type: "text", text: "1. 可按需配置视频生成模型价格；分组未单独配置时，默认沿用系统定价。" }],
          [
            { type: "text", text: "2. 价格调整后请同步通知管理员更新；历史价格说明可查看 " },
            { type: "link", text: "价格说明文档", href: PRICE_DOC_URL },
            { type: "text", text: "。" }
          ]
        ]
      },
      {
        key: "quota",
        title: "额度分配",
        href: "/admin/quota",
        description: [
          [{ type: "text", text: "1. 支持为业务团队和个人分配视频生成可用额度。" }],
          [
            { type: "text", text: "2. 额度分配规则与使用原因说明可查看 " },
            { type: "link", text: "分用额度相关说明", href: QUOTA_GUIDE_URL },
            { type: "text", text: " 和 " },
            { type: "link", text: "具体原因", href: BILLING_REASON_URL },
            { type: "text", text: "。" }
          ]
        ]
      },
      {
        key: "billing",
        title: "用量与估算账单",
        href: "/admin/billing",
        description: [
          [{ type: "text", text: "1. 查看视频生成模型的消耗 token 用量与预估费用。" }],
          [
            { type: "text", text: "2. 预估费用仅供内部参考；若与最终账单存在差异，可查看 " },
            { type: "link", text: "具体原因", href: BILLING_REASON_URL },
            { type: "text", text: "。" }
          ]
        ]
      },
      {
        key: "api-tester",
        title: "API 测试台",
        href: "/admin/api-tester",
        description: [[{ type: "text", text: "选择接口、编辑请求、查看响应、保存历史与导出 curl" }]]
      },
      {
        key: "audit",
        title: "审计日志",
        href: "/admin/audit",
        description: [[{ type: "text", text: "追踪管理员操作记录，支持筛选与查看详情" }]]
      },
      {
        key: "telemetry",
        title: "自迭代任务单",
        href: "/admin/telemetry",
        description: [[{ type: "text", text: "基于 /tvc 漏斗数据生成可验证的迭代任务单" }]]
      },
      {
        key: "tts-init",
        title: "初始化音色",
        href: "/admin/tts-init",
        description: [[{ type: "text", text: "一键生成/更新 TTS 音色样音并入库（管理员功能）" }]]
      }
    ]
  }, [])

  const visibleCards = useMemo(() => {
    return cards.filter((card) => !card.roles || card.roles.includes(role as AdminRole))
  }, [cards, role])

  const handleCardOpen = (href: string): void => {
    router.push(href)
  }

  const handleCardKeyDown = (event: KeyboardEvent<HTMLElement>, href: string): void => {
    if (event.key !== "Enter" && event.key !== " ") return
    event.preventDefault()
    handleCardOpen(href)
  }

  const renderSegment = (segment: CardSegment, cardKey: string, lineIndex: number, segmentIndex: number): ReactNode => {
    const key = `${cardKey}-${lineIndex}-${segmentIndex}`
    if (segment.type === "text" || !segment.href) {
      return <span key={key}>{segment.text}</span>
    }
    const handleLinkClick = (event: MouseEvent<HTMLAnchorElement>): void => {
      event.stopPropagation()
    }
    const handleLinkKeyDown = (event: KeyboardEvent<HTMLAnchorElement>): void => {
      event.stopPropagation()
    }
    return (
      <a
        key={key}
        href={segment.href}
        target="_blank"
        rel="noreferrer"
        className={styles.cardLink}
        onClick={handleLinkClick}
        onMouseDown={handleLinkClick}
        onKeyDown={handleLinkKeyDown}
      >
        {segment.text}
      </a>
    )
  }

  return (
    <main className={styles.page}>
      <div className={styles.header}>
        <h1 className={styles.title}>管理员后台</h1>
        <div className={styles.subtitle}>用于项目内接口联调与回归测试（仅管理员可访问）</div>
      </div>

      <div className={styles.cards}>
        {visibleCards.map((card) => (
          <article
            key={card.key}
            className={styles.card}
            role="link"
            tabIndex={0}
            onClick={() => handleCardOpen(card.href)}
            onKeyDown={(event) => handleCardKeyDown(event, card.href)}
          >
            <div className={styles.cardTitle}>{card.title}</div>
            <div className={styles.cardDescList}>
              {card.description.map((line, lineIndex) => (
                <div key={`${card.key}-${lineIndex}`} className={styles.cardDescLine}>
                  {line.map((segment, segmentIndex) => renderSegment(segment, card.key, lineIndex, segmentIndex))}
                </div>
              ))}
            </div>
          </article>
        ))}
      </div>
    </main>
  )
}
