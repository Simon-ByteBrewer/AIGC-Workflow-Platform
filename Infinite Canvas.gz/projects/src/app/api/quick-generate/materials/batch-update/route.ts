import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq, inArray, or, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { quickGenerateEpisodes, quickGenerateMaterials } from "@/shared/schema"
import {
  assertQuickGenerateMaterialTitlesAvailable,
  normalizeMaterialTitle,
  normalizeMaterialType
} from "@/server/domains/quick-generate/materialTitleUniqueness"

export const runtime = "nodejs"

const updateItemSchema = z.object({
  id: z.string().trim().min(1),
  title: z.string().trim().max(200).optional().nullable(),
  materialType: z.string().trim().min(1).optional(),
  voiceSpeakerId: z.string().trim().optional().nullable(),
  voiceSpeakerName: z.string().trim().optional().nullable(),
  assetId: z.string().trim().max(200).optional().nullable()
})

const batchUpdateSchema = z.object({
  items: z.array(updateItemSchema).min(1)
})

const TITLE_SYNCABLE_MATERIAL_TYPES = new Set(["character", "scene", "prop"])
const EPISODE_SYNC_BATCH_SIZE = 20

function replaceNameInStringList(list: unknown, oldTitle: string, newTitle: string): string[] {
  if (!Array.isArray(list)) return []
  return list
    .map((item) => {
      const current = String(item ?? "").trim()
      if (!current) return ""
      return current === oldTitle ? newTitle : current
    })
    .filter(Boolean)
}

function isTitleSyncableMaterialType(materialType: string): boolean {
  return TITLE_SYNCABLE_MATERIAL_TYPES.has(materialType)
}

function escapeLikePattern(value: string): string {
  return value.replace(/[\\%_]/g, "\\$&")
}

function chunkArray<T>(items: T[], size: number): T[][] {
  if (items.length <= size) return [items]

  const chunks: T[][] = []
  for (let index = 0; index < items.length; index += size) {
    chunks.push(items.slice(index, index + size))
  }
  return chunks
}

function syncEpisodePayloadMaterialTitle(input: {
  payload: unknown
  oldTitle: string
  newTitle: string
  materialType: string
}): unknown {
  if (!isTitleSyncableMaterialType(input.materialType)) {
    return input.payload
  }

  const payload =
    input.payload && typeof input.payload === "object" && !Array.isArray(input.payload)
      ? ({ ...(input.payload as Record<string, unknown>) } as Record<string, unknown>)
      : {}

  const workflowResponse =
    payload.workflowResponse && typeof payload.workflowResponse === "object" && !Array.isArray(payload.workflowResponse)
      ? ({ ...(payload.workflowResponse as Record<string, unknown>) } as Record<string, unknown>)
      : {}

  const requestPayload =
    payload.requestPayload && typeof payload.requestPayload === "object" && !Array.isArray(payload.requestPayload)
      ? ({ ...(payload.requestPayload as Record<string, unknown>) } as Record<string, unknown>)
      : {}

  const workflowInput =
    requestPayload.workflowInput && typeof requestPayload.workflowInput === "object" && !Array.isArray(requestPayload.workflowInput)
      ? ({ ...(requestPayload.workflowInput as Record<string, unknown>) } as Record<string, unknown>)
      : {}

  const replaceShotField = input.materialType === "character" ? "roles" : input.materialType === "scene" ? "scenes" : input.materialType === "prop" ? "items" : null
  const replaceInputField =
    input.materialType === "character" ? "role_list" : input.materialType === "scene" ? "scene_list" : input.materialType === "prop" ? "item_list" : null

  const nextShots = Array.isArray(workflowResponse.shots)
    ? workflowResponse.shots.map((raw) => {
        const shot = raw && typeof raw === "object" && !Array.isArray(raw) ? ({ ...(raw as Record<string, unknown>) } as Record<string, unknown>) : {}
        if (replaceShotField) {
          shot[replaceShotField] = replaceNameInStringList(shot[replaceShotField], input.oldTitle, input.newTitle)
        }
        return shot
      })
    : workflowResponse.shots

  const nextWorkflowInput = { ...workflowInput }
  if (replaceInputField && Array.isArray(workflowInput[replaceInputField])) {
    nextWorkflowInput[replaceInputField] = (workflowInput[replaceInputField] as unknown[])
      .map((row) => {
        const item = row && typeof row === "object" && !Array.isArray(row) ? ({ ...(row as Record<string, unknown>) } as Record<string, unknown>) : {}
        const currentName = String(item.name ?? "").trim()
        if (currentName === input.oldTitle) item.name = input.newTitle
        return item
      })
  }

  return {
    ...payload,
    workflowResponse: {
      ...workflowResponse,
      shots: nextShots
    },
    requestPayload: {
      ...requestPayload,
      workflowInput: nextWorkflowInput
    }
  }
}

export async function PUT(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  try {
    const session = await getSessionFromRequest(req)
    if (!session?.userId) {
      return NextResponse.json(makeApiErr(traceId, "UNAUTHORIZED", "未登录"), { status: 401 })
    }

    const body = await req.json().catch(() => ({}))
    const parsed = batchUpdateSchema.safeParse(body)
    if (!parsed.success) {
      logger.warn({
        event: "quick_generate_materials_batch_update_validation_failed",
        module: "quick_generate",
        traceId,
        message: "素材批量更新参数校验失败",
        itemCount: Array.isArray((body as { items?: unknown[] } | undefined)?.items) ? (body as { items?: unknown[] }).items?.length : undefined,
        errorMessage: parsed.error.message
      })
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "参数错误: " + parsed.error.message), { status: 400 })
    }

    const { items } = parsed.data
    const db = await getDb({ quickGenerateMaterials, quickGenerateEpisodes })

    // Use transaction to update all items
    await db.transaction(async (tx) => {
      const itemIds = Array.from(new Set(items.map((item) => item.id)))
      const existingRows = await tx
        .select({
          id: quickGenerateMaterials.id,
          title: quickGenerateMaterials.title,
          storyId: quickGenerateMaterials.storyId,
          materialType: quickGenerateMaterials.materialType,
          assetId: quickGenerateMaterials.assetId
        })
        .from(quickGenerateMaterials)
        .where(inArray(quickGenerateMaterials.id, itemIds))
      const existingById = new Map(existingRows.map((row) => [row.id, row]))
      await assertQuickGenerateMaterialTitlesAvailable({
        db: tx,
        action: "修改",
        candidates: items.flatMap((item) => {
          const existing = existingById.get(item.id)
          if (!existing) return []
          return [
            {
              storyId: existing.storyId,
              materialType:
                item.materialType !== undefined
                  ? normalizeMaterialType(item.materialType)
                  : normalizeMaterialType(existing.materialType),
              title: item.title !== undefined ? normalizeMaterialTitle(item.title) : normalizeMaterialTitle(existing.title),
              excludeId: item.id
            }
          ]
        })
      })

      for (const item of items) {
        const { id, ...updates } = item
        
        // Ensure voice fields are cleared if materialType is changed from character
        if (updates.materialType && updates.materialType !== "character") {
          updates.voiceSpeakerId = null
          updates.voiceSpeakerName = null
        }

        const filteredUpdates: Record<string, any> = { updatedAt: new Date() }
        if (updates.title !== undefined) filteredUpdates.title = updates.title
        if (updates.materialType !== undefined) filteredUpdates.materialType = updates.materialType
        
        if (updates.voiceSpeakerId !== undefined) {
          filteredUpdates.voiceSpeakerId = updates.voiceSpeakerId === null || updates.voiceSpeakerId === "" ? null : updates.voiceSpeakerId
        }
        if (updates.voiceSpeakerName !== undefined) {
          filteredUpdates.voiceSpeakerName = updates.voiceSpeakerName === null || updates.voiceSpeakerName === "" ? null : updates.voiceSpeakerName
        }
        if (updates.assetId !== undefined) {
          filteredUpdates.assetId = updates.assetId === null || updates.assetId === "" ? null : updates.assetId
        }

        console.log(`[batch-update] Executing update for id=${id}`, filteredUpdates)

        const existing = existingById.get(id)
        if (!existing) {
          console.log(`[batch-update] Record id=${id} not found, skipping`)
          continue
        }

        const oldTitle = normalizeMaterialTitle(existing.title)
        const nextTitle = filteredUpdates.title !== undefined ? normalizeMaterialTitle(filteredUpdates.title) : oldTitle
        const oldAssetId = normalizeMaterialTitle(existing.assetId)
        const nextAssetId = filteredUpdates.assetId !== undefined ? normalizeMaterialTitle(filteredUpdates.assetId) : oldAssetId
        const shouldSyncEpisodeTitle =
          Boolean(nextTitle && oldTitle && nextTitle !== oldTitle) && isTitleSyncableMaterialType(existing.materialType)

        // If assetId changes (including cleared), clear review fields to avoid mismatch.
        if (filteredUpdates.assetId !== undefined && nextAssetId !== oldAssetId) {
          filteredUpdates.assetStatus = null
          filteredUpdates.assetErrorMessage = null
        }

        await tx
          .update(quickGenerateMaterials)
          .set(filteredUpdates)
          .where(eq(quickGenerateMaterials.id, id))

        if (shouldSyncEpisodeTitle) {
          const syncStart = Date.now()
          const likePattern = `%${escapeLikePattern(oldTitle)}%`
          const candidateRows = await tx
            .select({
              id: quickGenerateEpisodes.id
            })
            .from(quickGenerateEpisodes)
            .where(
              and(
                eq(quickGenerateEpisodes.storyId, existing.storyId),
                or(
                  sql`${quickGenerateEpisodes.resultPayload}::text LIKE ${likePattern} ESCAPE '\'`,
                  sql`${quickGenerateEpisodes.requestPayload}::text LIKE ${likePattern} ESCAPE '\'`
                )
              )
            )

          let syncedEpisodeCount = 0

          for (const episodeIdChunk of chunkArray(
            candidateRows.map((episode) => episode.id),
            EPISODE_SYNC_BATCH_SIZE
          )) {
            const episodeRows = await tx
              .select({
                id: quickGenerateEpisodes.id,
                resultPayload: quickGenerateEpisodes.resultPayload,
                requestPayload: quickGenerateEpisodes.requestPayload
              })
              .from(quickGenerateEpisodes)
              .where(inArray(quickGenerateEpisodes.id, episodeIdChunk))

            for (const episode of episodeRows) {
              const mergedPayload = syncEpisodePayloadMaterialTitle({
                payload: {
                  ...(episode.resultPayload && typeof episode.resultPayload === "object" && !Array.isArray(episode.resultPayload)
                    ? (episode.resultPayload as Record<string, unknown>)
                    : {}),
                  requestPayload:
                    episode.requestPayload && typeof episode.requestPayload === "object" && !Array.isArray(episode.requestPayload)
                      ? episode.requestPayload
                      : undefined
                },
                oldTitle,
                newTitle: nextTitle,
                materialType: existing.materialType
              }) as Record<string, unknown>

              const nextResultPayload =
                mergedPayload.workflowResponse && typeof mergedPayload.workflowResponse === "object"
                  ? { workflowResponse: mergedPayload.workflowResponse }
                  : episode.resultPayload
              const nextRequestPayload =
                mergedPayload.requestPayload && typeof mergedPayload.requestPayload === "object"
                  ? mergedPayload.requestPayload
                  : episode.requestPayload

              const resultPayloadChanged = JSON.stringify(nextResultPayload) !== JSON.stringify(episode.resultPayload)
              const requestPayloadChanged = JSON.stringify(nextRequestPayload) !== JSON.stringify(episode.requestPayload)
              if (!resultPayloadChanged && !requestPayloadChanged) {
                continue
              }

              await tx
                .update(quickGenerateEpisodes)
                .set({
                  resultPayload: nextResultPayload,
                  requestPayload: nextRequestPayload,
                  updatedAt: new Date()
                })
                .where(eq(quickGenerateEpisodes.id, episode.id))

              syncedEpisodeCount += 1
            }
          }

          logger.info({
            event: "quick_generate_materials_batch_update_episode_title_sync_success",
            module: "quick_generate",
            traceId,
            message: "素材改名已同步到关联剧集",
            materialId: id,
            storyId: existing.storyId,
            materialType: existing.materialType,
            oldTitle,
            newTitle: nextTitle,
            candidateCount: candidateRows.length,
            syncedEpisodeCount,
            durationMs: Date.now() - syncStart
          })
        }
      }
    })

    logger.info({
      event: "quick_generate_materials_batch_update_success",
      module: "quick_generate",
      traceId,
      message: "素材批量更新成功",
      itemCount: items.length,
      durationMs: Date.now() - start
    })
    return NextResponse.json(makeApiOk(traceId, { updatedCount: items.length }))
  } catch (error: any) {
    logger.error({
      event: "quick_generate_materials_batch_update_failed",
      module: "quick_generate",
      traceId,
      message: "素材批量更新失败",
      durationMs: Date.now() - start,
      errorName: error?.name,
      errorMessage: error?.message,
      stack: error?.stack
    })
    const status = Number.isInteger(error?.status) ? Number(error.status) : 500
    const code = String(error?.code ?? "").trim() || "INTERNAL_ERROR"
    return NextResponse.json(makeApiErr(traceId, code, error.message || "更新失败"), { status })
  }
}
