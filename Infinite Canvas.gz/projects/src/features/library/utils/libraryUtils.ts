import type { Scope } from "../components/ScopeTabs"
import type { CategoryOption } from "../components/CategorySidebar"
import type { ViewMode } from "../components/LibraryToolbar"
import type { LibraryItem } from "@/shared/contracts/library/libraryItem"
import type { PublicResource, SharedResource } from "@/shared/schema"

export const MY_CATEGORIES: CategoryOption[] = [
  { id: "draft", label: "草稿" },
  { id: "video", label: "成片" },
  { id: "storyboard", label: "分镜脚本" },
  { id: "material", label: "素材" },
]

export const PUBLIC_CATEGORIES: CategoryOption[] = [
  { id: "all", label: "全部" },
  { id: "roles", label: "角色库" },
  { id: "backgrounds", label: "场景库" },
  { id: "props", label: "物品库" },
  { id: "audios", label: "音频库" },
  { id: "videos", label: "视频库" },
]

export const COPYRIGHT_CATEGORIES: CategoryOption[] = [
  { id: "all", label: "全部" },
  { id: "scene", label: "场景" },
  { id: "character", label: "人物" },
  { id: "prop", label: "物品" },
  { id: "video", label: "视频" },
  { id: "audio", label: "音频" }
]

export function normalizeScope(raw: string | null): Scope {
  if (raw === "public") return "library"
  if (raw === "library") return "library"
  if (raw === "shared") return "shared"
  if (raw === "copyright") return "copyright"
  return "my"
}

export function normalizeCategory(scope: Scope, raw: string | null): string {
  if (scope === "library" || scope === "shared" || scope === "copyright") return raw ?? "all"
  return raw ?? "draft"
}

export function normalizeView(raw: string | null): ViewMode {
  return raw === "list" ? "list" : "grid"
}

export function mapCategoryToPublicType(category: string): "all" | "character" | "background" | "props" | "audio" | "video" {
  if (category === "roles") return "character"
  if (category === "backgrounds") return "background"
  if (category === "props") return "props"
  if (category === "audios") return "audio"
  if (category === "videos") return "video"
  return "all"
}

export function mapPublicTypeToCategory(type: string): string {
  if (type === "character") return "roles"
  if (type === "background") return "backgrounds"
  if (type === "props") return "props"
  if (type === "audio" || type === "music" || type === "effect") return "audios"
  if (type === "video" || type === "transition") return "videos"
  return "all"
}

export function mapPublicResourceToItem(resource: PublicResource | SharedResource, scope: "library" | "shared"): LibraryItem {
  const base = scope === "shared" ? "/api/library/shared-resources/file" : "/api/library/public-resources/file"
  const stablePreviewUrl = resource.previewStorageKey ? `${base}/${resource.id}?kind=preview` : undefined
  const stableOriginalUrl = resource.originalStorageKey ? `${base}/${resource.id}?kind=original` : undefined
  const rawPreviewUrl = typeof resource.previewUrl === "string" ? resource.previewUrl.trim() : ""
  const rawOriginalUrl = typeof resource.originalUrl === "string" ? resource.originalUrl.trim() : ""
  const isHttpUrl = (u: string) => u.startsWith("http://") || u.startsWith("https://")
  const preferredPreviewUrl = rawPreviewUrl && isHttpUrl(rawPreviewUrl) ? rawPreviewUrl : undefined
  const preferredOriginalUrl = rawOriginalUrl && isHttpUrl(rawOriginalUrl) ? rawOriginalUrl : undefined

  const rawVersions = (resource as any)?._versions as Array<{
    id: string
    previewStorageKey?: string | null
    createdAt?: Date | string
    voiceSpeakerId?: string | null
    voiceSpeakerName?: string | null
    voiceAudioStorageKey?: string | null
  }> | undefined
  const versions = rawVersions
    ?.map((v) => ({
      id: v.id,
      thumbnail: v.previewStorageKey ? `${base}/${v.id}?kind=preview` : "",
      createdAt: v.createdAt ? (typeof v.createdAt === "string" ? v.createdAt : v.createdAt.toISOString()) : undefined,
      voiceSpeakerId: v.voiceSpeakerId ?? null,
      voiceSpeakerName: v.voiceSpeakerName ?? null,
      voiceAudioStorageKey: v.voiceAudioStorageKey ?? null
    }))
    .filter((v) => v.thumbnail)

  return {
    id: resource.id,
    title: resource.name,
    type: "material",
    scope,
    publicCategory: mapPublicTypeToCategory(resource.type),
    subtitle: resource.description,
    voiceSpeakerId: (resource as any)?.voiceSpeakerId ?? null,
    voiceSpeakerName: (resource as any)?.voiceSpeakerName ?? null,
    voiceAudioStorageKey: (resource as any)?.voiceAudioStorageKey ?? null,
    thumbnail:
      preferredPreviewUrl ||
      stablePreviewUrl ||
      rawPreviewUrl ||
      preferredOriginalUrl ||
      stableOriginalUrl ||
      rawOriginalUrl ||
      undefined,
    originalUrl:
      preferredOriginalUrl ||
      stableOriginalUrl ||
      rawOriginalUrl ||
      preferredPreviewUrl ||
      stablePreviewUrl ||
      rawPreviewUrl ||
      undefined,
    versions: versions && versions.length > 1 ? versions : undefined
  }
}

export type AiResourceType = "background" | "character" | "props"

export function mapAiTypeToDbType(t: AiResourceType): "background" | "character" | "props" {
  return t
}
