import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { updatePricingRuleByGroup } from "@/server/domains/admin/pricingAdmin"

export async function POST(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "仅平台管理员可修改价格"), { status: 403 })
  }

  try {
    const body = await req.json()
    await updatePricingRuleByGroup(actor.userId, actor.roleKey, actor.groupId, body)
    return NextResponse.json(makeApiOk(traceId, { success: true }))
  } catch (error: any) {
    return NextResponse.json(makeApiErr(traceId, "PRICING_UPDATE_FAILED", error?.message ?? "价格更新失败"), { status: 500 })
  }
}
