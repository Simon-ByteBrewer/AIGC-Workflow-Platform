import { Suspense } from "react"
import { QuotaRecordsPage } from "@/features/admin/quota/QuotaRecordsPage"

export default function AdminQuotaRecordsRoute() {
  return (
    <Suspense fallback={null}>
      <QuotaRecordsPage />
    </Suspense>
  )
}
