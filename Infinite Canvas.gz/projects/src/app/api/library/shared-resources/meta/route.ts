import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { inArray } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { sharedResources } from "@/shared/schema/library"

export const runtime = "nodejs"

const querySchema = z.object({
  ids: z.string().trim().min(1).max(10_000)
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({ ids: req.nextUrl.searchParams.get("ids") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const ids = parsed.data.ids
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 50)
  if (ids.length === 0) return NextResponse.json(makeApiOk(traceId, { items: [] as Array<{ id: string; name: string }> }), { status: 200 })

  await ensurePublicSchema()
  const db = await getDb({ sharedResources })
  const rows = await db.select({ id: sharedResources.id, name: sharedResources.name }).from(sharedResources).where(inArray(sharedResources.id, ids))

  const items = rows
    .map((r) => ({ id: String(r.id), name: String(r.name ?? "").trim() }))
    .filter((it) => it.id && it.name)

  return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
}

