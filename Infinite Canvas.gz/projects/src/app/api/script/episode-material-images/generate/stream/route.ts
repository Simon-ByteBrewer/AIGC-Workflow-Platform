import { and, eq } from "drizzle-orm"
import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { enqueueEpisodeMaterialJob, kickEpisodeMaterialWorker } from "@/server/domains/storyboard/jobs/episodeMaterialWorker"
import { createStartedJobEventStreamResponse } from "@/server/framework/jobs/createStartedJobEventStreamResponse"
import { stories } from "@/shared/schema/story"

export const runtime = "nodejs"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200).optional(),
  clearHistory: z.boolean().optional(),
  sceneModelName: z.string().trim().min(1).max(100).optional(),
  roleModelName: z.string().trim().min(1).max(100).optional(),
  itemModelName: z.string().trim().min(1).max(100).optional()
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  return createStartedJobEventStreamResponse({
    req,
    traceId,
    userId,
    startJob: async () => {
      const { jobId } = await enqueueEpisodeMaterialJob({
        userId,
        traceId,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId ?? null,
        clearHistory: parsed.data.clearHistory ?? true,
        sceneModelName: parsed.data.sceneModelName,
        roleModelName: parsed.data.roleModelName,
        itemModelName: parsed.data.itemModelName
      })
      kickEpisodeMaterialWorker()
      return { jobId }
    }
  })
}
