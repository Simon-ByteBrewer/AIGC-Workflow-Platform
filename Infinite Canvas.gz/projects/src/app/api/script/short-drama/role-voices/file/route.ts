import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "coze-coding-dev-sdk"
import { stories } from "@/shared/schema"
import { and, eq } from "drizzle-orm"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const querySchema = z.object({
  key: z.string().trim().min(1).max(5000)
})

function extractStoryIdFromKey(key: string): string {
  const parts = key.split("/").filter(Boolean)
  const idx = parts.findIndex((x) => x === "role-voices")
  const storyId = idx >= 0 ? String(parts[idx + 1] ?? "").trim() : ""
  return storyId
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ key: url.searchParams.get("key") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const key = parsed.data.key
  if (!key.startsWith("public/short-drama/role-voices/")) {
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限访问该资源"), { status: 403 })
  }

  const storyId = extractStoryIdFromKey(key)
  if (!storyId) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const db = await getDb({ stories })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

  const storage = getS3Storage()
  try {
    const presigned = await resolveStorageUrl(storage, key)
    return NextResponse.redirect(presigned)
  } catch {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
  }
}
