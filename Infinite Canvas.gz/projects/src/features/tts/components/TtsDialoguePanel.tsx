"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import styles from "./TtsDialoguePanel.module.css"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"

type Speaker = { id: string; name: string; sampleUrl: string | null; sampleText: string }
type Dialogue = { id: string; roleName: string; content: string }

export function TtsDialoguePanel({
  storyboardId,
  dialogues,
  roleOptions,
  onAudioGenerated
}: {
  storyboardId: string
  dialogues: Dialogue[]
  roleOptions?: string[]
  onAudioGenerated?: () => void
}): ReactElement {
  const [speakers, setSpeakers] = useState<Speaker[]>([])
  const [speakerByDialogueId, setSpeakerByDialogueId] = useState<Record<string, string>>({})
  const [preview, setPreview] = useState<{ name: string; src: string } | null>(null)
  const [loadingId, setLoadingId] = useState<string | null>(null)
  const [manualRole, setManualRole] = useState("")
  const [manualText, setManualText] = useState("")
  const [manualDialogues, setManualDialogues] = useState<Dialogue[]>([])
  const [hiddenDialogueIds, setHiddenDialogueIds] = useState<Set<string>>(() => new Set())

  useEffect(() => {
    let cancelled = false
    const load = async () => {
      try {
        const res = await fetch("/api/tts/speakers", { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { speakers?: Speaker[] } } | null
        const list = Array.isArray(json?.data?.speakers) ? (json?.data?.speakers ?? []) : []
        if (!cancelled) setSpeakers(list)
      } catch {
        if (!cancelled) setSpeakers([])
      }
    }
    void load()
    return () => {
      cancelled = true
    }
  }, [])

  const defaultSpeakerId = speakers[0]?.id ?? ""
  useEffect(() => {
    if (!defaultSpeakerId) return
    setSpeakerByDialogueId((prev) => {
      const next = { ...prev }
      for (const d of [...dialogues, ...manualDialogues]) {
        if (!next[d.id]) next[d.id] = defaultSpeakerId
      }
      return next
    })
  }, [defaultSpeakerId, dialogues, manualDialogues])

  const speakerOptions = useMemo(() => speakers, [speakers])

  const roleSelectOptions = useMemo(() => {
    const list = Array.isArray(roleOptions) ? roleOptions : []
    const out: Array<{ value: string; label: string }> = []
    const seen = new Set<string>()
    const push = (name: string) => {
      const n = name.trim()
      if (!n) return
      if (seen.has(n)) return
      seen.add(n)
      out.push({ value: n, label: n })
    }
    for (const n of list) push(n)
    push("旁白")
    return out.length ? out : [{ value: "旁白", label: "旁白" }]
  }, [roleOptions])

  const combinedDialogues = useMemo(() => {
    const list = [...dialogues, ...manualDialogues]
    const byKey = new Set<string>()
    const out: Array<Dialogue & { __manual?: boolean }> = []
    for (const d of list) {
      if (hiddenDialogueIds.has(d.id)) continue
      const k = `${d.roleName}::${d.content}`
      if (byKey.has(k)) continue
      byKey.add(k)
      out.push({ ...d, __manual: manualDialogues.some((m) => m.id === d.id) })
    }
    return out
  }, [dialogues, hiddenDialogueIds, manualDialogues])

  const addManualDialogue = useCallback(() => {
    const roleName = (manualRole || "旁白").trim()
    const content = manualText.trim()
    if (!content) return
    const id =
      typeof crypto !== "undefined" && typeof (crypto as any).randomUUID === "function"
        ? (crypto as any).randomUUID()
        : `manual-${Date.now()}-${Math.random().toString(16).slice(2)}`
    setManualDialogues((prev) => [{ id, roleName, content }, ...prev])
    setManualText("")
  }, [manualRole, manualText])

  const generateFor = useCallback(
    async (d: Dialogue) => {
      const speakerId = (speakerByDialogueId[d.id] ?? defaultSpeakerId).trim()
      if (!speakerId) return
      setLoadingId(d.id)
      try {
        const res = await fetch("/api/video-creation/audios/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ storyboardId, roleName: d.roleName, text: d.content, speakerId })
        })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { audioUrl?: string }; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        const url = (json.data?.audioUrl ?? "").trim()
        if (url) setPreview({ name: `${d.roleName} - ${speakerId}`, src: url })
        onAudioGenerated?.()
      } catch (err) {
        const msg = (err as any)?.message ? String((err as any).message) : "生成音频失败"
        alert(msg)
      } finally {
        setLoadingId(null)
      }
    },
    [defaultSpeakerId, onAudioGenerated, speakerByDialogueId, storyboardId]
  )

  return (
    <div className={styles.wrap} aria-label="台词配音">
      <div className={styles.header}>
        <div className={styles.title}>台词配音</div>
        <div className={styles.hint}>选择音色试听样音，生成台词音频</div>
      </div>

      <div className={styles.manualForm} aria-label="手动添加台词">
        <div className={styles.manualTop}>
          <ListboxSelect
            className={styles.select}
            value={(manualRole || roleSelectOptions[0]?.value || "旁白").trim()}
            ariaLabel="选择角色"
            options={roleSelectOptions}
            onChange={(next) => setManualRole(next)}
            disabled={roleSelectOptions.length === 0}
          />
          <div className={styles.manualActions}>
            <button
              type="button"
              className={styles.btnPrimary}
              onClick={addManualDialogue}
              disabled={!manualText.trim()}
              title="添加到台词列表"
            >
              添加台词
            </button>
          </div>
        </div>
        <textarea
          className={styles.manualTextarea}
          value={manualText}
          placeholder="输入台词内容（可多句）"
          onChange={(e) => setManualText(e.target.value)}
          maxLength={500}
        />
      </div>

      {combinedDialogues.length > 0 ? (
        <div className={styles.list}>
          {combinedDialogues.map((d) => {
            const selected = speakerByDialogueId[d.id] ?? defaultSpeakerId
            const speaker = speakerOptions.find((s) => s.id === selected) ?? null
            const canSample = Boolean(speaker?.sampleUrl)
            const isLoading = loadingId === d.id
            const isManual = Boolean((d as any).__manual)
            return (
              <div key={d.id} className={styles.row}>
                <div className={styles.rowTop}>
                  <div className={styles.role} title={d.roleName}>
                    {d.roleName}
                  </div>
                  <ListboxSelect
                    className={styles.select}
                    value={selected}
                    ariaLabel="选择音色"
                    options={speakerOptions.map((s) => ({ value: s.id, label: s.name }))}
                    onChange={(next) => setSpeakerByDialogueId((prev) => ({ ...prev, [d.id]: next }))}
                    disabled={speakerOptions.length === 0}
                  />
                  <button
                    type="button"
                    className={styles.btnGhost}
                    onClick={() => {
                      if (!speaker?.sampleUrl) return
                      setPreview({ name: `${speaker.name}（样音）`, src: speaker.sampleUrl })
                    }}
                    disabled={!canSample}
                  >
                    试听
                  </button>
                  <button type="button" className={styles.btnPrimary} onClick={() => void generateFor(d)} disabled={isLoading}>
                    {isLoading ? "生成中…" : "生成"}
                  </button>
                  <button
                    type="button"
                    className={styles.btnDanger}
                    onClick={() => {
                      if (isManual) setManualDialogues((prev) => prev.filter((m) => m.id !== d.id))
                      setHiddenDialogueIds((prev) => {
                        const next = new Set(prev)
                        next.add(d.id)
                        return next
                      })
                    }}
                    title="删除该条台词"
                  >
                    删除
                  </button>
                </div>
                <div className={styles.content} title={d.content}>
                  {d.content}
                </div>
              </div>
            )
          })}
        </div>
      ) : (
        <div className={styles.empty}>该分镜暂无可配音的台词</div>
      )}

      {preview ? (
        <div className={styles.preview} aria-label="试听">
          <div className={styles.previewHeader}>
            <div className={styles.previewTitle} title={preview.name}>
              {preview.name}
            </div>
            <button type="button" className={styles.previewClose} onClick={() => setPreview(null)} aria-label="关闭试听">
              ×
            </button>
          </div>
          <audio key={preview.src} className={styles.previewAudio} src={preview.src} controls autoPlay />
        </div>
      ) : null}
    </div>
  )
}
