import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { getDb } from "@/server/db/getDb"
import { publicCharacterCostumes, publicCharacterLooks, publicResources } from "@/shared/schema"
import { generatedImages, storyAssetLibrary } from "@/shared/schema/generation"
import { stories } from "@/shared/schema/story"
import { uploadPublicBuffer } from "@/shared/storage"
import { fetchImageBuffer } from "@/server/domains/tvc/vibeCreating/tooling/assets/fetchAsset"
import { and, desc, eq, isNull, sql } from "drizzle-orm"
import { logger } from "@/shared/logger"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200).optional(),
  characterId: z.string().trim().min(1).max(200).optional().nullable(),
  characterName: z.string().trim().min(1).max(200),
  characterDescription: z.string().trim().max(50_000).optional(),
  frontImageUrl: z.string().trim().min(1).max(4000),
  look: z
    .object({
      name: z.string().trim().min(1).max(200),
      description: z.string().trim().max(50_000).optional(),
      imageUrl: z.string().trim().min(1).max(4000)
    })
    .optional(),
  costume: z
    .object({
      name: z.string().trim().min(1).max(200),
      description: z.string().trim().max(50_000).optional(),
      imageUrl: z.string().trim().min(1).max(4000)
    })
    .optional()
})

function normalizeContentType(input: string): string {
  const raw = (input ?? "").trim().toLowerCase()
  const base = raw.split(";")[0]?.trim() || ""
  return base || "image/jpeg"
}

function fileExtFromContentType(contentType: string): string {
  const ct = normalizeContentType(contentType)
  if (ct === "image/png") return "png"
  if (ct === "image/webp") return "webp"
  if (ct === "image/gif") return "gif"
  if (ct === "image/avif") return "avif"
  if (ct === "image/jpeg" || ct === "image/jpg") return "jpg"
  return "jpg"
}

function tryExtractStorageKeyFromSourceUrl(input: { sourceUrl: string; baseOrigin: string }): string {
  const raw = (input.sourceUrl ?? "").trim()
  if (!raw) return ""
  if (raw.startsWith("public/short-drama/") || raw.startsWith("public/library/")) return raw

  const u = (() => {
    try {
      if (raw.startsWith("http://") || raw.startsWith("https://")) return new URL(raw)
      if (raw.startsWith("/")) return new URL(raw, input.baseOrigin)
      return null
    } catch {
      return null
    }
  })()
  if (!u) return ""

  if (u.pathname === "/api/script/short-drama/role-assets/file") {
    const key = (u.searchParams.get("key") ?? "").trim()
    if (key.startsWith("public/short-drama/")) return key
  }

  if (u.pathname.startsWith("/public/short-drama/") || u.pathname.startsWith("/public/library/")) {
    return u.pathname.slice(1)
  }

  return ""
}

async function persistImageFromUrl(
  sourceUrl: string,
  prefix: string,
  baseOrigin: string,
  cookieHeader: string | null
): Promise<{ storageKey: string }> {
  const directKey = tryExtractStorageKeyFromSourceUrl({ sourceUrl, baseOrigin })
  if (directKey) return { storageKey: directKey }

  const safeUrl = (() => {
    const s = (sourceUrl ?? "").trim()
    if (!s) return ""
    try {
      const u = new URL(s.startsWith("http") ? s : `http://local${s}`)
      return `${u.protocol}//${u.host}${u.pathname}`
    } catch {
      return s.slice(0, 160)
    }
  })()
  const isRelative = /^\//u.test((sourceUrl ?? "").trim())
  const resolvedUrl = isRelative ? new URL((sourceUrl ?? "").trim(), baseOrigin).toString() : sourceUrl
  const startedAt = Date.now()
  try {
    const cookie = (cookieHeader ?? "").trim()
    const { buffer, contentType } = await fetchImageBuffer(resolvedUrl, cookie ? { headers: { cookie } } : undefined)
    const fileExt = fileExtFromContentType(contentType)
    const uploaded = await uploadPublicBuffer({ buffer, contentType: normalizeContentType(contentType), fileExt, prefix })
    return { storageKey: uploaded.key }
  } catch (e) {
    const msg = typeof (e as any)?.message === "string" ? String((e as any).message) : "unknown"
    const http = msg.match(/HTTP\\s+(\\d{3})/u)?.[1] ?? null
    logger.error({
      event: "import_short_drama_character_download_failed",
      module: "library",
      traceId: "server",
      message: "保存角色到资源库：下载图片失败",
      safeUrl,
      isRelative,
      prefix,
      httpStatus: http,
      errorName: (e as any)?.name,
      errorMessage: msg,
      durationMs: Date.now() - startedAt
    })
    throw e
  }
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const now = new Date()
  const cookieHeader = req.headers.get("cookie")
  const baseOrigin = req.nextUrl.origin

  try {
    logger.info({
      event: "import_short_drama_character_enter",
      module: "library",
      traceId,
      message: "保存角色到资源库：开始",
      userId,
      storyId: parsed.data.storyId ?? null,
      characterId: parsed.data.characterId ?? null,
      characterName: parsed.data.characterName,
      frontUrlIsRelative: /^\//u.test(parsed.data.frontImageUrl),
      lookUrlIsRelative: parsed.data.look ? /^\//u.test(parsed.data.look.imageUrl) : null,
      costumeUrlIsRelative: parsed.data.costume ? /^\//u.test(parsed.data.costume.imageUrl) : null
    })
    const lookPersisted = parsed.data.look
      ? await persistImageFromUrl(parsed.data.look.imageUrl, "public/library/characters/look", baseOrigin, cookieHeader)
      : null
    const costumePersisted = parsed.data.costume
      ? await persistImageFromUrl(parsed.data.costume.imageUrl, "public/library/characters/costume", baseOrigin, cookieHeader)
      : null
    const frontPersisted = await persistImageFromUrl(parsed.data.frontImageUrl, "public/library/characters/front", baseOrigin, cookieHeader)

    const db = await getDb({ publicResources, publicCharacterLooks, publicCharacterCostumes, generatedImages, storyAssetLibrary, stories })
    const requestedId = typeof parsed.data.characterId === "string" ? parsed.data.characterId.trim() : ""
    let characterId = requestedId
    if (characterId) {
      const existed = await db
        .select({ id: publicResources.id, name: publicResources.name })
        .from(publicResources)
        .where(and(eq(publicResources.id, characterId), eq(publicResources.userId, userId), eq(publicResources.type, "character")))
        .limit(1)
      const existedName = typeof existed[0]?.name === "string" ? existed[0]!.name.trim() : ""
      const requestedName = parsed.data.characterName.trim()
      if (!existed[0] || !existedName || existedName !== requestedName) characterId = ""
    }

    if (!characterId) {
      characterId = crypto.randomUUID()
      const stablePreview = `/api/library/public-resources/file/${characterId}?kind=preview`
      const stableOriginal = `/api/library/public-resources/file/${characterId}?kind=original`

      await db.insert(publicResources).values({
        id: characterId,
        userId,
        type: "character",
        source: "ai",
        name: parsed.data.characterName,
        description: parsed.data.characterDescription ?? "",
        previewUrl: stablePreview,
        previewStorageKey: frontPersisted.storageKey,
        originalUrl: stableOriginal,
        originalStorageKey: frontPersisted.storageKey,
        durationMs: null,
        tags: [],
        applicableScenes: [],
        createdAt: now
      })
    } else {
      const stablePreview = `/api/library/public-resources/file/${characterId}?kind=preview`
      const stableOriginal = `/api/library/public-resources/file/${characterId}?kind=original`
      await db
        .update(publicResources)
        .set({
          previewUrl: stablePreview,
          previewStorageKey: frontPersisted.storageKey,
          originalUrl: stableOriginal,
          originalStorageKey: frontPersisted.storageKey,
          description: parsed.data.characterDescription ?? "",
          source: "ai"
        })
        .where(and(eq(publicResources.id, characterId), eq(publicResources.userId, userId), eq(publicResources.type, "character")))
    }

    const storyId = typeof parsed.data.storyId === "string" ? parsed.data.storyId.trim() : ""
    if (storyId) {
      const allowed = await db
        .select({ id: stories.id })
        .from(stories)
        .where(and(eq(stories.id, storyId), eq(stories.userId, userId)))
        .limit(1)
      if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

      const resourceRows = await db
        .select({
          originalUrl: publicResources.originalUrl,
          originalStorageKey: publicResources.originalStorageKey,
          previewUrl: publicResources.previewUrl,
          previewStorageKey: publicResources.previewStorageKey
        })
        .from(publicResources)
        .where(and(eq(publicResources.id, characterId), eq(publicResources.userId, userId), eq(publicResources.type, "character")))
        .limit(1)
      const resource = resourceRows[0] ?? null
      const stablePreview = `/api/library/public-resources/file/${characterId}?kind=preview`
      const stableOriginal = `/api/library/public-resources/file/${characterId}?kind=original`
      const url = (resource?.originalUrl ?? stableOriginal) as any
      const storageKey = String(resource?.originalStorageKey ?? "").trim()
      if (storageKey) {
        const thumbUrl = (resource?.previewUrl ?? stablePreview) as any
        const thumbStorageKey = String(resource?.previewStorageKey ?? "").trim() || null
        await db
          .insert(storyAssetLibrary)
          .values({
            storyId,
            name: parsed.data.characterName,
            displayName: null,
            url,
            storageKey,
            thumbnailUrl: thumbUrl,
            thumbnailStorageKey: thumbStorageKey,
            meta: { libraryType: "character", source: { type: "short_drama_import", publicResourceId: characterId } } as any
          } as any)
          .onConflictDoUpdate({
            target: [storyAssetLibrary.storyId, storyAssetLibrary.name],
            set: {
              displayName: null,
              url,
              storageKey,
              thumbnailUrl: thumbUrl,
              thumbnailStorageKey: thumbStorageKey,
              meta: { libraryType: "character", source: { type: "short_drama_import", publicResourceId: characterId } } as any
            } as any
          })

        const existed = await db
          .select({ id: generatedImages.id })
          .from(generatedImages)
          .where(and(eq(generatedImages.storyId, storyId), eq(generatedImages.category, "role"), eq(generatedImages.name, parsed.data.characterName), isNull(generatedImages.storyboardId)))
          .orderBy(desc(generatedImages.createdAt))
          .limit(1)
        const keepId = existed[0]?.id ?? null
        if (keepId) {
          await db
            .update(generatedImages)
            .set({
              url,
              storageKey,
              thumbnailUrl: thumbUrl,
              thumbnailStorageKey: thumbStorageKey as any,
              category: "role",
              storyboardId: null
            })
            .where(eq(generatedImages.id, keepId))
        } else {
          await db.insert(generatedImages).values({
            storyId,
            storyboardId: null,
            name: parsed.data.characterName,
            description: parsed.data.characterDescription ?? "",
            url,
            storageKey,
            thumbnailUrl: thumbUrl,
            thumbnailStorageKey: thumbStorageKey as any,
            category: "role",
            prompt: null
          })
        }
      }
    }

    let insertedLooks: any[] = []
    let insertedCostumes: any[] = []

    if (lookPersisted && parsed.data.look) {
      const maxRows = await db
        .select({ maxVersion: sql<number | null>`max(${publicCharacterLooks.version})`.mapWith(Number) })
        .from(publicCharacterLooks)
        .where(eq(publicCharacterLooks.characterResourceId, characterId))
        .limit(1)
      const nextVersion = Number(maxRows?.[0]?.maxVersion || 0) + 1
      await db.update(publicCharacterLooks).set({ isDefault: false, updatedAt: now }).where(eq(publicCharacterLooks.characterResourceId, characterId))
      insertedLooks = await db
        .insert(publicCharacterLooks)
        .values({
          characterResourceId: characterId,
          version: nextVersion,
          isDefault: true,
          name: parsed.data.look.name,
          description: parsed.data.look.description ?? "",
          previewStorageKey: lookPersisted.storageKey,
          originalStorageKey: lookPersisted.storageKey,
          previewUrl: null,
          originalUrl: null,
          createdAt: now,
          updatedAt: now
        })
        .returning()
    }

    if (costumePersisted && parsed.data.costume) {
      const maxRows = await db
        .select({ maxVersion: sql<number | null>`max(${publicCharacterCostumes.version})`.mapWith(Number) })
        .from(publicCharacterCostumes)
        .where(eq(publicCharacterCostumes.characterResourceId, characterId))
        .limit(1)
      const nextVersion = Number(maxRows?.[0]?.maxVersion || 0) + 1
      await db.update(publicCharacterCostumes).set({ isDefault: false, updatedAt: now }).where(eq(publicCharacterCostumes.characterResourceId, characterId))
      insertedCostumes = await db
        .insert(publicCharacterCostumes)
        .values({
          characterResourceId: characterId,
          version: nextVersion,
          isDefault: true,
          name: parsed.data.costume.name,
          description: parsed.data.costume.description ?? "",
          previewStorageKey: costumePersisted.storageKey,
          originalStorageKey: costumePersisted.storageKey,
          previewUrl: null,
          originalUrl: null,
          createdAt: now,
          updatedAt: now
        })
        .returning()
    }

    return NextResponse.json(
      makeApiOk(traceId, {
        characterId,
        lookId: insertedLooks[0]?.id ?? null,
        costumeId: insertedCostumes[0]?.id ?? null
      }),
      { status: 200 }
    )
  } catch (e) {
    const msg = String((e as any)?.message ?? "")
    return NextResponse.json(makeApiErr(traceId, "SAVE_FAILED", msg || "保存失败，请稍后重试"), { status: 500 })
  }
}
