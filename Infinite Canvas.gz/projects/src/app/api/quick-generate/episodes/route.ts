import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { inArray } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import {
  QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX,
  QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN
} from "@/shared/contracts/quickGenerateEpisode"
import { adminPromptPresets, groupPromptBindings, promptPresetUserBindings, quickGenerateEpisodes, userGroups } from "@/shared/schema"
import { userSecurity, users } from "@/shared/schema/auth"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { resolveQuickGeneratePromptSelectionsForUser } from "@/server/domains/admin/groupPromptAccess"
import { createQuickGenerateEpisodeAndEnqueueJob } from "@/server/domains/quick-generate/usecases/createQuickGenerateEpisodeAndEnqueueJob"
import { updateQuickGenerateEpisodeShots } from "@/server/domains/quick-generate/usecases/updateQuickGenerateEpisodeShots"

export const runtime = "nodejs"

const baseCreateSchema = {
  storyId: z.string().trim().min(1).max(200),
  episodeNo: z.number().int().min(1).max(10_000),
  videoModel: z.string().trim().min(1).max(100),
  storyboardPanelModel: z.string().trim().min(1).max(100),
  storyboardPromptPresetId: z.string().trim().max(200).optional(),
  videoPromptPresetId: z.string().trim().max(200).optional(),
  storyboardPanelPromptPresetId: z.string().trim().max(200).optional()
}

const contentSchema = z.string().trim().min(1).max(50_000)
const durationMinutesSchema = z
  .number()
  .int()
  .min(QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN)
  .max(QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX)

const postSchema = z.discriminatedUnion("type", [
  z
    .object({
      ...baseCreateSchema,
      type: z.literal("outline"),
      content: contentSchema,
      minDurationMinutes: durationMinutesSchema,
      maxDurationMinutes: durationMinutesSchema,
      shotsNum: z.number().int().min(1).max(10_000).optional()
    })
    .refine((value) => value.minDurationMinutes <= value.maxDurationMinutes, {
      message: "时长区间不合法",
      path: ["maxDurationMinutes"]
    })
    .strict(),
  z
    .object({
      ...baseCreateSchema,
      type: z.literal("storyboard"),
      content: contentSchema
    })
    .strict(),
  z
    .object({
      ...baseCreateSchema,
      type: z.literal("drama"),
      prompt: contentSchema
    })
    .strict()
])

const deleteSchema = z
  .object({
    episodeIds: z.array(z.string().trim().min(1)).min(1)
  })
  .strict()

/**
 * 优先从 query string 读取批量删除参数，兼容旧版 DELETE body 中的 episodeIds。
 */
async function resolveDeleteEpisodeParams(req: NextRequest): Promise<{ episodeIds?: unknown; invalidJson?: boolean }> {
  const queryIds = req.nextUrl.searchParams.get("ids")?.trim()
  if (queryIds) {
    try {
      return { episodeIds: JSON.parse(queryIds) }
    } catch {
      return { episodeIds: null }
    }
  }

  const rawBody = await req.text().catch(() => "")
  if (!rawBody.trim()) return {}

  try {
    const body = JSON.parse(rawBody) as { episodeIds?: unknown }
    return { episodeIds: body?.episodeIds }
  } catch {
    return { invalidJson: true }
  }
}

const shotSchema = z
  .object({
    persistedShotNo: z.number().int().min(1).max(10_000).optional(),
    shotText: z.string().max(50_000),
    roles: z.array(z.string().trim().max(200)).max(200),
    scenes: z.array(z.string().trim().max(200)).max(200),
    items: z.array(z.string().trim().max(200)).max(200),
    optimizedText: z.string().max(50_000).optional().default(""),
    speakerList: z.array(z.string().trim().max(200)).max(200).optional().default([]),
    refAudioNames: z.array(z.string().trim().max(200)).max(200).optional().default([]),
    mutedAutoAudioNames: z.array(z.string().trim().max(200)).max(200).optional().default([]),
    refVideoIds: z.array(z.string().trim().min(1).max(200)).max(200).optional().default([]),
    duration: z.number().int().min(4).max(15).optional().default(10),
    generateAudio: z.boolean().optional().default(true),
    watermark: z.boolean().optional().default(false),
    aspectRatio: z.string().trim().max(20).optional().default(""),
    resolution: z.enum(["480p", "720p", "1080p"]),
    videoModel: z.string().trim().min(1).max(100),
    storyboardPanelPrompt: z.string().max(50_000).optional().default(""),
    storyboardPanelModel: z.string().max(100).optional().default(""),
    storyboardPanelImages: z.array(z.string().url()).max(100).optional().default([]),
    storyboardPanelImageStorageKeys: z.array(z.string().trim().min(1).max(500)).max(100).optional().default([]),
    selectedStoryboardPanelImage: z.string().url().optional().or(z.literal("")).default(""),
    selectedStoryboardPanelImageStorageKey: z.string().trim().max(500).optional().default("")
  })
  .strict()

const putSchema = z.union([
  z
    .object({
      episodeId: z.string().trim().min(1).max(200),
      shots: z.array(shotSchema)
    })
    .strict(),
  z
    .object({
      episodeId: z.string().trim().min(1).max(200),
      shotNo: z.number().int().min(1).max(10_000),
      shot: shotSchema
    })
    .strict()
])

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const db = await getDb({ users, userSecurity, userGroups, adminPromptPresets, groupPromptBindings, promptPresetUserBindings, quickGenerateEpisodes })
    const promptSelections = await resolveQuickGeneratePromptSelectionsForUser({
      db,
      userId,
      storyboardPromptPresetId: parsed.data.storyboardPromptPresetId,
      videoPromptPresetId: parsed.data.videoPromptPresetId,
      storyboardPanelPromptPresetId: parsed.data.storyboardPanelPromptPresetId
    })

    logger.info({
      event: "quick_generate_episode_create_start",
      module: "quick_generate",
      traceId,
      message: "开始创建快速生成剧集",
      storyId: parsed.data.storyId,
      episodeNo: parsed.data.episodeNo,
      parseType: parsed.data.type,
      selectedPromptPresetIds: {
        storyboardPromptPresetId: parsed.data.storyboardPromptPresetId ?? null,
        videoPromptPresetId: parsed.data.videoPromptPresetId ?? null,
        storyboardPanelPromptPresetId: parsed.data.storyboardPanelPromptPresetId ?? null
      },
      resolvedPromptSelections: {
        storyboardPromptPresetId: promptSelections.storyboardPrompt?.presetId ?? null,
        storyboardPromptName: promptSelections.storyboardPrompt?.name ?? null,
        storyboardPromptLength: promptSelections.storyboardPrompt?.content?.length ?? 0,
        videoPromptPresetId: promptSelections.videoPrompt?.presetId ?? null,
        videoPromptName: promptSelections.videoPrompt?.name ?? null,
        videoPromptLength: promptSelections.videoPrompt?.content?.length ?? 0,
        storyboardPanelPromptPresetId: promptSelections.storyboardPanelPrompt?.presetId ?? null,
        storyboardPanelPromptName: promptSelections.storyboardPanelPrompt?.name ?? null,
        storyboardPanelPromptLength: promptSelections.storyboardPanelPrompt?.content?.length ?? 0
      }
    })

    const result =
      parsed.data.type === "drama"
        ? await createQuickGenerateEpisodeAndEnqueueJob({
            traceId,
            userId,
            storyId: parsed.data.storyId,
            episodeNo: parsed.data.episodeNo,
            type: parsed.data.type,
            prompt: parsed.data.prompt,
            videoModel: parsed.data.videoModel,
            storyboardPanelModel: parsed.data.storyboardPanelModel,
            storyboardPromptPresetId: promptSelections.storyboardPrompt?.presetId,
            storyboardPromptName: promptSelections.storyboardPrompt?.name,
            storyboardPersonalPrompt: promptSelections.storyboardPrompt?.content ?? null,
            videoPromptPresetId: promptSelections.videoPrompt?.presetId,
            videoPromptName: promptSelections.videoPrompt?.name,
            videoPersonalPrompt: promptSelections.videoPrompt?.content ?? null,
            storyboardPanelPromptPresetId: promptSelections.storyboardPanelPrompt?.presetId,
            storyboardPanelPromptName: promptSelections.storyboardPanelPrompt?.name,
            storyboardPanelPersonalPrompt: promptSelections.storyboardPanelPrompt?.content ?? null
          })
        : parsed.data.type === "outline"
          ? await createQuickGenerateEpisodeAndEnqueueJob({
              traceId,
              userId,
              storyId: parsed.data.storyId,
              episodeNo: parsed.data.episodeNo,
              type: parsed.data.type,
              content: parsed.data.content,
              minDurationMinutes: parsed.data.minDurationMinutes,
              maxDurationMinutes: parsed.data.maxDurationMinutes,
              shotsNum: parsed.data.shotsNum,
              videoModel: parsed.data.videoModel,
              storyboardPanelModel: parsed.data.storyboardPanelModel,
              storyboardPromptPresetId: promptSelections.storyboardPrompt?.presetId,
              storyboardPromptName: promptSelections.storyboardPrompt?.name,
              storyboardPersonalPrompt: promptSelections.storyboardPrompt?.content ?? null,
              videoPromptPresetId: promptSelections.videoPrompt?.presetId,
              videoPromptName: promptSelections.videoPrompt?.name,
              videoPersonalPrompt: promptSelections.videoPrompt?.content ?? null,
              storyboardPanelPromptPresetId: promptSelections.storyboardPanelPrompt?.presetId,
              storyboardPanelPromptName: promptSelections.storyboardPanelPrompt?.name,
              storyboardPanelPersonalPrompt: promptSelections.storyboardPanelPrompt?.content ?? null
            })
          : await createQuickGenerateEpisodeAndEnqueueJob({
              traceId,
              userId,
              storyId: parsed.data.storyId,
              episodeNo: parsed.data.episodeNo,
              type: parsed.data.type,
              content: parsed.data.content,
              videoModel: parsed.data.videoModel,
              storyboardPanelModel: parsed.data.storyboardPanelModel,
              storyboardPromptPresetId: promptSelections.storyboardPrompt?.presetId,
              storyboardPromptName: promptSelections.storyboardPrompt?.name,
              storyboardPersonalPrompt: promptSelections.storyboardPrompt?.content ?? null,
              videoPromptPresetId: promptSelections.videoPrompt?.presetId,
              videoPromptName: promptSelections.videoPrompt?.name,
              videoPersonalPrompt: promptSelections.videoPrompt?.content ?? null,
              storyboardPanelPromptPresetId: promptSelections.storyboardPanelPrompt?.presetId,
              storyboardPanelPromptName: promptSelections.storyboardPanelPrompt?.name,
              storyboardPanelPersonalPrompt: promptSelections.storyboardPanelPrompt?.content ?? null
            })

    logger.info({
      event: "quick_generate_episode_create_success",
      module: "quick_generate",
      traceId,
      message: "快速生成剧集创建成功",
      durationMs: Date.now() - start,
      storyId: parsed.data.storyId,
      episodeId: result.episodeId,
      jobId: result.jobId,
      parseType: parsed.data.type
    })

    return NextResponse.json(makeApiOk(traceId, result), { status: 202 })
  } catch (e) {
    const anyErr = e as { message?: string; code?: string }
    const msg = anyErr?.message?.trim() || "创建剧集失败"
    const code = anyErr?.code === "EPISODE_NO_EXISTS" ? "EPISODE_NO_EXISTS" : "UNKNOWN"
    const httpStatus = code === "EPISODE_NO_EXISTS" ? 409 : 500
    logger.error({
      event: "quick_generate_episode_create_failed",
      module: "quick_generate",
      traceId,
      message: "快速生成剧集创建失败",
      durationMs: Date.now() - start,
      errorCode: code,
      errorMessage: msg
    })
    return NextResponse.json(makeApiErr(traceId, code, msg), { status: httpStatus })
  }
}

export async function DELETE(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const deleteParams = await resolveDeleteEpisodeParams(req)
  if (deleteParams.invalidJson) {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = deleteSchema.safeParse({ episodeIds: deleteParams.episodeIds })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const db = await getDb({ quickGenerateEpisodes })

    logger.info({
      event: "quick_generate_episode_delete_start",
      module: "quick_generate",
      traceId,
      message: "开始删除快速生成剧集",
      episodeCount: parsed.data.episodeIds.length
    })

    await db.delete(quickGenerateEpisodes).where(inArray(quickGenerateEpisodes.id, parsed.data.episodeIds))

    logger.info({
      event: "quick_generate_episode_delete_success",
      module: "quick_generate",
      traceId,
      message: "快速生成剧集删除成功",
      durationMs: Date.now() - start,
      deletedCount: parsed.data.episodeIds.length
    })

    return NextResponse.json(makeApiOk(traceId, { deletedCount: parsed.data.episodeIds.length }))
  } catch (e) {
    const err = e as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "quick_generate_episode_delete_failed",
      module: "quick_generate",
      traceId,
      message: "快速生成剧集删除失败",
      durationMs: Date.now() - start,
      episodeCount: parsed.data.episodeIds.length,
      errorName: err?.name,
      errorMessage: err?.message,
      stack: err?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", err?.message?.trim() || "删除剧集失败"), { status: 500 })
  }
}

export async function PUT(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = putSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    logger.info({
      event: "quick_generate_episode_shots_update_start",
      module: "quick_generate",
      traceId,
      message: "开始更新剧集分镜",
      episodeId: parsed.data.episodeId,
      shotCount: "shots" in parsed.data ? parsed.data.shots.length : 1,
      updateMode: "shots" in parsed.data ? "batch" : "single",
      shotNo: "shotNo" in parsed.data ? parsed.data.shotNo : undefined
    })

    const result = await updateQuickGenerateEpisodeShots({
      userId,
      episodeId: parsed.data.episodeId,
      ...("shots" in parsed.data
        ? { shots: parsed.data.shots.map((shot) => ({ ...shot, optimizedText: shot.optimizedText ?? "" })) }
        : { shotNo: parsed.data.shotNo, shot: { ...parsed.data.shot, optimizedText: parsed.data.shot.optimizedText ?? "" } })
    })

    logger.info({
      event: "quick_generate_episode_shots_update_success",
      module: "quick_generate",
      traceId,
      message: "剧集分镜更新成功",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      updatedCount: result.updatedCount
    })

    return NextResponse.json(makeApiOk(traceId, result))
  } catch (e) {
    const err = e as { name?: string; message?: string; stack?: string; code?: string }
    const code = err?.code === "EPISODE_NOT_FOUND" ? "EPISODE_NOT_FOUND" : "UNKNOWN"
    const status = code === "EPISODE_NOT_FOUND" ? 404 : 500
    logger.error({
      event: "quick_generate_episode_shots_update_failed",
      module: "quick_generate",
      traceId,
      message: "剧集分镜更新失败",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      errorName: err?.name,
      errorCode: code,
      errorMessage: err?.message,
      stack: err?.stack
    })
    return NextResponse.json(makeApiErr(traceId, code, err?.message?.trim() || "更新分镜失败"), { status })
  }
}
