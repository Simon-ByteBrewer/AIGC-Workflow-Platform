import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { updateOfficialPricingRule } from "@/server/domains/admin/pricingAdmin"
import type { OfficialPricingUpdateRequest } from "@/shared/contracts/pricing"

function validateOfficialPricingPayload(body: unknown): OfficialPricingUpdateRequest {
  const payload = body as Partial<OfficialPricingUpdateRequest> | null
  if (!payload) {
    throw new Error("请求体不能为空")
  }
  if (typeof payload.modelName !== "string" || typeof payload.resolution !== "string" || typeof payload.officialPrice !== "string") {
    throw new Error("请求参数不正确")
  }
  if (typeof payload.hasReference !== "boolean") {
    throw new Error("请求参数不正确")
  }

  return {
    modelName: payload.modelName,
    resolution: payload.resolution,
    hasReference: payload.hasReference,
    officialPrice: payload.officialPrice
  }
}

export async function POST(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "仅平台管理员可更新官方价格"), { status: 403 })
  }

  try {
    const body = validateOfficialPricingPayload(await req.json())
    await updateOfficialPricingRule(actor.userId, actor.roleKey, body)
    return NextResponse.json(makeApiOk(traceId, { success: true }))
  } catch (error: any) {
    const message = error?.message ?? "官方价格更新失败"
    const status = message.includes("请求") || message.includes("参数") || message.includes("格式") || message.includes("不能为空")
      ? 400
      : 500
    return NextResponse.json(makeApiErr(traceId, "OFFICIAL_PRICING_UPDATE_FAILED", message), { status })
  }
}
