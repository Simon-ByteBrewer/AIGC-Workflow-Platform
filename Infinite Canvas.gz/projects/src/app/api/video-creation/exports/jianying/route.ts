import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { enqueueJianyingExportJob, kickJianyingExportWorker } from "@/server/domains/video-creation/jobs/jianyingExportWorker"
import { exportJianyingProject } from "@/server/domains/video-creation/exports/jianyingExportService"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  userId: z.string().trim().min(1).max(200),
  async: z.boolean().optional()
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const returnUrlOnly = req.headers.get("x-return-url") === "1"
  const baseUrl = new URL(req.url).origin
  const session = await getSessionFromRequest(req)
  const sessionUserId = session?.userId
  if (!sessionUserId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  if (parsed.data.userId !== sessionUserId) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "userId 与当前登录用户不一致"), { status: 403 })

  const asyncMode = parsed.data.async === true
  if (asyncMode) {
    const { jobId, snapshot } = await enqueueJianyingExportJob({
      userId: sessionUserId,
      storyId: parsed.data.storyId,
      traceId,
      baseUrl
    })
    kickJianyingExportWorker()
    return NextResponse.json(makeApiOk(traceId, { jobId, status: snapshot.status }), { status: 202 })
  }

  const result = await exportJianyingProject({ userId: sessionUserId, storyId: parsed.data.storyId, traceId, baseUrl })
  if (!result.ok) return NextResponse.json(makeApiErr(traceId, result.error.code, result.error.message), { status: result.error.status })
  if (returnUrlOnly) {
    return NextResponse.json(
      makeApiOk(traceId, {
        url: result.data.url,
        skipped: {
          skippedStoryboardIds: result.data.skippedStoryboardIds,
          missingVoiceoverEpisodeNos: result.data.missingVoiceoverEpisodeNos,
          missingAudioAssetIds: result.data.missingAudioAssetIds
        }
      }),
      { status: 200 }
    )
  }
  return NextResponse.redirect(result.data.url, { status: 302 })
}
