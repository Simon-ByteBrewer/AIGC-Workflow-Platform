import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { adminPromptPresets, groupPromptBindings, promptPresetUserBindings } from "@/shared/schema"
import { userSecurity, users } from "@/shared/schema/auth"
import { userGroups } from "@/shared/schema/userGroups"
import { listQuickGeneratePromptOptionsForUser } from "@/server/domains/admin/groupPromptAccess"

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  const db = await getDb({ users, userSecurity, userGroups, adminPromptPresets, groupPromptBindings, promptPresetUserBindings })
  const data = await listQuickGeneratePromptOptionsForUser({ db, userId })
  return NextResponse.json(makeApiOk(traceId, data), { status: 200 })
}
