import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories } from "@/shared/schema"
import { storyAssetLibrary } from "@/shared/schema/generation"
import { getSessionFromRequest } from "@/shared/session"
import { uploadPublicBuffer } from "@/shared/storage"
import { getTraceId } from "@/shared/trace"
import { fetchImageBuffer } from "@/server/domains/tvc/vibeCreating/tooling/assets/fetchAsset"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  characterKey: z.string().trim().min(1).max(200),
  characterName: z.string().trim().max(200).optional(),
  imageUrls: z.array(z.string().trim().min(1).max(20_000_000)).min(1).max(10)
})

function normalizeContentType(input: string): string {
  const raw = (input ?? "").trim().toLowerCase()
  const base = raw.split(";")[0]?.trim() || ""
  return base || "image/jpeg"
}

function fileExtFromContentType(contentType: string): string {
  const ct = normalizeContentType(contentType)
  if (ct === "image/png") return "png"
  if (ct === "image/webp") return "webp"
  if (ct === "image/gif") return "gif"
  if (ct === "image/avif") return "avif"
  if (ct === "image/jpeg" || ct === "image/jpg") return "jpg"
  return "jpg"
}

function safeSegment(input: string): string {
  return String(input ?? "")
    .trim()
    .replaceAll(/[^a-zA-Z0-9._:-]/gu, "_")
    .slice(0, 120)
}

function decodeDataImageUrl(input: string): { buffer: Buffer; contentType: string } | null {
  const raw = String(input ?? "").trim()
  if (!raw.startsWith("data:")) return null
  const m = raw.match(/^data:([^;,]+)?(?:;charset=[^;,]+)?(?:;base64)?,/iu)
  if (!m) return null
  const header = m[0]
  const contentType = normalizeContentType(m[1] ?? "image/png")
  const payload = raw.slice(header.length)
  const isBase64 = /;base64,/iu.test(header)
  try {
    const buffer = isBase64 ? Buffer.from(payload, "base64") : Buffer.from(decodeURIComponent(payload), "utf8")
    return { buffer, contentType }
  } catch {
    return null
  }
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const db = await getDb({ stories, storyAssetLibrary })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (!allowed[0]?.id) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const prefix = `public/short-drama/role-assets/${safeSegment(parsed.data.storyId)}/${safeSegment(parsed.data.characterKey)}/front`
  const now = new Date()
  const characterName = String(parsed.data.characterName ?? "").trim()

  const uploadedList = await Promise.all(
    parsed.data.imageUrls.map(async (originUrl) => {
      try {
        const origin = String(originUrl ?? "").trim()
        if (!origin) return null
        const decoded = decodeDataImageUrl(origin)
        const fetched = decoded ?? (await fetchImageBuffer(origin))
        const contentType = normalizeContentType(fetched.contentType)
        const uploaded = await uploadPublicBuffer({
          buffer: fetched.buffer,
          contentType,
          fileExt: fileExtFromContentType(contentType),
          prefix
        })
        const storageKey = uploaded.key
        const name = `short_drama_role_front:${safeSegment(parsed.data.characterKey)}:${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
        const url = `/api/script/short-drama/role-assets/file?key=${encodeURIComponent(storageKey)}`
        return { name, url, storageKey, originUrl: origin }
      } catch {
        return null
      }
    })
  )

  const uploadOk = uploadedList.filter(Boolean) as Array<{ name: string; url: string; storageKey: string; originUrl: string }>

  const inserted =
    uploadOk.length === 0
      ? []
      : await db
          .insert(storyAssetLibrary)
          .values(
            uploadOk.map((it) => ({
              storyId: parsed.data.storyId,
              name: it.name,
              displayName: characterName ? `${characterName}（角色图）` : null,
              url: it.url,
              storageKey: it.storageKey,
              thumbnailUrl: null,
              thumbnailStorageKey: null,
              meta: {
                libraryType: "short_drama_role_front",
                characterKey: parsed.data.characterKey,
                characterName: characterName || null,
                originUrl: it.originUrl
              },
              createdAt: now
            }))
          )
          .returning({ id: storyAssetLibrary.id, name: storyAssetLibrary.name, storageKey: storyAssetLibrary.storageKey })

  const idByName = new Map(inserted.map((r) => [String(r.name ?? ""), String(r.id ?? "")]))
  const images = uploadOk.map((it) => ({
    id: idByName.get(it.name) || null,
    url: it.storageKey,
    storageKey: it.storageKey,
    originUrl: it.originUrl
  }))

  return NextResponse.json(makeApiOk(traceId, { images }), { status: 200 })
}
