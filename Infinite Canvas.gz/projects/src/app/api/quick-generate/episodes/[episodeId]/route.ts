import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { updateQuickGenerateEpisodeNo } from "@/server/domains/quick-generate/usecases/updateQuickGenerateEpisodeNo"

export const runtime = "nodejs"

const patchSchema = z
  .object({
    episodeNo: z.number().int().min(1).max(10_000)
  })
  .strict()

export async function PATCH(
  req: NextRequest,
  context: { params: { episodeId: string } | Promise<{ episodeId: string }> }
): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const { episodeId } = await Promise.resolve(context.params)
  if (!episodeId?.trim()) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少剧集 ID"), { status: 400 })
  }

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = patchSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const result = await updateQuickGenerateEpisodeNo({
      userId,
      episodeId: episodeId.trim(),
      episodeNo: parsed.data.episodeNo
    })

    logger.info({
      event: "quick_generate_episode_no_update_success",
      module: "quick_generate",
      traceId,
      message: "剧集编号更新成功",
      durationMs: Date.now() - start,
      episodeId: result.episodeId,
      episodeNo: result.episodeNo
    })

    return NextResponse.json(makeApiOk(traceId, result))
  } catch (e) {
    const err = e as { message?: string; code?: string; stack?: string }
    const code =
      err?.code === "EPISODE_NO_EXISTS"
        ? "EPISODE_NO_EXISTS"
        : err?.code === "EPISODE_NOT_FOUND"
          ? "EPISODE_NOT_FOUND"
          : "UNKNOWN"
    const status = code === "EPISODE_NO_EXISTS" ? 409 : code === "EPISODE_NOT_FOUND" ? 404 : 500

    logger.error({
      event: "quick_generate_episode_no_update_failed",
      module: "quick_generate",
      traceId,
      message: "剧集编号更新失败",
      durationMs: Date.now() - start,
      errorCode: code,
      errorMessage: err?.message,
      stack: err?.stack,
      episodeId: episodeId.trim()
    })

    return NextResponse.json(makeApiErr(traceId, code, err?.message?.trim() || "更新剧集编号失败"), { status })
  }
}
