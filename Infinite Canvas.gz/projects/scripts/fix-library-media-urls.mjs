import fs from "node:fs"
import fsp from "node:fs/promises"
import path from "node:path"
import { fileURLToPath } from "node:url"
import { getDb, S3Storage } from "coze-coding-dev-sdk"
import { pgTable, text, timestamp } from "drizzle-orm/pg-core"
import { and, eq, sql } from "drizzle-orm"
 
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
 
function parseArgs(argv) {
  const args = { apply: false, limit: null, batchSize: 500, concurrency: 8, only: null, id: null, write: "absolute" }
  for (const raw of argv.slice(2)) {
    if (raw === "--apply") args.apply = true
    else if (raw.startsWith("--limit=")) args.limit = Number(raw.slice("--limit=".length)) || null
    else if (raw.startsWith("--batch=")) args.batchSize = Math.max(1, Math.min(2000, Number(raw.slice("--batch=".length)) || 500))
    else if (raw.startsWith("--concurrency=")) args.concurrency = Math.max(1, Math.min(50, Number(raw.slice("--concurrency=".length)) || 8))
    else if (raw.startsWith("--only=")) args.only = raw.slice("--only=".length).trim() || null
    else if (raw.startsWith("--id=")) args.id = raw.slice("--id=".length).trim() || null
    else if (raw.startsWith("--write=")) args.write = raw.slice("--write=".length).trim() || "absolute"
  }
  return args
}
 
function stripQuotes(v) {
  const s = String(v ?? "")
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1)
  return s
}
 
async function loadEnvFile(filePath) {
  try {
    const text = await fsp.readFile(filePath, "utf8")
    for (const line of text.split(/\r?\n/)) {
      const s = line.trim()
      if (!s || s.startsWith("#")) continue
      const idx = s.indexOf("=")
      if (idx <= 0) continue
      const k = s.slice(0, idx).trim()
      const v = stripQuotes(s.slice(idx + 1).trim())
      if (!k) continue
      if (process.env[k] == null) process.env[k] = v
    }
  } catch {
  }
}
 
function normalizePgEnv() {
  const keys = ["PGDATABASE_URL", "DATABASE_URL", "POSTGRES_URL"]
  for (const key of keys) {
    const raw = process.env[key]
    if (!raw) continue
    const trimmed = raw.trim()
    if (!trimmed) continue
    try {
      const url = new URL(trimmed)
      const compat = (url.searchParams.get("uselibpqcompat") ?? "").toLowerCase()
      if (compat === "true") continue
      const sslmode = (url.searchParams.get("sslmode") ?? "").toLowerCase()
      if (sslmode === "prefer" || sslmode === "require" || sslmode === "verify-ca") {
        url.searchParams.set("sslmode", "verify-full")
        process.env[key] = url.toString()
      }
      if ((process.env.NODE_ENV ?? "").toLowerCase() !== "production") {
        const connectTimeout = (url.searchParams.get("connect_timeout") ?? "").trim()
        if (!connectTimeout) url.searchParams.set("connect_timeout", "3")
        const options = (url.searchParams.get("options") ?? "").trim()
        if (!options) url.searchParams.set("options", "-c statement_timeout=15000 -c lock_timeout=15000")
        process.env[key] = url.toString()
      }
    } catch {
    }
  }
}
 
function readEnv(name) {
  const v = process.env[name]
  return typeof v === "string" ? v.trim() : ""
}
 
function readEnvInt(name) {
  const v = readEnv(name)
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}
 
function getStorageUrlMode() {
  const raw = (readEnv("STORAGE_URL_MODE") || "presigned").toLowerCase()
  return raw === "direct" ? "direct" : "presigned"
}
 
function buildDirectBucketUrl(key) {
  const endpointUrl = readEnv("COZE_BUCKET_ENDPOINT_URL")
  const bucketName = readEnv("COZE_BUCKET_NAME")
  if (!endpointUrl || !bucketName) throw new Error("S3 storage not configured")
  return new URL(`/${bucketName}/${key}`, endpointUrl).toString()
}
 
function getS3Storage() {
  const endpointUrl = readEnv("COZE_BUCKET_ENDPOINT_URL")
  const bucketName = readEnv("COZE_BUCKET_NAME")
  const accessKey = readEnv("COZE_BUCKET_ACCESS_KEY")
  const secretKey = readEnv("COZE_BUCKET_SECRET_KEY")
  const region = readEnv("COZE_BUCKET_REGION") || "cn-beijing"
  if (!endpointUrl || !bucketName || !accessKey || !secretKey) throw new Error("S3 storage not configured")
  return new S3Storage({ endpointUrl, accessKey, secretKey, bucketName, region })
}
 
async function resolveStorageUrl(storage, key) {
  if (getStorageUrlMode() === "direct") return buildDirectBucketUrl(key)
  const primary = readEnvInt("STORAGE_PRESIGNED_URL_EXPIRE_SECONDS") || 60 * 60 * 24 * 365
  const fallback = readEnvInt("STORAGE_PRESIGNED_URL_FALLBACK_SECONDS") || 60 * 60 * 24 * 7
  try {
    return await storage.generatePresignedUrl({ key, expireTime: primary })
  } catch {
    if (fallback !== primary) {
      try {
        return await storage.generatePresignedUrl({ key, expireTime: fallback })
      } catch {
      }
    }
    return buildDirectBucketUrl(key)
  }
}
 
async function generatePresignedUrl(storage, key) {
  const primary = readEnvInt("STORAGE_PRESIGNED_URL_EXPIRE_SECONDS") || 60 * 60 * 24 * 365
  const fallback = readEnvInt("STORAGE_PRESIGNED_URL_FALLBACK_SECONDS") || 60 * 60 * 24 * 7
  try {
    return await storage.generatePresignedUrl({ key, expireTime: primary })
  } catch {
    if (fallback !== primary) {
      try {
        return await storage.generatePresignedUrl({ key, expireTime: fallback })
      } catch {
      }
    }
    return buildDirectBucketUrl(key)
  }
}

function normalizeUrlForKeyGuess(rawUrl) {
  const s = String(rawUrl ?? "").trim()
  if (!s) return ""
  const noHash = s.split("#")[0] ?? s
  const noQuery = noHash.split("?")[0] ?? noHash
  return String(noQuery).trim()
}
 
function guessKeyCandidatesFromUrl(rawUrl) {
  const v = normalizeUrlForKeyGuess(rawUrl)
  if (!v) return []
  if (v.startsWith("about:")) return []
  if (v.startsWith("/api/")) return []
  if (v.startsWith("http://") || v.startsWith("https://")) return []
  const bucketName = readEnv("COZE_BUCKET_NAME")
  const out = new Set()
  out.add(v)
  if (v.startsWith("/")) out.add(v.slice(1))
  if (bucketName) {
    if (v.startsWith(`/${bucketName}/`)) out.add(v.slice(bucketName.length + 2))
    if (v.startsWith(`${bucketName}/`)) out.add(v.slice(bucketName.length + 1))
  }
  return Array.from(out).map((x) => String(x ?? "").trim()).filter(Boolean)
}
 
async function isUrlAccessible(url) {
  const u = String(url ?? "").trim()
  if (!u) return false
  try {
    const head = await fetch(u, { method: "HEAD", redirect: "follow" })
    if (head.status >= 200 && head.status < 400) return true
    if (head.status === 405 || head.status === 403 || head.status === 401) {
      const get = await fetch(u, { method: "GET", headers: { range: "bytes=0-0" }, redirect: "follow" })
      return get.status >= 200 && get.status < 400
    }
    return false
  } catch {
    return false
  }
}
 
async function resolveAndCheckKey(storage, key) {
  const k = String(key ?? "").trim()
  if (!k) return { ok: false, url: "" }
  const url = await resolveStorageUrl(storage, k)
  const ok = await isUrlAccessible(url)
  return { ok, url }
}
 
async function resolveAndCheckKeyAbsolute(storage, key) {
  const k = String(key ?? "").trim()
  if (!k) return { ok: false, url: "", via: "" }

  let direct = ""
  try {
    direct = buildDirectBucketUrl(k)
  } catch {
  }
  if (direct) {
    const ok = await isUrlAccessible(direct)
    if (ok) return { ok: true, url: direct, via: "direct" }
  }

  const presigned = await generatePresignedUrl(storage, k)
  const ok = await isUrlAccessible(presigned)
  if (ok) return { ok: true, url: presigned, via: "presigned" }
  return { ok: false, url: "", via: "" }
}

function stableFileUrl(scope, id, kind) {
  const base = scope === "shared" ? "/api/library/shared-resources/file" : "/api/library/public-resources/file"
  return `${base}/${encodeURIComponent(id)}?kind=${kind === "preview" ? "preview" : "original"}`
}
 
function shouldSkipUrl(url) {
  const s = String(url ?? "").trim()
  if (!s) return true
  if (s.startsWith("/api/library/public-resources/file/")) return true
  if (s.startsWith("/api/library/shared-resources/file/")) return true
  return false
}
 
function isHttpUrl(url) {
  const s = String(url ?? "").trim()
  return s.startsWith("http://") || s.startsWith("https://")
}

function isLocalhostUrl(url) {
  const s = String(url ?? "").trim()
  if (!s) return false
  try {
    const u = new URL(s)
    return u.hostname === "localhost" || u.hostname === "127.0.0.1" || u.hostname === "::1"
  } catch {
    return false
  }
}

async function runPool(items, limit, fn) {
  const concurrency = Math.max(1, Math.min(items.length, Math.trunc(limit)))
  let cursor = 0
  const results = new Array(items.length)
  const runners = Array.from({ length: concurrency }, async () => {
    while (true) {
      const i = cursor
      cursor += 1
      if (i >= items.length) return
      results[i] = await fn(items[i], i)
    }
  })
  await Promise.all(runners)
  return results
}
 
const publicResources = pgTable("public_resources", {
  id: text("id").primaryKey(),
  userId: text("user_id"),
  previewUrl: text("preview_url"),
  previewStorageKey: text("preview_storage_key"),
  originalUrl: text("original_url"),
  originalStorageKey: text("original_storage_key"),
  createdAt: timestamp("created_at", { withTimezone: true })
})
 
const sharedResources = pgTable("shared_resources", {
  id: text("id").primaryKey(),
  previewUrl: text("preview_url"),
  previewStorageKey: text("preview_storage_key"),
  originalUrl: text("original_url"),
  originalStorageKey: text("original_storage_key"),
  createdAt: timestamp("created_at", { withTimezone: true })
})
 
async function processTable(db, storage, tableName, table, scope, opts) {
  const backupDir = path.join(process.cwd(), ".tmp", "library-url-fix")
  await fsp.mkdir(backupDir, { recursive: true })
  const now = new Date().toISOString().replace(/[:.]/g, "-")
  const backupPath = path.join(backupDir, `backup-${tableName}-${now}.jsonl`)
  const backupStream = fs.createWriteStream(backupPath, { flags: "a" })
 
  const limitTotal = typeof opts.limit === "number" && opts.limit > 0 ? opts.limit : null
  const batchSize = opts.batchSize
  let offset = 0
  let scanned = 0
  let updated = 0
  let skipped = 0
  let notVerifiable = 0
  let verified = 0
  const sample = []
 
  while (true) {
    const query = db
      .select({
        id: table.id,
        previewUrl: table.previewUrl,
        previewStorageKey: table.previewStorageKey,
        originalUrl: table.originalUrl,
        originalStorageKey: table.originalStorageKey
      })
      .from(table)

    const rows = opts.id
      ? await query.where(eq(table.id, String(opts.id))).limit(1)
      : await query.orderBy(sql`${table.createdAt} desc nulls last`).limit(batchSize).offset(offset)
 
    if (!rows.length) break
 
    const remaining = limitTotal == null ? null : Math.max(0, limitTotal - scanned)
    const slice = remaining == null ? rows : rows.slice(0, remaining)
    if (!slice.length) break
 
    scanned += slice.length
    offset += slice.length
 
    const decisions = await runPool(slice, opts.concurrency, async (row) => {
      const id = String(row.id ?? "").trim()
      if (!id) return { id: "", apply: false, reason: "missing_id" }
 
      const rawPrevUrl = String(row.previewUrl ?? "").trim()
      const rawOrigUrl = String(row.originalUrl ?? "").trim()
      const prevKeyFromDb = String(row.previewStorageKey ?? "").trim()
      const origKeyFromDb = String(row.originalStorageKey ?? "").trim()
 
      let previewKey = prevKeyFromDb
      let originalKey = origKeyFromDb
 
      const previewKeyCandidates = previewKey ? [previewKey] : guessKeyCandidatesFromUrl(rawPrevUrl)
      const originalKeyCandidates = originalKey ? [originalKey] : guessKeyCandidatesFromUrl(rawOrigUrl)
 
      if (!previewKey) {
        for (const k of previewKeyCandidates) {
          const res = opts.write === "stable" ? await resolveAndCheckKey(storage, k) : await resolveAndCheckKeyAbsolute(storage, k)
          if (res.ok) {
            previewKey = k
            break
          }
        }
      } else {
        const res = opts.write === "stable" ? await resolveAndCheckKey(storage, previewKey) : await resolveAndCheckKeyAbsolute(storage, previewKey)
        if (!res.ok) previewKey = ""
      }
 
      if (!originalKey) {
        for (const k of originalKeyCandidates) {
          const res = opts.write === "stable" ? await resolveAndCheckKey(storage, k) : await resolveAndCheckKeyAbsolute(storage, k)
          if (res.ok) {
            originalKey = k
            break
          }
        }
      } else {
        const res = opts.write === "stable" ? await resolveAndCheckKey(storage, originalKey) : await resolveAndCheckKeyAbsolute(storage, originalKey)
        if (!res.ok) originalKey = ""
      }
 
      if (!previewKey && originalKey) previewKey = originalKey
      if (!originalKey && previewKey) originalKey = previewKey
 
      const canFixPreview = Boolean(previewKey)
      const canFixOriginal = Boolean(originalKey)
      if (!canFixPreview && !canFixOriginal) return { id, apply: false, reason: "no_accessible_key" }
 
      const previewResolved = canFixPreview
        ? opts.write === "stable"
          ? { ok: true, url: stableFileUrl(scope, id, "preview"), via: "stable" }
          : await resolveAndCheckKeyAbsolute(storage, previewKey)
        : { ok: false, url: "", via: "" }
      const originalResolved = canFixOriginal
        ? opts.write === "stable"
          ? { ok: true, url: stableFileUrl(scope, id, "original"), via: "stable" }
          : await resolveAndCheckKeyAbsolute(storage, originalKey)
        : { ok: false, url: "", via: "" }
 
      const nextPreviewUrl = previewResolved.ok ? previewResolved.url : rawPrevUrl
      const nextOriginalUrl = originalResolved.ok ? originalResolved.url : rawOrigUrl

      const rawPrevNeeds =
        !rawPrevUrl ||
        rawPrevUrl.startsWith("/api/library/public-resources/file/") ||
        rawPrevUrl.startsWith("/api/library/shared-resources/file/") ||
        !isHttpUrl(rawPrevUrl) ||
        isLocalhostUrl(rawPrevUrl)
      const rawOrigNeeds =
        !rawOrigUrl ||
        rawOrigUrl.startsWith("/api/library/public-resources/file/") ||
        rawOrigUrl.startsWith("/api/library/shared-resources/file/") ||
        !isHttpUrl(rawOrigUrl) ||
        isLocalhostUrl(rawOrigUrl)

      const previewUrlNeeds = canFixPreview && rawPrevNeeds
      const originalUrlNeeds = canFixOriginal && rawOrigNeeds
      const previewKeyNeeds = canFixPreview && prevKeyFromDb !== previewKey
      const originalKeyNeeds = canFixOriginal && origKeyFromDb !== originalKey
 
      if (!previewUrlNeeds && !originalUrlNeeds && !previewKeyNeeds && !originalKeyNeeds) {
        return { id, apply: false, reason: "already_ok" }
      }
 
      return {
        id,
        apply: true,
        before: { previewUrl: rawPrevUrl, originalUrl: rawOrigUrl, previewStorageKey: prevKeyFromDb, originalStorageKey: origKeyFromDb },
        after: {
          previewUrl: previewUrlNeeds ? nextPreviewUrl : rawPrevUrl,
          originalUrl: originalUrlNeeds ? nextOriginalUrl : rawOrigUrl,
          previewStorageKey: previewKeyNeeds ? previewKey : prevKeyFromDb,
          originalStorageKey: originalKeyNeeds ? originalKey : origKeyFromDb
        },
        meta: { previewVia: previewResolved.via || null, originalVia: originalResolved.via || null }
      }
    })
 
    for (const d of decisions) {
      if (!d || !d.id) continue
      if (!d.apply) {
        if (d.reason === "already_ok") skipped += 1
        else notVerifiable += 1
        continue
      }
      verified += 1
      if (sample.length < 5) sample.push({ id: d.id, before: d.before, after: d.after, meta: d.meta })
      if (!opts.apply) continue
 
      backupStream.write(`${JSON.stringify({ table: tableName, id: d.id, before: d.before, after: d.after })}\n`)
 
      await db
        .update(table)
        .set({
          previewUrl: d.after.previewUrl,
          originalUrl: d.after.originalUrl,
          previewStorageKey: d.after.previewStorageKey || null,
          originalStorageKey: d.after.originalStorageKey || null
        })
        .where(eq(table.id, d.id))
 
      updated += 1
    }
 
    if (limitTotal != null && scanned >= limitTotal) break
    if (opts.id) break
  }
 
  backupStream.end()
  return { table: tableName, scanned, verified, updated, skipped, notVerifiable, backupPath, sample }
}
 
async function main() {
  const args = parseArgs(process.argv)
  await loadEnvFile(path.join(process.cwd(), ".env.local"))
  await loadEnvFile(path.join(process.cwd(), ".env"))
  normalizePgEnv()
 
  const hasDbUrl = Boolean(readEnv("PGDATABASE_URL") || readEnv("DATABASE_URL") || readEnv("POSTGRES_URL"))
  if (!hasDbUrl) {
    console.error("Database URL is missing. Set PGDATABASE_URL or DATABASE_URL or POSTGRES_URL in .env.local.")
    process.exit(1)
  }
 
  const storage = getS3Storage()
  const db = await getDb({ publicResources, sharedResources })
 
  const apply = Boolean(args.apply)
  const write = (args.write ?? "absolute").toLowerCase() === "stable" ? "stable" : "absolute"
  const opts = { apply, limit: args.limit, batchSize: args.batchSize, concurrency: args.concurrency, id: args.id, write }
 
  const only = (args.only ?? "").toLowerCase()
  const needPublic = !only || only === "public"
  const needShared = !only || only === "shared"
 
  const results = []
  if (needPublic) results.push(await processTable(db, storage, "public_resources", publicResources, "public", opts))
  if (needShared) results.push(await processTable(db, storage, "shared_resources", sharedResources, "shared", opts))
 
  const badStablePublic = await db
    .select({ count: sql`count(*)` })
    .from(publicResources)
    .where(
      and(
        sql`${publicResources.previewUrl} like '/api/library/public-resources/file/%'`,
        sql`${publicResources.previewStorageKey} is null`
      )
    )
  const badStableShared = await db
    .select({ count: sql`count(*)` })
    .from(sharedResources)
    .where(
      and(
        sql`${sharedResources.previewUrl} like '/api/library/shared-resources/file/%'`,
        sql`${sharedResources.previewStorageKey} is null`
      )
    )
 
  const apiPublic = await db
    .select({ count: sql`count(*)` })
    .from(publicResources)
    .where(sql`${publicResources.previewUrl} like '/api/library/public-resources/file/%'`)
  const apiShared = await db
    .select({ count: sql`count(*)` })
    .from(sharedResources)
    .where(sql`${sharedResources.previewUrl} like '/api/library/shared-resources/file/%'`)

  console.log(
    JSON.stringify(
      {
        apply,
        write,
        id: args.id || null,
        results,
        sanity: {
          badStablePublic: Number(badStablePublic?.[0]?.count ?? 0),
          badStableShared: Number(badStableShared?.[0]?.count ?? 0),
          apiPublic: Number(apiPublic?.[0]?.count ?? 0),
          apiShared: Number(apiShared?.[0]?.count ?? 0)
        }
      },
      null,
      2
    )
  )
 }
 
main().catch((err) => {
  const msg = err && typeof err === "object" && "stack" in err ? String(err.stack) : String(err)
  console.error(msg)
  process.exit(1)
})
