import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { publicResources } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { downloadBinary } from "@/server/lib/http/downloadBinary"
import { uploadPublicBuffer } from "@/shared/storage"
import { getSpeakerName } from "@/features/tts/speakers"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"

export const runtime = "nodejs"

const bodySchema = z.object({
  resourceId: z.string().trim().min(1).max(200),
  speakerId: z.string().trim().min(1).max(200),
  speakerName: z.string().trim().max(200).optional(),
  audioUrl: z.string().trim().min(1).max(4000)
})

function safeSegment(input: string): string {
  return String(input ?? "")
    .trim()
    .replaceAll(/[^a-zA-Z0-9._:-]/gu, "_")
    .slice(0, 120)
}

function fileExtFromContentType(contentType: string): string {
  const raw = (contentType ?? "").trim().toLowerCase()
  if (raw.includes("wav")) return "wav"
  if (raw.includes("mpeg") || raw.includes("mp3")) return "mp3"
  if (raw.includes("ogg")) return "ogg"
  if (raw.includes("aac")) return "aac"
  if (raw.includes("mp4") || raw.includes("m4a")) return "m4a"
  return "bin"
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { resourceId, speakerId } = parsed.data
  const speakerName = parsed.data.speakerName?.trim() || getSpeakerName(speakerId) || speakerId

  const db = await getDb({ publicResources })
  const rows = await db
    .select({ id: publicResources.id, userId: publicResources.userId })
    .from(publicResources)
    .where(and(eq(publicResources.id, resourceId), eq(publicResources.userId, userId)))
    .limit(1)
  if (!rows[0]?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

  let downloaded: { buffer: Buffer; contentType: string | null }
  try {
    downloaded = await downloadBinary(parsed.data.audioUrl, traceId, 120_000)
  } catch {
    return NextResponse.json(makeApiErr(traceId, "ASSET_DOWNLOAD_FAILED", "下载音色失败"), { status: 400 })
  }

  const contentType = downloaded.contentType ?? "audio/mpeg"
  const fileExt = fileExtFromContentType(contentType)
  const prefix = `public/role-voices/${safeSegment(resourceId)}`
  const uploaded = await uploadPublicBuffer({ buffer: downloaded.buffer, contentType, fileExt, prefix })

  await db
    .update(publicResources)
    .set({
      voiceSpeakerId: speakerId,
      voiceSpeakerName: speakerName,
      voiceAudioStorageKey: uploaded.key
    })
    .where(and(eq(publicResources.id, resourceId), eq(publicResources.userId, userId)))

  return NextResponse.json(
    makeApiOk(traceId, {
      voiceSpeakerId: speakerId,
      voiceSpeakerName: speakerName,
      voiceAudioStorageKey: uploaded.key
    }),
    { status: 200 }
  )
}
