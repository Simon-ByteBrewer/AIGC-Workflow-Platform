"use client"

import { useEffect, useState, type ReactElement } from "react"
import { AlertCircle, Eye, EyeOff, LockKeyhole, ShieldCheck } from "lucide-react"
import type { ApiErr, ApiOk } from "@/shared/api"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/shared/ui/shadcn/dialog"
import { Input } from "@/shared/ui/shadcn/input"
import styles from "./AccountCenterPasswordDialog.module.css"

type ChangePasswordResult = ApiOk<{ ok: true; reauthRequired: boolean }> | ApiErr

type AccountCenterPasswordDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  onPasswordChanged: () => Promise<void>
}

/**
 * 个人中心修改密码弹窗。
 * 只负责收集输入、调用改密接口，并在成功后触发统一退出流程。
 */
export function AccountCenterPasswordDialog(props: AccountCenterPasswordDialogProps): ReactElement {
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmNewPassword, setConfirmNewPassword] = useState("")
  const [currentVisible, setCurrentVisible] = useState(false)
  const [nextVisible, setNextVisible] = useState(false)
  const [confirmVisible, setConfirmVisible] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState("")

  useEffect(() => {
    if (!props.open) {
      setCurrentPassword("")
      setNewPassword("")
      setConfirmNewPassword("")
      setCurrentVisible(false)
      setNextVisible(false)
      setConfirmVisible(false)
      setSubmitting(false)
      setError("")
    }
  }, [props.open])

  const submit = async (): Promise<void> => {
    if (submitting) return
    if (!currentPassword.trim() || !newPassword.trim() || !confirmNewPassword.trim()) {
      setError("请完整填写旧密码、新密码和确认新密码")
      return
    }
    if (newPassword !== confirmNewPassword) {
      setError("两次输入的新密码不一致")
      return
    }

    setSubmitting(true)
    setError("")

    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword, confirmNewPassword })
      })
      const json = (await res.json().catch(() => null)) as ChangePasswordResult | null
      if (!res.ok || !json) {
        const message = json && !json.ok ? json.error.message : "修改密码失败"
        throw new Error(message)
      }
      if (!json.ok) {
        throw new Error(json.error.message || "修改密码失败")
      }

      props.onOpenChange(false)
      alert("密码修改成功，请重新登录")
      await props.onPasswordChanged()
    } catch (err) {
      const anyErr = err as { message?: string }
      setError(anyErr?.message ?? "修改密码失败")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent
        className={styles.dialogContent}
        overlayClassName={styles.overlay}
      >
        <div className={styles.shell}>
          <div className={styles.hero}>
            <div className={styles.heroBadge}>
              <ShieldCheck size={14} strokeWidth={2.2} />
              <span>账号安全</span>
            </div>
            <DialogHeader className={styles.header}>
              <DialogTitle className={styles.title}>修改密码</DialogTitle>
              <div className={styles.hint}>更新后当前登录状态会自动失效，请使用新密码重新登录。</div>
            </DialogHeader>
            <div className={styles.tipCard}>
              <div className={styles.tipTitle}>安全提醒</div>
              <div className={styles.tipText}>建议使用你未在其他平台重复使用过的密码，避免账号被撞库。</div>
            </div>
          </div>

          <div className={styles.body}>
            <div className={styles.form}>
              <label className={styles.field}>
                <div className={styles.fieldTop}>
                  <span className={styles.label}>旧密码</span>
                  <span className={styles.meta}>用于校验当前身份</span>
                </div>
                <div className={styles.inputShell}>
                  <span className={styles.inputIcon} aria-hidden="true">
                    <LockKeyhole size={16} strokeWidth={2.2} />
                  </span>
                  <Input
                    type={currentVisible ? "text" : "password"}
                    value={currentPassword}
                    onChange={(event) => setCurrentPassword(event.target.value)}
                    placeholder="请输入当前使用的密码"
                    className={styles.input}
                  />
                  <button
                    type="button"
                    className={styles.visibilityButton}
                    onClick={() => setCurrentVisible((prev) => !prev)}
                    aria-label={currentVisible ? "隐藏旧密码" : "显示旧密码"}
                    title={currentVisible ? "隐藏旧密码" : "显示旧密码"}
                  >
                    {currentVisible ? <EyeOff size={16} strokeWidth={2.2} /> : <Eye size={16} strokeWidth={2.2} />}
                  </button>
                </div>
                <div className={styles.helper}>请输入当前登录密码，用于确认本次修改是你本人操作。</div>
              </label>

              <label className={styles.field}>
                <div className={styles.fieldTop}>
                  <span className={styles.label}>新密码</span>
                  <span className={styles.meta}>建议字母与数字组合</span>
                </div>
                <div className={styles.inputShell}>
                  <span className={styles.inputIcon} aria-hidden="true">
                    <LockKeyhole size={16} strokeWidth={2.2} />
                  </span>
                  <Input
                    type={nextVisible ? "text" : "password"}
                    value={newPassword}
                    onChange={(event) => setNewPassword(event.target.value)}
                    placeholder="请输入新的登录密码"
                    className={styles.input}
                  />
                  <button
                    type="button"
                    className={styles.visibilityButton}
                    onClick={() => setNextVisible((prev) => !prev)}
                    aria-label={nextVisible ? "隐藏新密码" : "显示新密码"}
                    title={nextVisible ? "隐藏新密码" : "显示新密码"}
                  >
                    {nextVisible ? <EyeOff size={16} strokeWidth={2.2} /> : <Eye size={16} strokeWidth={2.2} />}
                  </button>
                </div>
                <div className={styles.helper}>建议使用更强的新密码，避免与旧密码相同。</div>
              </label>

              <label className={styles.field}>
                <div className={styles.fieldTop}>
                  <span className={styles.label}>确认新密码</span>
                  <span className={styles.meta}>确保两次输入一致</span>
                </div>
                <div className={styles.inputShell}>
                  <span className={styles.inputIcon} aria-hidden="true">
                    <LockKeyhole size={16} strokeWidth={2.2} />
                  </span>
                  <Input
                    type={confirmVisible ? "text" : "password"}
                    value={confirmNewPassword}
                    onChange={(event) => setConfirmNewPassword(event.target.value)}
                    placeholder="请再次输入新密码"
                    className={styles.input}
                  />
                  <button
                    type="button"
                    className={styles.visibilityButton}
                    onClick={() => setConfirmVisible((prev) => !prev)}
                    aria-label={confirmVisible ? "隐藏确认新密码" : "显示确认新密码"}
                    title={confirmVisible ? "隐藏确认新密码" : "显示确认新密码"}
                  >
                    {confirmVisible ? <EyeOff size={16} strokeWidth={2.2} /> : <Eye size={16} strokeWidth={2.2} />}
                  </button>
                </div>
                <div className={styles.helper}>确认无误后提交，修改成功后需要重新登录。</div>
              </label>

              {error ? (
                <div className={styles.error} role="alert">
                  <AlertCircle size={16} strokeWidth={2.2} />
                  <span>{error}</span>
                </div>
              ) : null}
            </div>

            <div className={styles.footer}>
              <div className={styles.footerNote}>修改成功后将自动退出当前账号。</div>
              <div className={styles.footerActions}>
                <button type="button" className={styles.secondaryButton} onClick={() => props.onOpenChange(false)} disabled={submitting}>
                  取消
                </button>
                <button type="button" className={styles.primaryButton} onClick={() => void submit()} disabled={submitting}>
                  {submitting ? "正在更新..." : "确认修改"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
