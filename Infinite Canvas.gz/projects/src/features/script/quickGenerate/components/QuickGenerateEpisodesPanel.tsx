"use client"

import { Trash2 } from "lucide-react"
import { useMemo, useState, type ReactElement } from "react"
import { useRouter } from "next/navigation"
import { createQuickGenerateEpisode, updateQuickGenerateEpisodeNo } from "../api-client"
import { updateOpenEpisodeTab } from "../openEpisodeTabs"
import { setEpisodeDefaultVideoModel } from "../videoModel"
import { QuickGenerateCreateEpisodeDialog } from "./QuickGenerateCreateEpisodeDialog"
import styles from "./QuickGenerateEpisodesPanel.module.css"

type EpisodeItem = {
  id: string
  episodeNo: number
  title: string | null
  status: string
  totalShots: number
  promptCount: number
  videoTotalCount: number
  videoShotCount: number
}

type QuickGenerateEpisodesPanelProps = {
  storyId: string
  episodes: EpisodeItem[]
  selectedIds: Set<string>
  toggleSelect: (episodeId: string, checked: boolean) => void
  requestDelete: (episodeIds: string[]) => void
}

/**
 * 统一剧集卡片状态展示，兼容当前占位状态与后续服务端扩展状态。
 */
function getEpisodeStatusMeta(status: string, isDone: boolean): { label: string; toneClass: string } {
  const normalized = status.trim().toLowerCase()
  if (normalized.includes("fail") || normalized.includes("error")) {
    return { label: "失败", toneClass: styles.statusDanger }
  }
  if (isDone) {
    return { label: "完成", toneClass: styles.statusSuccess }
  }
  return { label: "处理中", toneClass: styles.statusProcessing }
}

function suggestEpisodeNo(episodes: EpisodeItem[]): number {
  const maxNo = episodes.reduce((acc, e) => Math.max(acc, Number(e.episodeNo) || 0), 0)
  return Math.max(1, maxNo + 1)
}

export function validateEpisodeNoDraft(input: {
  draftValue: string
  episodeId: string
  episodes: Array<Pick<EpisodeItem, "id" | "episodeNo">>
}): { nextEpisodeNo: number | null; errorMessage: string } {
  const trimmed = input.draftValue.trim()
  if (!trimmed) return { nextEpisodeNo: null, errorMessage: "" }
  if (!/^\d+$/.test(trimmed)) return { nextEpisodeNo: null, errorMessage: "请输入正确的剧集编号" }

  const nextEpisodeNo = Math.trunc(Number(trimmed))
  if (!Number.isFinite(nextEpisodeNo) || nextEpisodeNo <= 0) {
    return { nextEpisodeNo: null, errorMessage: "请输入正确的剧集编号" }
  }

  const hasDuplicate = input.episodes.some(
    (episode) => episode.id !== input.episodeId && Math.trunc(Number(episode.episodeNo) || 0) === nextEpisodeNo
  )
  if (hasDuplicate) return { nextEpisodeNo, errorMessage: "已有重复剧集编号" }

  return { nextEpisodeNo, errorMessage: "" }
}

export function QuickGenerateEpisodesPanel(props: QuickGenerateEpisodesPanelProps): ReactElement {
  const router = useRouter()
  const [dialogOpen, setDialogOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [editingEpisodeId, setEditingEpisodeId] = useState("")
  const [editingEpisodeNoDraft, setEditingEpisodeNoDraft] = useState("")
  const [editingErrorMessage, setEditingErrorMessage] = useState("")
  const [savingEpisodeId, setSavingEpisodeId] = useState("")

  const defaultEpisodeNo = useMemo(() => suggestEpisodeNo(props.episodes), [props.episodes])
  const hasAnyEpisode = props.episodes.length > 0

  const beginEditEpisodeNo = (episode: EpisodeItem) => {
    setEditingEpisodeId(episode.id)
    setEditingEpisodeNoDraft(String(Math.trunc(Number(episode.episodeNo) || 0)))
    setEditingErrorMessage("")
  }

  const cancelEditEpisodeNo = () => {
    if (savingEpisodeId) return
    setEditingEpisodeId("")
    setEditingEpisodeNoDraft("")
    setEditingErrorMessage("")
  }

  const submitEpisodeNoUpdate = async (episode: EpisodeItem) => {
    if (savingEpisodeId) return
    const validation = validateEpisodeNoDraft({
      draftValue: editingEpisodeNoDraft,
      episodeId: episode.id,
      episodes: props.episodes
    })
    if (!validation.nextEpisodeNo) {
      setEditingErrorMessage(validation.errorMessage || "请输入正确的剧集编号")
      return
    }
    if (validation.errorMessage) {
      setEditingErrorMessage(validation.errorMessage)
      return
    }
    if (validation.nextEpisodeNo === Math.trunc(Number(episode.episodeNo) || 0)) {
      cancelEditEpisodeNo()
      return
    }

    setSavingEpisodeId(episode.id)
    setEditingErrorMessage("")
    try {
      const updated = await updateQuickGenerateEpisodeNo({ episodeId: episode.id, episodeNo: validation.nextEpisodeNo })
      updateOpenEpisodeTab(props.storyId, { id: episode.id, episodeNo: updated.episodeNo })
      cancelEditEpisodeNo()
      router.refresh()
    } catch (error) {
      setEditingErrorMessage(error instanceof Error ? error.message : "更新剧集编号失败")
    } finally {
      setSavingEpisodeId("")
    }
  }

  return (
    <>
      <div className={styles.grid} aria-label="剧集列表">
        <button type="button" className={styles.addCard} onClick={() => setDialogOpen(true)} disabled={busy}>
          <div className={styles.addIcon}>+</div>
          <div className={styles.addText}>新增剧集</div>
        </button>

        {!hasAnyEpisode ? (
          <article className={styles.episodeCard} style={{ cursor: "default" }}>
            <div className={styles.episodeTitle}>暂无剧集</div>
            <div className={styles.episodeMeta}>当前项目还没有剧集内容，后续创建或生成的剧集会在这里统一管理。</div>
          </article>
        ) : null}

        {props.episodes.map((e) => {
          const title = e.title?.trim() || `第 ${e.episodeNo} 集`
          const isSelected = props.selectedIds.has(e.id)
          const isEditing = editingEpisodeId === e.id
          const totalShots = Number.isFinite(e.totalShots) ? Math.max(0, Math.trunc(e.totalShots)) : 0
          const promptCount = Number.isFinite(e.promptCount) ? Math.max(0, Math.trunc(e.promptCount)) : 0
          const videoShotCount = Number.isFinite(e.videoShotCount) ? Math.max(0, Math.trunc(e.videoShotCount)) : 0
          const isDone = totalShots > 0 && videoShotCount >= totalShots
          const statusMeta = getEpisodeStatusMeta(e.status, isDone)
          const validation = isEditing
            ? validateEpisodeNoDraft({
                draftValue: editingEpisodeNoDraft,
                episodeId: e.id,
                episodes: props.episodes
              })
            : null
          const inlineErrorMessage = isEditing ? validation?.errorMessage || editingErrorMessage : ""
          const isSaveDisabled = Boolean(savingEpisodeId) || !isEditing || Boolean(inlineErrorMessage)
          const stats = [
            { label: "分镜数", value: totalShots },
            { label: "生成提示词的分镜数", value: promptCount },
            { label: "生成视频的分镜数", value: videoShotCount }
          ]
          return (
            <article
              key={e.id}
              className={`${styles.episodeCard} ${isSelected ? styles.episodeCardSelected : ""}`}
              onClick={() => {
                // 新页面本期不做：先跳转到占位路由（后续替换为真实创作页）
                const qs = new URLSearchParams()
                qs.set("storyId", props.storyId)
                router.push(`/script/quick-generate/${encodeURIComponent(props.storyId)}/episodes/${encodeURIComponent(e.id)}?${qs.toString()}`)
              }}
            >
              <div
                className={`${styles.selectBox} ${isSelected ? styles.selectBoxActive : ""}`}
                onClick={(event) => {
                  event.stopPropagation()
                  props.toggleSelect(e.id, !isSelected)
                }}
              >
                <input type="checkbox" checked={isSelected} readOnly className={styles.selectInput} />
              </div>
              <button
                type="button"
                className={styles.deleteSingleBtn}
                title="删除剧集"
                onClick={(event) => {
                  event.stopPropagation()
                  props.requestDelete([e.id])
                }}
              >
                <Trash2 size={14} />
              </button>
              <div className={styles.episodeHeader}>
                <div
                  className={styles.episodeHeaderMain}
                  onClick={(event) => {
                    event.stopPropagation()
                  }}
                >
                  {isEditing ? (
                    <div className={styles.episodeTitleEditor}>
                      <input
                        autoFocus
                        type="text"
                        inputMode="numeric"
                        className={`${styles.episodeTitleInput} ${inlineErrorMessage ? styles.episodeTitleInputError : ""}`}
                        value={editingEpisodeNoDraft}
                        aria-label="剧集编号"
                        onClick={(event) => {
                          event.stopPropagation()
                        }}
                        onChange={(event) => {
                          setEditingEpisodeNoDraft(event.target.value.replace(/[^\d]/g, ""))
                          setEditingErrorMessage("")
                        }}
                        onKeyDown={(event) => {
                          event.stopPropagation()
                          if (event.key === "Enter") {
                            event.preventDefault()
                            void submitEpisodeNoUpdate(e)
                          }
                          if (event.key === "Escape") {
                            event.preventDefault()
                            cancelEditEpisodeNo()
                          }
                        }}
                      />
                      <div className={styles.episodeTitleEditorActions}>
                        <button
                          type="button"
                          className={styles.episodeTitleSaveBtn}
                          disabled={isSaveDisabled}
                          onClick={(event) => {
                            event.stopPropagation()
                            void submitEpisodeNoUpdate(e)
                          }}
                        >
                          {savingEpisodeId === e.id ? "保存中..." : "保存"}
                        </button>
                        <button
                          type="button"
                          className={styles.episodeTitleCancelBtn}
                          disabled={Boolean(savingEpisodeId)}
                          onClick={(event) => {
                            event.stopPropagation()
                            cancelEditEpisodeNo()
                          }}
                        >
                          取消
                        </button>
                      </div>
                      {inlineErrorMessage ? <div className={styles.episodeTitleError}>{inlineErrorMessage}</div> : null}
                    </div>
                  ) : (
                    <button
                      type="button"
                      className={styles.episodeTitleButton}
                      title="修改剧集编号"
                      onClick={(event) => {
                        event.stopPropagation()
                        beginEditEpisodeNo(e)
                      }}
                    >
                      <div className={styles.episodeTitle}>{title}</div>
                    </button>
                  )}
                </div>
                <span className={`${styles.statusBadge} ${statusMeta.toneClass}`}>{statusMeta.label}</span>
              </div>
              <div className={styles.episodeStats} aria-label="剧集统计">
                {stats.map((stat) => (
                  <div key={stat.label} className={styles.statCard}>
                    <div className={styles.statLabel}>{stat.label}</div>
                    <div className={styles.statValue}>{stat.value}</div>
                  </div>
                ))}
              </div>
            </article>
          )
        })}
      </div>

      <QuickGenerateCreateEpisodeDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        defaultEpisodeNo={defaultEpisodeNo}
        onSubmit={async (input) => {
          if (busy) return
          setBusy(true)
          try {
            const createInput =
              input.type === "drama"
                ? {
                    storyId: props.storyId,
                    episodeNo: input.episodeNo,
                    type: input.type,
                    prompt: input.prompt,
                    videoModel: input.videoModel,
                    storyboardPanelModel: input.storyboardPanelModel,
                    storyboardPromptPresetId: input.storyboardPromptPresetId,
                    videoPromptPresetId: input.videoPromptPresetId,
                    storyboardPanelPromptPresetId: input.storyboardPanelPromptPresetId
                  }
                : input.type === "outline"
                  ? {
                      storyId: props.storyId,
                      episodeNo: input.episodeNo,
                      type: input.type,
                      content: input.content,
                      minDurationMinutes: input.minDurationMinutes,
                      maxDurationMinutes: input.maxDurationMinutes,
                      shotsNum: input.shotsNum,
                      videoModel: input.videoModel,
                      storyboardPanelModel: input.storyboardPanelModel,
                      storyboardPromptPresetId: input.storyboardPromptPresetId,
                      videoPromptPresetId: input.videoPromptPresetId,
                      storyboardPanelPromptPresetId: input.storyboardPanelPromptPresetId
                    }
                  : {
                      storyId: props.storyId,
                      episodeNo: input.episodeNo,
                      type: input.type,
                      content: input.content,
                      videoModel: input.videoModel,
                      storyboardPanelModel: input.storyboardPanelModel,
                      storyboardPromptPresetId: input.storyboardPromptPresetId,
                      videoPromptPresetId: input.videoPromptPresetId,
                      storyboardPanelPromptPresetId: input.storyboardPanelPromptPresetId
                    }
            const { episodeId, jobId } = await createQuickGenerateEpisode(createInput)
            setEpisodeDefaultVideoModel(episodeId, input.videoModel)
            // 让服务端列表数据更新
            router.refresh()

            // 进入任务队列：将 storyId 带入并跳转到占位页（后续实现）
            const qs = new URLSearchParams()
            qs.set("storyId", props.storyId)
            qs.set("jobId", jobId)
            router.push(`/script/quick-generate/${encodeURIComponent(props.storyId)}/episodes/${encodeURIComponent(episodeId)}?${qs.toString()}`)
          } finally {
            setBusy(false)
          }
        }}
      />
    </>
  )
}
