import { NextResponse, type NextRequest } from "next/server"
import { eq, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { auditLogs, groupAuditCapabilityConfigs, userGroups } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { getGroupAuditCapabilityConfig, groupAuditCapabilityConfigUpdateSchema, updateGroupAuditCapabilityConfig } from "@/server/domains/admin/groupAuditCapabilityConfig"

export const runtime = "nodejs"

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  const { id } = await ctx.params
  if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ userGroups, groupAuditCapabilityConfigs })
  const rows = await db.select({ id: userGroups.id, name: userGroups.name }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
  const group = rows[0]
  if (!group?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

  const config = await getGroupAuditCapabilityConfig(db, id)
  return NextResponse.json(makeApiOk(traceId, { group, config }), { status: 200 })
}

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  const { id } = await ctx.params
  if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
  const parsed = groupAuditCapabilityConfigUpdateSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ userGroups, auditLogs, groupAuditCapabilityConfigs })
  const rows = await db.select({ id: userGroups.id, name: userGroups.name }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
  const group = rows[0]
  if (!group?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

  const result = await updateGroupAuditCapabilityConfig({
    db,
    groupId: id,
    actorUserId: actor.userId,
    traceId,
    data: parsed.data
  })

  await db.execute(sql`
    insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
    values (
      ${actor.userId},
      'user_group.audit_capability_config.update',
      'user_group',
      ${id},
      null,
      ${JSON.stringify({ id, config: result.before })}::jsonb,
      ${JSON.stringify({ id, config: result.after })}::jsonb,
      ${actor.ip},
      ${actor.userAgent},
      ${traceId}
    )
  `)

  return NextResponse.json(makeApiOk(traceId, { group, config: result.config }), { status: 200 })
}
