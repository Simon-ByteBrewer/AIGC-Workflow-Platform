"use client"

import { useMemo, useState, useSyncExternalStore, type ReactElement } from "react"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/shared/ui/shadcn/dropdown-menu"
import type { QuickGenerateOption } from "./QuickGenerateEpisodeResultPage"
import styles from "./QuickGenerateMultiSelectDropdown.module.css"

type QuickGenerateMultiSelectDropdownProps = {
  options: QuickGenerateOption[]
  value: string[]
  onChange: (next: string[]) => void
  placeholder: string
}

function normalizeList(values: string[]): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const v of values) {
    const s = String(v ?? "").trim()
    if (!s || seen.has(s)) continue
    seen.add(s)
    out.push(s)
  }
  return out
}

/**
 * 截断已选素材名称，避免长名称破坏标签区布局。
 * @param value - 原始素材名称
 * @param maxChars - 最大展示字符数
 * @returns 截断后的展示文案
 */
function truncateChipLabel(value: string, maxChars = 8): string {
  const chars = Array.from(String(value ?? ""))
  if (chars.length <= maxChars) return value
  return chars.slice(0, maxChars).join("")
}

export function QuickGenerateMultiSelectDropdown(props: QuickGenerateMultiSelectDropdownProps): ReactElement {
  // Radix DropdownMenu will generate ids during SSR which may not match on the client
  // if the initial render tree differs. Render a static trigger until mounted to
  // avoid hydration attribute mismatches.
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  )

  const [q, setQ] = useState("")
  const selected = useMemo(() => normalizeList(props.value), [props.value])
  const selectedSet = useMemo(() => new Set(selected), [selected])
  const maxTriggerChips = 3
  const selectedSummary = selected.length === 0 ? props.placeholder : `已选 ${selected.length} 项`

  const options = useMemo(() => {
    if (!q.trim()) return props.options
    const qq = q.trim().toLowerCase()
    return props.options.filter((item) => item.label.toLowerCase().includes(qq) || item.value.toLowerCase().includes(qq))
  }, [props.options, q])

  const triggerEl = (
    <button type="button" className={styles.trigger}>
      <span className={styles.triggerBody}>
        <span className={selected.length === 0 ? styles.triggerText : styles.triggerSummary}>{selectedSummary}</span>
        {selected.length === 0 ? (
          <span className={styles.triggerHint}>点击展开后可多选</span>
        ) : (
          <span className={styles.triggerSelectionRow}>
            <span className={styles.triggerChips}>
              {selected.slice(0, maxTriggerChips).map((item) => {
                const opt = props.options.find((o) => o.value === item)
                const fullLabel = opt?.label ?? item
                return (
                  <span key={`trig-${item}`} className={styles.chip} title={fullLabel}>
                    {opt?.image ? <img src={opt.image} alt={opt.label} className={styles.chipThumb} /> : null}
                    <span className={styles.chipText}>{truncateChipLabel(fullLabel, 10)}</span>
                  </span>
                )
              })}
            </span>
            {selected.length > maxTriggerChips ? (
              <span className={styles.moreBadge} title={`还有 ${selected.length - maxTriggerChips} 个已选`}>
                +{selected.length - maxTriggerChips}
              </span>
            ) : null}
          </span>
        )}
      </span>
      <span className={styles.chev}>▼</span>
    </button>
  )

  if (!mounted) {
    // Keep SSR and the very first client render identical.
    return triggerEl
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {triggerEl}
      </DropdownMenuTrigger>
      <DropdownMenuContent className={styles.content} align="start" side="bottom" sideOffset={6}>
        <input className={styles.search} value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索..." />
        <div className={styles.list}>
          {options.length === 0 ? <div className={styles.empty}>没有匹配项</div> : null}
          {options.map((opt) => (
            <DropdownMenuCheckboxItem
              key={opt.value}
              className={styles.optionItem}
              checked={selectedSet.has(opt.value)}
              onCheckedChange={(checked) => {
                if (checked) props.onChange(normalizeList([...selected, opt.value]))
                else props.onChange(selected.filter((x) => x !== opt.value))
              }}
            >
              <div className={styles.itemRow}>
                {opt.image ? <img src={opt.image} alt={opt.label} className={styles.thumb} /> : null}
                <span>{opt.label}</span>
              </div>
            </DropdownMenuCheckboxItem>
          ))}
        </div>
        <DropdownMenuSeparator />
        <div className={styles.selectedRow} aria-label="已选项">
          <div className={styles.selectedHeader}>已选项 {selected.length > 0 ? `(${selected.length})` : ""}</div>
          {selected.length === 0 ? <div className={styles.empty}>未选择</div> : null}
          {selected.map((item) => {
            const opt = props.options.find((o) => o.value === item)
            const fullLabel = opt?.label ?? item
            return (
              <span key={`sel-${item}`} className={styles.chip} title={fullLabel}>
                {opt?.image ? <img src={opt.image} alt={opt.label} className={styles.chipThumb} /> : null}
                <span className={styles.chipText}>{truncateChipLabel(fullLabel, 12)}</span>
                <button type="button" className={styles.chipBtn} onClick={() => props.onChange(selected.filter((x) => x !== item))}>
                  ×
                </button>
              </span>
            )
          })}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
