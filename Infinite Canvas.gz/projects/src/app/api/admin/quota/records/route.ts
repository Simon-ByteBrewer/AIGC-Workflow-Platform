import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { listQuotaAllocationRecords } from "@/server/domains/admin/quotaRecordAdmin"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"

export const runtime = "nodejs"

const querySchema = z.object({
  scope: z.enum(["all", "mine"]).optional(),
  targetType: z.enum(["all", "group", "user"]).optional(),
  targetId: z.string().trim().min(1).max(200).optional(),
  actionType: z.enum(["all", "increase", "modify"]).optional(),
  startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  actorName: z.string().trim().max(100).optional(),
  limit: z.string().trim().optional(),
  offset: z.string().trim().optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)

  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    const url = new URL(req.url)
    const parsed = querySchema.safeParse(Object.fromEntries(url.searchParams.entries()))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    const scope = parsed.data.scope ?? "all"
    const targetType = parsed.data.targetType ?? "all"
    const targetId = parsed.data.targetId ?? null
    const actionType = parsed.data.actionType ?? "all"
    const startDate = parsed.data.startDate ?? null
    const endDate = parsed.data.endDate ?? null
    const actorName = parsed.data.actorName ?? ""
    const limit = Math.max(1, Math.min(200, Number(parsed.data.limit ?? "100") || 100))
    const offset = Math.max(0, Number(parsed.data.offset ?? "0") || 0)
    const items = await listQuotaAllocationRecords({
      actorUserId: actor.userId,
      actorRoleKey: actor.roleKey === "admin" ? "super_admin" : "group_admin",
      actorGroupId: actor.groupId,
      scope,
      targetType,
      targetId,
      actionType,
      startDate,
      endDate,
      actorName,
      limit,
      offset
    })

    return NextResponse.json(makeApiOk(traceId, {
      items,
      limit,
      offset,
      scope,
      targetType,
      targetId,
      actionType,
      startDate,
      endDate,
      actorName
    }))
  } catch (error: any) {
    logger.error({
      event: "quota_record_list_failed",
      module: "admin/quota",
      traceId,
      message: "获取额度分配记录失败",
      errorName: error?.name,
      errorMessage: error?.message,
      stack: error?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "QUOTA_RECORD_LIST_FAILED", error?.message ?? "获取额度分配记录失败"), { status: 500 })
  }
}
