import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { publicResources, insertPublicResourceSchema } from "@/shared/schema"
import { uploadPublicBuffer } from "@/shared/storage"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { eq } from "drizzle-orm"

export const runtime = "nodejs"

const bodySchema = z.object({
  url: z.string().trim().min(1).max(4000),
  name: z.string().trim().max(200).optional(),
  description: z.string().trim().max(2000).optional(),
  tags: z.array(z.string().trim().min(1)).max(100).optional(),
  durationMs: z.number().int().positive().optional().nullable()
})

function normalizeContentType(input: string): string {
  const raw = (input ?? "").trim().toLowerCase()
  const base = raw.split(";")[0]?.trim() || ""
  return base || "video/mp4"
}

function fileExtFromContentType(contentType: string, url: string): string {
  const ct = normalizeContentType(contentType)
  if (ct === "video/mp4") return "mp4"
  if (ct === "video/webm") return "webm"
  if (ct === "video/quicktime") return "mov"
  if (ct === "video/x-m4v") return "m4v"
  if (ct === "video/ogg") return "ogv"
  try {
    const u = new URL(url)
    const ext = u.pathname.split(".").pop() ?? ""
    if (ext && ext.length <= 5) return ext
  } catch {}
  return "mp4"
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()

  const rawUrl = parsed.data.url.trim()
  const isRelative = rawUrl.startsWith("/")
  const resolvedUrl = isRelative ? new URL(rawUrl, req.nextUrl.origin).toString() : rawUrl
  const cookieHeader = isRelative ? req.headers.get("cookie") : null

  const resp = await fetch(resolvedUrl, cookieHeader ? { headers: { cookie: cookieHeader } } : undefined)
  if (!resp.ok) {
    return NextResponse.json(makeApiErr(traceId, "ASSET_DOWNLOAD_FAILED", `下载资源失败：HTTP ${resp.status}`), { status: 400 })
  }
  const contentType = normalizeContentType(resp.headers.get("content-type") ?? "")
  const buffer = Buffer.from(await resp.arrayBuffer())
  const fileExt = fileExtFromContentType(contentType, resolvedUrl)
  const uploaded = await uploadPublicBuffer({ buffer, contentType, fileExt, prefix: "public/video" })

  const resourceName = parsed.data.name?.trim() || "独立镜头视频"
  const payload = insertPublicResourceSchema.parse({
    userId,
    type: "video",
    source: "ai",
    name: resourceName,
    description: parsed.data.description ?? "",
    previewUrl: uploaded.url,
    previewStorageKey: uploaded.key,
    originalUrl: uploaded.url,
    originalStorageKey: uploaded.key,
    durationMs: parsed.data.durationMs ?? null,
    tags: parsed.data.tags ?? [],
    applicableScenes: []
  })

  const db = await getDb({ publicResources })
  const [row] = await db.insert(publicResources).values(payload).returning({ id: publicResources.id })
  const id = row?.id ?? null
  if (id) {
    const stablePreview = `/api/library/public-resources/file/${id}?kind=preview`
    const stableOriginal = `/api/library/public-resources/file/${id}?kind=original`
    await db
      .update(publicResources)
      .set({
        previewUrl: stablePreview,
        originalUrl: stableOriginal
      })
      .where(eq(publicResources.id, id))
  }

  return NextResponse.json(makeApiOk(traceId, { id, url: id ? `/api/library/public-resources/file/${id}?kind=original` : uploaded.url }), { status: 200 })
}
