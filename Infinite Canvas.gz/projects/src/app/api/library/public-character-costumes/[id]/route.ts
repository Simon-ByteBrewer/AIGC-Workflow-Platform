import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { publicCharacterCostumes, publicResources } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

const patchSchema = z
  .object({
    name: z.string().trim().max(200).optional(),
    description: z.string().trim().max(10_000).optional(),
    previewStorageKey: z.string().trim().min(1).max(2000).optional().nullable(),
    originalStorageKey: z.string().trim().min(1).max(2000).optional().nullable(),
    previewUrl: z.string().trim().min(1).max(2000).optional().nullable(),
    originalUrl: z.string().trim().min(1).max(2000).optional().nullable(),
    setDefault: z.boolean().optional()
  })
  .strict()

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const rawParams = await params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const rawBody = await req.json().catch(() => null)
  const parsedBody = patchSchema.safeParse(rawBody)
  if (!parsedBody.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const db = await getDb({ publicResources, publicCharacterCostumes })
  const rows = await db
    .select({
      id: publicCharacterCostumes.id,
      characterResourceId: publicCharacterCostumes.characterResourceId,
      isDefault: publicCharacterCostumes.isDefault
    })
    .from(publicCharacterCostumes)
    .innerJoin(publicResources, eq(publicCharacterCostumes.characterResourceId, publicResources.id))
    .where(and(eq(publicCharacterCostumes.id, parsedParams.data.id), eq(publicResources.userId, userId), eq(publicResources.type, "character")))
    .limit(1)

  const existed = rows[0]
  if (!existed) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "服装不存在"), { status: 404 })

  if (parsedBody.data.setDefault) {
    await db
      .update(publicCharacterCostumes)
      .set({ isDefault: false })
      .where(eq(publicCharacterCostumes.characterResourceId, existed.characterResourceId))
  }

  const nextSet: Record<string, any> = { updatedAt: new Date() }
  if (typeof parsedBody.data.name === "string") nextSet.name = parsedBody.data.name
  if (typeof parsedBody.data.description === "string") nextSet.description = parsedBody.data.description
  if (parsedBody.data.previewStorageKey !== undefined) nextSet.previewStorageKey = parsedBody.data.previewStorageKey
  if (parsedBody.data.originalStorageKey !== undefined) nextSet.originalStorageKey = parsedBody.data.originalStorageKey
  if (parsedBody.data.previewUrl !== undefined) nextSet.previewUrl = parsedBody.data.previewUrl
  if (parsedBody.data.originalUrl !== undefined) nextSet.originalUrl = parsedBody.data.originalUrl
  if (parsedBody.data.setDefault !== undefined) nextSet.isDefault = parsedBody.data.setDefault

  const updated = await db.update(publicCharacterCostumes).set(nextSet).where(eq(publicCharacterCostumes.id, existed.id)).returning()
  const item = updated[0]
  if (!item) return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", "更新失败"), { status: 500 })
  return NextResponse.json(makeApiOk(traceId, { item }), { status: 200 })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const rawParams = await params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const db = await getDb({ publicResources, publicCharacterCostumes })
  const rows = await db
    .select({
      id: publicCharacterCostumes.id,
      characterResourceId: publicCharacterCostumes.characterResourceId,
      isDefault: publicCharacterCostumes.isDefault
    })
    .from(publicCharacterCostumes)
    .innerJoin(publicResources, eq(publicCharacterCostumes.characterResourceId, publicResources.id))
    .where(and(eq(publicCharacterCostumes.id, parsedParams.data.id), eq(publicResources.userId, userId), eq(publicResources.type, "character")))
    .limit(1)

  const existed = rows[0]
  if (!existed) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "服装不存在"), { status: 404 })

  await db.delete(publicCharacterCostumes).where(eq(publicCharacterCostumes.id, existed.id))

  if (existed.isDefault) {
    const latest = await db
      .select({ id: publicCharacterCostumes.id })
      .from(publicCharacterCostumes)
      .where(eq(publicCharacterCostumes.characterResourceId, existed.characterResourceId))
      .orderBy(desc(publicCharacterCostumes.version))
      .limit(1)
    const next = latest[0]
    if (next) {
      await db.update(publicCharacterCostumes).set({ isDefault: true, updatedAt: new Date() }).where(eq(publicCharacterCostumes.id, next.id))
    }
  }

  return NextResponse.json(makeApiOk(traceId, { deleted: true }), { status: 200 })
}

