"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import { useRouter } from "next/navigation"
import styles from "./EpisodeMaterialGalleryPage.module.css"
import { EpisodeMaterialRegenerateModal } from "./EpisodeMaterialRegenerateModal"
import { EpisodeMaterialSection } from "./EpisodeMaterialSection"
import type { MaterialAsset, MaterialSummary } from "./types"

type Props = { storyId: string }

export function EpisodeMaterialGalleryPage({ storyId }: Props): ReactElement {
  const router = useRouter()
  const sid = (storyId ?? "").trim()

  const [summary, setSummary] = useState<MaterialSummary>({ scene: [], role: [], item: [] })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [editing, setEditing] = useState<MaterialAsset | null>(null)

  const loadSummary = useCallback(async () => {
    if (!sid) return
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/script/episode-material-assets/summary?storyId=${encodeURIComponent(sid)}&limit=800`, { cache: "no-store" })
      const json = (await res.json().catch(() => null)) as
        | { ok: boolean; data?: { scene?: any[]; role?: any[]; item?: any[] }; error?: { message?: string } }
        | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const mapOne = (it: any): MaterialAsset => ({
        id: String(it?.id ?? ""),
        kind: String(it?.kind ?? ""),
        name: String(it?.name ?? ""),
        roleName: typeof it?.roleName === "string" ? it.roleName : it?.roleName ?? null,
        makeupName: typeof it?.makeupName === "string" ? it.makeupName : it?.makeupName ?? null,
        costumeName: typeof it?.costumeName === "string" ? it.costumeName : it?.costumeName ?? null,
        prompt: typeof it?.prompt === "string" ? it.prompt : it?.prompt ?? null,
        url: String(it?.url ?? ""),
        thumbnailUrl: typeof it?.thumbnailUrl === "string" ? it.thumbnailUrl : null,
        meta: it?.meta ?? undefined,
        createdAt: typeof it?.createdAt === "string" ? it.createdAt : undefined
      })
      const scene = (Array.isArray(json.data?.scene) ? json.data?.scene : []).map(mapOne).filter((x) => x.id)
      const role = (Array.isArray(json.data?.role) ? json.data?.role : []).map(mapOne).filter((x) => x.id)
      const item = (Array.isArray(json.data?.item) ? json.data?.item : []).map(mapOne).filter((x) => x.id)
      setSummary({ scene, role, item })
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载失败")
      setSummary({ scene: [], role: [], item: [] })
    } finally {
      setLoading(false)
    }
  }, [sid])

  useEffect(() => {
    void loadSummary()
  }, [loadSummary])

  const anyCount = summary.scene.length + summary.role.length + summary.item.length
  const emptyHint = useMemo(() => (loading ? "加载中…" : "暂无图片素材结果"), [loading])

  const onDeleteAsset = useCallback(
    async (asset: MaterialAsset) => {
      if (!sid) return
      const ok = window.confirm(`确认删除「${asset.name || asset.id}」？将同时删除已入库记录。`)
      if (!ok) return
      setError(null)
      try {
        const res = await fetch("/api/script/episode-material-assets/delete", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ storyId: sid, assetId: asset.id })
        })
        const json = (await res.json().catch(() => null)) as { ok: boolean; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        await loadSummary()
      } catch (e) {
        const anyErr = e as { message?: string }
        setError(anyErr?.message ?? "删除失败")
      }
    },
    [loadSummary, sid]
  )

  return (
    <div className={styles.page} aria-label="图片素材结果">
      <div className={styles.header}>
        <div className={styles.title}>图片素材（场景 / 人物 / 物品）</div>
        <div className={styles.actions}>
          <button type="button" className={styles.btn} onClick={() => router.push(`/script/workspace/${encodeURIComponent(sid)}`)}>
            返回剧本
          </button>
          <button type="button" className={`${styles.btn} ${styles.btnPrimary}`} onClick={() => void loadSummary()} disabled={loading}>
            {loading ? "加载中…" : "刷新"}
          </button>
        </div>
      </div>

      {error ? <div className={styles.hint}>{error}</div> : null}

      <main className={styles.main} aria-label="素材列表">
        {anyCount === 0 ? <div className={styles.hint}>{emptyHint}</div> : null}
        <EpisodeMaterialSection title="场景" items={summary.scene} onRegenerate={(a) => setEditing(a)} onDelete={(a) => void onDeleteAsset(a)} />
        <EpisodeMaterialSection title="人物" items={summary.role} onRegenerate={(a) => setEditing(a)} onDelete={(a) => void onDeleteAsset(a)} />
        <EpisodeMaterialSection title="物品" items={summary.item} onRegenerate={(a) => setEditing(a)} onDelete={(a) => void onDeleteAsset(a)} />
      </main>

      {editing ? (
        <EpisodeMaterialRegenerateModal
          storyId={sid}
          asset={editing}
          onClose={() => setEditing(null)}
          onSubmitted={() => {
            setEditing(null)
            void loadSummary()
          }}
        />
      ) : null}
    </div>
  )
}
