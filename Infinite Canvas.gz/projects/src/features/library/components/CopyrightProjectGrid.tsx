"use client"

import type { ReactElement } from "react"
import { FolderClosed } from "lucide-react"
import type { CopyrightLibraryProject } from "@/shared/contracts/library/copyrightLibrary"
import styles from "./CopyrightLibrary.module.css"

interface CopyrightProjectGridProps {
  projects: CopyrightLibraryProject[]
  loading: boolean
  onOpenProject: (projectId: string) => void
}

function formatProjectDate(value?: string | null): string {
  const raw = String(value ?? "").trim()
  if (!raw) return "最近未更新"
  const date = new Date(raw)
  if (Number.isNaN(date.getTime())) return "最近未更新"
  return `最近更新 ${date.toLocaleDateString("zh-CN")}`
}

function getProjectTypeLabel(projectType: CopyrightLibraryProject["projectType"]): string {
  return projectType === "canvas" ? "画布" : "快速开始"
}

export function CopyrightProjectGrid({ projects, loading, onOpenProject }: CopyrightProjectGridProps): ReactElement {
  if (loading) {
    return <div className={styles.projectEmpty}>版权库加载中...</div>
  }

  if (projects.length === 0) {
    return <div className={styles.projectEmpty}>当前筛选条件下暂无版权项目</div>
  }

  return (
    <div className={styles.projectGrid}>
      {projects.map((project) => {
        const items = project.items ?? []
        const reviewedCount = items.filter((item) => String(item.assetStatus ?? "").trim() === "Active").length
        const processingCount = items.filter((item) => String(item.assetStatus ?? "").trim() === "Processing").length
        const failedCount = items.filter((item) => String(item.assetStatus ?? "").trim() === "Failed").length
        return (
          <button key={project.storyId} type="button" className={styles.folderCard} onClick={() => onOpenProject(project.storyId)}>
            <div className={styles.folderTop}>
              <div className={styles.folderIcon}>
                <FolderClosed size={24} strokeWidth={2} />
              </div>
              <div className={styles.folderText}>
                <div className={styles.folderTitle}>{project.title}</div>
                <div className={styles.folderMeta}>{formatProjectDate(project.updatedAt)}</div>
                <div
                  className={`${styles.folderSourceBadge} ${
                    project.projectType === "canvas" ? styles.folderSourceBadgeCanvas : styles.folderSourceBadgeQuick
                  }`}
                >
                  {getProjectTypeLabel(project.projectType)}
                </div>
              </div>
            </div>
            <div className={styles.folderStats}>
              <span className={styles.folderStat}>素材 {items.length}</span>
              <span className={styles.folderStat}>已通过 {reviewedCount}</span>
              {processingCount > 0 ? <span className={styles.folderStat}>审核中 {processingCount}</span> : null}
              {failedCount > 0 ? <span className={styles.folderStat}>失败 {failedCount}</span> : null}
            </div>
          </button>
        )
      })}
    </div>
  )
}
