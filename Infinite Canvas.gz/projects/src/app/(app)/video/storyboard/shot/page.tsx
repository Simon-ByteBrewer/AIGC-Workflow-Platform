import { Suspense, type ReactElement } from "react"
import { ShotGeneratorPage } from "@/features/video/shot-generator/ShotGeneratorPage"

export const dynamic = "force-dynamic"

export default async function Page({
  searchParams
}: {
  searchParams:
    | Record<string, string | string[] | undefined>
    | Promise<Record<string, string | string[] | undefined>>
}): Promise<ReactElement> {
  const resolved = await Promise.resolve(searchParams)
  const storyIdRaw = resolved.storyId
  const storyId = Array.isArray(storyIdRaw) ? storyIdRaw[0] : storyIdRaw
  const outlineIdRaw = resolved.outlineId
  const outlineId = Array.isArray(outlineIdRaw) ? outlineIdRaw[0] : outlineIdRaw
  const storyboardIdRaw = resolved.storyboardId
  const storyboardId = Array.isArray(storyboardIdRaw) ? storyboardIdRaw[0] : storyboardIdRaw

  return (
    <Suspense fallback={null}>
      <ShotGeneratorPage initialStoryId={storyId} initialOutlineId={outlineId} initialStoryboardId={storyboardId} />
    </Suspense>
  )
}

