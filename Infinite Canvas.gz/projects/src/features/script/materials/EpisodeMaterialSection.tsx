"use client"

import { useEffect, useState, useRef, type ReactElement } from "react"
import type { MaterialAsset } from "./types"
import styles from "./EpisodeMaterialGalleryPage.module.css"

type Props = {
  title: string
  items: MaterialAsset[]
  onRegenerate: (asset: MaterialAsset) => void
  onDelete: (asset: MaterialAsset) => void
  onShowFailure?: (asset: MaterialAsset) => void
  onAdd?: () => void
}

function parseJsonMeta(meta: unknown): unknown {
  if (typeof meta !== "string") return meta
  const s = meta.trim()
  if (!s) return meta
  if (!(s.startsWith("{") || s.startsWith("["))) return meta
  try {
    return JSON.parse(s)
  } catch {
    return meta
  }
}

function normalizeUrl(raw: unknown): string {
  if (typeof raw !== "string") return ""
  const s = raw.trim()
  if (!s) return ""
  const stripped = s.replaceAll("`", "").replaceAll('"', "").replaceAll("'", "").replace(/\s+/g, "").trim()
  return stripped
}

function viewsArrayFromMeta(meta: unknown): any[] {
  const parsed = parseJsonMeta(meta)
  if (!parsed) return []
  if (Array.isArray(parsed)) return parsed
  if (typeof parsed !== "object") return []
  const obj: any = parsed as any
  const direct = parseJsonMeta(obj?.views)
  if (Array.isArray(direct)) return direct
  const nested = parseJsonMeta(obj?.meta?.views)
  if (Array.isArray(nested)) return nested
  return []
}

function isFrontLike(v: any): boolean {
  const view = String(v?.view ?? "").trim().toLowerCase()
  if (view === "front" || view === "f" || view === "forward") return true
  const name = String(v?.cameraName ?? v?.camera_name ?? "").trim().toLowerCase()
  return name.includes("正视") || name.includes("正面") || name.includes("front")
}

function isBackLike(v: any): boolean {
  const view = String(v?.view ?? "").trim().toLowerCase()
  if (view === "back" || view === "b" || view === "rear") return true
  const name = String(v?.cameraName ?? v?.camera_name ?? "").trim().toLowerCase()
  return name.includes("背视") || name.includes("背面") || name.includes("后") || name.includes("back")
}

function viewUrlsFromMeta(meta: unknown): { front: string; back: string } | null {
  const metaRoot = parseJsonMeta(meta)
  const views = viewsArrayFromMeta(meta)
  
  // 优先查找 front/back 标记的视图
  const frontRow = views.find((v: any) => isFrontLike(v))
  const backRow = views.find((v: any) => isBackLike(v))
  const frontFromMark = normalizeUrl(frontRow?.url)
  const backFromMark = normalizeUrl(backRow?.url)
  
  if (frontFromMark && backFromMark) {
    return { front: frontFromMark, back: backFromMark }
  }

  // 如果没有标记，直接取前两个视图
  const urls = views.map((v: any) => normalizeUrl(v?.url)).filter(Boolean)
  const first = urls[0] ?? ""
  const second = urls[1] ?? ""
  
  if (first && second) {
    return { front: first, back: second }
  }
  
  if (first) {
    return { front: first, back: first }
  }
  
  return null
}

function viewThumbUrlsFromMeta(meta: unknown): { front: string; back: string } | null {
  const views = viewsArrayFromMeta(meta)
  const frontRow = views.find((v: any) => isFrontLike(v))
  const backRow = views.find((v: any) => isBackLike(v))
  const frontFromMark = normalizeUrl(frontRow?.thumbnailUrl ?? frontRow?.url)
  const backFromMark = normalizeUrl(backRow?.thumbnailUrl ?? backRow?.url)
  if (frontFromMark && backFromMark) {
    return { front: frontFromMark, back: backFromMark }
  }
  const urls = views.map((v: any) => normalizeUrl(v?.thumbnailUrl ?? v?.url)).filter(Boolean)
  const first = urls[0] ?? ""
  const second = urls[1] ?? ""
  if (first && second) {
    return { front: first, back: second }
  }
  if (first) {
    return { front: first, back: first }
  }
  return null
}

type PreviewItem = { src: string; alt: string; label?: string }

function metaObjectFromUnknown(meta: unknown): any | null {
  const parsed = parseJsonMeta(meta)
  if (!parsed) return null
  if (typeof parsed !== "object") return null
  if (Array.isArray(parsed)) return null
  return parsed as any
}

function deriveThumbUrl(asset: MaterialAsset): string {
  const kind = (asset.kind ?? "").trim().toLowerCase()
  const thumb = normalizeUrl(asset.thumbnailUrl)
  if (thumb) return thumb
  const direct = normalizeUrl(asset.url)
  if (direct) return direct
  const metaObj = metaObjectFromUnknown(asset.meta)
  if (!metaObj) return ""
  const sceneUrls = kind === "scene" || kind === "场景" ? viewThumbUrlsFromMeta(metaObj) : null
  if (sceneUrls?.front) return sceneUrls.front
  if (sceneUrls?.back) return sceneUrls.back
  const base = normalizeUrl(metaObj?.selectedUrl ?? metaObj?.baseUrl ?? metaObj?.lookUrl ?? metaObj?.costumeUrl)
  if (base) return base
  const views = viewsArrayFromMeta(metaObj)
  const anyUrl = views.map((v: any) => normalizeUrl(v?.thumbnailUrl ?? v?.url)).find(Boolean) ?? ""
  return anyUrl
}

function deriveStatus(asset: MaterialAsset): { label: string | null; tone?: "info" | "muted" | "error"; title?: string } {
  const url = normalizeUrl(asset.url)
  if (url) return { label: null }
  const metaObj = metaObjectFromUnknown(asset.meta)
  const status = String(metaObj?.generationStatus ?? "").trim().toLowerCase()
  const err = typeof metaObj?.errorMessage === "string" ? metaObj.errorMessage.trim() : ""
  if (status === "failed" || status === "error" || err) return { label: "失败", tone: "error", ...(err ? { title: err } : {}) }
  if (status === "pending" || status === "running") return { label: "生成中", tone: "info" }
  return { label: "未生成", tone: "muted" }
}

export function EpisodeMaterialSection({ title, items, onRegenerate, onDelete, onShowFailure, onAdd }: Props): ReactElement {
  const [preview, setPreview] = useState<{ title: string; items: PreviewItem[] } | null>(null)
  const [visibleCount, setVisibleCount] = useState(40)
  const loadMoreRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const target = loadMoreRef.current
    if (!target) return
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          setVisibleCount((prev) => prev + 40)
        }
      },
      { rootMargin: "200px 0px" }
    )
    observer.observe(target)
    return () => observer.disconnect()
  }, [items.length, visibleCount])

  const visibleItems = items.slice(0, visibleCount)

  useEffect(() => {
    if (!preview) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPreview(null)
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [preview])

  return (
    <section className={styles.section} aria-label={title}>
      <div className={styles.sectionTitle}>
        {title}（{items.length}）
      </div>
      <div className={styles.grid}>
        {visibleItems.map((a) => (
          <div key={a.id} className={styles.card}>
            {(() => {
              const k = (a.kind ?? "").trim().toLowerCase()
              const isScene = k === "scene" || k === "场景"
              const isRole = k === "role" || k === "character" || k === "人物"
              const urls = isScene || isRole ? viewUrlsFromMeta(a.meta) : null
              const thumbUrls = isScene || isRole ? viewThumbUrlsFromMeta(a.meta) : null
              const status = deriveStatus(a)
              if ((isScene || isRole) && urls) {
                const name = a.name || title
                const badgeCls =
                  status.tone === "error" ? styles.thumbBadgeError : status.tone === "info" ? styles.thumbBadgeInfo : styles.thumbBadgeMuted
                return (
                  <div className={`${styles.thumb} ${styles.thumbDual}`} title={status.title}>
                    {status.label ? <div className={`${styles.thumbBadge} ${badgeCls}`}>{status.label}</div> : null}
                    <button
                      type="button"
                      className={styles.thumbHalf}
                      onClick={() =>
                        setPreview({
                          title: name,
                          items: [
                            { src: urls.front, alt: `${name}-正视`, label: "正视" },
                            { src: urls.back, alt: `${name}-背视`, label: "背视" }
                          ]
                        })
                      }
                      aria-label={`预览 正视 ${name}`}
                    >
                      <img
                        className={`${styles.thumbImg} ${styles.thumbImgDual}`}
                        src={(thumbUrls?.front || urls.front) as string}
                        alt={`${name}-正视`}
                        loading="lazy"
                        decoding="async"
                      />
                    </button>
                    <button
                      type="button"
                      className={styles.thumbHalf}
                      onClick={() =>
                        setPreview({
                          title: name,
                          items: [
                            { src: urls.front, alt: `${name}-正视`, label: "正视" },
                            { src: urls.back, alt: `${name}-背视`, label: "背视" }
                          ]
                        })
                      }
                      aria-label={`预览 背视 ${name}`}
                    >
                      <img
                        className={`${styles.thumbImg} ${styles.thumbImgDual}`}
                        src={(thumbUrls?.back || urls.back) as string}
                        alt={`${name}-背视`}
                        loading="lazy"
                        decoding="async"
                      />
                    </button>
                  </div>
                )
              }
              const url = deriveThumbUrl(a)
              const name = a.name || title
              const badgeCls =
                status.tone === "error" ? styles.thumbBadgeError : status.tone === "info" ? styles.thumbBadgeInfo : styles.thumbBadgeMuted
              if (!url) {
                return (
                  <div className={`${styles.thumb} ${styles.thumbPlaceholder}`} aria-label={`${status.label ?? "未生成"} ${name}`} title={status.title}>
                    {status.label ? <div className={`${styles.thumbBadge} ${badgeCls}`}>{status.label}</div> : null}
                    <img className={styles.thumbPlaceholderImg} src="/assets/material-failed.svg" alt="占位图" />
                    <div className={styles.thumbPlaceholderText}>{name}</div>
                  </div>
                )
              }
              return (
                <button
                  type="button"
                  className={styles.thumb}
                  onClick={() => setPreview({ title: name, items: [{ src: url, alt: name }] })}
                  aria-label={`预览 ${name}`}
                  title={status.title}
                >
                  {status.label ? <div className={`${styles.thumbBadge} ${badgeCls}`}>{status.label}</div> : null}
                  <img className={styles.thumbImg} src={url} alt={name} loading="lazy" decoding="async" />
                </button>
              )
            })()}
            <div className={styles.name} title={a.name}>
              {a.name}
            </div>
            {a.roleName || a.makeupName || a.costumeName ? (
              <div className={styles.tags}>
                {a.roleName ? <span className={styles.tag}>{a.roleName}</span> : null}
                {a.makeupName ? <span className={styles.tag}>{a.makeupName}</span> : null}
                {a.costumeName ? <span className={styles.tag}>{a.costumeName}</span> : null}
              </div>
            ) : null}
            <div className={styles.cardActions}>
              {(() => {
                const status = deriveStatus(a)
                if (status.label !== "失败") return null
                if (!onShowFailure) return null
                return (
                  <button type="button" className={styles.btn} onClick={() => onShowFailure(a)}>
                    失败详情
                  </button>
                )
              })()}
              <button type="button" className={styles.btn} onClick={() => onRegenerate(a)}>
                重制
              </button>
              <button type="button" className={`${styles.btn} ${styles.btnDanger}`} onClick={() => onDelete(a)}>
                删除
              </button>
            </div>
          </div>
        ))}
        {onAdd ? (
          <div key={`${title}-add`} className={styles.card}>
            <button
              type="button"
              className={`${styles.thumb} ${styles.thumbPlaceholder}`}
              aria-label={`新增${title}`}
              onClick={() => onAdd()}
            >
              <div className={styles.thumbPlaceholderText}>＋</div>
              <div className={styles.thumbPlaceholderText}>新增</div>
            </button>
            <div className={styles.name}>新增{title}</div>
            <div className={styles.cardActions}>
              <button type="button" className={styles.btn} onClick={() => onAdd()}>
                添加
              </button>
            </div>
          </div>
        ) : null}
        {visibleCount < items.length ? (
          <div ref={loadMoreRef} style={{ height: "20px", gridColumn: "1 / -1" }} aria-hidden="true" />
        ) : null}
      </div>

      {preview ? (
        <div className={styles.previewOverlay} onClick={() => setPreview(null)}>
          <div className={styles.previewModal} onClick={(e) => e.stopPropagation()}>
            <button type="button" className={styles.previewClose} onClick={() => setPreview(null)} aria-label="关闭">
              ✕
            </button>
            <div className={styles.previewTitle}>{preview.title}</div>
            <div className={styles.previewGrid}>
              {preview.items.map((item, i) => (
                <div key={i} className={styles.previewItem}>
                  <img src={item.src} alt={item.alt} className={styles.previewImg} />
                  {item.label ? <div className={styles.previewLabel}>{item.label}</div> : null}
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </section>
  )
}
