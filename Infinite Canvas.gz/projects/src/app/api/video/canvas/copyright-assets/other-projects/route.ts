import { NextResponse, type NextRequest } from "next/server"
import { and, desc, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { canvasCopyrightAssets, quickGenerateMaterials, quickGenerateProjects, stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  search: z.string().trim().max(100).optional(),
  mediaType: z.enum(["image", "video", "audio"]).optional()
})

type OtherProjectAssetItem = {
  id: string
  title: string
  mediaType: "image" | "video" | "audio"
  sourceAssetId: string
  sourceUrl: string
  previewUrl: string
  sourceStorageKey: string
  previewStorageKey: string
  mimeType: string
  sizeBytes?: number | null
  reviewAssetId: string
  reviewStatus: "Active"
  sourceType: "quick_generate" | "other_canvas_project"
  sourceProjectStoryId: string
  sourceProjectTitle: string
}

type OtherProjectGroup = {
  storyId: string
  title: string
  updatedAt: string | null
  projectType: "quick_generate" | "canvas"
  items: OtherProjectAssetItem[]
}

/**
 * 统一清洗文本字段，避免跨项目聚合时出现空白差异。
 */
function trimText(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

/**
 * 将 Quick Generate 的素材类型归一为版权库的媒体类型。
 */
function normalizeQuickGenerateMediaType(materialType: unknown): "image" | "video" | "audio" {
  const raw = trimText(materialType).toLowerCase()
  if (raw === "video") return "video"
  if (raw === "audio") return "audio"
  return "image"
}

/**
 * 从 stories.metadata 中读取画布项目审核 group_id。
 */
function getCanvasGroupId(metadata: unknown): string {
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return ""
  const root = metadata as Record<string, unknown>
  const review = root.canvasAssetReview
  if (!review || typeof review !== "object" || Array.isArray(review)) return ""
  return trimText((review as Record<string, unknown>).groupId)
}

/**
 * 校验当前用户是否有权访问指定画布项目。
 */
async function assertStoryAccess(input: {
  storyId: string
  userId: string
}): Promise<boolean> {
  const db = await getDb({ stories })
  const rows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, input.storyId), eq(stories.userId, input.userId)))
    .limit(1)
  return rows.length > 0
}

/**
 * 根据搜索词判断其他项目的已过审条目是否应出现在版权库里。
 */
function matchOtherProjectSearch(projectTitle: string, item: OtherProjectAssetItem, search: string): boolean {
  if (!search) return true
  return (
    projectTitle.toLowerCase().includes(search) ||
    item.title.toLowerCase().includes(search) ||
    item.sourceAssetId.toLowerCase().includes(search) ||
    item.reviewAssetId.toLowerCase().includes(search)
  )
}

/**
 * 加载“其他项目”可共享的已过审资源，包含 Quick Generate 和其他具备 group_id 的画布项目。
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({
    storyId: req.nextUrl.searchParams.get("storyId") ?? "",
    search: req.nextUrl.searchParams.get("search") ?? undefined,
    mediaType: req.nextUrl.searchParams.get("mediaType") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const allowed = await assertStoryAccess({ storyId: parsed.data.storyId, userId })
  if (!allowed) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用项目"), { status: 404 })

  const search = trimText(parsed.data.search).toLowerCase()
  const mediaTypeFilter = parsed.data.mediaType
  const grouped = new Map<string, OtherProjectGroup>()

  const db = await getDb({ stories, quickGenerateProjects, quickGenerateMaterials, canvasCopyrightAssets })

  const quickRows = await db
    .select({
      projectStoryId: stories.id,
      projectTitle: stories.title,
      projectUpdatedAt: stories.updatedAt,
      materialId: quickGenerateMaterials.id,
      materialTitle: quickGenerateMaterials.title,
      materialType: quickGenerateMaterials.materialType,
      sourceUrl: quickGenerateMaterials.sourceUrl,
      sourceStorageKey: quickGenerateMaterials.storageKey,
      reviewAssetId: quickGenerateMaterials.assetId
    })
    .from(quickGenerateMaterials)
    .innerJoin(quickGenerateProjects, eq(quickGenerateMaterials.projectId, quickGenerateProjects.id))
    .innerJoin(stories, eq(quickGenerateProjects.storyId, stories.id))
    .where(
      and(
        eq(stories.userId, userId),
        eq(stories.storyType, "quick_generate"),
        eq(quickGenerateMaterials.assetStatus, "Active")
      )
    )
    .orderBy(desc(stories.updatedAt), desc(quickGenerateMaterials.updatedAt), desc(quickGenerateMaterials.createdAt))

  for (const row of quickRows) {
    const projectStoryId = trimText(row.projectStoryId)
    if (!projectStoryId || projectStoryId === parsed.data.storyId) continue

    const reviewAssetId = trimText(row.reviewAssetId)
    const sourceUrl = trimText(row.sourceUrl)
    if (!reviewAssetId || !sourceUrl) continue

    const mediaType = normalizeQuickGenerateMediaType(row.materialType)
    if (mediaTypeFilter && mediaType !== mediaTypeFilter) continue

    const item: OtherProjectAssetItem = {
      id: trimText(row.materialId),
      title: trimText(row.materialTitle) || "未命名素材",
      mediaType,
      sourceAssetId: "",
      sourceUrl,
      previewUrl: mediaType === "image" ? sourceUrl : "",
      sourceStorageKey: trimText(row.sourceStorageKey),
      previewStorageKey: "",
      mimeType: "",
      sizeBytes: null,
      reviewAssetId,
      reviewStatus: "Active",
      sourceType: "quick_generate",
      sourceProjectStoryId: projectStoryId,
      sourceProjectTitle: trimText(row.projectTitle) || "未命名 Quick Generate 项目"
    }
    if (!matchOtherProjectSearch(item.sourceProjectTitle, item, search)) continue

    const group =
      grouped.get(projectStoryId) ??
      {
        storyId: projectStoryId,
        title: item.sourceProjectTitle,
        updatedAt: row.projectUpdatedAt ? row.projectUpdatedAt.toISOString() : null,
        projectType: "quick_generate" as const,
        items: []
      }
    group.items.push(item)
    grouped.set(projectStoryId, group)
  }

  const canvasStoryRows = await db
    .select({
      storyId: stories.id,
      title: stories.title,
      updatedAt: stories.updatedAt,
      metadata: stories.metadata
    })
    .from(stories)
    .where(and(eq(stories.userId, userId), eq(stories.storyType, "canvas")))
    .orderBy(desc(stories.updatedAt))

  const otherCanvasStoryIds = canvasStoryRows
    .filter((row) => trimText(row.storyId) && trimText(row.storyId) !== parsed.data.storyId && getCanvasGroupId(row.metadata))
    .map((row) => trimText(row.storyId))

  if (otherCanvasStoryIds.length > 0) {
    const canvasRows = await db
      .select({
        storyId: canvasCopyrightAssets.storyId,
        itemId: canvasCopyrightAssets.id,
        title: canvasCopyrightAssets.title,
        mediaType: canvasCopyrightAssets.mediaType,
        sourceAssetId: canvasCopyrightAssets.sourceAssetId,
        sourceUrl: canvasCopyrightAssets.sourceUrl,
        previewUrl: canvasCopyrightAssets.previewUrl,
        sourceStorageKey: canvasCopyrightAssets.sourceStorageKey,
        previewStorageKey: canvasCopyrightAssets.previewStorageKey,
        mimeType: canvasCopyrightAssets.mimeType,
        sizeBytes: canvasCopyrightAssets.sizeBytes,
        reviewAssetId: canvasCopyrightAssets.reviewAssetId,
        updatedAt: canvasCopyrightAssets.updatedAt
      })
      .from(canvasCopyrightAssets)
      .where(and(eq(canvasCopyrightAssets.reviewStatus, "Active")))
      .orderBy(desc(canvasCopyrightAssets.updatedAt), desc(canvasCopyrightAssets.createdAt))

    const canvasStoryMetaById = new Map(
      canvasStoryRows
        .filter((row) => otherCanvasStoryIds.includes(trimText(row.storyId)))
        .map((row) => [
          trimText(row.storyId),
          {
            title: trimText(row.title) || "未命名画布项目",
            updatedAt: row.updatedAt ? row.updatedAt.toISOString() : null
          }
        ])
    )

    for (const row of canvasRows) {
      const storyId = trimText(row.storyId)
      if (!otherCanvasStoryIds.includes(storyId)) continue

      const sourceUrl = trimText(row.sourceUrl)
      const reviewAssetId = trimText(row.reviewAssetId)
      if (!sourceUrl || !reviewAssetId) continue

      const mediaType = (trimText(row.mediaType) || "image") as "image" | "video" | "audio"
      if (mediaTypeFilter && mediaType !== mediaTypeFilter) continue

      const meta = canvasStoryMetaById.get(storyId)
      if (!meta) continue

      const item: OtherProjectAssetItem = {
        id: trimText(row.itemId),
        title: trimText(row.title) || "未命名素材",
        mediaType,
        sourceAssetId: trimText(row.sourceAssetId),
        sourceUrl,
        previewUrl: trimText(row.previewUrl),
        sourceStorageKey: trimText(row.sourceStorageKey),
        previewStorageKey: trimText(row.previewStorageKey),
        mimeType: trimText(row.mimeType),
        sizeBytes: typeof row.sizeBytes === "number" && Number.isFinite(row.sizeBytes) ? row.sizeBytes : null,
        reviewAssetId,
        reviewStatus: "Active",
        sourceType: "other_canvas_project",
        sourceProjectStoryId: storyId,
        sourceProjectTitle: meta.title
      }
      if (!matchOtherProjectSearch(meta.title, item, search)) continue

      const group =
        grouped.get(storyId) ??
        {
          storyId,
          title: meta.title,
          updatedAt: meta.updatedAt,
          projectType: "canvas" as const,
          items: []
        }
      group.items.push(item)
      grouped.set(storyId, group)
    }
  }

  return NextResponse.json(makeApiOk(traceId, { projects: Array.from(grouped.values()) }), { status: 200 })
}
