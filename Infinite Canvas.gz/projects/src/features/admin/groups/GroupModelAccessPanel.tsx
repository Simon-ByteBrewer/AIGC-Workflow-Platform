"use client"

import { type ReactElement } from "react"
import type { AdminModelType } from "@/shared/contracts/adminUserModelAccess"
import styles from "./GroupsPage.module.css"
import type { UserModelDraftGroups, UserModelDraftRow } from "../users/userModelAccessForm"

const sections: Array<{ type: AdminModelType; title: string; description: string }> = [
  { type: "video", title: "视频模型", description: "用于后续视频生成工作流的模型名到 EP 映射" },
  { type: "language", title: "文本模型", description: "用于后续文本生成工作流的模型名到 EP 映射" },
  { type: "image", title: "图片模型", description: "用于后续图片生成工作流的模型名到 EP 映射" }
]

type Props = {
  apiKeyConfigured: boolean
  apiKeyMasked: string | null
  apiKeyDraft: string
  apiKeyAction: "unchanged" | "replace" | "clear"
  modelRows: UserModelDraftGroups
  showExternalImageModelButton: boolean
  onAddExternalImageModel: () => void
  disabled?: boolean
  onApiKeyDraftChange: (value: string) => void
  onClearApiKey: () => void
  onUndoClearApiKey: () => void
  onAddRow: (type: AdminModelType) => void
  onRemoveRow: (type: AdminModelType, rowId: string) => void
  onUpdateRow: (type: AdminModelType, rowId: string, patch: Partial<UserModelDraftRow>) => void
}

function renderApiKeyStatus(props: Props): string {
  if (props.apiKeyAction === "clear") return "保存后将清空当前 API Key"
  if (props.apiKeyAction === "replace" && props.apiKeyDraft.trim()) return "保存后将更新为新的 API Key"
  if (props.apiKeyConfigured && props.apiKeyMasked) return `当前已配置：${props.apiKeyMasked}`
  return "当前未配置 API Key"
}

export function GroupModelAccessPanel(props: Props): ReactElement {
  return (
    <div className={styles.configPanel}>
      <div className={styles.groupHint}>超级管理员在这里为整个用户组配置 API Key 和模型定义，组管理员只能控制账号启用状态。</div>

      <div className={styles.modelAccessCard}>
        <div className={styles.modelAccessHeader}>
          <div>
            <div className={styles.modelAccessTitle}>组级 API Key</div>
            <div className={styles.modelAccessDesc}>{renderApiKeyStatus(props)}</div>
          </div>
          <div className={styles.topActions}>
            {props.apiKeyConfigured && props.apiKeyAction !== "clear" ? (
              <button type="button" className={styles.topBtn} onClick={props.onClearApiKey} disabled={props.disabled}>
                清空已配置
              </button>
            ) : null}
            {props.apiKeyAction === "clear" ? (
              <button type="button" className={styles.topBtn} onClick={props.onUndoClearApiKey} disabled={props.disabled}>
                撤销清空
              </button>
            ) : null}
          </div>
        </div>
        <input
          className={styles.input}
          value={props.apiKeyDraft}
          onChange={(event) => props.onApiKeyDraftChange(event.target.value)}
          placeholder={props.apiKeyMasked ? `留空则保持 ${props.apiKeyMasked}` : "输入该组统一使用的 API Key"}
          disabled={props.disabled}
        />
      </div>

      <div className={styles.modelSectionList}>
        {sections.map((section) => (
          <div key={section.type} className={styles.modelAccessCard}>
            <div className={styles.modelAccessHeader}>
              <div>
                <div className={styles.modelAccessTitle}>{section.title}</div>
                <div className={styles.modelAccessDesc}>{section.description}</div>
              </div>
              <div className={styles.topActions}>
                {section.type === "image" && props.showExternalImageModelButton ? (
                  <button type="button" className={styles.topBtnPrimary} onClick={props.onAddExternalImageModel} disabled={props.disabled}>
                    新增外部模型接入
                  </button>
                ) : null}
                <button type="button" className={styles.topBtnPrimary} onClick={() => props.onAddRow(section.type)} disabled={props.disabled}>
                  新增模型
                </button>
              </div>
            </div>

            <div className={styles.modelTable}>
              <div className={`${styles.modelRow} ${styles.modelRowHead}`}>
                <div>模型名称(展示名)</div>
                <div>真实名称</div>
                <div>EP 接入点</div>
                <div>默认启用</div>
                <div>操作</div>
              </div>
              {props.modelRows[section.type].length === 0 ? (
                <div className={styles.muted}>暂无配置</div>
              ) : (
                props.modelRows[section.type].map((row) => (
                  <div key={row.id} className={styles.modelRow}>
                    <input
                      className={styles.input}
                      value={row.modelName}
                      onChange={(event) => props.onUpdateRow(section.type, row.id, { modelName: event.target.value })}
                      placeholder="例如 seedance-2_0_pro"
                      disabled={props.disabled}
                    />
                    {section.type === "video" ? (
                      <select
                        className={styles.input}
                        value={row.realName || ""}
                        onChange={(event) => props.onUpdateRow(section.type, row.id, { realName: event.target.value })}
                        disabled={props.disabled}
                      >
                        <option value="" disabled>请选择真实名称</option>
                        <option value="seedance_2_0">seedance_2_0</option>
                        <option value="seedance_2_0_fast">seedance_2_0_fast</option>
                        <option value="seedance_2_0_pro">seedance_2_0_pro</option>
                      </select>
                    ) : section.type === "image" ? (
                      <select
                        className={styles.input}
                        value={row.realName || ""}
                        onChange={(event) => props.onUpdateRow(section.type, row.id, { realName: event.target.value })}
                        disabled={props.disabled}
                      >
                        <option value="doubao-seedream-5.0-lite">doubao-seedream-5.0-lite</option>
                        <option value="doubao-seedream-4.5">doubao-seedream-4.5</option>
                        <option value="doubao-seedream-4.0">doubao-seedream-4.0</option>
                      </select>
                    ) : (
                      <input
                        className={styles.input}
                        value={row.realName || ""}
                        onChange={(event) => props.onUpdateRow(section.type, row.id, { realName: event.target.value })}
                        placeholder="例如 base-language-model"
                        disabled={props.disabled}
                      />
                    )}
                    <input
                      className={styles.input}
                      value={row.ep}
                      onChange={(event) => props.onUpdateRow(section.type, row.id, { ep: event.target.value })}
                      placeholder="例如 ep-20230030020332"
                      disabled={props.disabled}
                    />
                    <label className={styles.switchLabel}>
                      <input
                        type="checkbox"
                        checked={row.enabled}
                        onChange={(event) => props.onUpdateRow(section.type, row.id, { enabled: event.target.checked })}
                        disabled={props.disabled}
                      />
                      <span>{row.enabled ? "启用" : "禁用"}</span>
                    </label>
                    <button type="button" className={styles.topBtn} onClick={() => props.onRemoveRow(section.type, row.id)} disabled={props.disabled}>
                      删除
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
