"use client"

import { useState, type ReactElement } from "react"
import { Pencil } from "lucide-react"
import styles from "./QuickGenerateMaterialCard.module.css"
import type { QuickGenerateMaterial } from "@/shared/schema/quickGenerate"
import { QuickGenerateMaterialCardEditor } from "./QuickGenerateMaterialCardEditor"

type Speaker = { id: string; name: string; sampleUrl?: string }
type AudioMaterial = { id: string; title: string; assetId: string; assetStatus: string; sourceUrl: string }

type AssetReviewStatus = "Active" | "Processing" | "Failed"

export function QuickGenerateMaterialCard({
  item,
  batchEditMode,
  audioMaterials,
  isSelected,
  toggleSelect,
  requestDelete,
  onClickDetail,
  onSave,
  onDraftChange,
  speakers
}: {
  item: QuickGenerateMaterial
  batchEditMode: boolean
  audioMaterials: AudioMaterial[]
  isSelected: boolean
  toggleSelect: (id: string, checked: boolean) => void
  requestDelete: (ids: string[]) => void
  onClickDetail: (item: QuickGenerateMaterial) => void
  onSave: (id: string, updates: Partial<QuickGenerateMaterial>) => Promise<void>
  onDraftChange: (id: string, draft: Partial<QuickGenerateMaterial>) => void
  speakers: Speaker[]
}): ReactElement {
  const [editing, setEditing] = useState(false)
  const isEditing = batchEditMode || editing

  const getTypeName = (type: string) => {
    const map: Record<string, string> = {
      scene: "场景",
      character: "人物",
      prop: "物品",
      video: "视频",
      audio: "音频",
      reference: "参考"
    }
    return map[type] || type
  }

  const renderPreview = () => {
    if (item.materialType === "video") return <div className={styles.previewPlaceholder}>🎥 视频</div>
    if (item.materialType === "audio") return <div className={styles.previewPlaceholder}>🎵 音频</div>
    if (item.sourceUrl) {
      return (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={item.sourceUrl} alt={item.title || ""} className={styles.previewImage} loading="lazy" decoding="async" />
      )
    }
    return <div className={styles.previewPlaceholder}>📄 未知</div>
  }

  const assetStatus = String((item as any).assetStatus ?? "").trim() as AssetReviewStatus | ""
  const assetErrorMessage = String((item as any).assetErrorMessage ?? "").trim()
  const assetId = String((item as any).assetId ?? "").trim()

  const renderAssetTag = () => {
    if (!assetStatus) return null
    if (assetStatus === "Active") return <span className={`${styles.tag} ${styles.assetTagActive}`}>已通过</span>
    if (assetStatus === "Processing") return <span className={`${styles.tag} ${styles.assetTagProcessing}`}>审核中</span>
    if (assetStatus === "Failed") {
      const title = assetErrorMessage ? `失败原因：${assetErrorMessage}` : "失败原因：未知"
      return (
        <span
          className={`${styles.tag} ${styles.assetTagFailed}`}
          title={title}
          onClick={(e) => {
            e.stopPropagation()
            if (assetErrorMessage) alert(assetErrorMessage)
          }}
        >
          审核失败
        </span>
      )
    }
    return null
  }

  return (
    <article
      className={`${styles.listCard} ${batchEditMode ? styles.listCardEditing : ""}`}
      onClick={() => {
        if (!isEditing) onClickDetail(item)
      }}
    >
      <div className={styles.cardPreview}>
        {renderPreview()}

        {/* 批量选择框 */}
        <div
          className={`${styles.selectBox} ${isSelected ? styles.selectBoxActive : ""}`}
          onClick={(e) => {
            e.stopPropagation()
            toggleSelect(item.id, !isSelected)
          }}
        >
          <input
            type="checkbox"
            checked={isSelected}
            readOnly
            className={styles.selectInput}
          />
        </div>

        {/* 单独删除按钮 */}
        {!isEditing && !isSelected && (
          <button
            type="button"
            className={styles.deleteSingleBtn}
            title="删除素材"
            onClick={(e) => {
              e.stopPropagation()
              requestDelete([item.id])
            }}
          >
            ✕
          </button>
        )}
      </div>

      <div className={styles.cardInfo}>
        {isEditing ? (
          <QuickGenerateMaterialCardEditor
            item={item}
            batchEditMode={batchEditMode}
            singleEditing={editing}
            onExitSingleEditing={() => {
              setEditing(false)
            }}
            onSave={onSave}
            onDraftChange={onDraftChange}
            speakers={speakers}
            audioMaterials={audioMaterials}
          />
        ) : (
          <>
            <div
              className={styles.listTitleWrapper}
              onClick={(e) => {
                e.stopPropagation()
                setEditing(true)
              }}
              title="点击编辑"
            >
              <span className={styles.listTitle}>{item.title?.trim() || "未命名素材"}</span>
              <Pencil size={12} className={styles.pencilIcon} />
            </div>
            <div className={styles.listMeta}>
              <span className={styles.tag}>{getTypeName(item.materialType || "reference")}</span>
              {item.materialType === "character" && (
                <span className={styles.tag}>{item.voiceSpeakerName || "未绑定音色"}</span>
              )}
              {renderAssetTag()}
            </div>
            <div
              className={styles.assetRow}
              onClick={(e) => {
                e.stopPropagation()
              }}
            >
              <div className={styles.assetRowLeft} title={assetId || "未设置"}>
                <span className={styles.assetLabel}>assetId</span>
                <span className={styles.assetValue}>{assetId || "未设置"}</span>
              </div>
            </div>
          </>
        )}
      </div>
    </article>
  )
}
