"use client"

import type { ReactElement } from "react"
import { useCallback, useEffect, useMemo, useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/shared/ui/shadcn/dialog"
import { Trash2 } from "lucide-react"
import styles from "./CharacterVariantModal.module.css"

type VariantKind = "look" | "costume"
type VariantScope = "library" | "shared"

type VariantItem = {
  id: string
  characterResourceId: string
  version: number
  isDefault: boolean
  name: string
  description: string
  previewUrl: string | null
  previewStorageKey: string | null
  originalUrl: string | null
  originalStorageKey: string | null
  createdAt: string | null
  updatedAt: string | null
}

function buildListUrl(kind: VariantKind, scope: VariantScope, characterId: string): string {
  const base =
    scope === "shared"
      ? kind === "look"
        ? "/api/library/shared-character-looks/list"
        : "/api/library/shared-character-costumes/list"
      : kind === "look"
        ? "/api/library/public-character-looks/list"
        : "/api/library/public-character-costumes/list"
  const qs = new URLSearchParams({ characterId, limit: "200", offset: "0" })
  return `${base}?${qs.toString()}`
}

function buildFileUrl(kind: VariantKind, scope: VariantScope, id: string, fileKind: "preview" | "original"): string {
  const base =
    scope === "shared"
      ? kind === "look"
        ? "/api/library/shared-character-looks/file"
        : "/api/library/shared-character-costumes/file"
      : kind === "look"
        ? "/api/library/public-character-looks/file"
        : "/api/library/public-character-costumes/file"
  return `${base}/${encodeURIComponent(id)}?kind=${encodeURIComponent(fileKind)}`
}

function normalizeVariantItem(raw: any): VariantItem | null {
  const id = typeof raw?.id === "string" ? raw.id : ""
  const characterResourceId = typeof raw?.characterResourceId === "string" ? raw.characterResourceId : ""
  const version = typeof raw?.version === "number" ? raw.version : Number(raw?.version ?? NaN)
  if (!id || !characterResourceId || !Number.isFinite(version)) return null

  return {
    id,
    characterResourceId,
    version,
    isDefault: Boolean(raw?.isDefault),
    name: typeof raw?.name === "string" ? raw.name : "",
    description: typeof raw?.description === "string" ? raw.description : "",
    previewUrl: typeof raw?.previewUrl === "string" ? raw.previewUrl : null,
    previewStorageKey: typeof raw?.previewStorageKey === "string" ? raw.previewStorageKey : null,
    originalUrl: typeof raw?.originalUrl === "string" ? raw.originalUrl : null,
    originalStorageKey: typeof raw?.originalStorageKey === "string" ? raw.originalStorageKey : null,
    createdAt: typeof raw?.createdAt === "string" ? raw.createdAt : null,
    updatedAt: typeof raw?.updatedAt === "string" ? raw.updatedAt : null
  }
}

function formatTime(value: string | null): string {
  if (!value) return ""
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return value
  const yyyy = d.getFullYear()
  const mm = String(d.getMonth() + 1).padStart(2, "0")
  const dd = String(d.getDate()).padStart(2, "0")
  const hh = String(d.getHours()).padStart(2, "0")
  const mi = String(d.getMinutes()).padStart(2, "0")
  return `${yyyy}-${mm}-${dd} ${hh}:${mi}`
}

export function CharacterVariantModal(props: {
  open: boolean
  onOpenChange: (open: boolean) => void
  defaultKind?: VariantKind
  onKindChange?: (kind: VariantKind) => void
  scope: VariantScope
  characterId: string
  characterName: string
}): ReactElement {
  const [kind, setKind] = useState<VariantKind>(props.defaultKind ?? "look")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [items, setItems] = useState<VariantItem[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)

  const title = kind === "look" ? "装造" : "服装"

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const url = buildListUrl(kind, props.scope, props.characterId)
      const res = await fetch(url, { cache: "no-store" })
      const json = (await res.json().catch(() => null)) as
        | { ok: boolean; data?: { items?: any[]; total?: number }; error?: { message?: string } }
        | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const rawList = Array.isArray(json.data?.items) ? json.data?.items ?? [] : []
      const next = rawList.map(normalizeVariantItem).filter(Boolean) as VariantItem[]
      next.sort((a, b) => (b.version ?? 0) - (a.version ?? 0))
      setItems(next)
      setActiveId((prev) => {
        if (prev && next.some((x) => x.id === prev)) return prev
        return next[0]?.id ?? null
      })
    } catch (e) {
      const anyErr = e as { message?: string }
      setItems([])
      setActiveId(null)
      setError(anyErr?.message ?? "加载失败")
    } finally {
      setLoading(false)
    }
  }, [kind, props.characterId, props.scope])

  const handleDelete = useCallback(async (variantId: string) => {
    setDeletingId(variantId)
    try {
      const url = buildFileUrl(kind, props.scope, variantId, "original")
      const [base] = url.split("/file/")
      const deleteUrl = `${base}/${encodeURIComponent(variantId)}`
      
      const res = await fetch(deleteUrl, {
        method: "DELETE",
        credentials: "include"
      })
      
      if (!res.ok) {
        const json = (await res.json().catch(() => null)) as { error?: { message?: string } } | null
        throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      }
      
      // 删除成功后重新加载列表
      await load()
      setDeleteConfirmId(null)
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "删除失败")
    } finally {
      setDeletingId(null)
    }
  }, [kind, props.scope, load])

  useEffect(() => {
    if (!props.open) return
    setKind(props.defaultKind ?? "look")
  }, [props.defaultKind, props.open])

  useEffect(() => {
    if (!props.open) return
    setItems([])
    setActiveId(null)
    void load()
  }, [kind, load, props.open])

  const active = useMemo(() => items.find((x) => x.id === activeId) ?? null, [activeId, items])
  const activeImageUrl = useMemo(() => {
    if (!active) return null
    if (active.previewStorageKey || active.originalStorageKey) {
      return buildFileUrl(kind, props.scope, active.id, "preview")
    }
    return active.previewUrl || active.originalUrl || null
  }, [active, kind, props.scope])

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent
        className={styles.content}
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => e.stopPropagation()}
        onPointerDownOutside={(e) => {
          ;(e as any)?.detail?.originalEvent?.stopPropagation?.()
        }}
        onInteractOutside={(e) => {
          ;(e as any)?.detail?.originalEvent?.stopPropagation?.()
        }}
      >
        <DialogHeader className={styles.header}>
          <DialogTitle className={styles.title}>{props.characterName} · 形象</DialogTitle>
          <div className={styles.tabs} role="tablist" aria-label="形象类型">
            <button
              type="button"
              className={kind === "look" ? `${styles.tab} ${styles.tabActive}` : styles.tab}
              onClick={() => {
                setKind("look")
                props.onKindChange?.("look")
              }}
              aria-selected={kind === "look"}
              role="tab"
            >
              装造
            </button>
            <button
              type="button"
              className={kind === "costume" ? `${styles.tab} ${styles.tabActive}` : styles.tab}
              onClick={() => {
                setKind("costume")
                props.onKindChange?.("costume")
              }}
              aria-selected={kind === "costume"}
              role="tab"
            >
              服装
            </button>
          </div>
        </DialogHeader>

        <div className={styles.body}>
          <div className={styles.listPane}>
            <div className={styles.listHeader}>
              <span className={styles.listHeaderTitle}>版本</span>
              <button
                type="button"
                className={styles.refreshBtn}
                onClick={() => void load()}
                disabled={loading}
              >
                刷新
              </button>
            </div>

            {loading ? <div className={styles.hint}>加载中...</div> : null}
            {error ? <div className={styles.error}>{error}</div> : null}
            {!loading && !error && items.length === 0 ? <div className={styles.hint}>暂无{title}版本</div> : null}

            <div className={styles.list}>
              {items.map((v) => {
                const selected = v.id === activeId
                const meta = formatTime(v.updatedAt || v.createdAt)
                const displayName = v.name?.trim() ? v.name.trim() : `V${v.version}`
                const isDeleting = deletingId === v.id
                return (
                  <div
                    key={v.id}
                    role="button"
                    tabIndex={0}
                    className={`${styles.listItem} ${selected ? styles.listItemActive : ""}`}
                    onClick={() => setActiveId(v.id)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault()
                        setActiveId(v.id)
                      }
                    }}
                    aria-selected={selected}
                  >
                    <div className={styles.listItemTop}>
                      <span className={styles.listItemName}>{displayName}</span>
                      <div className={styles.listItemActions}>
                        {v.isDefault ? <span className={styles.defaultTag}>默认</span> : null}
                        <button
                          type="button"
                          className={styles.deleteBtn}
                          onClick={(e) => {
                            e.stopPropagation()
                            setDeleteConfirmId(v.id)
                          }}
                          disabled={isDeleting}
                          aria-label={`删除${displayName}`}
                          title="删除"
                        >
                          <Trash2 size={14} strokeWidth={2} />
                        </button>
                      </div>
                    </div>
                    <div className={styles.listItemMeta}>{meta}</div>
                  </div>
                )
              })}
            </div>
          </div>

          <div className={styles.detailPane}>
            {active ? (
              <>
                <div className={styles.imageWrap}>
                  {activeImageUrl ? <img className={styles.image} src={activeImageUrl} alt={active.name || title} /> : <div className={styles.imageEmpty}>暂无图片</div>}
                </div>
                <div className={styles.detailMeta}>
                  <div className={styles.detailRow}>
                    <span className={styles.detailLabel}>版本</span>
                    <span className={styles.detailValue}>{active.name?.trim() ? active.name.trim() : `V${active.version}`}</span>
                  </div>
                  <div className={styles.detailRow}>
                    <span className={styles.detailLabel}>更新时间</span>
                    <span className={styles.detailValue}>{formatTime(active.updatedAt || active.createdAt) || "-"}</span>
                  </div>
                </div>
                <div className={styles.desc}>
                  {active.description?.trim() ? active.description : <span className={styles.descEmpty}>暂无描述</span>}
                </div>
              </>
            ) : (
              <div className={styles.hint}>请选择一个版本</div>
            )}
          </div>
        </div>

        {/* 删除确认对话框 */}
        {deleteConfirmId ? (
          <div className={styles.deleteConfirmOverlay}>
            <div className={styles.deleteConfirmBox}>
              <div className={styles.deleteConfirmTitle}>确认删除</div>
              <div className={styles.deleteConfirmMessage}>
                {items.find(i => i.id === deleteConfirmId)?.isDefault ? (
                  <>
                    当前版本是<strong>默认版本</strong>，删除后将自动选择其他版本为默认。确定要删除吗？
                  </>
                ) : (
                  <>
                    确定要删除版本 <strong>{items.find(i => i.id === deleteConfirmId)?.name || '该版本'}</strong> 吗？删除后无法恢复。
                  </>
                )}
              </div>
              <div className={styles.deleteConfirmActions}>
                <button
                  type="button"
                  className={styles.deleteConfirmBtn}
                  onClick={() => setDeleteConfirmId(null)}
                >
                  取消
                </button>
                <button
                  type="button"
                  className={`${styles.deleteConfirmBtn} ${styles.deleteConfirmBtnDanger}`}
                  onClick={() => handleDelete(deleteConfirmId)}
                  disabled={deletingId !== null}
                >
                  {deletingId === deleteConfirmId ? '删除中...' : '确认删除'}
                </button>
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  )
}
