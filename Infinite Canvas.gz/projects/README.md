# ai-video

Next.js App Router 项目骨架（TypeScript + ESLint）。

## 项目结构约定
- 见 [docs/architecture.md](./docs/architecture.md)

## 🔍 日志诊断与故障排查

## 部署（源码交付）
### 1) 准备代码与环境
- 复制/拉取源码到服务器
- 安装 Node.js（建议与 `.nvmrc` 一致）
- 进入项目目录后执行：`npm ci`

### 2) 配置环境变量
在项目根目录创建 `.env.local`（不要提交到仓库），最少需要：
- 数据库：`PGDATABASE_URL`（或 `DATABASE_URL`/`POSTGRES_URL`）
- 生产环境必须：`AUTH_SESSION_SECRET`（用于会话 cookie 签名）
- 对象存储（如需上传/资源库等能力）：`COZE_BUCKET_ENDPOINT_URL`/`COZE_BUCKET_NAME`/`COZE_BUCKET_ACCESS_KEY`/`COZE_BUCKET_SECRET_KEY`

其余可选项见 `.env.example`（Coze/Ark/Jianying 导出等能力可按需启用）。

### 3) 初始化数据库表
本项目会在运行时自动创建/对齐 public schema。

推荐做法：
1. 配置好 `PGDATABASE_URL`
2. 启动服务（`npm run dev` 或 `npm run start`）
3. 调用一次登录接口（即使账号不存在也会先触发表创建）：`POST /api/auth/login`

### 4) 创建初始账号（用于登录与管理后台）
当前登录逻辑不会自动创建账号；需要先在数据库中插入 users/user_security。

1. 生成密码哈希：
   - `npm run auth:hash-password -- "YourPassword"`
2. 用生成的哈希写入数据库（示例）：

```sql
insert into public.users (name, email, password, is_active)
values ('admin', 'account:admin', '<PASTE_PASSWORD_HASH_HERE>', true);

insert into public.user_security (user_id, role_key, token_version)
select id, 'admin', 1 from public.users where name = 'admin'
on conflict do nothing;
```

### 5) 构建与启动
- 构建：`npm run build`
- 启动：`npm run start`（默认端口 3000，可通过 `PORT` 调整）
- 登录态 cookie 会根据 `APP_ORIGIN` 判断是否加 `Secure`：`APP_ORIGIN=https://...` 时要求 HTTPS，`APP_ORIGIN=http://...` 时支持 HTTP 访问。
遇到问题需要诊断时，请参考：
- [日志诊断指南](./docs/log-diagnosis-guide.md)
- [诊断脚本使用指南](./scripts/README.md)
- [剧本正文超时问题诊断报告](./docs/script-body-timeout-diagnosis.md)
- [Coze 异步接口分析报告](./docs/coze-async-api-analysis.md)
- [剧本正文异步接口使用指南](./docs/script-body-async-api-guide.md)

## 超级管理员后台（API 测试台）

### 访问条件
- 默认仅在非生产环境可用；生产环境需设置 `ADMIN_PANEL_ENABLED=1` 才会放行 `/admin`。
- 仅允许账号为 `admin` 的用户访问 `/admin/**`。

### 登录账号
- 账号：`admin`
- 密码：`admin`

说明：项目登录逻辑会在首次使用该账号登录时自动创建用户，因此无需提前建库。

### 入口
- 登录后（账号为 `admin`），顶部栏会出现“盾牌”图标入口，或直接访问：`/admin`。

### 使用方式
1. 使用 `admin/admin` 登录。
2. 打开 `/admin/api-tester`，在左侧选择接口。
3. 编辑请求 Method、URL、Headers、Body（JSON/Text/FormData/File），点击“发送”查看响应。
4. 需要测试事件流接口时，勾选“流式模式（EventSource）”（仅支持 GET）。
5. “历史”会保存最近 40 条请求到 localStorage，可一键复用；“复制 curl”可导出当前请求。
