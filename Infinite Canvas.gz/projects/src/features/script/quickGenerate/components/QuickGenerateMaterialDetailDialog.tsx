"use client"

import { useState, useEffect, useMemo, useCallback, useRef, type ReactElement } from "react"
import { createPortal } from "react-dom"
import { X } from "lucide-react"
import styles from "./QuickGenerateMaterialDetailDialog.module.css"
import { useRouter } from "next/navigation"
import { batchUpdateQuickGenerateMaterials } from "../api-client"

type Speaker = { id: string; name: string; sampleUrl?: string }
type AudioMaterial = { id: string; title: string; assetId: string; assetStatus: string; sourceUrl: string }
const CUSTOM_VOICE_ID = "__custom__"
const VOICE_DROPDOWN_GAP = 6
const VOICE_DROPDOWN_WIDTH = 220

type VoiceDropdownPosition = {
  left: number
  top: number
  width: number
  maxHeight: number
}

export type QuickGenerateMaterialPreview = {
  id: string
  title: string | null
  materialType: string
  sourceUrl: string | null
  voiceSpeakerId: string | null
  voiceSpeakerName: string | null
  metadata: unknown
}

type QuickGenerateMaterialDetailDialogProps = {
  material: QuickGenerateMaterialPreview | null
  audioMaterials?: AudioMaterial[]
  onClose: () => void
}

/**
 * 从音色表接口加载当前可用音色列表。
 * 返回的 sampleUrl 来自 tts_speaker_samples，用于详情弹窗试听。
 */
async function fetchSpeakerList(): Promise<Speaker[]> {
  const res = await fetch("/api/tts/speakers", { cache: "no-store" })
  const json = await res.json().catch(() => null)
  return Array.isArray(json?.data?.speakers) ? json.data.speakers : []
}

export function QuickGenerateMaterialDetailDialog({
  material,
  audioMaterials = [],
  onClose
}: QuickGenerateMaterialDetailDialogProps): ReactElement | null {
  const router = useRouter()
  const previewAudioRef = useRef<HTMLAudioElement | null>(null)
  const voiceTriggerRef = useRef<HTMLButtonElement | null>(null)
  const voiceDropdownRef = useRef<HTMLDivElement | null>(null)
  const voiceSearchInputRef = useRef<HTMLInputElement | null>(null)
  const [speakers, setSpeakers] = useState<Speaker[]>([])
  const [voiceSpeakerId, setVoiceSpeakerId] = useState<string>("")
  const [customAudioId, setCustomAudioId] = useState<string>("")
  const [voiceBinding, setVoiceBinding] = useState(false)
  const [voicePreview, setVoicePreview] = useState<{ name: string; src: string } | null>(null)
  const [speakerSearch, setSpeakerSearch] = useState("")
  const [speakerMenuOpen, setSpeakerMenuOpen] = useState(false)
  const [voiceDropdownPosition, setVoiceDropdownPosition] = useState<VoiceDropdownPosition | null>(null)
  
  const selectedCustomAudio = useMemo(() => {
    if (!customAudioId) return null
    return audioMaterials.find((audio) => audio.id === customAudioId) ?? null
  }, [audioMaterials, customAudioId])

  const filteredSpeakers = useMemo(() => {
    const keyword = speakerSearch.trim().toLowerCase()
    if (!keyword) return speakers
    return speakers.filter((speaker) => speaker.name.toLowerCase().includes(keyword))
  }, [speakerSearch, speakers])

  const selectedSpeaker = useMemo(() => speakers.find((s) => s.id === voiceSpeakerId) ?? null, [speakers, voiceSpeakerId])
  const voiceSelectionLabel = useMemo(() => {
    if (!voiceSpeakerId) return "未绑定音色"
    if (voiceSpeakerId === CUSTOM_VOICE_ID) {
      return selectedCustomAudio?.title?.trim() || String(material?.voiceSpeakerName ?? "").trim() || "自定义音色"
    }
    return speakers.find((speaker) => speaker.id === voiceSpeakerId)?.name ?? "未绑定音色"
  }, [material?.voiceSpeakerName, selectedCustomAudio?.title, speakers, voiceSpeakerId])
  const voiceStatusLabel = voiceSelectionLabel || "未绑定音色"

  // 提取绑定的音色信息；样音地址统一从音色表返回的数据中获取
  const boundVoice = useMemo(() => {
    if (!material) return null
    if (material.voiceSpeakerId) {
      const matchedAudio = audioMaterials.find((audio) => audio.assetId === material.voiceSpeakerId) ?? null
      const matchedSpeaker = speakers.find((s) => s.id === material.voiceSpeakerId) ?? null
      return {
        speakerId: material.voiceSpeakerId,
        speakerName: material.voiceSpeakerName || matchedAudio?.title || matchedSpeaker?.name || null,
        src: matchedAudio?.sourceUrl || matchedSpeaker?.sampleUrl || null
      }
    }
    // 兼容老数据
    const meta = material.metadata as any
    if (meta?.voiceSpeakerId) {
      const matchedAudio = audioMaterials.find((audio) => audio.assetId === meta.voiceSpeakerId) ?? null
      const matchedSpeaker = speakers.find((s) => s.id === meta.voiceSpeakerId) ?? null
      return {
        speakerId: meta.voiceSpeakerId,
        speakerName: meta.voiceSpeakerName || matchedAudio?.title || matchedSpeaker?.name || null,
        src: matchedAudio?.sourceUrl || matchedSpeaker?.sampleUrl || null
      }
    }
    return null
  }, [audioMaterials, material, speakers])

  useEffect(() => {
    if (!material || material.materialType !== "character") return
    let cancelled = false
    void (async () => {
      try {
        const list = await fetchSpeakerList()
        if (!cancelled) setSpeakers(list)
      } catch {
        if (!cancelled) setSpeakers([])
      }
    })()
    return () => { cancelled = true }
  }, [material])

  useEffect(() => {
    if (!material) {
      setVoicePreview(null)
      setVoiceSpeakerId("")
      setCustomAudioId("")
      setSpeakerSearch("")
      setSpeakerMenuOpen(false)
      return
    }

    // 仅在切换素材时清空试听态，避免刷新音色列表后把刚加载出来的播放器立刻卸载。
    setVoicePreview(null)
    setSpeakerSearch("")
    setSpeakerMenuOpen(false)
  }, [material?.id])

  useEffect(() => {
    if (!material) return

    const rawVoiceId = String(boundVoice?.speakerId ?? "").trim()
    const isTtsSpeaker = rawVoiceId && speakers.some((speaker) => speaker.id === rawVoiceId)
    if (isTtsSpeaker) {
      setVoiceSpeakerId(rawVoiceId)
      setCustomAudioId("")
      return
    }
    if (rawVoiceId.startsWith("asset-")) {
      setVoiceSpeakerId(CUSTOM_VOICE_ID)
      const matchedAudio = audioMaterials.find((audio) => audio.assetId === rawVoiceId) ?? null
      setCustomAudioId(matchedAudio?.id ?? "")
      return
    }
    setVoiceSpeakerId("")
    setCustomAudioId("")
  }, [audioMaterials, boundVoice?.speakerId, material, speakers])

  useEffect(() => {
    if (voiceSpeakerId !== CUSTOM_VOICE_ID) return
    if (customAudioId) return
    if (audioMaterials.length === 0) return
    const preferred = audioMaterials.find((audio) => String(audio.assetId ?? "").trim()) ?? audioMaterials[0]
    setCustomAudioId(preferred?.id ?? "")
  }, [audioMaterials, customAudioId, voiceSpeakerId])

  useEffect(() => {
    if (!voicePreview?.src) return
    const audio = previewAudioRef.current
    if (!audio) return
    void audio.play().catch(() => {
      alert("样音已加载，但浏览器未自动播放，请点击播放器播放。")
    })
  }, [voicePreview?.src])

  useEffect(() => {
    if (!speakerMenuOpen) return
    const updateDropdownPosition = () => {
      const trigger = voiceTriggerRef.current
      if (!trigger) return
      const rect = trigger.getBoundingClientRect()
      const width = Math.max(Math.ceil(rect.width), VOICE_DROPDOWN_WIDTH)
      const viewportWidth = window.innerWidth
      const viewportHeight = window.innerHeight
      const left = Math.max(12, Math.min(rect.left, viewportWidth - width - 12))
      const top = rect.bottom + VOICE_DROPDOWN_GAP
      const maxHeight = Math.max(180, viewportHeight - top - 12)
      setVoiceDropdownPosition({ left, top, width, maxHeight })
    }

    updateDropdownPosition()
    const timer = window.setTimeout(() => {
      voiceSearchInputRef.current?.focus()
    }, 0)
    window.addEventListener("resize", updateDropdownPosition)
    window.addEventListener("scroll", updateDropdownPosition, true)
    return () => {
      window.clearTimeout(timer)
      window.removeEventListener("resize", updateDropdownPosition)
      window.removeEventListener("scroll", updateDropdownPosition, true)
    }
  }, [speakerMenuOpen])

  const requestVoicePreview = useCallback(async () => {
    if (!voiceSpeakerId.trim()) return
    if (voiceSpeakerId === CUSTOM_VOICE_ID) {
      if (!selectedCustomAudio?.sourceUrl) return
      setVoicePreview({ name: `${selectedCustomAudio.title}（试听）`, src: selectedCustomAudio.sourceUrl })
      return
    }
    try {
      const freshSpeakers = await fetchSpeakerList()
      setSpeakers(freshSpeakers)
      const matchedSpeaker = freshSpeakers.find((speaker) => speaker.id === voiceSpeakerId.trim()) ?? null
      if (!matchedSpeaker?.sampleUrl) {
        alert("该音色尚未生成试听语音，请先进行音色初始化。")
        return
      }
      setVoicePreview({ name: `${matchedSpeaker.name}（试听）`, src: matchedSpeaker.sampleUrl })
    } catch (e: any) {
      alert(e?.message || "获取试听语音失败")
    }
  }, [selectedCustomAudio?.sourceUrl, selectedCustomAudio?.title, voiceSpeakerId])

  const bindVoice = useCallback(async () => {
    if (!material) return
    const sid = voiceSpeakerId.trim()

    setVoiceBinding(true)
    try {
      if (sid === CUSTOM_VOICE_ID) {
        const assetId = String(selectedCustomAudio?.assetId ?? "").trim()
        const audioTitle = String(selectedCustomAudio?.title ?? "").trim()
        if (!assetId) {
          alert("自定义音色选择的音频素材缺少 assetId，请先为该音频填写/生成 assetId 后再绑定。")
          return
        }
        await batchUpdateQuickGenerateMaterials([
          {
            id: material.id,
            voiceSpeakerId: assetId,
            voiceSpeakerName: audioTitle || "自定义音色"
          }
        ])
      } else if (!sid) {
        await batchUpdateQuickGenerateMaterials([
          {
            id: material.id,
            voiceSpeakerId: null,
            voiceSpeakerName: null
          }
        ])
      } else {
        if (!selectedSpeaker) return
        await batchUpdateQuickGenerateMaterials([
          {
            id: material.id,
            voiceSpeakerId: sid,
            voiceSpeakerName: selectedSpeaker.name
          }
        ])
      }
      
      alert("绑定成功")
      router.refresh()
    } catch (e: any) {
      alert(e.message || "绑定失败")
    } finally {
      setVoiceBinding(false)
    }
  }, [material, router, selectedCustomAudio?.assetId, selectedCustomAudio?.title, selectedSpeaker, voiceSpeakerId])

  const handleVoiceSelectionChange = useCallback((next: string) => {
    setVoiceSpeakerId(next)
    setSpeakerMenuOpen(false)
    setSpeakerSearch("")
  }, [])

  useEffect(() => {
    if (!material) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [material, onClose])

  useEffect(() => {
    if (!material) return
    const timer = window.setTimeout(() => {
      const overlay = document.querySelector<HTMLElement>(`.${styles.overlay}`)
      const dialog = document.querySelector<HTMLElement>(`.${styles.dialog}`)
      const previewArea = document.querySelector<HTMLElement>(`.${styles.previewArea}`)
      const mediaImage = document.querySelector<HTMLElement>(`.${styles.mediaImage}`)
      const overlayComputed = overlay ? window.getComputedStyle(overlay) : null
      const dialogComputed = dialog ? window.getComputedStyle(dialog) : null
      const previewComputed = previewArea ? window.getComputedStyle(previewArea) : null
      const mediaComputed = mediaImage ? window.getComputedStyle(mediaImage) : null
      const dialogRect = dialog?.getBoundingClientRect()
      const previewRect = previewArea?.getBoundingClientRect()
      const dialogCenter = dialogRect ? { x: Math.round(dialogRect.left + dialogRect.width / 2), y: Math.round(dialogRect.top + dialogRect.height / 2) } : null
      const previewCenter = previewRect ? { x: Math.round(previewRect.left + previewRect.width / 2), y: Math.round(previewRect.top + previewRect.height / 2) } : null
      const dialogHit = dialogCenter ? document.elementFromPoint(dialogCenter.x, dialogCenter.y) : null
      const previewHit = previewCenter ? document.elementFromPoint(previewCenter.x, previewCenter.y) : null
      const previewStack = previewCenter
        ? document.elementsFromPoint(previewCenter.x, previewCenter.y).slice(0, 8).map((el) => ({
            tagName: el.tagName,
            className: (el as HTMLElement).className ?? null,
          }))
        : []

      // #region debug-point D:overlay-layer-inspect
      // fetch("http://127.0.0.1:7777/event", {
      //   method: "POST",
      //   headers: { "Content-Type": "application/json" },
      //   body: JSON.stringify({
      //     sessionId: "quick-generate-upload-overlay-blur-20260416",
      //     runId: "pre-fix",
      //     hypothesisId: "D",
      //     location: "QuickGenerateMaterialDetailDialog",
      //     msg: "[DEBUG] material detail overlay layer inspection",
      //     data: {
      //       materialId: material.id,
      //       materialType: material.materialType,
      //       overlay: overlay
      //         ? {
      //             className: overlay.className,
      //             zIndex: overlayComputed?.zIndex ?? null,
      //             position: overlayComputed?.position ?? null,
      //             backdropFilter: overlayComputed?.backdropFilter ?? null,
      //             webkitBackdropFilter: overlayComputed?.getPropertyValue("-webkit-backdrop-filter") ?? null,
      //             backgroundColor: overlayComputed?.backgroundColor ?? null,
      //           }
      //         : null,
      //       dialog: dialog
      //         ? {
      //             className: dialog.className,
      //             zIndex: dialogComputed?.zIndex ?? null,
      //             position: dialogComputed?.position ?? null,
      //             transform: dialogComputed?.transform ?? null,
      //             isolation: dialogComputed?.isolation ?? null,
      //             backdropFilter: dialogComputed?.backdropFilter ?? null,
      //             backgroundColor: dialogComputed?.backgroundColor ?? null,
      //             filter: dialogComputed?.filter ?? null,
      //           }
      //         : null,
      //       previewArea: previewArea
      //         ? {
      //             className: previewArea.className,
      //             zIndex: previewComputed?.zIndex ?? null,
      //             position: previewComputed?.position ?? null,
      //             isolation: previewComputed?.isolation ?? null,
      //             backgroundColor: previewComputed?.backgroundColor ?? null,
      //             filter: previewComputed?.filter ?? null,
      //           }
      //         : null,
      //       mediaImage: mediaImage
      //         ? {
      //             className: mediaImage.className,
      //             zIndex: mediaComputed?.zIndex ?? null,
      //             position: mediaComputed?.position ?? null,
      //             opacity: mediaComputed?.opacity ?? null,
      //             filter: mediaComputed?.filter ?? null,
      //           }
      //         : null,
      //       dialogCenter,
      //       previewCenter,
      //       dialogHit: dialogHit
      //         ? { tagName: dialogHit.tagName, className: (dialogHit as HTMLElement).className ?? null }
      //         : null,
      //       previewHit: previewHit
      //         ? { tagName: previewHit.tagName, className: (previewHit as HTMLElement).className ?? null }
      //         : null,
      //       previewStack,
      //     },
      //     ts: Date.now(),
      //   }),
      // }).catch(() => {})
      // #endregion
    }, 180)
    return () => window.clearTimeout(timer)
  }, [material])

  if (!material) return null

  const isImage = material.materialType === "scene" || material.materialType === "character" || material.materialType === "prop"

  const content = (
    <>
      <div className={styles.overlay} onClick={onClose} />
      <div className={styles.dialog} role="dialog" aria-modal="true" aria-label={material.title || "素材详情"}>
        <button type="button" className={styles.customCloseBtn} onClick={onClose} aria-label="关闭">
          <X size={18} strokeWidth={2.5} />
        </button>
        <div className={styles.header}>
          <div className={styles.title}>{material.title || "素材详情"}</div>
        </div>

        <div className={styles.body}>
          <div className={styles.previewArea}>
            {material.materialType === "video" && material.sourceUrl ? (
              <video src={material.sourceUrl} controls className={styles.media} />
            ) : material.materialType === "audio" && material.sourceUrl ? (
              <audio src={material.sourceUrl} controls className={styles.mediaAudio} />
            ) : isImage && material.sourceUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={material.sourceUrl} alt={material.title || ""} className={styles.mediaImage} />
            ) : (
              <div className={styles.placeholder}>不支持预览</div>
            )}
          </div>

          {material.materialType === "character" && (
            <div className={styles.voicePanel}>
              <div className={styles.voiceTitle}>人物音色绑定</div>
              <div className={styles.voiceRow}>
                <div className={styles.voiceSelectWrap}>
                  <button
                    ref={voiceTriggerRef}
                    type="button"
                    className={styles.voiceSelect}
                    aria-label="选择音色"
                    aria-haspopup="listbox"
                    aria-expanded={speakerMenuOpen}
                    onClick={() => {
                      if (speakers.length === 0) return
                      setSpeakerMenuOpen((open) => {
                        const nextOpen = !open
                        if (!nextOpen) setSpeakerSearch("")
                        return nextOpen
                      })
                    }}
                    disabled={false}
                  >
                    <span className={styles.voiceSelectLabel}>{voiceSelectionLabel}</span>
                    <span className={styles.voiceSelectArrow}>{speakerMenuOpen ? "▴" : "▾"}</span>
                  </button>
                </div>
                <div className={styles.voiceActions}>
                  <button
                    type="button"
                    className={styles.btnSecondary}
                    onClick={() => void requestVoicePreview()}
                    disabled={!voiceSpeakerId || (voiceSpeakerId === CUSTOM_VOICE_ID && !selectedCustomAudio?.sourceUrl)}
                  >
                    试听
                  </button>
                  <button
                    type="button"
                    className={styles.btnPrimary}
                    onClick={() => void bindVoice()}
                    disabled={voiceBinding || (voiceSpeakerId === CUSTOM_VOICE_ID && audioMaterials.length === 0)}
                  >
                    {voiceBinding ? "绑定中…" : "绑定"}
                  </button>
                </div>
              </div>
              {voiceSpeakerId === CUSTOM_VOICE_ID && (
                <div className={styles.voiceRow}>
                  <div className={styles.voiceSelectWrap}>
                    <select
                      className={styles.voiceCustomSelect}
                      value={customAudioId}
                      onChange={(e) => {
                        setCustomAudioId(e.target.value)
                      }}
                      disabled={voiceBinding || audioMaterials.length === 0}
                    >
                      {audioMaterials.length === 0 ? (
                        <option value="">暂无音频素材</option>
                      ) : (
                        audioMaterials.map((audio) => {
                          const hasAssetId = Boolean(String(audio.assetId ?? "").trim())
                          const label = hasAssetId ? audio.title : `${audio.title}（无assetId）`
                          return (
                            <option key={audio.id} value={audio.id}>
                              {label}
                            </option>
                          )
                        })
                      )}
                    </select>
                  </div>
                  {selectedCustomAudio?.sourceUrl ? (
                    <button
                      type="button"
                      className={styles.btnSecondary}
                      onClick={() => {
                        setVoicePreview({ name: `${selectedCustomAudio.title}（试听）`, src: selectedCustomAudio.sourceUrl })
                      }}
                      disabled={voiceBinding}
                    >
                      试听
                    </button>
                  ) : null}
                </div>
              )}
              <div className={styles.voiceMeta}>当前绑定：{boundVoice?.speakerName || "未绑定"}</div>
              {(voicePreview?.src || boundVoice?.src) && (
                <audio
                  ref={previewAudioRef}
                  key={voicePreview?.src || boundVoice?.src}
                  src={voicePreview?.src || boundVoice?.src || undefined}
                  controls
                  className={styles.voiceAudioPlayer}
                  autoPlay={!!voicePreview?.src}
                  onError={() => {
                    alert("该音色样音文件当前不可访问，请重新初始化音色后再试。")
                  }}
                />
              )}
            </div>
          )}
        </div>
      </div>
      {speakerMenuOpen && voiceDropdownPosition && createPortal(
        <>
          <button
            type="button"
            className={styles.voiceDropdownOverlay}
            aria-label="关闭音色菜单"
            onClick={() => {
              setSpeakerMenuOpen(false)
              setSpeakerSearch("")
            }}
          />
          <div
            ref={voiceDropdownRef}
            className={styles.voiceDropdown}
            style={{
              left: `${voiceDropdownPosition.left}px`,
              top: `${voiceDropdownPosition.top}px`,
              width: `${voiceDropdownPosition.width}px`,
              maxHeight: `${voiceDropdownPosition.maxHeight}px`
            }}
            role="listbox"
            aria-label="选择音色"
          >
            <div className={styles.voiceDropdownSticky}>
              <div className={`${styles.voiceOption} ${styles.voiceOptionActive}`}>
                {voiceStatusLabel}
              </div>
              <button
                type="button"
                className={`${styles.voiceOption} ${voiceSpeakerId === CUSTOM_VOICE_ID ? styles.voiceOptionActive : ""}`}
                onClick={() => handleVoiceSelectionChange(CUSTOM_VOICE_ID)}
              >
                自定义音色
              </button>
              <div className={styles.voiceSearchRow}>
                <input
                  ref={voiceSearchInputRef}
                  type="text"
                  className={styles.voiceSearchInput}
                  value={speakerSearch}
                  onChange={(e) => setSpeakerSearch(e.target.value)}
                  placeholder="按音色名称搜索"
                />
              </div>
            </div>
            <div className={styles.voiceDropdownList}>
              {filteredSpeakers.length === 0 ? (
                <div className={styles.voiceDropdownEmpty}>暂无匹配音色</div>
              ) : (
                filteredSpeakers.map((speaker) => (
                  <button
                    key={speaker.id}
                    type="button"
                    className={`${styles.voiceOption} ${voiceSpeakerId === speaker.id ? styles.voiceOptionActive : ""}`}
                    onClick={() => handleVoiceSelectionChange(speaker.id)}
                  >
                    {speaker.name}
                  </button>
                ))
              )}
            </div>
          </div>
        </>,
        document.body
      )}
    </>
  )

  if (typeof document === "undefined") return null
  return createPortal(content, document.body)
}
