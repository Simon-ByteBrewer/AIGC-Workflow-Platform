"use client"

import type { ReactElement } from "react"
import styles from "./GroupsPage.module.css"

type GroupAuditCapabilityConfigModalProps = {
  groupName: string
  loading: boolean
  saving: boolean
  accessKeyDraft: string
  secretKeyDraft: string
  projectNameDraft: string
  secretKeyConfigured: boolean
  onAccessKeyChange: (value: string) => void
  onSecretKeyChange: (value: string) => void
  onProjectNameChange: (value: string) => void
  onClose: () => void
  onSave: () => void
}

/**
 * 组级审核能力配置弹窗。
 * SK 不回显明文；已配置时允许留空，表示保持现有值不变。
 */
export function GroupAuditCapabilityConfigModal(props: GroupAuditCapabilityConfigModalProps): ReactElement {
  const canSave = Boolean(props.accessKeyDraft.trim() && props.projectNameDraft.trim() && (props.secretKeyDraft.trim() || props.secretKeyConfigured))

  return (
    <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="审核能力配置" onMouseDown={props.onClose}>
      <div className={styles.modal} onMouseDown={(event) => event.stopPropagation()}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>审核能力配置：{props.groupName}</div>
          <button type="button" className={styles.modalClose} onClick={props.onClose} aria-label="关闭">
            ×
          </button>
        </div>
        <div className={styles.modalBody}>
          <div className={styles.groupHint}>为当前用户组维护审核能力凭证。SK 不会回显明文；如已配置，留空表示保持不变。</div>
          {props.loading ? (
            <div className={styles.muted}>加载中…</div>
          ) : (
            <>
              <label className={styles.field}>
                <div className={styles.label}>AK</div>
                <input
                  className={styles.input}
                  value={props.accessKeyDraft}
                  onChange={(event) => props.onAccessKeyChange(event.target.value)}
                  placeholder="请输入 AK"
                />
              </label>
              <label className={styles.field}>
                <div className={styles.label}>SK</div>
                <input
                  type="password"
                  className={styles.input}
                  value={props.secretKeyDraft}
                  onChange={(event) => props.onSecretKeyChange(event.target.value)}
                  placeholder={props.secretKeyConfigured ? "已配置，留空表示不修改" : "请输入 SK"}
                />
              </label>
              <label className={styles.field}>
                <div className={styles.label}>项目名称</div>
                <input
                  className={styles.input}
                  value={props.projectNameDraft}
                  onChange={(event) => props.onProjectNameChange(event.target.value)}
                  placeholder="请输入项目名称"
                />
              </label>
            </>
          )}
          <div className={styles.modalActions}>
            <button type="button" className={styles.topBtn} onClick={props.onClose} disabled={props.saving}>
              取消
            </button>
            <button type="button" className={styles.topBtnPrimary} onClick={props.onSave} disabled={props.loading || props.saving || !canSave}>
              {props.saving ? "保存中…" : "保存并关闭"}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
