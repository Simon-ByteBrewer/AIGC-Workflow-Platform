"use client"

import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import { X } from "lucide-react"
import styles from "./UploadResourceModal.module.css"
import { getMediaDurationMsFromFile } from "@/shared/utils/mediaDuration"

export type ResourceType = 'character' | 'background' | 'props' | 'audio' | 'music' | 'effect' | 'transition' | 'video'

export type UploadProgress = {
  loaded: number
  total: number
  percent: number | null
}

type VariantInput = {
  id: string
  text: string
  tags: string
}

interface UploadResourceModalProps {
  open: boolean
  onClose: () => void
  onUpload: (
    data: FormData,
    opts?: { onProgress?: (p: UploadProgress) => void; onAbort?: (abort: () => void) => void }
  ) => Promise<{ id?: string | null; url?: string | null; storageKey?: string | null } | void>
  onAiGenerate?: (input: {
    file: File
    characterName: string
    characterDescription?: string
    lookItems: Array<{ id: string; text: string; tags: string }>
    costumeItems: Array<{ id: string; text: string; tags: string }>
  }) => Promise<void>
}

export function UploadResourceModal({ open, onClose, onUpload, onAiGenerate }: UploadResourceModalProps): ReactElement | null {
  const [file, setFile] = useState<File | null>(null)
  const [type, setType] = useState<ResourceType>('character')
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [tags, setTags] = useState('')
  const [scenes, setScenes] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [progressPercent, setProgressPercent] = useState<number | null>(null)
  const abortRef = useRef<(() => void) | null>(null)
  const [bulkSubmitting, setBulkSubmitting] = useState(false)
  const [aiError, setAiError] = useState<string | null>(null)
  const [itemSubmittingById, setItemSubmittingById] = useState<Record<string, boolean>>({})
  const [individualExtracted, setIndividualExtracted] = useState(false)
  const [lookItems, setLookItems] = useState<VariantInput[]>([])
  const [costumeItems, setCostumeItems] = useState<VariantInput[]>([])

  const canSubmit = useMemo(() => file != null && !submitting, [file, submitting])
  const accept = useMemo(() => {
    if (type === "audio" || type === "music" || type === "effect") return "audio/*"
    if (type === "video" || type === "transition") return "video/*"
    return "image/*"
  }, [type])
  const isCharacterType = type === "character"
  const canAiBase = Boolean(file && name.trim())
  const allLookReady = lookItems.length > 0 && lookItems.every((it) => it.text.trim() && it.tags.trim())
  const allCostumeReady = costumeItems.length > 0 && costumeItems.every((it) => it.text.trim() && it.tags.trim())
  const canAiGenerate = isCharacterType && canAiBase && allLookReady && allCostumeReady && !bulkSubmitting && !submitting

  const createVariantInput = useCallback((): VariantInput => {
    const id =
      typeof globalThis.crypto?.randomUUID === "function"
        ? globalThis.crypto.randomUUID()
        : `variant_${Date.now()}_${Math.random().toString(16).slice(2)}`
    return { id, text: "", tags: "" }
  }, [])

  useEffect(() => {
    if (!open) return
    setLookItems([createVariantInput()])
    setCostumeItems([createVariantInput()])
    setItemSubmittingById({})
    setIndividualExtracted(false)
    setAiError(null)
  }, [createVariantInput, open])

  useEffect(() => {
    if (!open) return
    setAiError(null)
    setItemSubmittingById({})
    setIndividualExtracted(false)
  }, [open, type])

  const handleSubmit = async () => {
    if (!file) return
    
    try {
      setSubmitting(true)
      setError(null)
      setProgressPercent(0)
      abortRef.current = null
      
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', type)
      if (name.trim()) fd.append('name', name.trim())
      if (description.trim()) fd.append('description', description.trim())
      if (tags.trim()) fd.append('tags', tags.trim())
      if (scenes.trim()) fd.append('applicableScenes', scenes.trim())

      const mediaKind = type === "audio" || type === "music" || type === "effect" ? "audio" : type === "video" || type === "transition" ? "video" : null
      if (mediaKind) {
        const durationMs = await getMediaDurationMsFromFile(file, mediaKind)
        if (typeof durationMs === "number") fd.append("durationMs", String(durationMs))
      }

      await onUpload(fd, {
        onProgress: (p) => setProgressPercent(p.percent),
        onAbort: (abort) => {
          abortRef.current = abort
        }
      })
      
      // Reset form
      setFile(null)
      setName('')
      setDescription('')
      setTags('')
      setScenes('')
      setProgressPercent(null)
      onClose()
    } catch (e) {
      setError(e instanceof Error ? e.message : '上传失败')
      setProgressPercent(null)
    } finally {
      setSubmitting(false)
    }
  }

  const submitAiGenerate = async (input: { lookItems: VariantInput[]; costumeItems: VariantInput[]; itemId?: string }) => {
    if (!file) return
    const characterName = name.trim()
    if (!characterName) {
      setAiError("请输入人物姓名")
      return
    }
    const filteredLooks = input.lookItems.map((it) => ({ ...it, text: it.text.trim(), tags: it.tags.trim() }))
    const filteredCostumes = input.costumeItems.map((it) => ({ ...it, text: it.text.trim(), tags: it.tags.trim() }))
    const anyMissing =
      filteredLooks.some((it) => !it.text || !it.tags) || filteredCostumes.some((it) => !it.text || !it.tags)
    if (anyMissing) {
      setAiError("妆造与服装的描述、标签均为必填")
      return
    }
    if (typeof input.itemId === "string") {
      setItemSubmittingById((prev) => ({ ...prev, [input.itemId as string]: true }))
    } else {
      setBulkSubmitting(true)
    }
    setAiError(null)
    try {
      if (!onAiGenerate) throw new Error("当前版本暂不支持 AI 生成")
      await onAiGenerate({
        file,
        characterName,
        characterDescription: description.trim() ? description.trim() : undefined,
        lookItems: filteredLooks,
        costumeItems: filteredCostumes
      })
      setFile(null)
      setName("")
      setDescription("")
      setLookItems([createVariantInput()])
      setCostumeItems([createVariantInput()])
      setIndividualExtracted(false)
      onClose()
    } catch (e) {
      setAiError(e instanceof Error ? e.message : "生成失败")
    } finally {
      if (typeof input.itemId === "string") {
        setItemSubmittingById((prev) => ({ ...prev, [input.itemId as string]: false }))
      } else {
        setBulkSubmitting(false)
      }
    }
  }

  const updateLookItem = useCallback((id: string, patch: Partial<VariantInput>) => {
    setLookItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)))
  }, [])

  const updateCostumeItem = useCallback((id: string, patch: Partial<VariantInput>) => {
    setCostumeItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)))
  }, [])

  const addLookItem = useCallback(() => {
    setLookItems((prev) => [...prev, createVariantInput()])
  }, [createVariantInput])

  const addCostumeItem = useCallback(() => {
    setCostumeItems((prev) => [...prev, createVariantInput()])
  }, [createVariantInput])

  const removeLookItem = useCallback((id: string) => {
    setLookItems((prev) => prev.filter((it) => it.id !== id))
  }, [])

  const removeCostumeItem = useCallback((id: string) => {
    setCostumeItems((prev) => prev.filter((it) => it.id !== id))
  }, [])

  if (!open) return null

  return (
    <>
      <div className={styles.overlay} onClick={() => (submitting ? undefined : onClose())} />
      <div className={styles.modal}>
        <div className={styles.header}>
          <div className={styles.title}>上传公共资源</div>
          <button
            type="button"
            className={styles.closeBtn}
            onClick={() => {
              if (submitting) abortRef.current?.()
              else onClose()
            }}
          >
            <X size={20} />
          </button>
        </div>

        <div className={styles.body}>
          <div className={styles.row}>
            <div className={styles.field}>
              <label className={styles.label}>资源类型</label>
              <select 
                className={styles.select}
                value={type}
                onChange={(e) => setType(e.target.value as ResourceType)}
              >
                <option value="character">角色库</option>
                <option value="background">场景库</option>
                <option value="props">物品库</option>
                <option value="audio">音频库</option>
                <option value="music">音乐库</option>
                <option value="effect">音效库</option>
                <option value="video">视频库</option>
                <option value="transition">转场库</option>
              </select>
            </div>
            <div className={styles.field}>
              <label className={styles.label}>文件</label>
              <input 
                type="file" 
                className={styles.fileInput}
                accept={accept}
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                disabled={submitting}
              />
            </div>
          </div>

          {isCharacterType ? (
            <div className={styles.row}>
              <div className={styles.field}>
                <label className={styles.label}>人物姓名</label>
                <input
                  type="text"
                  className={styles.input}
                  placeholder="必填"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={submitting || bulkSubmitting}
                />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>人物描述</label>
                <input
                  type="text"
                  className={styles.input}
                  placeholder="可选"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={submitting || bulkSubmitting}
                />
              </div>
            </div>
          ) : (
            <>
              <div className={styles.row}>
                <div className={styles.field}>
                  <label className={styles.label}>名称</label>
                  <input 
                    type="text" 
                    className={styles.input}
                    placeholder="可选"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    disabled={submitting}
                  />
                </div>
                <div className={styles.field}>
                  <label className={styles.label}>标签</label>
                  <input 
                    type="text" 
                    className={styles.input}
                    placeholder="逗号分隔，如：商务,正式"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    disabled={submitting}
                  />
                </div>
              </div>

              <div className={styles.field}>
                <label className={styles.label}>描述</label>
                <input 
                  type="text" 
                  className={styles.input}
                  placeholder="可选"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={submitting}
                />
              </div>

              <div className={styles.field}>
                <label className={styles.label}>适用场景</label>
                <input 
                  type="text" 
                  className={styles.input}
                  placeholder="逗号分隔，如：广告,宣传片"
                  value={scenes}
                  onChange={(e) => setScenes(e.target.value)}
                  disabled={submitting}
                />
              </div>
            </>
          )}

          {isCharacterType ? (
            <div className={styles.aiSection}>
              <div className={styles.sectionHeader}>
                <div className={styles.sectionTitle}>妆造</div>
                <button type="button" className={styles.addBtn} onClick={addLookItem} disabled={bulkSubmitting || submitting}>
                  + 添加妆造
                </button>
              </div>
              <div className={styles.variantList}>
                {lookItems.map((it, idx) => {
                  const loading = Boolean(itemSubmittingById[it.id])
                  const canSingle =
                    canAiBase &&
                    it.text.trim().length > 0 &&
                    it.tags.trim().length > 0 &&
                    !bulkSubmitting &&
                    !submitting &&
                    !loading
                  const canRemove = lookItems.length > 1 && !bulkSubmitting && !submitting && !loading
                  return (
                    <div key={it.id} className={styles.variantCard}>
                      <div className={styles.variantTitle}>妆造 {idx + 1}</div>
                      <div className={styles.variantInputs}>
                        <input
                          className={styles.input}
                          placeholder="标签（必填）"
                          value={it.tags}
                          onChange={(e) => updateLookItem(it.id, { tags: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                        <input
                          className={styles.input}
                          placeholder="描述（必填）"
                          value={it.text}
                          onChange={(e) => updateLookItem(it.id, { text: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                      </div>
                      <div className={styles.variantActions}>
                        <button
                          type="button"
                          className={styles.removeBtn}
                          disabled={!canRemove}
                          onClick={() => removeLookItem(it.id)}
                        >
                          删除
                        </button>
                        <button
                          type="button"
                          className={styles.smallBtn}
                          disabled={!canSingle}
                          onClick={() => {
                            setIndividualExtracted(true)
                            void submitAiGenerate({
                              lookItems: [{ ...it }],
                              costumeItems: [],
                              itemId: it.id
                            })
                          }}
                        >
                          {loading ? "抽取中..." : "抽取"}
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className={styles.sectionHeader}>
                <div className={styles.sectionTitle}>服装</div>
                <button type="button" className={styles.addBtn} onClick={addCostumeItem} disabled={bulkSubmitting || submitting}>
                  + 添加服装
                </button>
              </div>
              <div className={styles.variantList}>
                {costumeItems.map((it, idx) => {
                  const loading = Boolean(itemSubmittingById[it.id])
                  const canSingle =
                    canAiBase &&
                    it.text.trim().length > 0 &&
                    it.tags.trim().length > 0 &&
                    !bulkSubmitting &&
                    !submitting &&
                    !loading
                  const canRemove = costumeItems.length > 1 && !bulkSubmitting && !submitting && !loading
                  return (
                    <div key={it.id} className={styles.variantCard}>
                      <div className={styles.variantTitle}>服装 {idx + 1}</div>
                      <div className={styles.variantInputs}>
                        <input
                          className={styles.input}
                          placeholder="标签（必填）"
                          value={it.tags}
                          onChange={(e) => updateCostumeItem(it.id, { tags: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                        <input
                          className={styles.input}
                          placeholder="描述（必填）"
                          value={it.text}
                          onChange={(e) => updateCostumeItem(it.id, { text: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                      </div>
                      <div className={styles.variantActions}>
                        <button
                          type="button"
                          className={styles.removeBtn}
                          disabled={!canRemove}
                          onClick={() => removeCostumeItem(it.id)}
                        >
                          删除
                        </button>
                        <button
                          type="button"
                          className={styles.smallBtn}
                          disabled={!canSingle}
                          onClick={() => {
                            setIndividualExtracted(true)
                            void submitAiGenerate({
                              lookItems: [],
                              costumeItems: [{ ...it }],
                              itemId: it.id
                            })
                          }}
                        >
                          {loading ? "抽取中..." : "抽取"}
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className={styles.aiActions}>
                <button
                  type="button"
                  className={styles.aiBtn}
                  disabled={!canAiGenerate || individualExtracted}
                  onClick={() => void submitAiGenerate({ lookItems, costumeItems })}
                >
                  {bulkSubmitting ? "生成中..." : "AI 生成"}
                </button>
                {individualExtracted ? <div className={styles.helperText}>已进行单项抽取，一键抽取已禁用</div> : null}
              </div>
              {aiError ? <div className={styles.error}>{aiError}</div> : null}
            </div>
          ) : null}

          {submitting ? (
            <div className={styles.progressBox}>
              <div className={styles.progressHeader}>
                <span>上传中</span>
                <span>{typeof progressPercent === "number" ? `${progressPercent}%` : ""}</span>
              </div>
              <div className={styles.progressTrack}>
                <div className={styles.progressFill} style={{ width: `${Math.max(0, Math.min(100, progressPercent ?? 0))}%` }} />
              </div>
            </div>
          ) : null}

          {error && <div className={styles.error}>{error}</div>}
        </div>

        <div className={styles.footer}>
          <button 
            type="button" 
            className={styles.cancelBtn} 
            onClick={() => {
              if (submitting) abortRef.current?.()
              else onClose()
            }}
          >
            {submitting ? '取消上传' : '取消'}
          </button>
          <button 
            type="button" 
            className={styles.submitBtn}
            disabled={!canSubmit}
            onClick={handleSubmit}
          >
            {submitting ? '上传中...' : '上传'}
          </button>
        </div>
      </div>
    </>
  )
}
