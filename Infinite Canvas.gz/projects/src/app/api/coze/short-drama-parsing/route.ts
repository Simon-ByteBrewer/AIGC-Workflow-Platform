import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { readEnv } from "@/features/coze/env"
import { callCozeRunEndpoint, CozeRunEndpointError } from "@/features/coze/runEndpointClient"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { getSessionFromRequest } from "@/shared/session"
import { enqueueShortDramaParsingJob, kickShortDramaParsingWorker } from "@/server/domains/short-drama/jobs/shortDramaParsingWorker"
import { updateStoryMetadata } from "@/server/domains/library/usecases/updateStoryMetadata"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  user_requirement: z.string().trim().min(1).max(200_000),
  async: z.boolean().optional()
})

export async function POST(req: Request): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()

  logger.info({
    event: "short_drama_parsing_start",
    module: "coze",
    traceId,
    message: "开始剧本解析"
  })

  let json: unknown
  try {
    json = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "COZE_INVALID_JSON", "请求体不是合法 JSON"), {
      status: 400
    })
  }

  const parsed = inputSchema.safeParse(json)
  if (!parsed.success) {
    logger.warn({
      event: "short_drama_parsing_validation_failed",
      module: "coze",
      traceId,
      message: "剧本解析入参校验失败"
    })
    return NextResponse.json(makeApiErr(traceId, "COZE_VALIDATION_FAILED", "入参格式不正确"), {
      status: 400
    })
  }

  const url = readEnv("SHORT_DRAMA_PARSING_API_URL")
  const token = readEnv("SHORT_DRAMA_PARSING_API_TOKEN")
  if (!url || !token) {
    return NextResponse.json(
      makeApiErr(
        traceId,
        "COZE_NOT_CONFIGURED",
        "Coze 未配置，请设置 SHORT_DRAMA_PARSING_API_URL 与 SHORT_DRAMA_PARSING_API_TOKEN"
      ),
      { status: 500 }
    )
  }

  try {
    const session = await getSessionFromRequest(req as unknown as NextRequest)
    const userId = session?.userId
    if (!userId) {
      return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), {
        status: 401
      })
    }

    const asyncMode = parsed.data.async ?? false
    if (asyncMode) {
      const { jobId, snapshot } = await enqueueShortDramaParsingJob({
        userId,
        traceId,
        storyId: parsed.data.storyId,
        user_requirement: parsed.data.user_requirement
      })
      kickShortDramaParsingWorker()
      logger.info({
        event: "short_drama_parsing_async_queued",
        module: "coze",
        traceId,
        message: "剧本解析任务已入队",
        jobId
      })
      return NextResponse.json(makeApiOk(traceId, { jobId, status: snapshot.status }), { status: 202 })
    }

    const coze = await callCozeRunEndpoint({
      traceId,
      url,
      token,
      body: { user_requirement: parsed.data.user_requirement },
      module: "coze_short_drama_parsing"
    })

    await updateStoryMetadata({
      userId,
      storyId: parsed.data.storyId,
      patch: {
        shortDrama: {
          planningResult: coze.data,
          planningConfirmedAt: Date.now(),
          setupSource: "script_body"
        }
      }
    })

    const durationMs = Date.now() - start
    logger.info({
      event: "short_drama_parsing_success",
      module: "coze",
      traceId,
      message: "剧本解析成功",
      durationMs,
      cozeStatus: coze.status
    })

    return NextResponse.json(makeApiOk(traceId, coze.data), { status: 200 })
  } catch (err) {
    const durationMs = Date.now() - start
    if (err instanceof CozeRunEndpointError) {
      logger.error({
        event: "short_drama_parsing_failed",
        module: "coze",
        traceId,
        message: "剧本解析失败（Coze 调用失败）",
        durationMs,
        status: err.status
      })
      return NextResponse.json(makeApiErr(traceId, "COZE_REQUEST_FAILED", "Coze 调用失败，请稍后重试"), { status: 502 })
    }

    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "short_drama_parsing_error",
      module: "coze",
      traceId,
      message: "剧本解析异常",
      durationMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })

    return NextResponse.json(makeApiErr(traceId, "COZE_UNKNOWN", "生成失败，请稍后重试"), {
      status: 500
    })
  }
}
