"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import type { BillingDetailsResponse, BillingFilter } from "@/shared/contracts/billing"
import { BillingDetailTable } from "./BillingDetailTable"
import { buildBillingSearchParams, type DetailsResponse, readApiJson, VIDEO_RESOLUTION_OPTIONS } from "./billingApi"
import { BillingModalShell } from "./BillingModalShell"
import { REFERENCE_MODE_OPTIONS } from "./billingPresentation"
import styles from "./BillingPage.module.css"

type BillingDetailsModalProps = {
  scopeType: "group" | "user"
  scopeId: string
  scopeName?: string | null
  initialFilter: BillingFilter
  onClose: () => void
}

/**
 * 团队/个人账单详情弹窗。
 * 说明：弹窗内维护独立筛选状态，方便在不影响总览列表的前提下定位单个任务消耗。
 */
export function BillingDetailsModal({ scopeType, scopeId, scopeName, initialFilter, onClose }: BillingDetailsModalProps) {
  const [from, setFrom] = useState(initialFilter.from ?? "")
  const [to, setTo] = useState(initialFilter.to ?? "")
  const [modelName, setModelName] = useState(initialFilter.modelName ?? "")
  const [referenceMode, setReferenceMode] = useState<BillingFilter["referenceMode"]>(initialFilter.referenceMode ?? "all")
  const [videoResolution, setVideoResolution] = useState<BillingFilter["videoResolution"]>(initialFilter.videoResolution)
  const [taskId, setTaskId] = useState("")
  const [videoTaskId, setVideoTaskId] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [detailData, setDetailData] = useState<BillingDetailsResponse | null>(null)

  const currentFilter = useMemo<BillingFilter>(
    () => ({
      from,
      to,
      groupId: initialFilter.groupId,
      userId: initialFilter.userId,
      modelName,
      taskId,
      videoTaskId,
      referenceMode,
      videoResolution
    }),
    [from, initialFilter.groupId, initialFilter.userId, modelName, referenceMode, taskId, to, videoResolution, videoTaskId]
  )

  const loadDetails = useCallback(async (filter: BillingFilter) => {
    setLoading(true)
    setError(null)
    try {
      const sp = new URLSearchParams(buildBillingSearchParams(filter))
      sp.set("scopeType", scopeType)
      sp.set("scopeId", scopeId)
      const res = await fetch(`/api/admin/billing/details?${sp.toString()}`)
      const json = await readApiJson<DetailsResponse>(res, "加载账单详情失败")
      if (!json.ok) throw new Error(json.error.message)
      setDetailData(json.data)
    } catch (e: any) {
      setError(e?.message ?? "加载账单详情失败")
    } finally {
      setLoading(false)
    }
  }, [scopeId, scopeType])

  function handleReset() {
    const resetFilter: BillingFilter = {
      from: initialFilter.from ?? "",
      to: initialFilter.to ?? "",
      groupId: initialFilter.groupId,
      userId: initialFilter.userId,
      modelName: initialFilter.modelName ?? "",
      referenceMode: initialFilter.referenceMode ?? "all",
      videoResolution: initialFilter.videoResolution,
      taskId: "",
      videoTaskId: ""
    }
    setFrom(resetFilter.from ?? "")
    setTo(resetFilter.to ?? "")
    setModelName(resetFilter.modelName ?? "")
    setReferenceMode(resetFilter.referenceMode ?? "all")
    setVideoResolution(resetFilter.videoResolution)
    setTaskId("")
    setVideoTaskId("")
    void loadDetails(resetFilter)
  }

  useEffect(() => {
    void loadDetails({
      from: initialFilter.from ?? "",
      to: initialFilter.to ?? "",
      groupId: initialFilter.groupId,
      userId: initialFilter.userId,
      modelName: initialFilter.modelName ?? "",
      taskId: "",
      videoTaskId: "",
      referenceMode: initialFilter.referenceMode ?? "all",
      videoResolution: initialFilter.videoResolution
    })
  }, [initialFilter.from, initialFilter.groupId, initialFilter.modelName, initialFilter.referenceMode, initialFilter.to, initialFilter.userId, initialFilter.videoResolution, loadDetails])

  const modalHint = loading
    ? "加载中..."
    : `日期范围 ${(from ?? "").trim() && (to ?? "").trim() ? `${from} - ${to}` : "全部日期"}，完成任务数 ${detailData?.completedTaskCount ?? 0}，花费 ${detailData?.totalCost ?? "0.0000"}`

  return (
    <BillingModalShell title={detailData?.scopeName ?? scopeName ?? "账单详情"} hint={modalHint} onClose={onClose}>
      <section className={styles.detailFilters}>
        <input type="date" className={styles.input} value={from} onChange={(e) => setFrom(e.target.value)} />
        <input type="date" className={styles.input} value={to} onChange={(e) => setTo(e.target.value)} />
        <input className={styles.input} value={taskId} onChange={(e) => setTaskId(e.target.value)} placeholder="任务 ID" />
        <input className={styles.input} value={videoTaskId} onChange={(e) => setVideoTaskId(e.target.value)} placeholder="task_id" />
        <input className={styles.input} value={modelName} onChange={(e) => setModelName(e.target.value)} placeholder="模型名称" />
        <select
          className={styles.input}
          value={referenceMode ?? "all"}
          onChange={(e) => setReferenceMode(e.target.value as BillingFilter["referenceMode"])}
        >
          {REFERENCE_MODE_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <select
          className={styles.input}
          value={videoResolution ?? "all"}
          onChange={(e) => setVideoResolution(e.target.value === "all" ? undefined : (e.target.value as BillingFilter["videoResolution"]))}
        >
          {VIDEO_RESOLUTION_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        <div className={styles.filterActions}>
          <button className={styles.btn} onClick={() => void loadDetails(currentFilter)} disabled={loading}>
            查询
          </button>
          <button className={styles.btnSecondary} onClick={handleReset} disabled={loading}>
            重置条件
          </button>
        </div>
      </section>

      {error ? <div className={styles.error}>{error}</div> : null}

      <BillingDetailTable items={detailData?.items ?? []} showEmpty={!loading} />
    </BillingModalShell>
  )
}
