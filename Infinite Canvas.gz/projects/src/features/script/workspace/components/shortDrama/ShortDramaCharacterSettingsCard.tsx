"use client"

import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent } from "react"
import { createPortal } from "react-dom"
import styles from "./ShortDramaCharacterSettingsCard.module.css"
import { patchStoryShortDramaMetadata, submitShortDramaRoleParsingTask } from "../../api/shortDrama"
import { Section, TextField, SmallField } from "./ShortDramaPlanningFields"
import { cloneJson, toText, unwrapCharacterSettings } from "./shortDramaPlanningModel"
import { RoleAssetDrawModal } from "@/features/script/workspace/components/shortDrama/RoleAssetDrawModal"
import { useActiveJobs } from "@/features/video/hooks/useActiveJobs"
import { SHORT_DRAMA_ROLE_IMAGE_DRAW_JOB_TYPE } from "@/shared/jobs/jobTypes"
import { toCozeStyle } from "@/shared/shotStyle"
import { openImagePreview } from "@/shared/ui/image-preview/store"
import { ConfirmModal } from "@/shared/ui/ConfirmModal"
import { useResolvedImageUrl } from "@/shared/hooks/useResolvedImageUrl"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"
import type { ImageModelKind, ImageModelListResponse, ImageModelOption } from "@/shared/contracts/imageModelAccess"
import { RoleImageModelDialog } from "@/features/script/workspace/components/shortDrama/RoleImageModelDialog"
import { readAcceptedJobIdFromStream } from "@/shared/readAcceptedJobIdFromStream"

type ShortDramaCharacterSettingsCardProps = Readonly<{
  storyId: string
  planningResult: any
  planningConfirmedAt?: number
  worldSetting: any
  characterSetting: any
  shotStyle?: string
  roleImageDraws?: any
  onSaved?: (nextCharacterSetting: any, nextRoleImageDraws?: any) => void
}>

type CharacterItem = Record<string, unknown>
type RoleImageDrawState = Record<
  string,
  {
    prompt: string
    imageUrls: string[]
    selectedUrl?: string
    selectedUrlBase?: string
    selectedAssetId?: string
    needsReselect?: boolean
    assetSelection?: {
      characterId?: string | null
      lookId?: string | null
      costumeId?: string | null
      lookIdByVariant?: Record<string, string>
      costumeIdByVariant?: Record<string, string>
      lookCandidateStorageKeysByVariant?: Record<string, string[]>
      costumeCandidateStorageKeysByVariant?: Record<string, string[]>
      selectedLookCandidateKeyByVariant?: Record<string, string>
      selectedCostumeCandidateKeyByVariant?: Record<string, string>
      activeDrawJobIds?: string[]
      selectedHairIndex?: number
      selectedClothingIndex?: number
      hairText?: string
      hairTagsText?: string
      clothingText?: string
      clothingTagsText?: string
      frontImageUrl?: string
    }
    assetSelectionByFrontImageUrl?: Record<string, any>
  }
>

type VariantSpecItem = {
  name: string
  description: string
  tags: string[]
}

type VoiceSpeaker = { id: string; name: string; sampleUrl: string | null; sampleText: string }
type PendingRoleImageAction = { scope: "all" | "current"; forceRegenerate: boolean }

function stripUrlQuery(input: string): string {
  const raw = String(input ?? "").trim()
  if (!raw) return ""
  if (raw.startsWith("data:")) return raw
  const q = raw.indexOf("?")
  const h = raw.indexOf("#")
  const cut = q >= 0 && h >= 0 ? Math.min(q, h) : q >= 0 ? q : h >= 0 ? h : -1
  return cut >= 0 ? raw.slice(0, cut) : raw
}

function toRoleAssetFileUrl(storageKey: string): string {
  return `/api/script/short-drama/role-assets/file?key=${encodeURIComponent(storageKey)}`
}

function toRoleVoiceFileUrl(storageKey: string): string {
  return `/api/script/short-drama/role-voices/file?key=${encodeURIComponent(storageKey)}`
}

function toCandidateSrc(candidate: string): string {
  const raw = String(candidate ?? "").trim()
  if (!raw) return ""
  if (raw.startsWith("public/short-drama/role-assets/")) return toRoleAssetFileUrl(raw)
  return raw
}

function toVoiceSrc(candidate: string): string {
  const raw = String(candidate ?? "").trim()
  if (!raw) return ""
  if (raw.startsWith("public/short-drama/role-voices/")) return toRoleVoiceFileUrl(raw)
  return raw
}

function ResolvedImageCard(props: {
  src: string
  alt: string
  active: boolean
  className: string
  imgClassName: string
  onPreview: (src: string) => void
  onSelect?: () => void
}) {
  const resolved = useResolvedImageUrl(props.src)
  const usable = resolved || props.src
  if (!usable) return null
  return (
    <div
      className={props.className}
      role="button"
      tabIndex={0}
      onClick={() => props.onPreview(usable)}
      onKeyDown={(e) => {
        if (e.key === "Enter") props.onPreview(usable)
      }}
    >
      <div className={styles.imageSelectBar}>
        <button
          type="button"
          className={props.active ? `${styles.imageSelectBadge} ${styles.imageSelectBadgeActive}` : styles.imageSelectBadge}
          aria-label={props.active ? "已选中" : "选中"}
          onClick={(e) => {
            e.stopPropagation()
            props.onSelect?.()
          }}
        >
          <span className={props.active ? `${styles.imageSelectDot} ${styles.imageSelectDotActive}` : styles.imageSelectDot} />
        </button>
      </div>
      <img className={props.imgClassName} alt={props.alt} src={usable} />
    </div>
  )
}

function ResolvedImageButton(props: { src: string; alt: string; className: string; onPreview: (src: string) => void }) {
  const resolved = useResolvedImageUrl(props.src)
  const usable = resolved || props.src
  if (!usable) return null
  return (
    <button type="button" className={props.className} onClick={() => props.onPreview(usable)}>
      <img src={usable} alt={props.alt} />
    </button>
  )
}

function extractNameFromPrompt(prompt: string): string {
  const first = String(prompt ?? "").split("\n")[0] ?? ""
  const m = first.match(/^姓名：(.+)$/u)
  return String(m?.[1] ?? "").trim()
}

function normalizeRoleImageDrawState(value: unknown): RoleImageDrawState {
  const base = value && typeof value === "object" ? (value as any) : {}
  const normalized: RoleImageDrawState = {}
  for (const [k, v] of Object.entries(base)) {
    if (!k) continue
    if (!v || typeof v !== "object") continue
    const prompt = typeof (v as any).prompt === "string" ? (v as any).prompt : ""
    const urlsRaw = (v as any).imageUrls ?? (v as any).image_urls
    const urls = Array.isArray(urlsRaw) ? urlsRaw : []
    const imageUrls = urls
      .map((u: any) => String(u ?? "").trim())
      .filter(
        (u: string) =>
          u.startsWith("http") || u.startsWith("data:") || u.startsWith("public/short-drama/role-assets/") || u.startsWith("/api/")
      )
      .slice(0, 10)
    const rawSelectedUrl = typeof (v as any).selectedUrl === "string" ? (v as any).selectedUrl.trim() : ""
    const rawSelectedUrlBase = typeof (v as any).selectedUrlBase === "string" ? (v as any).selectedUrlBase.trim() : ""
    const selectedBase = (rawSelectedUrlBase || stripUrlQuery(rawSelectedUrl)).trim()
    const selectedUrlBase = selectedBase || undefined
    const selectedUrl =
      selectedBase ? imageUrls.find((u) => stripUrlQuery(u) === selectedBase) ?? (rawSelectedUrl || undefined) : undefined
  const rawSelectedAssetId = typeof (v as any).selectedAssetId === "string" ? (v as any).selectedAssetId.trim() : (v as any).selectedUri ? String((v as any).selectedUri).trim() : ""
    const selectedAssetId = rawSelectedAssetId || undefined
    const needsReselect = Boolean((v as any).needsReselect) || Boolean((rawSelectedUrl || rawSelectedUrlBase) && !selectedUrl)
    const rawMap = (v as any).assetSelectionByFrontImageUrl
    const assetSelectionByFrontImageUrl =
      rawMap && typeof rawMap === "object" && !Array.isArray(rawMap)
        ? (Object.fromEntries(
            Object.entries(rawMap as any)
              .map(([k, val]) => [String(k ?? "").trim(), val])
              .filter(([k]) => Boolean(k))
          ) as Record<string, any>)
        : undefined
    const rawSel = (v as any).assetSelection
    const sel = rawSel && typeof rawSel === "object" ? rawSel : null
    const assetSelection = sel
      ? {
          characterId: typeof sel.characterId === "string" ? sel.characterId : null,
          lookId: typeof sel.lookId === "string" ? sel.lookId : null,
          costumeId: typeof sel.costumeId === "string" ? sel.costumeId : null,
          lookIdByVariant:
            sel.lookIdByVariant && typeof sel.lookIdByVariant === "object"
              ? (Object.fromEntries(
                  Object.entries(sel.lookIdByVariant as any)
                    .map(([k, val]) => [String(k ?? "").trim(), String(val ?? "").trim()])
                    .filter(([k, val]) => Boolean(k) && Boolean(val))
                ) as Record<string, string>)
              : undefined,
          costumeIdByVariant:
            sel.costumeIdByVariant && typeof sel.costumeIdByVariant === "object"
              ? (Object.fromEntries(
                  Object.entries(sel.costumeIdByVariant as any)
                    .map(([k, val]) => [String(k ?? "").trim(), String(val ?? "").trim()])
                    .filter(([k, val]) => Boolean(k) && Boolean(val))
                ) as Record<string, string>)
              : undefined,
          selectedHairIndex: Number.isFinite(sel.selectedHairIndex) ? Math.trunc(sel.selectedHairIndex) : undefined,
          selectedClothingIndex: Number.isFinite(sel.selectedClothingIndex) ? Math.trunc(sel.selectedClothingIndex) : undefined,
          hairText: typeof sel.hairText === "string" ? sel.hairText : undefined,
          hairTagsText: typeof sel.hairTagsText === "string" ? sel.hairTagsText : undefined,
          clothingText: typeof sel.clothingText === "string" ? sel.clothingText : undefined,
          clothingTagsText: typeof sel.clothingTagsText === "string" ? sel.clothingTagsText : undefined,
          frontImageUrl: typeof sel.frontImageUrl === "string" ? sel.frontImageUrl : undefined
        }
      : undefined
    normalized[k] = {
      prompt: String(prompt ?? ""),
      imageUrls,
      selectedUrl,
      selectedUrlBase,
      selectedAssetId,
      needsReselect,
      assetSelection,
      assetSelectionByFrontImageUrl
    }
    const nameKey = extractNameFromPrompt(prompt)
    if (nameKey && !normalized[nameKey]) normalized[nameKey] = normalized[k]!
  }
  return normalized
}

function normalizeVariantSpecs(value: unknown): VariantSpecItem[] | null {
  if (!Array.isArray(value)) return null
  const out: VariantSpecItem[] = []
  for (const raw of value) {
    if (!raw || typeof raw !== "object") continue
    const name = typeof (raw as any).name === "string" ? (raw as any).name.trim() : ""
    const description = typeof (raw as any).description === "string" ? (raw as any).description.trim() : ""
    const tagsRaw = (raw as any).tags
    const tags =
      Array.isArray(tagsRaw) ? tagsRaw.map((t) => String(t ?? "").trim()).filter(Boolean).slice(0, 20) : []
    if (!name && !description && tags.length === 0) continue
    out.push({ name, description, tags })
  }
  return out
}

function parseVariantSpecsFromText(raw: string): VariantSpecItem[] | null {
  const text = String(raw ?? "").trim()
  if (!text) return null
  const parts = text
    .split(/[\n；;]+/g)
    .map((x) => x.trim())
    .filter(Boolean)
    .slice(0, 20)
  const hasMulti = parts.length > 1
  const hasColon = parts.some((p) => /[:：]/.test(p))
  if (!hasMulti && !hasColon) return null

  const out: VariantSpecItem[] = []
  for (const p of parts) {
    const m = p.match(/^(.+?)[：:]\s*(.*)$/)
    const left = (m?.[1] ?? "").trim()
    let rest = (m?.[2] ?? p).trim()
    let tags: string[] = []
    const tagMatch = rest.match(/(?:（([^）]+)）|\(([^)]+)\))\s*$/)
    if (tagMatch) {
      const tagText = (tagMatch[1] ?? tagMatch[2] ?? "").trim()
      rest = rest.slice(0, rest.length - tagMatch[0].length).trim()
      tags = tagText
        .split(/[、,，]/g)
        .map((x) => x.trim())
        .filter(Boolean)
        .slice(0, 20)
    }
    const name = left
    const description = rest
    if (!name && !description && tags.length === 0) continue
    out.push({ name, description, tags })
  }
  return out
}

function formatVariantSpecsForPrompt(value: unknown): string {
  const list = normalizeVariantSpecs(value)
  if (!list) return String(value ?? "").trim()
  if (list.length === 0) return ""
  return list
    .map((x) => {
      const head = x.name ? `${x.name}：` : ""
      const desc = x.description ? x.description : ""
      const tags = x.tags.length ? `（${x.tags.join("、")}）` : ""
      const combined = `${head}${desc}${tags}`.trim()
      return combined
    })
    .filter(Boolean)
    .join("；")
}

function buildCharacterSettingForSave(input: { normalized: ReturnType<typeof unwrapCharacterSettings>; inner: any }): any {
  if (input.normalized.wrapper === "wrapped" && input.normalized.original && typeof input.normalized.original === "object") {
    return { ...(input.normalized.original as any), character_settings: input.inner }
  }
  return input.inner
}

function getCharacters(inner: any): CharacterItem[] {
  const base = inner && typeof inner === "object" ? inner : {}
  const list = (base as any)?.characters
  return Array.isArray(list) ? (list.filter((x) => x && typeof x === "object") as CharacterItem[]) : []
}

function withCharacters(inner: any, characters: CharacterItem[]): any {
  const base = inner && typeof inner === "object" ? inner : {}
  return { ...base, characters }
}

function defaultCharacter(): CharacterItem {
  return {
    character_id: typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}_${Math.random()}`,
    character_name: "",
    character_type: "",
    age: "",
    occupation: "",
    appearance: "",
    physique: "",
    hairstyle: "",
    clothing: "",
    personality: "",
    strengths: "",
    weaknesses: "",
    tone: "",
    script_setting: "",
    special_skills: "",
    cover_description: "",
    voice_speaker_id: "",
    voice_speaker_name: "",
    voice_audio_storage_key: ""
  }
}

function ensureCharacterIds(inner: any): any {
  const base = inner && typeof inner === "object" ? inner : {}
  const list = getCharacters(base)
  if (list.length === 0) return base
  let changed = false
  const nextList = list.map((c) => {
    const id = String((c as any)?.character_id ?? "").trim()
    if (id) return c
    changed = true
    return { ...c, character_id: typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}_${Math.random()}` }
  })
  return changed ? withCharacters(base, nextList) : base
}

function getCharacterKey(c: any, idx: number): string {
  const id = String(c?.character_id ?? "").trim()
  if (id) return id
  const name = toText(c?.character_name).trim()
  if (name) return name
  return `角色${idx + 1}`
}

function getCharacterDisplayName(c: any, idx: number): string {
  return toText(c?.character_name).trim() || `角色${idx + 1}`
}

function mergeRoleDraw(draws: RoleImageDrawState, key: string, name: string): RoleImageDrawState[string] | null {
  const a = draws[key]
  const b = draws[name]
  const pick = (v: any) => (typeof v === "string" ? v : "")
  const imageUrls = Array.isArray(a?.imageUrls) && a.imageUrls.length ? a.imageUrls : Array.isArray(b?.imageUrls) ? b.imageUrls : []
  const prompt = pick(a?.prompt) || pick(b?.prompt) || ""
  const selectedUrl = pick(a?.selectedUrl) || pick(b?.selectedUrl) || undefined
  const selectedUrlBase = pick(a?.selectedUrlBase) || pick(b?.selectedUrlBase) || undefined
  const selectedAssetId = pick(a?.selectedAssetId) || pick(b?.selectedAssetId) || undefined
  const needsReselect = Boolean(a?.needsReselect) || Boolean(b?.needsReselect)
  const assetSelection = (a?.assetSelection ?? b?.assetSelection) as any
  const assetSelectionByFrontImageUrl = (a?.assetSelectionByFrontImageUrl ?? b?.assetSelectionByFrontImageUrl) as any
  return { prompt, imageUrls, selectedUrl, selectedUrlBase, selectedAssetId, needsReselect, assetSelection, assetSelectionByFrontImageUrl }
}

function clampInt(value: number, min: number, max: number): number {
  if (!Number.isFinite(value)) return min
  const n = Math.trunc(value)
  if (n < min) return min
  if (n > max) return max
  return n
}

export function ShortDramaCharacterSettingsCard({
  storyId,
  planningResult,
  planningConfirmedAt,
  worldSetting,
  characterSetting,
  shotStyle,
  roleImageDraws,
  onSaved
}: ShortDramaCharacterSettingsCardProps) {
  const normalized = useMemo(() => unwrapCharacterSettings(characterSetting), [characterSetting])
  const [draft, setDraft] = useState<any>(() => {
    const inner = normalized.inner && typeof normalized.inner === "object" ? normalized.inner : {}
    return cloneJson(ensureCharacterIds(inner))
  })
  const [snapshot, setSnapshot] = useState<any>(() => cloneJson(draft))
  const [editing, setEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [errorText, setErrorText] = useState<string | null>(null)
  const [resettingRoleSetting, setResettingRoleSetting] = useState(false)
  const [resetRoleErrorText, setResetRoleErrorText] = useState<string | null>(null)
  const [activeIndex, setActiveIndex] = useState(0)
  const [imagesError, setImagesError] = useState<string | null>(null)
  const [generatingAll, setGeneratingAll] = useState(false)
  const [generatingCharacterKeys, setGeneratingCharacterKeys] = useState<Set<string>>(() => new Set())
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [confirmTitle, setConfirmTitle] = useState("")
  const [confirmDesc, setConfirmDesc] = useState("")
  const confirmActionRef = useRef<null | (() => void)>(null)
  const [roleImageModelDialogOpen, setRoleImageModelDialogOpen] = useState(false)
  const [roleImageModelDialogTitle, setRoleImageModelDialogTitle] = useState("")
  const [roleImageModelDialogDesc, setRoleImageModelDialogDesc] = useState("")
  const [roleImageModelKinds, setRoleImageModelKinds] = useState<Array<{ value: ImageModelKind; label: string }>>([])
  const [roleImageModelItems, setRoleImageModelItems] = useState<ImageModelOption[]>([])
  const [roleImageModelKind, setRoleImageModelKind] = useState<ImageModelKind>("internal")
  const [roleImageModelName, setRoleImageModelName] = useState("")
  const [roleImageModelLoading, setRoleImageModelLoading] = useState(false)
  const [roleImageModelSubmitting, setRoleImageModelSubmitting] = useState(false)
  const [roleImageModelError, setRoleImageModelError] = useState<string | null>(null)
  const pendingRoleImageActionRef = useRef<PendingRoleImageAction | null>(null)
  const [frontDrawCountText, setFrontDrawCountText] = useState("3")
  const [drawModal, setDrawModal] = useState<
    null | { characterKey: string; characterName: string; characterDescription: string; frontImageUrl: string; hairstyleOptions: VariantSpecItem[]; clothingOptions: VariantSpecItem[] }
  >(null)
  const [draws, setDraws] = useState<RoleImageDrawState>(() => normalizeRoleImageDrawState(roleImageDraws))
  const drawsJustPatchedRef = useRef(false)
  const refreshTimerRef = useRef<number | null>(null)
  const autoPersistedFrontKeysRef = useRef<Set<string>>(new Set())
  const aliveRef = useRef(true)
  const queuedJobIdsRef = useRef<Record<string, true>>({})
  const jobWatchQueueRef = useRef<string[]>([])
  const jobWatchRunningRef = useRef(false)
  const [speakers, setSpeakers] = useState<VoiceSpeaker[]>([])
  const [voiceSpeakerId, setVoiceSpeakerId] = useState("")
  const [voicePreview, setVoicePreview] = useState<{ name: string; src: string } | null>(null)
  const [voicePreviewing, setVoicePreviewing] = useState(false)
  const [voiceBinding, setVoiceBinding] = useState(false)
  const [voiceErrorText, setVoiceErrorText] = useState<string | null>(null)
  const [uploadingFrontImage, setUploadingFrontImage] = useState(false)
  const uploadInputRef = useRef<HTMLInputElement | null>(null)
  const [virtualAvatarOpen, setVirtualAvatarOpen] = useState(false)
  const [virtualAvatarError, setVirtualAvatarError] = useState<string | null>(null)
  const [virtualAvatarImageUrl, setVirtualAvatarImageUrl] = useState("")
  const [virtualAvatarAssetId, setVirtualAvatarAssetId] = useState("")
  const [virtualAvatarSaving, setVirtualAvatarSaving] = useState(false)
  const virtualAvatarInputRef = useRef<HTMLInputElement | null>(null)

  const [libraryCharacterOpen, setLibraryCharacterOpen] = useState(false)
  const [libraryCharacters, setLibraryCharacters] = useState<any[]>([])
  const [libraryCharactersLoading, setLibraryCharactersLoading] = useState(false)
  const [libraryCharacterError, setLibraryCharacterError] = useState<string | null>(null)
  const [libraryCharacterSelecting, setLibraryCharacterSelecting] = useState(false)

  const isLocked = !planningResult || (typeof planningConfirmedAt !== "number" && !characterSetting)
  const cozeStyle = useMemo(() => {
    const raw = typeof shotStyle === "string" ? shotStyle.trim() : ""
    return raw ? toCozeStyle(raw) : ""
  }, [shotStyle])
  const characters = getCharacters(draft)
  const active = characters[activeIndex] ?? null
  const activeVoiceSpeakerId = toText((active as any)?.voice_speaker_id).trim()
  const activeVoiceSpeakerName = toText((active as any)?.voice_speaker_name).trim()
  const activeVoiceStorageKey = toText((active as any)?.voice_audio_storage_key).trim()
  const boundVoiceSrc = useMemo(() => toVoiceSrc(activeVoiceStorageKey), [activeVoiceStorageKey])
  const activeCharacterName = useMemo(() => (active ? getCharacterDisplayName(active, activeIndex) : ""), [active, activeIndex])
  const { jobs: activeJobs } = useActiveJobs({ storyId, enabled: Boolean(storyId) })
  const hasRoleImageDrawActive = useMemo(() => {
    return activeJobs.some((j) => {
      if (j.type !== SHORT_DRAMA_ROLE_IMAGE_DRAW_JOB_TYPE) return false
      if (!(j.status === "queued" || j.status === "running")) return false
      return true
    })
  }, [activeJobs])
  const allRoleImageBusy = generatingAll || hasRoleImageDrawActive
  const characterNameByKey = useMemo(() => {
    const out = new Map<string, string>()
    for (let i = 0; i < characters.length; i++) {
      const c = characters[i]
      const key = getCharacterKey(c, i)
      const name = getCharacterDisplayName(c, i)
      if (key && name) out.set(key, name)
    }
    return out
  }, [characters])

  useEffect(() => {
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch("/api/tts/speakers", { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { speakers?: VoiceSpeaker[] } } | null
        const list = Array.isArray(json?.data?.speakers) ? (json?.data?.speakers ?? []) : []
        if (!cancelled) setSpeakers(list)
      } catch {
        if (!cancelled) setSpeakers([])
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  const readFileAsDataUrl = useCallback((file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = () => resolve(String(reader.result ?? ""))
      reader.onerror = () => reject(new Error("读取文件失败"))
      reader.readAsDataURL(file)
    })
  }, [])

  const defaultVoiceSpeakerId = useMemo(() => speakers[0]?.id ?? "", [speakers])
  useEffect(() => {
    const next = (activeVoiceSpeakerId || defaultVoiceSpeakerId).trim()
    if (!next) return
    setVoiceSpeakerId(next)
    setVoicePreview(null)
    setVoiceErrorText(null)
  }, [activeIndex, activeVoiceSpeakerId, defaultVoiceSpeakerId])

  const speakerOptions = useMemo(() => speakers.map((s) => ({ value: s.id, label: s.name })), [speakers])
  const selectedSpeaker = useMemo(() => speakers.find((s) => s.id === voiceSpeakerId) ?? null, [speakers, voiceSpeakerId])
  const voicePreviewText = useMemo(() => {
    const name = activeCharacterName || "角色"
    return `我叫${name}，这是我的专属音色。`
  }, [activeCharacterName])

  const buildRoleImagePrompt = useCallback((ch: any, index: number): { key: string; name: string; prompt: string } | null => {
    const pick = (v: unknown) => String(v ?? "").trim()
    const shrink = (s: string, max = 800) => (s.length > max ? s.slice(0, max) : s)
    const name = getCharacterDisplayName(ch, index)
    if (/^旁白$/u.test(name) || /^narrator$/i.test(name)) return null
    const key = getCharacterKey(ch, index)

    const type = pick(ch?.character_type)
    const age = pick(ch?.age)
    const occupation = pick(ch?.occupation)
    const appearance = pick(ch?.appearance)
    const physique = pick(ch?.physique)
    const hairstyle = formatVariantSpecsForPrompt(ch?.hairstyle)
    const clothing = formatVariantSpecsForPrompt(ch?.clothing)

    const lines: string[] = []
    lines.push(`姓名：${shrink(name, 60)}`)
    if (type) lines.push(`类型：${shrink(type, 60)}`)
    if (age) lines.push(`年龄：${shrink(age, 40)}`)
    if (occupation) lines.push(`职业：${shrink(occupation, 120)}`)
    if (appearance) lines.push(`相貌：${shrink(appearance)}`)
    if (physique) lines.push(`体格：${shrink(physique)}`)
    if (hairstyle) lines.push(`发型：${shrink(hairstyle)}`)
    if (clothing) lines.push(`服装：${shrink(clothing)}`)

    return { key, name, prompt: lines.join("\n") }
  }, [])

  const requestVoicePreview = useCallback(
    async (overrideSpeakerId?: string): Promise<string> => {
      const sid = String(overrideSpeakerId ?? voiceSpeakerId ?? defaultVoiceSpeakerId).trim()
      if (!sid) return ""
      setVoicePreviewing(true)
      setVoiceErrorText(null)
      try {
        const res = await fetch("/api/tts/preview", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ speakerId: sid, text: voicePreviewText })
        })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { audioUrl?: string }; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        const url = String(json.data?.audioUrl ?? "").trim()
        if (url) setVoicePreview({ name: `${selectedSpeaker?.name ?? sid}（试听）`, src: url })
        return url
      } catch (e) {
        const anyErr = e as { message?: string }
        setVoiceErrorText(anyErr?.message ?? "试听失败")
        return ""
      } finally {
        setVoicePreviewing(false)
      }
    },
    [defaultVoiceSpeakerId, selectedSpeaker?.name, voicePreviewText, voiceSpeakerId]
  )

  const bindVoiceToCharacter = useCallback(async () => {
    if (!active) return
    if (editing || saving || isLocked) return
    if (voiceBinding) return
    const sid = (voiceSpeakerId || defaultVoiceSpeakerId).trim()
    if (!sid) return
    const characterKey = getCharacterKey(active, activeIndex)
    if (!characterKey) return
    setVoiceBinding(true)
    setVoiceErrorText(null)
    try {
      const previewUrl = await requestVoicePreview(sid)
      if (!previewUrl) throw new Error("试听失败")
      const res = await fetch("/api/script/short-drama/role-voices/bind", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          storyId,
          characterKey,
          speakerId: sid,
          speakerName: selectedSpeaker?.name ?? sid,
          audioUrl: previewUrl
        })
      })
      const json = (await res.json().catch(() => null)) as {
        ok: boolean
        data?: { voiceSpeakerId?: string; voiceSpeakerName?: string; voiceAudioStorageKey?: string }
        error?: { message?: string }
      } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const voiceAudioStorageKey = String(json.data?.voiceAudioStorageKey ?? "").trim()
      const voiceSpeakerName = String(json.data?.voiceSpeakerName ?? selectedSpeaker?.name ?? sid).trim()
      if (!voiceAudioStorageKey) throw new Error("未获取到音色存储信息")

      const base = draft && typeof draft === "object" ? cloneJson(draft) : {}
      const list = getCharacters(base)
      const idx = Math.max(0, Math.min(activeIndex, list.length - 1))
      const current = list[idx] ?? defaultCharacter()
      const nextList = list.slice()
      nextList[idx] = {
        ...current,
        voice_speaker_id: sid,
        voice_speaker_name: voiceSpeakerName,
        voice_audio_storage_key: voiceAudioStorageKey
      }
      const nextDraft = withCharacters(base, nextList)
      const nextCharacterSetting = buildCharacterSettingForSave({ normalized, inner: nextDraft })
      await patchStoryShortDramaMetadata(storyId, {
        planningResult,
        worldSetting,
        characterSetting: nextCharacterSetting,
        planningConfirmedAt
      })
      const characterName = getCharacterDisplayName(active, activeIndex)
      const mergedDraw = mergeRoleDraw(draws, characterKey, characterName)
      const characterResourceId = typeof (mergedDraw as any)?.assetSelection?.characterId === "string" ? String((mergedDraw as any).assetSelection.characterId).trim() : ""
      if (characterResourceId) {
        try {
          await fetch("/api/library/public-resources/voice-bind", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              resourceId: characterResourceId,
              speakerId: sid,
              speakerName: voiceSpeakerName || selectedSpeaker?.name || sid,
              audioUrl: previewUrl
            })
          })
        } catch {}
      }
      setDraft(nextDraft)
      setSnapshot(cloneJson(nextDraft))
      onSaved?.(nextCharacterSetting)
    } catch (e) {
      const anyErr = e as { message?: string }
      setVoiceErrorText(anyErr?.message ?? "绑定失败")
    } finally {
      setVoiceBinding(false)
    }
  }, [
    active,
    activeIndex,
    defaultVoiceSpeakerId,
    draft,
    draws,
    editing,
    isLocked,
    normalized,
    onSaved,
    planningConfirmedAt,
    planningResult,
    requestVoicePreview,
    saving,
    selectedSpeaker?.name,
    storyId,
    voiceBinding,
    voiceSpeakerId,
    worldSetting
  ])

  useEffect(() => {
    if (editing) return
    const inner = normalized.inner && typeof normalized.inner === "object" ? normalized.inner : {}
    const ensured = cloneJson(ensureCharacterIds(inner))
    setDraft(ensured)
    setSnapshot(cloneJson(ensured))
    const nextChars = getCharacters(ensured)
    setActiveIndex((prev) => clampInt(prev, 0, Math.max(0, nextChars.length - 1)))
  }, [editing, normalized])

  useEffect(() => {
    return () => {
      if (refreshTimerRef.current) window.clearTimeout(refreshTimerRef.current)
      aliveRef.current = false
    }
  }, [])

  useEffect(() => {
    if (drawsJustPatchedRef.current) {
      drawsJustPatchedRef.current = false
      return
    }
    setDraws(normalizeRoleImageDrawState(roleImageDraws))
  }, [roleImageDraws])

  // 组件卸载时清理生成状态
  useEffect(() => {
    return () => {
      setGeneratingCharacterKeys(new Set())
      setGeneratingAll(false)
    }
  }, [])

  const applyRoleImageDraws = useCallback(
    (raw: unknown): void => {
      const nextDraws = normalizeRoleImageDrawState(raw)
      setDraws(nextDraws)
      const inner = draft && typeof draft === "object" ? cloneJson(draft) : {}
      const nextCharacterSetting = buildCharacterSettingForSave({ normalized, inner })
      onSaved?.(nextCharacterSetting, raw)
    },
    [draft, normalized, onSaved]
  )

  const fetchLatestRoleImageDraws = useCallback(async (): Promise<unknown> => {
    const res = await fetch(`/api/library/stories/${encodeURIComponent(storyId)}/detail`, { cache: "no-store" })
    const json = (await res.json().catch(() => null)) as any
    if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
    const story = json?.data?.story
    const metadata = story?.metadata
    const shortDrama = metadata && typeof metadata === "object" ? (metadata as any).shortDrama : null
    const roleImageDraws = shortDrama && typeof shortDrama === "object" ? (shortDrama as any).roleImageDraws : null
    return roleImageDraws
  }, [storyId])

  const fetchLatestShortDrama = useCallback(async (): Promise<{
    storyText: string
    planningResult: unknown
    worldSetting: unknown
    characterSetting: unknown
    planningConfirmedAt?: number
    roleImageDraws?: unknown
  }> => {
    const res = await fetch(`/api/library/stories/${encodeURIComponent(storyId)}/detail`, { cache: "no-store" })
    const json = (await res.json().catch(() => null)) as any
    if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
    const story = json?.data?.story
    const storyText = typeof story?.storyText === "string" ? story.storyText.replaceAll("\r\n", "\n").trim() : ""
    const metadata = story?.metadata
    const shortDrama = metadata && typeof metadata === "object" ? (metadata as any).shortDrama : null
    const planningResult = shortDrama ? (shortDrama as any).planningResult ?? null : null
    const worldSetting = shortDrama ? (shortDrama as any).worldSetting ?? null : null
    const characterSetting = shortDrama ? (shortDrama as any).characterSetting ?? null : null
    const planningConfirmedAt = shortDrama && typeof (shortDrama as any).planningConfirmedAt === "number" ? (shortDrama as any).planningConfirmedAt : undefined
    const roleImageDraws = shortDrama ? (shortDrama as any).roleImageDraws : undefined
    return { storyText, planningResult, worldSetting, characterSetting, planningConfirmedAt, roleImageDraws }
  }, [storyId])

  const waitForJob = useCallback(async (jobId: string, input?: { onWaiting?: () => Promise<boolean> }): Promise<"done"> => {
    const id = String(jobId ?? "").trim()
    if (!id) throw new Error("任务不存在或已过期")
    let waitMs = 650
    let firstErrorAt: number | null = null
    let lastWaitingCheckAt = 0
    const deadline = Date.now() + 15 * 60_000
    while (Date.now() < deadline) {
      if (!aliveRef.current) return "done"
      const res = await fetch(`/api/jobs/${encodeURIComponent(id)}`, { method: "GET" })
      const json = (await res.json().catch(() => null)) as any
      if (res.status === 404) {
        if (input?.onWaiting && Date.now() - lastWaitingCheckAt > 2500) {
          lastWaitingCheckAt = Date.now()
          if (await input.onWaiting().catch(() => false)) return "done"
        }
        await new Promise<void>((r) => window.setTimeout(() => r(), waitMs))
        waitMs = Math.min(2000, Math.round(waitMs * 1.2))
        continue
      }
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const status = String(json?.data?.status ?? "").trim()
      if (status === "done") return "done"
      if (status === "error") {
        if (firstErrorAt === null) firstErrorAt = Date.now()
        if (Date.now() - firstErrorAt < 20_000) {
          if (input?.onWaiting && Date.now() - lastWaitingCheckAt > 2500) {
            lastWaitingCheckAt = Date.now()
            if (await input.onWaiting().catch(() => false)) return "done"
          }
          await new Promise<void>((r) => window.setTimeout(() => r(), waitMs))
          waitMs = Math.min(4000, Math.round(waitMs * 1.2))
          continue
        }
        const msg = String((json?.data?.snapshot as any)?.errorMessage ?? "").trim()
        throw new Error(msg || "任务失败，请稍后重试")
      }
      firstErrorAt = null
      if (input?.onWaiting && Date.now() - lastWaitingCheckAt > 2500) {
        lastWaitingCheckAt = Date.now()
        if (await input.onWaiting().catch(() => false)) return "done"
      }
      await new Promise<void>((r) => window.setTimeout(() => r(), waitMs))
      waitMs = Math.min(4000, Math.round(waitMs * 1.2))
    }
    throw new Error("等待任务完成超时，请稍后重试")
  }, [])

  const resetRoleSettingFromScriptBody = useCallback((): void => {
    confirmActionRef.current = () => {
      void (async () => {
        if (resettingRoleSetting || saving) return
        setResetRoleErrorText(null)
        setErrorText(null)
        setImagesError(null)
        setResettingRoleSetting(true)
        try {
          const latest0 = await fetchLatestShortDrama()
          if (!latest0.storyText) throw new Error("暂无剧本正文，无法重制角色设定")
          const prevFp = (() => {
            try {
              return JSON.stringify(latest0.characterSetting ?? null)
            } catch {
              return ""
            }
          })()

          const task = await submitShortDramaRoleParsingTask({ storyId, novelText: latest0.storyText })
          window.dispatchEvent(new Event("open_task_center"))
          await waitForJob(task.jobId, {
            onWaiting: async () => {
              const latest = await fetchLatestShortDrama()
              const next = latest.characterSetting ?? null
              if (!next) return false
              let nextFp = ""
              try {
                nextFp = JSON.stringify(next)
              } catch {
                nextFp = ""
              }
              return nextFp !== prevFp
            }
          })

          const latest1 = await fetchLatestShortDrama()
          const nextCharacterSetting = latest1.characterSetting
          if (!nextCharacterSetting) throw new Error("重制完成但未返回角色设定")
          const clearedRoleImageDraws = {}

          await patchStoryShortDramaMetadata(storyId, {
            planningResult: latest1.planningResult,
            worldSetting: latest1.worldSetting,
            characterSetting: nextCharacterSetting,
            planningConfirmedAt: latest1.planningConfirmedAt,
            roleImageDraws: clearedRoleImageDraws,
            setupSource: "script_body"
          })

          const nextNormalized = unwrapCharacterSettings(nextCharacterSetting)
          const inner = nextNormalized.inner && typeof nextNormalized.inner === "object" ? nextNormalized.inner : {}
          const ensured = cloneJson(ensureCharacterIds(inner))
          setDraft(ensured)
          setSnapshot(cloneJson(ensured))
          setDraws(normalizeRoleImageDrawState(clearedRoleImageDraws))
          setActiveIndex(0)
          onSaved?.(nextCharacterSetting, clearedRoleImageDraws)
        } catch (e) {
          const anyErr = e as { message?: string }
          setResetRoleErrorText(anyErr?.message ?? "重制角色设定失败")
        } finally {
          setResettingRoleSetting(false)
        }
      })()
    }
    setConfirmTitle("重制角色设定")
    setConfirmDesc("将重新从剧本正文提取角色设定，并覆盖当前角色设定。为避免旧角色图错配，新角色设定生效后会清空当前角色图候选。")
    setConfirmOpen(true)
  }, [fetchLatestShortDrama, onSaved, resettingRoleSetting, saving, storyId, waitForJob])

  const drainRoleImageDrawJobWatchQueue = useCallback(async (): Promise<void> => {
    if (jobWatchRunningRef.current) return
    jobWatchRunningRef.current = true
    try {
      while (aliveRef.current) {
        const id = jobWatchQueueRef.current.shift()
        if (!id) return
        let waitMs = 650
        let firstErrorAt: number | null = null
        const deadline = Date.now() + 10 * 60_000
        try {
          while (aliveRef.current && Date.now() < deadline) {
            const res = await fetch(`/api/jobs/${encodeURIComponent(id)}`, { method: "GET" })
            const json = (await res.json().catch(() => null)) as any
            if (res.status === 404) {
              await new Promise<void>((r) => window.setTimeout(() => r(), waitMs))
              waitMs = Math.min(2000, Math.round(waitMs * 1.2))
              continue
            }
            if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
            const status = String(json?.data?.status ?? "").trim()
            if (status === "done") {
              const latest = await fetchLatestRoleImageDraws()
              applyRoleImageDraws(latest)
              break
            }
            if (status === "error") {
              if (firstErrorAt === null) firstErrorAt = Date.now()
              if (Date.now() - firstErrorAt < 20_000) {
                await new Promise<void>((r) => window.setTimeout(() => r(), waitMs))
                waitMs = Math.min(4000, Math.round(waitMs * 1.2))
                continue
              }
              const msg = String((json?.data?.snapshot as any)?.errorMessage ?? "").trim()
              throw new Error(msg || "生成失败，请稍后重试")
            }
            firstErrorAt = null
            await new Promise<void>((r) => window.setTimeout(() => r(), waitMs))
            waitMs = Math.min(4000, Math.round(waitMs * 1.2))
          }
        } catch (e) {
          const anyErr = e as { message?: string }
          if (aliveRef.current) setImagesError(anyErr?.message ?? "生成角色图片失败")
        } finally {
          delete queuedJobIdsRef.current[id]
        }
      }
    } finally {
      jobWatchRunningRef.current = false
    }
  }, [applyRoleImageDraws, fetchLatestRoleImageDraws])

  const enqueueRoleImageDrawJobWatch = useCallback(
    (jobId: string): void => {
      const id = String(jobId ?? "").trim()
      if (!id) return
      if (queuedJobIdsRef.current[id]) return
      queuedJobIdsRef.current[id] = true
      jobWatchQueueRef.current.push(id)
      void drainRoleImageDrawJobWatchQueue()
    },
    [drainRoleImageDrawJobWatchQueue]
  )

  const persistCharacterIdsIfNeeded = useCallback(async (): Promise<void> => {
    const innerFromProp = normalized.inner && typeof normalized.inner === "object" ? normalized.inner : {}
    const listFromProp = getCharacters(innerFromProp)
    const missing = listFromProp.some((c) => !String((c as any)?.character_id ?? "").trim())
    if (!missing) return

    const inner = draft && typeof draft === "object" ? cloneJson(draft) : {}
    const ensuredInner = ensureCharacterIds(inner)
    const nextCharacterSetting = buildCharacterSettingForSave({ normalized, inner: ensuredInner })
    await patchStoryShortDramaMetadata(storyId, {
      planningResult,
      worldSetting,
      characterSetting: nextCharacterSetting,
      planningConfirmedAt
    })
    setDraft(cloneJson(ensuredInner))
    setSnapshot(cloneJson(ensuredInner))
    onSaved?.(nextCharacterSetting)
  }, [draft, normalized, onSaved, planningConfirmedAt, planningResult, storyId, worldSetting])

  const enqueueRoleImageDrawJob = useCallback(
    async (input: {
      mode: "all" | "one"
      forceRegenerate: boolean
      drawCount: number
      modelKind: ImageModelKind
      modelName: string
      prompts: Array<{ key: string; name: string; prompt: string }>
    }): Promise<{ jobId: string }> => {
      const res = await fetch("/api/script/short-drama/role-image-draw/stream", {
        method: "POST",
        headers: { "content-type": "application/json", accept: "text/event-stream" },
        body: JSON.stringify({
          storyId,
          mode: input.mode,
          forceRegenerate: input.forceRegenerate,
          drawCount: input.drawCount,
          modelKind: input.modelKind,
          modelName: input.modelName,
          style: cozeStyle || undefined,
          prompts: input.prompts
        })
      })
      if (!res.ok) {
        const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: { message?: string } } | null
        throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      }
      const jobId = await readAcceptedJobIdFromStream({ res })
      if (!jobId) throw new Error("提交任务失败：未返回 jobId")
      window.dispatchEvent(new Event("open_task_center"))
      enqueueRoleImageDrawJobWatch(jobId)
      return { jobId }
    },
    [cozeStyle, enqueueRoleImageDrawJobWatch, storyId]
  )

  const syncRoleImageModelSelection = useCallback(
    (
      kinds: Array<{ value: ImageModelKind; label: string }>,
      items: ImageModelOption[],
      preferredKind?: ImageModelKind,
      preferredModelName?: string
    ) => {
      const nextKind =
        kinds.find((item) => item.value === preferredKind)?.value ??
        kinds[0]?.value ??
        "internal"
      const scopedItems = items.filter((item) => item.kind === nextKind)
      const nextModelName =
        scopedItems.find((item) => item.modelName === preferredModelName)?.modelName ??
        scopedItems[0]?.modelName ??
        ""
      setRoleImageModelKind(nextKind)
      setRoleImageModelName(nextModelName)
    },
    []
  )

  const loadRoleImageModels = useCallback(
    async (preferred?: { kind?: ImageModelKind; modelName?: string }): Promise<void> => {
      setRoleImageModelLoading(true)
      setRoleImageModelError(null)
      try {
        const res = await fetch("/api/script/short-drama/role-image-models", { method: "GET", cache: "no-store" })
        const json = (await res.json().catch(() => null)) as
          | { ok?: boolean; data?: ImageModelListResponse; error?: { message?: string } }
          | null
        if (!res.ok || !json?.ok || !json.data) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        const kinds = Array.isArray(json.data.kinds) ? json.data.kinds : []
        const items = Array.isArray(json.data.items) ? json.data.items : []
        setRoleImageModelKinds(kinds)
        setRoleImageModelItems(items)
        syncRoleImageModelSelection(kinds, items, preferred?.kind, preferred?.modelName)
        if (items.length === 0) {
          setRoleImageModelError("当前账号未配置可用的图片模型")
        }
      } catch (e) {
        const anyErr = e as { message?: string }
        setRoleImageModelKinds([])
        setRoleImageModelItems([])
        setRoleImageModelKind("internal")
        setRoleImageModelName("")
        setRoleImageModelError(anyErr?.message ?? "加载图片模型失败")
      } finally {
        setRoleImageModelLoading(false)
      }
    },
    [syncRoleImageModelSelection]
  )

  const openRoleImageModelDialog = useCallback(
    async (input: { scope: "all" | "current"; forceRegenerate: boolean; title: string; desc: string }): Promise<void> => {
      pendingRoleImageActionRef.current = { scope: input.scope, forceRegenerate: input.forceRegenerate }
      setRoleImageModelDialogTitle(input.title)
      setRoleImageModelDialogDesc(input.desc)
      setRoleImageModelError(null)
      setRoleImageModelSubmitting(false)
      setRoleImageModelDialogOpen(true)
      await loadRoleImageModels({ kind: roleImageModelKind, modelName: roleImageModelName })
    },
    [loadRoleImageModels, roleImageModelKind, roleImageModelName]
  )

  const persistFrontImages = useCallback(
    async (input: { characterKey: string; characterName: string; imageUrls: string[] }): Promise<string[]> => {
      const res = await fetch("/api/script/short-drama/persist-role-front-images", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ storyId, characterKey: input.characterKey, characterName: input.characterName, imageUrls: input.imageUrls })
      })
      const json = (await res.json().catch(() => null)) as any
      if (!res.ok || !json?.ok) return input.imageUrls
      const images = Array.isArray(json?.data?.images) ? json.data.images : []
      const urls = images.map((x: any) => String(x?.url ?? "").trim()).filter(Boolean)
      return urls.length ? urls : input.imageUrls
    },
    [storyId]
  )

  const patchRoleImageDraws = useCallback(
    async (next: RoleImageDrawState) => {
      const inner = draft && typeof draft === "object" ? cloneJson(draft) : {}
      const nextCharacterSetting = buildCharacterSettingForSave({ normalized, inner })
      await patchStoryShortDramaMetadata(storyId, {
        planningResult,
        worldSetting,
        characterSetting: nextCharacterSetting,
        planningConfirmedAt,
        roleImageDraws: next
      })
      drawsJustPatchedRef.current = true
      onSaved?.(nextCharacterSetting, next)
      setDraws(next)
    },
    [draft, normalized, onSaved, planningConfirmedAt, planningResult, storyId, worldSetting]
  )

  const uploadFrontImageForActive = useCallback(
    async (file: File) => {
      if (!active || editing || saving || isLocked || uploadingFrontImage) return
      const name = getCharacterDisplayName(active, activeIndex)
      const key = getCharacterKey(active, activeIndex)
      if (!key) return
      setUploadingFrontImage(true)
      setImagesError(null)
      try {
        await persistCharacterIdsIfNeeded()
        const dataUrl = await readFileAsDataUrl(file)
        if (!dataUrl) throw new Error("读取图片失败")
        const persisted = await persistFrontImages({ characterKey: key, characterName: name, imageUrls: [dataUrl] }).catch(() => [dataUrl])
        const urls = persisted.length ? persisted : [dataUrl]
        const selectedUrl = String(urls[0] ?? "").trim()
        const selectedUrlBase = selectedUrl ? stripUrlQuery(selectedUrl) : ""
        const existed = mergeRoleDraw(draws, key, name)
        const next: RoleImageDrawState = {
          ...draws,
          [key]: {
            prompt: existed?.prompt ?? "",
            imageUrls: urls,
            selectedUrl: selectedUrl || undefined,
            selectedUrlBase: selectedUrlBase || undefined,
            selectedAssetId: undefined,
          needsReselect: false,
            assetSelection: existed?.assetSelection,
            assetSelectionByFrontImageUrl: existed?.assetSelectionByFrontImageUrl
          }
        }
        await patchRoleImageDraws(next)
      } catch (e) {
        const anyErr = e as { message?: string }
        setImagesError(anyErr?.message ?? "上传失败")
      } finally {
        setUploadingFrontImage(false)
      }
    },
    [
      active,
      activeIndex,
      draws,
      editing,
      isLocked,
      patchRoleImageDraws,
      persistCharacterIdsIfNeeded,
      persistFrontImages,
      readFileAsDataUrl,
      saving,
      uploadingFrontImage
    ]
  )

  const handleUploadFrontImageChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.currentTarget.files?.[0] ?? null
      e.currentTarget.value = ""
      if (!file) return
      void uploadFrontImageForActive(file)
    },
    [uploadFrontImageForActive]
  )

  const openLibraryCharacterPicker = useCallback(async () => {
    setLibraryCharacterOpen(true)
    setLibraryCharactersLoading(true)
    setLibraryCharacterError(null)
    try {
      const res = await fetch("/api/library/public-resources/list?type=character&limit=100")
      const json = await res.json()
      if (!res.ok || !json.ok) throw new Error(json?.error?.message ?? "获取公共资源失败")
      setLibraryCharacters(json.data?.items ?? [])
    } catch (e) {
      setLibraryCharacterError(e instanceof Error ? e.message : "获取公共资源失败")
    } finally {
      setLibraryCharactersLoading(false)
    }
  }, [])

  const selectLibraryCharacter = useCallback(async (resourceId: string, previewUrl: string, looks?: any[], costumes?: any[]) => {
    if (!active || !resourceId) return
    setLibraryCharacterSelecting(true)
    try {
      const characterName = getCharacterDisplayName(active, activeIndex)
      const characterKey = getCharacterKey(active, activeIndex)
      if (!characterKey) return

      // Make sure character ids are persisted before we start writing roleImageDraws.
      await persistCharacterIdsIfNeeded()
      
      const res = await fetch("/api/library/public-resources/import-short-drama-character", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          storyId,
          characterId: characterKey,
          characterName,
          frontImageUrl: previewUrl,
          looks: looks && looks.length > 0 ? looks : undefined,
          costumes: costumes && costumes.length > 0 ? costumes : undefined
        })
      })
      const json = await res.json()
      if (!res.ok || !json.ok) throw new Error(json?.error?.message ?? "复用资源库形象失败")
      
      const nextId = json.data?.characterId
      if (!nextId) throw new Error("保存失败：未返回角色资产 ID")
      
      const existed = mergeRoleDraw(draws, characterKey, characterName)
      const persistedFront = await persistFrontImages({ characterKey, characterName, imageUrls: [previewUrl] }).catch(() => [previewUrl])
      const pickedFront = String(persistedFront?.[0] ?? previewUrl).trim()
      const baseUrl = stripUrlQuery(pickedFront)

      const nextImageUrls = (() => {
        const prev = Array.isArray(existed?.imageUrls) ? existed!.imageUrls : []
        if (prev.length === 0) return pickedFront ? [pickedFront] : []
        const out: string[] = []
        const seen = new Set<string>()
        const push = (u: string) => {
          const t = String(u ?? "").trim()
          if (!t) return
          const k = stripUrlQuery(t)
          if (!k || seen.has(k)) return
          seen.add(k)
          out.push(t)
        }
        // Newest first so user sees the newly "reused" image immediately.
        push(pickedFront)
        for (const u of prev) push(u)
        return out.slice(0, 20)
      })()
      
      const nextAssetSelection = {
        characterId: nextId,
        lookId: null,
        costumeId: null,
        lookIdByVariant: {} as Record<string, string>,
        costumeIdByVariant: {} as Record<string, string>,
        lookCandidateStorageKeysByVariant: {} as Record<string, string[]>,
        costumeCandidateStorageKeysByVariant: {} as Record<string, string[]>,
        selectedLookCandidateKeyByVariant: {} as Record<string, string>,
        selectedCostumeCandidateKeyByVariant: {} as Record<string, string>,
        activeDrawJobIds: [] as string[],
        selectedHairIndex: 0,
        selectedClothingIndex: 0,
        hairText: "",
        hairTagsText: "",
        clothingText: "",
        clothingTagsText: "",
        frontImageUrl: pickedFront
      }
      
      // Handle returned looks and costumes to pre-fill the variants
      if (json.data?.looks && Array.isArray(json.data.looks)) {
        json.data.looks.forEach((l: any, idx: number) => {
          const variantName = l.name || `装造${idx + 1}`
          nextAssetSelection.lookIdByVariant[variantName] = l.id
          nextAssetSelection.selectedLookCandidateKeyByVariant[variantName] = l.imageUrl
          if (l.storageKey) {
            nextAssetSelection.lookCandidateStorageKeysByVariant[variantName] = [l.storageKey]
          }
        })
      }
      
      if (json.data?.costumes && Array.isArray(json.data.costumes)) {
        json.data.costumes.forEach((c: any, idx: number) => {
          const variantName = c.name || `服装${idx + 1}`
          nextAssetSelection.costumeIdByVariant[variantName] = c.id
          nextAssetSelection.selectedCostumeCandidateKeyByVariant[variantName] = c.imageUrl
          if (c.storageKey) {
            nextAssetSelection.costumeCandidateStorageKeysByVariant[variantName] = [c.storageKey]
          }
        })
      }
      
      const nextMap = existed?.assetSelectionByFrontImageUrl && typeof existed.assetSelectionByFrontImageUrl === "object" ? { ...existed.assetSelectionByFrontImageUrl } : {}
      nextMap[baseUrl] = nextAssetSelection
      
      const next: RoleImageDrawState = {
        ...draws,
        [characterKey]: {
          prompt: existed?.prompt ?? "",
          imageUrls: nextImageUrls,
          selectedUrl: pickedFront,
          selectedUrlBase: baseUrl,
          selectedAssetId: nextId,
          needsReselect: false,
          assetSelection: nextAssetSelection,
          assetSelectionByFrontImageUrl: nextMap
        }
      }
      
      const nextDraft = cloneJson(draft)
      const nextChars = getCharacters(nextDraft)
      const activeChar = nextChars[activeIndex]
      if (activeChar) {
        if (json.data?.looks && Array.isArray(json.data.looks) && json.data.looks.length > 0) {
          (activeChar as any).hairstyle = json.data.looks.map((l: any, idx: number) => `${l.name || `装造${idx + 1}`}：${l.description || "默认"}`).join("；")
        }
        if (json.data?.costumes && Array.isArray(json.data.costumes) && json.data.costumes.length > 0) {
          (activeChar as any).clothing = json.data.costumes.map((c: any, idx: number) => `${c.name || `服装${idx + 1}`}：${c.description || "默认"}`).join("；")
        }
      }
      
      setDraft(nextDraft)
      setSnapshot(cloneJson(nextDraft))
      const nextCharacterSetting = buildCharacterSettingForSave({ normalized, inner: nextDraft })

      await patchStoryShortDramaMetadata(storyId, {
        planningResult,
        worldSetting,
        characterSetting: nextCharacterSetting,
        planningConfirmedAt,
        roleImageDraws: next
      })

      setDraws(next)
      onSaved?.(nextCharacterSetting, next)

      setLibraryCharacterOpen(false)
    } catch (e) {
      setLibraryCharacterError(e instanceof Error ? e.message : "复用资源库形象失败")
    } finally {
      setLibraryCharacterSelecting(false)
    }
  }, [active, activeIndex, draft, draws, normalized, onSaved, storyId, planningResult, worldSetting, planningConfirmedAt])

  const openVirtualAvatarPicker = useCallback(() => {
    setVirtualAvatarError(null)
    setVirtualAvatarImageUrl("")
    setVirtualAvatarAssetId("")
    setVirtualAvatarOpen(true)
  }, [])

  const handleVirtualAvatarFileChange = useCallback(
    async (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.currentTarget.files?.[0] ?? null
      e.currentTarget.value = ""
      if (!file) return
      setVirtualAvatarError(null)
      try {
        const dataUrl = await readFileAsDataUrl(file)
        if (!dataUrl) throw new Error("读取图片失败")
        setVirtualAvatarImageUrl(dataUrl)
      } catch (err) {
        const msg = (err as any)?.message ?? "读取图片失败"
        setVirtualAvatarError(String(msg))
      }
    },
    [readFileAsDataUrl]
  )

  const saveVirtualAvatarForActive = useCallback(async () => {
    if (!active || editing || saving || isLocked || virtualAvatarSaving) return
    const assetId = virtualAvatarAssetId.trim()
    if (!virtualAvatarImageUrl) {
      setVirtualAvatarError("请先上传人物形象")
      return
    }
    if (!assetId) {
      setVirtualAvatarError("请填写assetID")
      return
    }
    const name = getCharacterDisplayName(active, activeIndex)
    const key = getCharacterKey(active, activeIndex)
    if (!key) return
    setVirtualAvatarSaving(true)
    setImagesError(null)
    try {
      await persistCharacterIdsIfNeeded()
      const persisted = await persistFrontImages({
        characterKey: key,
        characterName: name,
        imageUrls: [virtualAvatarImageUrl]
      }).catch(() => [virtualAvatarImageUrl])
      const urls = persisted.length ? persisted : [virtualAvatarImageUrl]
      const selectedUrl = String(urls[0] ?? "").trim()
      const selectedUrlBase = selectedUrl ? stripUrlQuery(selectedUrl) : ""
      const existed = mergeRoleDraw(draws, key, name)
      const next: RoleImageDrawState = {
        ...draws,
        [key]: {
          prompt: existed?.prompt ?? "",
          imageUrls: urls,
          selectedUrl: selectedUrl || undefined,
          selectedUrlBase: selectedUrlBase || undefined,
          selectedAssetId: assetId || undefined,
          needsReselect: false,
          assetSelection: existed?.assetSelection,
          assetSelectionByFrontImageUrl: existed?.assetSelectionByFrontImageUrl
        }
      }
      await patchRoleImageDraws(next)
      setVirtualAvatarOpen(false)
    } catch (err) {
      const msg = (err as any)?.message ?? "保存失败"
      setImagesError(String(msg))
      setVirtualAvatarError(String(msg))
    } finally {
      setVirtualAvatarSaving(false)
    }
  }, [
    active,
    activeIndex,
    draws,
    editing,
    isLocked,
    patchRoleImageDraws,
    persistCharacterIdsIfNeeded,
    persistFrontImages,
    saving,
    virtualAvatarAssetId,
    virtualAvatarImageUrl,
    virtualAvatarSaving
  ])

  useEffect(() => {
    if (editing || saving || isLocked) return
    if (allRoleImageBusy || generatingCharacterKeys.size > 0) return
    if (!draws || typeof draws !== "object") return

    const shouldPersistExternalUrl = (u: string) => {
      const s = String(u ?? "").trim()
      if (!s.startsWith("http")) return false
      if (s.includes("public/short-drama/role-assets/")) return false
      return true
    }

    const toPersist: Array<{ key: string; entry: RoleImageDrawState[string] }> = []
    for (const [key, entry] of Object.entries(draws)) {
      if (!key) continue
      if (!entry || typeof entry !== "object") continue
      if (autoPersistedFrontKeysRef.current.has(key)) continue
      const urls = Array.isArray((entry as any).imageUrls) ? ((entry as any).imageUrls as string[]) : []
      const hasStorage = urls.some((u) => String(u ?? "").trim().startsWith("public/short-drama/role-assets/"))
      if (hasStorage) continue
      const hasExternal = urls.some((u) => shouldPersistExternalUrl(String(u ?? "").trim()))
      if (!hasExternal) continue
      toPersist.push({ key, entry })
    }
    if (toPersist.length === 0) return

    for (const it of toPersist) autoPersistedFrontKeysRef.current.add(it.key)

    ;(async () => {
      const next: RoleImageDrawState = { ...draws }
      let changed = false
      for (const it of toPersist) {
        const key = it.key
        const entry = it.entry
        const urls = Array.isArray(entry.imageUrls) ? entry.imageUrls : []
        const name = characterNameByKey.get(key) || key
        const persisted = await persistFrontImages({ characterKey: key, characterName: name, imageUrls: urls }).catch(() => urls)
        const prevSelected = String(entry.selectedUrl ?? "").trim()
        const prevIndex = prevSelected ? urls.findIndex((u) => String(u ?? "").trim() === prevSelected) : -1
        const picked = prevIndex >= 0 ? String(persisted[prevIndex] ?? "").trim() : ""
        const selectedUrl = picked || (prevSelected ? String(persisted[0] ?? "").trim() : "")
        next[key] = {
          ...entry,
          imageUrls: persisted,
          selectedUrl: selectedUrl || undefined,
          selectedUrlBase: selectedUrl ? stripUrlQuery(selectedUrl) : entry.selectedUrlBase,
          selectedAssetId: entry.selectedAssetId,
          needsReselect: Boolean(entry.selectedUrl && !selectedUrl) ? true : false
        }
        changed = true
      }
      if (changed) await patchRoleImageDraws(next)
    })().catch(() => {})
  }, [allRoleImageBusy, characterNameByKey, draws, editing, generatingCharacterKeys.size, isLocked, patchRoleImageDraws, persistFrontImages, saving])

  useEffect(() => {
    if (editing || saving) return
    const inner = normalized.inner && typeof normalized.inner === "object" ? cloneJson(normalized.inner) : {}
    const ensured = ensureCharacterIds(inner)
    setDraft(ensured)
    setSnapshot(cloneJson(ensured))
    const list = getCharacters(ensured)
    setActiveIndex((i) => clampInt(i, 0, Math.max(0, list.length - 1)))
  }, [editing, normalized.inner, saving])

  const updateActive = (patch: Record<string, unknown>) => {
    setDraft((prev: any) => {
      const prevObj = prev && typeof prev === "object" ? prev : {}
      const list = getCharacters(prevObj)
      const idx = Math.max(0, Math.min(activeIndex, list.length - 1))
      const current = list[idx] ?? defaultCharacter()
      const nextList = list.slice()
      nextList[idx] = { ...current, ...patch }
      return withCharacters(prevObj, nextList)
    })
  }

  const updateActiveVariantList = (key: "hairstyle" | "clothing", next: VariantSpecItem[]) => {
    updateActive({ [key]: next.map((x) => ({ name: x.name, description: x.description, tags: x.tags })) })
  }

  const renderVariantList = (key: "hairstyle" | "clothing", label: string) => {
    const raw = (active as any)?.[key]
    const parsed = normalizeVariantSpecs(raw)
    if (!parsed) {
      return (
        <TextField
          label={label}
          value={toText(raw)}
          editing={editing}
          rows={3}
          onChange={(v) => updateActive({ [key]: v })}
        />
      )
    }

    const list = parsed
    return (
      <div className={styles.variantField}>
        <div className={styles.variantLabelRow}>
          <div className={styles.variantLabel}>{label}</div>
          {editing ? (
            <button
              type="button"
              className={styles.variantAddBtn}
              onClick={() => updateActiveVariantList(key, [...list, { name: "", description: "", tags: [] }])}
            >
              添加
            </button>
          ) : null}
        </div>

        {list.length === 0 ? <div className={styles.variantEmpty}>—</div> : null}

        <div className={styles.variantList}>
          {list.map((item, idx) => {
            const tagsText = item.tags.join(",")
            return (
              <div key={`${key}-${idx}`} className={styles.variantItem}>
                <div className={styles.variantItemTop}>
                  {editing ? (
                    <>
                      <input
                        className={styles.variantInput}
                        value={item.name}
                        placeholder="名称（如：日常/工作/宴会）"
                        onChange={(e) => {
                          const next = list.slice()
                          next[idx] = { ...item, name: e.currentTarget.value }
                          updateActiveVariantList(key, next)
                        }}
                      />
                      <input
                        className={styles.variantInput}
                        value={tagsText}
                        placeholder="标签（逗号分隔）"
                        onChange={(e) => {
                          const nextTags = e.currentTarget.value
                            .split(",")
                            .map((s) => s.trim())
                            .filter(Boolean)
                            .slice(0, 20)
                          const next = list.slice()
                          next[idx] = { ...item, tags: nextTags }
                          updateActiveVariantList(key, next)
                        }}
                      />
                      <button
                        type="button"
                        className={styles.variantRemoveBtn}
                        onClick={() => {
                          const next = list.filter((_, i) => i !== idx)
                          updateActiveVariantList(key, next)
                        }}
                      >
                        删除
                      </button>
                    </>
                  ) : (
                    <>
                      <div className={styles.variantName}>{item.name || "未命名"}</div>
                      {item.tags.length ? (
                        <div className={styles.variantTags}>
                          {item.tags.map((t) => (
                            <span key={t} className={styles.variantTag}>
                              {t}
                            </span>
                          ))}
                        </div>
                      ) : null}
                    </>
                  )}
                </div>

                {editing ? (
                  <textarea
                    className={styles.variantTextarea}
                    value={item.description}
                    rows={3}
                    placeholder="描述"
                    onChange={(e) => {
                      const next = list.slice()
                      next[idx] = { ...item, description: e.currentTarget.value }
                      updateActiveVariantList(key, next)
                    }}
                  />
                ) : (
                  <div className={styles.variantDesc}>{item.description || "—"}</div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  const onAddCharacter = () => {
    setDraft((prev: any) => {
      const prevObj = prev && typeof prev === "object" ? prev : {}
      const list = getCharacters(prevObj)
      const nextList = [...list, defaultCharacter()]
      return withCharacters(prevObj, nextList)
    })
    setActiveIndex(characters.length)
  }

  const onRemoveActive = () => {
    setDraft((prev: any) => {
      const prevObj = prev && typeof prev === "object" ? prev : {}
      const list = getCharacters(prevObj)
      if (list.length === 0) return prevObj
      const idx = Math.max(0, Math.min(activeIndex, list.length - 1))
      const nextList = list.filter((_, i) => i !== idx)
      return withCharacters(prevObj, nextList)
    })
    setActiveIndex((i) => Math.max(0, i - 1))
  }

  const onEditClick = () => {
    if (isLocked) return
    setSnapshot(cloneJson(draft))
    setErrorText(null)
    setEditing(true)
  }

  const onCancelClick = () => {
    setDraft(cloneJson(snapshot))
    setErrorText(null)
    setEditing(false)
  }

  const onSaveClick = async () => {
    if (saving) return
    setSaving(true)
    setErrorText(null)
    try {
      const inner = draft && typeof draft === "object" ? cloneJson(draft) : {}
      const nextCharacterSetting = buildCharacterSettingForSave({ normalized, inner })
      await patchStoryShortDramaMetadata(storyId, {
        planningResult,
        worldSetting,
        characterSetting: nextCharacterSetting,
        planningConfirmedAt
      })
      setSnapshot(cloneJson(inner))
      setEditing(false)
      onSaved?.(nextCharacterSetting)
    } catch (e) {
      const anyErr = e as { message?: string }
      setErrorText(anyErr?.message ?? "保存失败，请稍后重试")
    } finally {
      setSaving(false)
    }
  }

  const generateAllRoleImages = async (forceRegenerate: boolean, modelKind: ImageModelKind, modelName: string) => {
    if (isLocked || editing || saving) return
    if (hasRoleImageDrawActive) return
    if (generatingAll) return
    setGeneratingAll(true)
    setImagesError(null)
    try {
      await persistCharacterIdsIfNeeded()
      const prompts = characters
        .map((c, idx) => buildRoleImagePrompt(c, idx))
        .filter(Boolean)
        .slice(0, 50) as Array<{ key: string; name: string; prompt: string }>
      if (prompts.length === 0) return
      const drawCount = clampInt(Number(frontDrawCountText), 1, 5)
      let ok = 0
      let firstErr: string | null = null
      for (const p of prompts) {
        try {
          await enqueueRoleImageDrawJob({
            mode: "one",
            forceRegenerate,
            drawCount,
            modelKind,
            modelName,
            prompts: [{ key: p.key, name: p.name, prompt: p.prompt }]
          })
          ok += 1
        } catch (e) {
          const msg = String((e as any)?.message ?? "").trim()
          if (!firstErr && msg) firstErr = msg
        }
      }
      if (ok === 0) throw new Error(firstErr || "生成角色图片失败")
    } catch (e) {
      const anyErr = e as { message?: string }
      setImagesError(anyErr?.message ?? "生成角色图片失败")
      throw e
    } finally {
      setGeneratingAll(false)
    }
  }

  const generateCurrentRoleImage = async (forceRegenerate: boolean, modelKind: ImageModelKind, modelName: string) => {
    if (isLocked || editing || saving) return
    if (!active) return
    const currentKey = getCharacterKey(active, activeIndex)
    if (generatingCharacterKeys.has(currentKey)) return
    setGeneratingCharacterKeys(prev => new Set(prev).add(currentKey))
    setImagesError(null)
    try {
      await persistCharacterIdsIfNeeded()
      const prompt = buildRoleImagePrompt(active, activeIndex)
      if (!prompt) return
      const existed = mergeRoleDraw(draws, prompt.key, prompt.name)
      if (!forceRegenerate && existed?.imageUrls?.length) return
      const drawCount = clampInt(Number(frontDrawCountText), 1, 5)
      await enqueueRoleImageDrawJob({
        mode: "one",
        forceRegenerate,
        drawCount,
        modelKind,
        modelName,
        prompts: [{ key: prompt.key, name: prompt.name, prompt: prompt.prompt }]
      })
    } catch (e) {
      const anyErr = e as { message?: string }
      setImagesError(anyErr?.message ?? "生成角色图片失败")
      throw e
    } finally {
      setGeneratingCharacterKeys(prev => {
        const next = new Set(prev)
        next.delete(currentKey)
        return next
      })
    }
  }

  const openConfirm = useCallback((input: { title: string; desc: string; onConfirm: () => void }): void => {
    confirmActionRef.current = input.onConfirm
    setConfirmTitle(input.title)
    setConfirmDesc(input.desc)
    setConfirmOpen(true)
  }, [])

  const submitRoleImageModelDialog = useCallback(async (): Promise<void> => {
    const pending = pendingRoleImageActionRef.current
    if (!pending) return
    if (!roleImageModelName.trim()) {
      setRoleImageModelError("请选择图片模型")
      return
    }

    setRoleImageModelSubmitting(true)
    setRoleImageModelError(null)
    try {
      if (pending.scope === "all") {
        await generateAllRoleImages(pending.forceRegenerate, roleImageModelKind, roleImageModelName)
      } else {
        await generateCurrentRoleImage(pending.forceRegenerate, roleImageModelKind, roleImageModelName)
      }
      setRoleImageModelDialogOpen(false)
      pendingRoleImageActionRef.current = null
    } catch (e) {
      const anyErr = e as { message?: string }
      setRoleImageModelError(anyErr?.message ?? "提交生成任务失败")
    } finally {
      setRoleImageModelSubmitting(false)
    }
  }, [generateAllRoleImages, generateCurrentRoleImage, roleImageModelKind, roleImageModelName])

  const selectFrontImage = useCallback(
    async (characterKey: string, characterName: string, url: string) => {
      const trimmed = url.trim()
      if (!trimmed) return
      const existed = mergeRoleDraw(draws, characterKey, characterName)
      const baseUrl = stripUrlQuery(trimmed)
      const next: RoleImageDrawState = {
        ...draws,
        [characterKey]: {
          prompt: existed?.prompt ?? "",
          imageUrls: existed?.imageUrls ?? [],
          selectedUrl: trimmed,
          selectedUrlBase: baseUrl || undefined,
          selectedAssetId: undefined,
          needsReselect: false,
          assetSelection: existed?.assetSelection,
          assetSelectionByFrontImageUrl: existed?.assetSelectionByFrontImageUrl
        }
      }
      await patchRoleImageDraws(next)
    },
    [draws, patchRoleImageDraws]
  )

  const openAssetModalForActive = useCallback(() => {
    if (!active) return
    const name = getCharacterDisplayName(active, activeIndex)
    const key = getCharacterKey(active, activeIndex)
    const merged = mergeRoleDraw(draws, key, name)
    const selectedUrl = merged?.selectedUrl?.trim() || ""
    if (!selectedUrl) return

    const type = toText((active as any)?.character_type).trim()
    const age = toText((active as any)?.age).trim()
    const occupation = toText((active as any)?.occupation).trim()
    const appearance = toText((active as any)?.appearance).trim()
    const physique = toText((active as any)?.physique).trim()
    const scriptSetting = toText((active as any)?.script_setting).trim()
    const pieces: string[] = []
    if (type) pieces.push(`类型：${type}`)
    if (age) pieces.push(`年龄：${age}`)
    if (occupation) pieces.push(`职业：${occupation}`)
    if (scriptSetting) pieces.push(`剧本人设：${scriptSetting}`)
    if (appearance) pieces.push(`相貌：${appearance}`)
    if (physique) pieces.push(`体格：${physique}`)
    const characterDescription = pieces.join("\n")

    const hairRaw = (active as any)?.hairstyle
    const clothingRaw = (active as any)?.clothing
    const hairList = normalizeVariantSpecs(hairRaw) ?? parseVariantSpecsFromText(String(hairRaw ?? ""))
    const clothingList = normalizeVariantSpecs(clothingRaw) ?? parseVariantSpecsFromText(String(clothingRaw ?? ""))
    const hairstyleOptions =
      hairList ??
      (String(hairRaw ?? "").trim()
        ? [{ name: "默认", description: String(hairRaw ?? "").trim(), tags: [] }]
        : [{ name: "默认", description: "", tags: [] }])
    const clothingOptions =
      clothingList ??
      (String(clothingRaw ?? "").trim()
        ? [{ name: "默认", description: String(clothingRaw ?? "").trim(), tags: [] }]
        : [{ name: "默认", description: "", tags: [] }])

    setDrawModal({
      characterKey: key,
      characterName: name,
      frontImageUrl: selectedUrl,
      characterDescription,
      hairstyleOptions,
      clothingOptions
    })
  }, [active, activeIndex, draws])

  return (
    <div className={styles.root}>
      <div className={styles.header}>
        <div className={styles.headerMain}>
          <div className={styles.title}>角色设定</div>
          <div className={styles.subTitle}>{isLocked ? "请先在剧本策划中确认并生成设定" : "可基于策划内容调整"}</div>
        </div>
        <div className={styles.headerActions}>
          {editing ? (
            <>
              <button type="button" className={styles.secondaryBtn} onClick={onCancelClick} disabled={saving}>
                取消
              </button>
              <button type="button" className={styles.primaryBtn} onClick={onSaveClick} disabled={saving}>
                {saving ? "保存中…" : "保存"}
              </button>
            </>
          ) : (
            <>
              <button type="button" className={styles.secondaryBtn} onClick={resetRoleSettingFromScriptBody} disabled={saving || resettingRoleSetting}>
                {resettingRoleSetting ? "重制中…" : "重制角色设定"}
              </button>
              <button type="button" className={styles.primaryBtn} onClick={onEditClick} disabled={isLocked}>
                编辑
              </button>
            </>
          )}
        </div>
      </div>

      {errorText ? <div className={styles.error}>{errorText}</div> : null}
      {resetRoleErrorText ? <div className={styles.error}>{resetRoleErrorText}</div> : null}
      {imagesError ? <div className={styles.error}>{imagesError}</div> : null}

      <div className={styles.characterBar} aria-label="角色列表">
        <div className={styles.characterTopRow}>
          <div className={styles.characterTabs}>
            {characters.length ? (
              <select
                className={styles.characterSelect}
                value={activeIndex}
                onChange={(e) => setActiveIndex(clampInt(Number(e.currentTarget.value), 0, characters.length - 1))}
              >
                {characters.map((c, idx) => {
                  const name = toText((c as any)?.character_name).trim() || `角色${idx + 1}`
                  return (
                    <option key={`${name}_${idx}`} value={idx}>
                      {name}
                    </option>
                  )
                })}
              </select>
            ) : (
              <div className={styles.placeholder}>暂无角色</div>
            )}
          </div>
          {!editing ? (
            <div className={styles.characterActions}>
              {(() => {
                const hasAll = characters.every((c, idx) => {
                  const name = getCharacterDisplayName(c, idx)
                  const key = getCharacterKey(c, idx)
                  return Boolean(mergeRoleDraw(draws, key, name)?.imageUrls?.length)
                })
                return (
                  <button
                    type="button"
                    className={styles.secondaryBtn}
                    onClick={() =>
                      void openRoleImageModelDialog({
                        scope: "all",
                        forceRegenerate: hasAll,
                        title: hasAll ? "重新生成全部角色图" : "生成全部角色图",
                        desc: hasAll ? "请选择本次重新生成要使用的图片模型。" : "请选择本次生成全部角色图要使用的图片模型。"
                      })
                    }
                    disabled={isLocked || saving || allRoleImageBusy || generatingCharacterKeys.size > 0 || characters.length === 0}
                  >
                    {allRoleImageBusy ? "生成中…" : hasAll ? "重新生成全部" : "生成全部角色图"}
                  </button>
                )
              })()}
            </div>
          ) : null}
        </div>
        {editing ? (
          <div className={styles.characterActions}>
            <button type="button" className={styles.secondaryBtn} onClick={onAddCharacter}>
              新增角色
            </button>
            <button type="button" className={styles.secondaryBtn} onClick={onRemoveActive} disabled={!characters.length}>
              删除当前
            </button>
          </div>
        ) : null}
      </div>

      {active ? (
        <div className={styles.grid}>
          <Section title="角色形象">
            <div className={styles.imagePanel}>
              {(() => {
                const name = getCharacterDisplayName(active, activeIndex)
                const key = getCharacterKey(active, activeIndex)
                const draw = mergeRoleDraw(draws, key, name)
                const selectedBase = (draw?.selectedUrlBase?.trim() || stripUrlQuery(draw?.selectedUrl?.trim() || "")).trim()
                const src = (() => {
                  if (!selectedBase) return ""
                  const urls = Array.isArray(draw?.imageUrls) ? draw?.imageUrls ?? [] : []
                  const hit = urls.find((u) => stripUrlQuery(String(u ?? "").trim()) === selectedBase)
                  return String(hit ?? draw?.selectedUrl ?? "").trim()
                })()
                const baseSrc = toCandidateSrc(src)
                if (!baseSrc) return <div className={styles.imagePlaceholder}>请从下方候选中选择角色图</div>
                return <ResolvedImageButton src={baseSrc} alt={name} className={styles.imageThumb} onPreview={(s) => openImagePreview({ src: s, alt: name })} />
              })()}
              <div className={styles.imageMeta}>
                <div className={styles.imageMetaTitle}>当前角色图</div>
                  <div className={styles.imageMetaDesc}>基于外形字段生成</div>
                <div className={styles.imageActions}>
                  {(() => {
                    const name = getCharacterDisplayName(active, activeIndex)
                    const key = getCharacterKey(active, activeIndex)
                    const has = Boolean(mergeRoleDraw(draws, key, name)?.imageUrls?.length)
                    const isGeneratingThis = generatingCharacterKeys.has(key)
                    return (
                      <button
                        type="button"
                        className={has ? `${styles.secondaryBtn} ${styles.dangerBtn}` : styles.secondaryBtn}
                        onClick={() =>
                          void openRoleImageModelDialog({
                            scope: "current",
                            forceRegenerate: has,
                            title: has ? "重新生成当前角色图" : "生成当前角色图",
                            desc: has ? "请选择本次重新生成当前角色图要使用的图片模型。" : "请选择本次生成当前角色图要使用的图片模型。"
                          })
                        }
                        disabled={isLocked || saving || allRoleImageBusy || isGeneratingThis}
                      >
                        {isGeneratingThis ? "生成中…" : has ? "重新生成当前" : "生成当前"}
                      </button>
                    )
                  })()}
                  <div className={styles.drawCountWrap}>
                    <div className={styles.drawCountLabel}>抽卡数</div>
                    <input
                      className={styles.drawCountInput}
                      type="number"
                      min={1}
                      max={5}
                      value={frontDrawCountText}
                      onChange={(e) => setFrontDrawCountText(e.currentTarget.value)}
                      onBlur={() => setFrontDrawCountText(String(clampInt(Number(frontDrawCountText), 1, 5)))}
                    />
                  </div>
                  {(() => {
                    const key = getCharacterKey(active, activeIndex)
                    const isGeneratingThis = generatingCharacterKeys.has(key)
                    return (
                      <>
                        <input
                          ref={uploadInputRef}
                          type="file"
                          accept="image/*"
                          className={styles.hiddenFileInput}
                          onChange={handleUploadFrontImageChange}
                          disabled={uploadingFrontImage}
                        />
                        <button
                          type="button"
                          className={styles.secondaryBtn}
                          onClick={() => uploadInputRef.current?.click()}
                          disabled={isLocked || saving || allRoleImageBusy || isGeneratingThis || uploadingFrontImage}
                        >
                          {uploadingFrontImage ? "上传中…" : "上传人物形象"}
                        </button>
                        <button
                          type="button"
                          className={styles.secondaryBtn}
                          onClick={openLibraryCharacterPicker}
                          disabled={isLocked || saving || allRoleImageBusy || isGeneratingThis}
                        >
                          使用资源库形象
                        </button>
                        <button
                          type="button"
                          className={styles.secondaryBtn}
                          onClick={openVirtualAvatarPicker}
                          disabled={isLocked || saving || allRoleImageBusy || isGeneratingThis}
                        >
                          使用虚拟形象
                        </button>
                        <button
                          type="button"
                          className={styles.secondaryBtn}
                          onClick={openAssetModalForActive}
                          disabled={
                            isLocked ||
                            saving ||
                            allRoleImageBusy ||
                            isGeneratingThis ||
                            !Boolean((() => {
                              const name = getCharacterDisplayName(active, activeIndex)
                              const key = getCharacterKey(active, activeIndex)
                              return mergeRoleDraw(draws, key, name)?.selectedUrl
                            })())
                          }
                        >
                          选择装造/服装
                        </button>
                      </>
                    )
                  })()}
                </div>
              </div>
            </div>
            {(() => {
              const name = getCharacterDisplayName(active, activeIndex)
              const key = getCharacterKey(active, activeIndex)
              const draw = mergeRoleDraw(draws, key, name)
              const urls = Array.isArray(draw?.imageUrls) ? draw?.imageUrls ?? [] : []
              if (urls.length === 0) return null
              const selectedBase = (draw?.selectedUrlBase?.trim() || stripUrlQuery(draw?.selectedUrl?.trim() || "")).trim()

              return (
                <div className={styles.imageDrawGrid} aria-label="抽卡结果">
                  {draw?.needsReselect ? <div className={styles.imageReselectHint}>当前形象图已重新生成，请重新选择</div> : null}
                  {urls.slice(0, 5).map((u, i) => (
                    (() => {
                      const uTrim = String(u ?? "").trim()
                      const baseSrc = toCandidateSrc(uTrim)
                      const isActive = Boolean(selectedBase && stripUrlQuery(uTrim) === selectedBase)
                      return (
                        <ResolvedImageCard
                          key={`${key}_${i}`}
                          src={baseSrc}
                          alt={`${name}_${i + 1}`}
                          active={isActive}
                          className={isActive ? `${styles.imageDrawCard} ${styles.imageDrawCardActive}` : styles.imageDrawCard}
                          imgClassName={styles.imageDrawImg}
                          onPreview={(src) => openImagePreview({ src, alt: `${name}_${i + 1}` })}
                          onSelect={() => {
                            void selectFrontImage(key, name, uTrim)
                          }}
                        />
                      )
                    })()
                  ))}
                </div>
              )
            })()}
          </Section>

        <Section title="音色设定">
          <div className={styles.voicePanel}>
            <div className={styles.voiceRow}>
              <div className={styles.voiceField}>
                <div className={styles.voiceLabel}>音色</div>
                <ListboxSelect
                  className={styles.voiceSelect}
                  value={voiceSpeakerId || defaultVoiceSpeakerId || ""}
                  ariaLabel="选择音色"
                  options={speakerOptions}
                  onChange={(v) => setVoiceSpeakerId(v)}
                  disabled={speakerOptions.length === 0 || isLocked}
                />
              </div>
              <div className={styles.voiceActions}>
                <button
                  type="button"
                  className={styles.secondaryBtn}
                  onClick={() => void requestVoicePreview()}
                  disabled={!active || !voiceSpeakerId.trim() || voicePreviewing || isLocked}
                >
                  {voicePreviewing ? "试听中…" : "试听"}
                </button>
                <button
                  type="button"
                  className={styles.primaryBtn}
                  onClick={() => void bindVoiceToCharacter()}
                  disabled={!active || !voiceSpeakerId.trim() || voiceBinding || isLocked || editing || saving}
                >
                  {voiceBinding ? "绑定中…" : "绑定"}
                </button>
              </div>
            </div>
            <div className={styles.voiceMeta}>
              <div className={styles.voiceMetaItem}>已绑定：{activeVoiceSpeakerName || "未绑定"}</div>
              <div className={styles.voiceMetaItem}>试听文案：{voicePreviewText}</div>
            </div>
            {voiceErrorText ? <div className={styles.error}>{voiceErrorText}</div> : null}
            {voicePreview?.src || boundVoiceSrc ? (
              <audio
                key={voicePreview?.src || boundVoiceSrc}
                className={styles.voiceAudio}
                src={voicePreview?.src || boundVoiceSrc}
                controls
                autoPlay={Boolean(voicePreview?.src)}
              />
            ) : null}
          </div>
        </Section>

          <Section title="基础信息">
            <div className={styles.kvGrid}>
              <SmallField
                label="姓名"
                value={toText((active as any)?.character_name)}
                editing={editing}
                placeholder="角色名"
                onChange={(v) => updateActive({ character_name: v })}
              />
              <SmallField
                label="类型"
                value={toText((active as any)?.character_type)}
                editing={editing}
                placeholder="如：女主/男主/反派"
                onChange={(v) => updateActive({ character_type: v })}
              />
              <SmallField label="年龄" value={toText((active as any)?.age)} editing={editing} onChange={(v) => updateActive({ age: v })} />
              <SmallField
                label="职业"
                value={toText((active as any)?.occupation)}
                editing={editing}
                onChange={(v) => updateActive({ occupation: v })}
              />
            </div>
          </Section>

          <Section title="人物小传">
            <TextField
              label="剧本人设"
              value={toText((active as any)?.script_setting)}
              editing={editing}
              rows={5}
              onChange={(v) => updateActive({ script_setting: v })}
            />
            <TextField
              label="性格"
              value={toText((active as any)?.personality)}
              editing={editing}
              rows={4}
              onChange={(v) => updateActive({ personality: v })}
            />
          </Section>

          <Section title="外形与包装">
            <TextField
              label="相貌"
              value={toText((active as any)?.appearance)}
              editing={editing}
              rows={4}
              onChange={(v) => updateActive({ appearance: v })}
            />
            <TextField
              label="体格"
              value={toText((active as any)?.physique)}
              editing={editing}
              rows={3}
              onChange={(v) => updateActive({ physique: v })}
            />
            {renderVariantList("hairstyle", "发型")}
            {renderVariantList("clothing", "服装")}
            <TextField
              label="封面描述"
              value={toText((active as any)?.cover_description)}
              editing={editing}
              rows={3}
              onChange={(v) => updateActive({ cover_description: v })}
            />
          </Section>

          <Section title="能力与缺点">
            <TextField
              label="特长/技能"
              value={toText((active as any)?.special_skills)}
              editing={editing}
              rows={4}
              onChange={(v) => updateActive({ special_skills: v })}
            />
            <TextField
              label="弱点"
              value={toText((active as any)?.weaknesses)}
              editing={editing}
              rows={4}
              onChange={(v) => updateActive({ weaknesses: v })}
            />
            <TextField
              label="口吻"
              value={toText((active as any)?.tone)}
              editing={editing}
              rows={4}
              onChange={(v) => updateActive({ tone: v })}
            />
          </Section>
        </div>
      ) : (
        <div className={styles.empty}>暂无可编辑角色</div>
      )}

      {drawModal ? (
        <RoleAssetDrawModal
          open={Boolean(drawModal)}
          onOpenChange={(open: boolean) => {
            if (open) return
            setDrawModal(null)
          }}
          storyId={storyId}
          characterKey={drawModal.characterKey}
          style={cozeStyle || undefined}
          savedSelection={(() => {
            const existed = mergeRoleDraw(draws, drawModal.characterKey, drawModal.characterName)
            const front = drawModal.frontImageUrl.trim()
            const frontBase = front ? front.split("?")[0] : ""
            const map = existed?.assetSelectionByFrontImageUrl && typeof existed.assetSelectionByFrontImageUrl === "object" ? existed.assetSelectionByFrontImageUrl : null
            const picked = front && map ? ((map as any)[front] ?? (frontBase ? (map as any)[frontBase] : null)) : null
            if (picked && typeof picked === "object") return picked as any
            const fallbackCharacterId = (existed?.assetSelection as any)?.characterId ?? null
            return fallbackCharacterId ? ({ characterId: fallbackCharacterId } as any) : undefined
          })()}
          onPersistSelection={(selection: NonNullable<RoleImageDrawState[string]["assetSelection"]>) => {
            const existed = mergeRoleDraw(draws, drawModal.characterKey, drawModal.characterName)
            const front = drawModal.frontImageUrl.trim()
            const frontBase = front ? front.split("?")[0] : ""
            const prevMap =
              existed?.assetSelectionByFrontImageUrl && typeof existed.assetSelectionByFrontImageUrl === "object" && !Array.isArray(existed.assetSelectionByFrontImageUrl)
                ? existed.assetSelectionByFrontImageUrl
                : {}
            const nextSel = { ...(selection as any), frontImageUrl: front }
            const nextMap = front
              ? { ...prevMap, [front]: nextSel, ...(frontBase && frontBase !== front ? { [frontBase]: nextSel } : {}) }
              : prevMap
            const nextCharacterId = typeof (selection as any)?.characterId === "string" ? String((selection as any).characterId).trim() : ""
            const prevCharacterId = typeof (existed?.assetSelection as any)?.characterId === "string" ? String((existed?.assetSelection as any).characterId).trim() : ""
            const mergedSelection = (nextCharacterId || prevCharacterId) ? ({ characterId: nextCharacterId || prevCharacterId } as any) : undefined
            const next: RoleImageDrawState = {
              ...draws,
              [drawModal.characterKey]: {
                prompt: existed?.prompt ?? "",
                imageUrls: existed?.imageUrls ?? [],
                selectedUrl: existed?.selectedUrl,
                selectedUrlBase: existed?.selectedUrlBase,
                selectedAssetId: existed?.selectedAssetId,
                needsReselect: existed?.needsReselect,
                assetSelection: mergedSelection,
                assetSelectionByFrontImageUrl: nextMap
              }
            }
            void patchRoleImageDraws(next)
          }}
          characterName={drawModal.characterName}
          characterDescription={drawModal.characterDescription}
          frontImageUrl={drawModal.frontImageUrl}
          hairstyleOptions={drawModal.hairstyleOptions}
          clothingOptions={drawModal.clothingOptions}
        />
      ) : null}
      {virtualAvatarOpen ? createPortal(
        <div
          className={styles.virtualAvatarOverlay}
          role="presentation"
          onClick={() => {
            if (virtualAvatarSaving) return
            setVirtualAvatarOpen(false)
          }}
        >
          <div
            className={styles.virtualAvatarModal}
            role="dialog"
            aria-modal="true"
            aria-label="选择虚拟形象"
            onClick={(e) => e.stopPropagation()}
          >
            <div className={styles.virtualAvatarHeader}>
              <div className={styles.virtualAvatarTitle}>选择虚拟形象</div>
              <button
                type="button"
                className={styles.virtualAvatarClose}
                onClick={() => {
                  if (virtualAvatarSaving) return
                  setVirtualAvatarOpen(false)
                }}
                disabled={virtualAvatarSaving}
              >
                ×
              </button>
            </div>
            <div className={styles.virtualAvatarForm}>
              <input
                ref={virtualAvatarInputRef}
                type="file"
                accept="image/*"
                className={styles.hiddenFileInput}
                onChange={handleVirtualAvatarFileChange}
                disabled={virtualAvatarSaving}
              />
              <div className={styles.virtualAvatarPreview}>
                {virtualAvatarImageUrl ? (
                  <img className={styles.virtualAvatarPreviewImg} src={virtualAvatarImageUrl} alt="虚拟形象" />
                ) : (
                  <div className={styles.virtualAvatarEmpty}>请上传人物形象</div>
                )}
              </div>
              <button
                type="button"
                className={styles.virtualAvatarUploadBtn}
                onClick={() => virtualAvatarInputRef.current?.click()}
                disabled={virtualAvatarSaving}
              >
                选择图片
              </button>
              <input
                className={styles.virtualAvatarAssetIdInput}
                placeholder="填写assetID"
                value={virtualAvatarAssetId}
                onChange={(e) => setVirtualAvatarAssetId(e.currentTarget.value)}
                disabled={virtualAvatarSaving}
              />
              {virtualAvatarError ? <div className={styles.virtualAvatarError}>{virtualAvatarError}</div> : null}
              <div className={styles.virtualAvatarActions}>
                <button
                  type="button"
                  className={styles.virtualAvatarAction}
                  onClick={() => void saveVirtualAvatarForActive()}
                  disabled={virtualAvatarSaving}
                >
                  {virtualAvatarSaving ? "保存中…" : "保存"}
                </button>
                <button
                  type="button"
                  className={styles.virtualAvatarGhost}
                  onClick={() => setVirtualAvatarOpen(false)}
                  disabled={virtualAvatarSaving}
                >
                  取消
                </button>
              </div>
            </div>
          </div>
        </div>,
        document.body
      ) : null}

      {libraryCharacterOpen ? createPortal(
        <div
          className={styles.virtualAvatarOverlay}
          role="presentation"
          onClick={() => {
            if (libraryCharacterSelecting) return
            setLibraryCharacterOpen(false)
          }}
        >
          <div
            className={styles.virtualAvatarModal}
            role="dialog"
            aria-modal="true"
            aria-label="使用资源库形象"
            onClick={(e) => e.stopPropagation()}
            style={{ width: "640px", maxWidth: "90vw", maxHeight: "80vh", display: "flex", flexDirection: "column" }}
          >
            <div className={styles.virtualAvatarHeader}>
              <div className={styles.virtualAvatarTitle}>使用资源库形象</div>
              <button
                type="button"
                className={styles.virtualAvatarClose}
                onClick={() => {
                  if (libraryCharacterSelecting) return
                  setLibraryCharacterOpen(false)
                }}
                disabled={libraryCharacterSelecting}
              >
                ×
              </button>
            </div>
            <div className={styles.virtualAvatarForm} style={{ flex: 1, overflow: "auto", padding: "16px" }}>
              {libraryCharacterError ? <div className={styles.error} style={{ marginBottom: "16px" }}>{libraryCharacterError}</div> : null}
              
              {libraryCharactersLoading ? (
                <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>加载资源库中...</div>
              ) : libraryCharacters.length === 0 ? (
                <div style={{ textAlign: "center", padding: "40px", color: "#666" }}>资源库暂无角色形象</div>
              ) : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))", gap: "16px" }}>
                  {libraryCharacters.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      disabled={libraryCharacterSelecting}
                      onClick={() => selectLibraryCharacter(c.id, c.previewUrl || c.originalUrl, c._looks, c._costumes)}
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "8px",
                        border: "1px solid #eee",
                        borderRadius: "8px",
                        padding: "8px",
                        background: "white",
                        cursor: libraryCharacterSelecting ? "not-allowed" : "transition",
                        transition: "all 0.2s",
                        opacity: libraryCharacterSelecting ? 0.6 : 1
                      }}
                    >
                      <div style={{ width: "100%", aspectRatio: "1/1", overflow: "hidden", borderRadius: "4px", backgroundColor: "#f5f5f5" }}>
                        <img 
                          src={c.previewUrl || c.originalUrl} 
                          alt={c.name} 
                          style={{ width: "100%", height: "100%", objectFit: "cover" }} 
                        />
                      </div>
                      <div style={{ fontSize: "14px", fontWeight: 500, color: "#333", textAlign: "center", width: "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {c.name || "未命名角色"}
                      </div>
                      <div style={{ fontSize: "12px", color: "#666", textAlign: "center" }}>
                        点击复用
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>,
        document.body
      ) : null}

      <RoleImageModelDialog
        open={roleImageModelDialogOpen}
        title={roleImageModelDialogTitle || "选择图片模型"}
        description={roleImageModelDialogDesc || "请选择本次生成角色图片要使用的模型。"}
        loading={roleImageModelLoading}
        submitting={roleImageModelSubmitting}
        errorText={roleImageModelError}
        kindOptions={roleImageModelKinds}
        selectedKind={roleImageModelKind}
        selectedModelName={roleImageModelName}
        items={roleImageModelItems}
        onOpenChange={(open) => {
          setRoleImageModelDialogOpen(open)
          if (!open) {
            pendingRoleImageActionRef.current = null
            setRoleImageModelSubmitting(false)
          }
        }}
        onChangeKind={(kind) => {
          setRoleImageModelKind(kind)
          const nextItems = roleImageModelItems.filter((item) => item.kind === kind)
          setRoleImageModelName(nextItems[0]?.modelName ?? "")
        }}
        onChangeModelName={setRoleImageModelName}
        onConfirm={() => {
          void submitRoleImageModelDialog()
        }}
      />

      <ConfirmModal
        open={confirmOpen}
        title={confirmTitle || "确认操作"}
        message={confirmDesc}
        confirmText="确认"
        cancelText="取消"
        onCancel={() => {
          setConfirmOpen(false)
          confirmActionRef.current = null
        }}
        onConfirm={() => {
          const act = confirmActionRef.current
          setConfirmOpen(false)
          confirmActionRef.current = null
          act?.()
        }}
      />
    </div>
  )
}
