import { formatMentionDisplayLabel, type QuickGenerateMentionItem, type QuickGenerateMentionKind } from "./quickGenerateMentions"

export type QuickGenerateMaterialPreview = {
  id: string
  title: string | null
  materialType: string
  sourceUrl: string | null
  voiceSpeakerId: string | null
  voiceSpeakerName: string | null
  metadata: unknown
}

export type OrderedReferencedMaterial = {
  orderNo: number
  token: string
  kind: QuickGenerateMentionKind
  name: string
  label: string
  previewUrl?: string
  material: QuickGenerateMaterialPreview | null
  removableAudio: boolean
}

function toMaterialLookupKey(kind: QuickGenerateMentionKind, name: string): string {
  return `${kind}:${String(name ?? "").trim()}`
}

function toTitleMaterialKind(kind: QuickGenerateMentionKind): string | null {
  if (kind === "role") return "character"
  if (kind === "scene") return "scene"
  if (kind === "item") return "prop"
  if (kind === "video") return "video"
  if (kind === "audio") return "audio"
  return null
}

/**
 * 根据提示词出现顺序构建“统一编号”的引用素材列表。
 *
 * 设计说明：
 * 1. 编号只依赖当前 prompt 的首次出现顺序，保证 prompt 胶囊与下方素材区严格一致；
 * 2. 音频引用仍追加在非音频素材之后，保持当前 quick-generate 的交互习惯；
 * 3. 每条记录同时携带可预览 material，避免 UI 层重复做多次查找。
 */
export function buildOrderedReferencedMaterials(input: {
  promptRefs: QuickGenerateMentionItem[]
  audioRefNames: string[]
  audioOptionNameSet: Set<string>
  materials: QuickGenerateMaterialPreview[]
}): OrderedReferencedMaterial[] {
  const byToken = new Map<string, OrderedReferencedMaterial>()
  const materialByLookup = new Map<string, QuickGenerateMaterialPreview>()
  const roleMaterialByVoiceName = new Map<string, QuickGenerateMaterialPreview>()

  for (const material of input.materials) {
    const title = String(material.title ?? "").trim()
    const type = String(material.materialType ?? "").trim()
    if (title) {
      const kind =
        type === "character" ? "role" :
        type === "scene" ? "scene" :
        type === "prop" ? "item" :
        type === "video" ? "video" :
        type === "audio" ? "audio" :
        null
      if (kind) {
        const key = toMaterialLookupKey(kind, title)
        if (!materialByLookup.has(key)) materialByLookup.set(key, material)
      }
    }

    if (type === "character") {
      const voiceName = String(material.voiceSpeakerName ?? "").trim()
      if (voiceName && !roleMaterialByVoiceName.has(voiceName)) roleMaterialByVoiceName.set(voiceName, material)
    }
  }

  const ordered: OrderedReferencedMaterial[] = []
  const append = (entry: Omit<OrderedReferencedMaterial, "orderNo">) => {
    if (byToken.has(entry.token)) return
    const next: OrderedReferencedMaterial = { ...entry, orderNo: ordered.length + 1 }
    ordered.push(next)
    byToken.set(entry.token, next)
  }

  for (const ref of input.promptRefs.filter((item) => item.kind !== "audio")) {
    const materialKind = toTitleMaterialKind(ref.kind)
    const material = materialKind ? materialByLookup.get(toMaterialLookupKey(ref.kind, ref.name)) ?? null : null
    append({
      token: ref.token,
      kind: ref.kind,
      name: ref.name,
      label: ref.label,
      previewUrl: ref.previewUrl,
      material,
      removableAudio: false
    })
  }

  input.audioRefNames
    .map((name, index) => ({ name: String(name ?? "").trim(), index }))
    .filter((entry) => entry.name && input.audioOptionNameSet.has(entry.name))
    .forEach((entry) => {
      const audioMaterial = materialByLookup.get(toMaterialLookupKey("audio", entry.name)) ?? roleMaterialByVoiceName.get(entry.name) ?? null
      append({
        token: `audio:${entry.index}:${entry.name}`,
        kind: "audio",
        name: entry.name,
        label: formatMentionDisplayLabel(entry.name, "audio"),
        previewUrl: undefined,
        material: audioMaterial,
        removableAudio: true
      })
    })

  return ordered
}

export function buildMentionOrderMap(items: OrderedReferencedMaterial[]): Record<string, number> {
  const map: Record<string, number> = {}
  for (const item of items) {
    if (item.token.startsWith("{{")) map[item.token] = item.orderNo
  }
  return map
}
