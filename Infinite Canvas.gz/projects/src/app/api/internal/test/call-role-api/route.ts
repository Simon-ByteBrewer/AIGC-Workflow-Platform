import { NextResponse } from "next/server"
import { readEnv } from "@/features/coze/env"
import { callCozeRunEndpoint, CozeRunEndpointError } from "@/features/coze/runEndpointClient"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"

export async function POST(req: Request): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()

  logger.info({
    event: "role_api_call_start",
    module: "role_api",
    traceId,
    message: "开始测试 ROLE_API 调用（内部测试接口）"
  })

  let json: unknown
  try {
    json = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "ROLE_API_INVALID_JSON", "请求体不是合法 JSON"), {
      status: 400
    })
  }

  const url = readEnv("ROLE_API_URL")
  const token = readEnv("ROLE_API_TOKEN")
  if (!url || !token) {
    return NextResponse.json(
      makeApiErr(
        traceId,
        "ROLE_API_NOT_CONFIGURED",
        "ROLE_API 未配置，请设置 ROLE_API_URL 与 ROLE_API_TOKEN"
      ),
      { status: 500 }
    )
  }

  try {
    logger.info({
      event: "role_api_call_request",
      module: "role_api",
      traceId,
      message: "调用 ROLE_API",
      url,
      bodyPreview: JSON.stringify(json).slice(0, 500)
    })

    const coze = await callCozeRunEndpoint({
      traceId,
      url,
      token,
      body: json,
      module: "role_api"
    })

    const durationMs = Date.now() - start
    logger.info({
      event: "role_api_call_success",
      module: "role_api",
      traceId,
      message: "ROLE_API 调用成功",
      durationMs,
      cozeStatus: coze.status,
      dataType: typeof coze.data,
      dataPreview: JSON.stringify(coze.data).slice(0, 500)
    })

    return NextResponse.json(makeApiOk(traceId, {
      success: true,
      durationMs,
      data: coze.data
    }), { status: 200 })
  } catch (err) {
    const durationMs = Date.now() - start
    if (err instanceof CozeRunEndpointError) {
      logger.error({
        event: "role_api_call_failed",
        module: "role_api",
        traceId,
        message: "ROLE_API 调用失败（Coze 调用失败）",
        durationMs,
        status: err.status,
        errorCode: err.errorCode,
        errorMessage: err.cozeMessage
      })
      return NextResponse.json(
        makeApiErr(traceId, "ROLE_API_REQUEST_FAILED", "ROLE_API 调用失败，请稍后重试"),
        { status: 502 }
      )
    }

    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "role_api_call_error",
      module: "role_api",
      traceId,
      message: "ROLE_API 调用异常",
      durationMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })

    return NextResponse.json(makeApiErr(traceId, "ROLE_API_UNKNOWN", "调用失败，请稍后重试"), {
      status: 500
    })
  }
}
