import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { CozeTtsClient } from "@/server/integrations/coze/ttsClient"
import { DEFAULT_TTS_TEST_TEXT } from "@/features/tts/speakers"

export const runtime = "nodejs"

const bodySchema = z.object({
  speakerId: z.string().trim().min(1).max(200),
  text: z.string().trim().min(1).max(1000).optional(),
  speed: z.number().min(0.5).max(2).optional()
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const tts = await CozeTtsClient.synthesize({
      text: parsed.data.text ?? DEFAULT_TTS_TEST_TEXT,
      speaker: parsed.data.speakerId,
      traceId,
      speed: parsed.data.speed
    })
    return NextResponse.json(makeApiOk(traceId, { audioUrl: tts.audioUrl, audioSize: tts.audioSize }), { status: 200 })
  } catch (e) {
    const msg = String((e as any)?.message ?? "")
    if (msg === "COZE_NOT_CONFIGURED") {
      return NextResponse.json(makeApiErr(traceId, "COZE_NOT_CONFIGURED", "语音服务未配置"), { status: 500 })
    }
    return NextResponse.json(makeApiErr(traceId, "TTS_PREVIEW_FAILED", "试听生成失败"), { status: 500 })
  }
}

