import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { enqueueVoiceoverAudioJob } from "@/server/domains/storyboard/jobs/voiceoverAudioWorker"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  scope: z.enum(["all", "episode"]),
  episodeNo: z.number().int().positive().optional(),
  speakerId: z.string().trim().min(1).max(200),
  speed: z.number().min(0.5).max(2).optional()
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  if (parsed.data.scope === "episode" && !parsed.data.episodeNo) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少 episodeNo"), { status: 400 })
  }

  const { jobId } = await enqueueVoiceoverAudioJob({
    userId,
    traceId,
    storyId: parsed.data.storyId,
    scope: parsed.data.scope,
    episodeNo: parsed.data.scope === "episode" ? parsed.data.episodeNo : undefined,
    speakerId: parsed.data.speakerId,
    speed: parsed.data.speed ?? 1
  })
  kickAllWorkers()

  return NextResponse.json(makeApiOk(traceId, { jobId }), { status: 202 })
}
