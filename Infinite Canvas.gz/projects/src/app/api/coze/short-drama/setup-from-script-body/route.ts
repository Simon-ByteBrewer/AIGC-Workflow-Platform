import { NextResponse } from "next/server"
import { z } from "zod"
import { readEnv } from "@/features/coze/env"
import { callCozeRunEndpoint, CozeRunEndpointError } from "@/features/coze/runEndpointClient"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { getSessionFromRequest } from "@/shared/session"
import type { NextRequest } from "next/server"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  video_type: z.enum(["premium", "commentary"]).optional(),
  script_body: z.string().trim().min(1).max(200_000)
})

export const runtime = "nodejs"

export async function POST(req: Request): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()

  logger.info({
    event: "coze_short_drama_setup_from_script_body_start",
    module: "coze",
    traceId,
    message: "开始从剧本正文生成短剧前置设定"
  })

  let json: unknown
  try {
    json = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "COZE_INVALID_JSON", "请求体不是合法 JSON"), {
      status: 400
    })
  }

  const parsed = inputSchema.safeParse(json)
  if (!parsed.success) {
    logger.warn({
      event: "coze_short_drama_setup_from_script_body_validation_failed",
      module: "coze",
      traceId,
      message: "从剧本正文生成短剧前置设定入参校验失败"
    })
    return NextResponse.json(makeApiErr(traceId, "COZE_VALIDATION_FAILED", "入参格式不正确"), {
      status: 400
    })
  }

  const url = readEnv("SHORT_DRAMA_SCRIPT_BODY_API_URL")
  const token = readEnv("SHORT_DRAMA_SCRIPT_BODY_API_TOKEN")
  if (!url || !token) {
    return NextResponse.json(
      makeApiErr(
        traceId,
        "COZE_NOT_CONFIGURED",
        "Coze 未配置，请设置 SHORT_DRAMA_SCRIPT_BODY_API_URL 与 SHORT_DRAMA_SCRIPT_BODY_API_TOKEN"
      ),
      { status: 500 }
    )
  }

  try {
    const session = await getSessionFromRequest(req as unknown as NextRequest)
    const userId = session?.userId
    if (!userId) {
      return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), {
        status: 401
      })
    }

    const coze = await callCozeRunEndpoint({
      traceId,
      url,
      token,
      body: {
        storyId: parsed.data.storyId,
        video_type: parsed.data.video_type ?? "commentary",
        script_body: parsed.data.script_body
      },
      module: "coze_short_drama_setup_from_script_body"
    })

    const durationMs = Date.now() - start
    logger.info({
      event: "coze_short_drama_setup_from_script_body_success",
      module: "coze",
      traceId,
      message: "从剧本正文生成短剧前置设定成功",
      durationMs,
      cozeStatus: coze.status
    })

    return NextResponse.json(makeApiOk(traceId, coze.data), { status: 200 })
  } catch (err) {
    const durationMs = Date.now() - start
    if (err instanceof CozeRunEndpointError) {
      logger.error({
        event: "coze_short_drama_setup_from_script_body_failed",
        module: "coze",
        traceId,
        message: "从剧本正文生成短剧前置设定失败（Coze 调用失败）",
        durationMs,
        status: err.status
      })
      return NextResponse.json(makeApiErr(traceId, "COZE_REQUEST_FAILED", "Coze 调用失败，请稍后重试"), { status: 502 })
    }

    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "coze_short_drama_setup_from_script_body_error",
      module: "coze",
      traceId,
      message: "从剧本正文生成短剧前置设定异常",
      durationMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })

    return NextResponse.json(makeApiErr(traceId, "COZE_UNKNOWN", "生成失败，请稍后重试"), { status: 500 })
  }
}
