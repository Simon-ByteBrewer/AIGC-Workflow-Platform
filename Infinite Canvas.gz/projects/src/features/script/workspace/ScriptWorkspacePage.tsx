
"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import type { ReactElement } from "react"
import { useRouter } from "next/navigation"
import styles from "./ScriptWorkspacePage.module.css"
import type { ScriptWorkspaceMode, OutlineItem } from "./utils"
import { OutlineNav } from "./components/OutlineNav"
import { PreviewPanel } from "./components/PreviewPanel"
import { ChatSidebar } from "./components/ChatSidebar"
import { WorkspaceResizeHandle } from "./components/WorkspaceResizeHandle"
import { useOutlineActions } from "./hooks/useOutlineActions"
import { useScriptRewrite } from "./hooks/useScriptRewrite"
import type { ApiErr, ApiOk } from "@/shared/api"
import { ProgressNav } from "@/shared/ui/ProgressNav"

type ScriptWorkspacePageProps = Readonly<{
  mode: ScriptWorkspaceMode
  storyId: string
  outline?: string
  view?: string
  outlines: ReadonlyArray<OutlineItem>
  storyMetadata?: Record<string, unknown>
  videoCategory: "premium" | "commentary"
}>

/**
 * 剧本创作工作区页面（与参考图保持结构一致）
 * @param {ScriptWorkspacePageProps} props - 组件属性
 * @param {ScriptWorkspaceMode} props.mode - 进入模式（source/brief）
 * @param {string} props.storyId - 故事 ID
 * @returns {ReactElement} 页面内容
 */
export function ScriptWorkspacePage({ mode, storyId, outline, view, outlines, storyMetadata, videoCategory }: ScriptWorkspacePageProps): ReactElement {
  const router = useRouter()
  const gridRef = useRef<HTMLDivElement | null>(null)
  const [isCompact, setIsCompact] = useState(false)
  const [chatOpen, setChatOpen] = useState(false)
  const hideChatSidebar = true
  const outlineIndex = (() => {
    const parsed = Number(outline)
    if (!Number.isFinite(parsed)) return 1
    if (parsed < 1) return 1
    return Math.trunc(parsed)
  })()

  const [localOutlines, setLocalOutlines] = useState<ReadonlyArray<OutlineItem>>(() => outlines.slice())
  const [localStoryMetadata, setLocalStoryMetadata] = useState<Record<string, unknown>>(() => (storyMetadata ?? {}) as Record<string, unknown>)

  useEffect(() => {
    setLocalOutlines(outlines.slice())
  }, [outlines])

  useEffect(() => {
    setLocalStoryMetadata(((storyMetadata ?? {}) as Record<string, unknown>) ?? {})
  }, [storyMetadata])

  useEffect(() => {
    const query = window.matchMedia("(max-width: 1023px)")
    const sync = () => setIsCompact(query.matches)
    sync()
    query.addEventListener("change", sync)
    return () => query.removeEventListener("change", sync)
  }, [])

  useEffect(() => {
    if (!isCompact || hideChatSidebar) setChatOpen(false)
  }, [hideChatSidebar, isCompact])

  const activeOutline = localOutlines.find((o) => o.sequence === outlineIndex) ?? localOutlines[0] ?? null

  const initialPreviewMode = useMemo(() => {
    const v = typeof view === "string" ? view.trim().toLowerCase() : ""
    const hasScriptBody = Boolean((storyMetadata as any)?.shortDrama?.scriptBody || (storyMetadata as any)?.shortDrama?.scriptBodyRef)
    if (v === "body" || v === "rewrite" || v === "outline") return v as "body" | "rewrite" | "outline"
    if (v === "original") return "outline"
    return hasScriptBody ? "body" : "outline"
  }, [storyMetadata, view])

  const activeDraft = useMemo(() => {
    if (!activeOutline) return null
    const drafts = Array.isArray(activeOutline.outlineDrafts) ? activeOutline.outlineDrafts : []
    const activeId = (activeOutline.activeOutlineDraftId ?? "").trim()
    if (activeId) return drafts.find((d) => d.id === activeId) ?? drafts[drafts.length - 1] ?? null
    return drafts[drafts.length - 1] ?? null
  }, [activeOutline])

  const {
    deleting,
    confirmDeleteOutlineIds,
    setConfirmDeleteOutlineIds,
    handleDeleteOutline,
    handleBatchDeleteOutlines,
    persistOutlineDraft,
    toast,
    setToast,
    selectedOutlineIds,
    toggleSelected,
    clearSelection,
    selectAll
  } = useOutlineActions({ outlines: localOutlines, setLocalOutlines, setLocalStoryMetadata })

  const {
    rewriteRequirements,
    setRewriteRequirements,
    rewriteBySeq,
    rewriteMessages,
    previewMode,
    setPreviewMode,
    handleRewrite,
    isRewriteStreaming,
    activeRewrite,
    threadRef,
    shouldAutoScrollRef
  } = useScriptRewrite({ storyId, activeOutline, persistOutlineDraft, setToast, initialPreviewMode })

  const hasPersistedRewrite = Boolean(activeDraft?.content?.trim())
  const canShowRewrite = Boolean(
    hasPersistedRewrite || (activeRewrite && (activeRewrite.status === "streaming" || activeRewrite.status === "done"))
  )

  const [generatingStoryboard, setGeneratingStoryboard] = useState(false)
  const [generatingScriptBody, setGeneratingScriptBody] = useState(false)
  const [scriptBodyJobId, setScriptBodyJobId] = useState<string | null>(null)
  const [scriptBodyJobStage, setScriptBodyJobStage] = useState<string | null>(null)
  const SCRIPT_BODY_JOB_TYPE = "coze_generate_script_body"

  const replaceViewInUrl = useCallback(
    (nextView: "outline" | "rewrite" | "body") => {
      try {
        const qs = new URLSearchParams(window.location.search)
        qs.set("view", nextView)
        router.replace(`${window.location.pathname}?${qs.toString()}`)
      } catch {
        return
      }
    },
    [router]
  )

  const setPreviewModeWithUrl = useCallback(
    (next: "outline" | "rewrite" | "body") => {
      setPreviewMode(next)
      replaceViewInUrl(next)
    },
    [replaceViewInUrl, setPreviewMode]
  )

  useEffect(() => {
    if (typeof view === "string" && view.trim()) return
    replaceViewInUrl(initialPreviewMode)
  }, [initialPreviewMode, replaceViewInUrl, view])

  // 只负责进入分镜创作页，具体生成由用户在下一步手动触发。
  const handleGenerateStoryboardText = useCallback(async () => {
    if (!activeOutline) return
    if (generatingStoryboard) return
    setGeneratingStoryboard(true)
    try {
      const outlineId = activeOutline.outlineId
      router.push(
        `/video/storyboard/description?storyId=${encodeURIComponent(storyId)}&outlineId=${encodeURIComponent(outlineId)}`
      )
    } catch (e) {
      const anyErr = e as { message?: string }
      setToast({ type: "error", message: anyErr?.message ?? "生成失败，请稍后重试" })
    } finally {
      setGeneratingStoryboard(false)
    }
  }, [activeOutline, generatingStoryboard, router, storyId, setToast])

  const handleOpenCanvasCreation = useCallback(() => {
    if (!activeOutline) return
    const qs = new URLSearchParams()
    qs.set("storyId", storyId)
    qs.set("outlineId", activeOutline.outlineId)
    router.push(`/video/canvas?${qs.toString()}`)
  }, [activeOutline, router, storyId])

  const scriptBody = useMemo(() => {
    const shortDrama = (localStoryMetadata as any)?.shortDrama
    if (!shortDrama || typeof shortDrama !== "object") {
      console.log('[ScriptWorkspacePage] scriptBody: shortDrama not found or invalid', { shortDrama })
      return null
    }
    const v = (shortDrama as any).scriptBody
    console.log('[ScriptWorkspacePage] scriptBody:', v)
    console.log('[ScriptWorkspacePage] scriptBody.episodes:', v?.episodes)
    return v ?? null
  }, [localStoryMetadata])

  const scriptBodyRefExists = useMemo(() => {
    const shortDrama = (localStoryMetadata as any)?.shortDrama
    if (!shortDrama || typeof shortDrama !== "object") return false
    const ref = (shortDrama as any)?.scriptBodyRef
    const key = ref && typeof ref === "object" ? String((ref as any)?.storageKey ?? "").trim() : ""
    return Boolean(key)
  }, [localStoryMetadata])

  const voiceoverAudios = useMemo(() => {
    const shortDrama = (localStoryMetadata as any)?.shortDrama
    if (!shortDrama || typeof shortDrama !== "object") return null
    const v = (shortDrama as any).voiceoverAudios
    if (!v || typeof v !== "object" || Array.isArray(v)) return null
    return v as Record<string, unknown>
  }, [localStoryMetadata])

  const voiceoverTts = useMemo(() => {
    const shortDrama = (localStoryMetadata as any)?.shortDrama
    if (!shortDrama || typeof shortDrama !== "object") return null
    const v = (shortDrama as any).voiceoverTts
    if (!v || typeof v !== "object" || Array.isArray(v)) return null
    return v as Record<string, unknown>
  }, [localStoryMetadata])

  const manualTexts = useMemo(() => {
    const shortDrama = (localStoryMetadata as any)?.shortDrama
    if (!shortDrama || typeof shortDrama !== "object") return null
    const v = (shortDrama as any).manualTexts
    if (!v || typeof v !== "object" || Array.isArray(v)) return null
    return v as Record<string, unknown>
  }, [localStoryMetadata])

  const refreshStoryMetadata = useCallback(async (): Promise<boolean> => {
    try {
      const res = await fetch(`/api/library/stories/${encodeURIComponent(storyId)}/detail`, { cache: "no-store" })
      const json = (await res.json().catch(() => null)) as ApiOk<{ story?: { metadata?: Record<string, unknown> } }> | ApiErr | null
      console.log('[ScriptWorkspacePage] refreshStoryMetadata response:', json)
      if (!res.ok || !json?.ok) {
        console.log('[ScriptWorkspacePage] refreshStoryMetadata failed:', { ok: res.ok, json })
        return false
      }
      const next = (json.data as any)?.story?.metadata
      console.log('[ScriptWorkspacePage] refreshStoryMetadata metadata:', next)
      console.log('[ScriptWorkspacePage] refreshStoryMetadata shortDrama:', next?.shortDrama)
      console.log('[ScriptWorkspacePage] refreshStoryMetadata scriptBody:', next?.shortDrama?.scriptBody)
      if (next && typeof next === "object" && !Array.isArray(next)) {
        setLocalStoryMetadata(next as Record<string, unknown>)
        console.log('[ScriptWorkspacePage] refreshStoryMetadata success, setLocalStoryMetadata called')
        return true
      }
      return false
    } catch (error) {
      console.log('[ScriptWorkspacePage] refreshStoryMetadata error:', error)
      return false
    }
  }, [storyId])

  const scriptBodyInput = useMemo(() => {
    const normalizeLine = (line: string) => line.replace(/[\u200B-\u200D\uFEFF]/g, "").trim()
    const isEpisodeLine = (l: string) => /^第\s*\d+\s*集/u.test(l)
    const pickObject = (v: unknown): Record<string, unknown> | null => {
      if (!v || typeof v !== "object" || Array.isArray(v)) return null
      return v as Record<string, unknown>
    }
    const normalizeOutlineJson = (v: unknown): Record<string, unknown> | null => {
      const obj = pickObject(v)
      if (!obj) return null
      const nested = pickObject((obj as any).outline_json)
      return nested ?? obj
    }
    const normalizeSixStageOutlineKeys = (outlineJson: Record<string, unknown> | null): Record<string, unknown> | null => {
      const root = pickObject(outlineJson)
      if (!root) return outlineJson
      const six = pickObject((root as any).six_stage_outline)
      if (!six) return outlineJson

      const stageKeyFromStageName = (name: string) => {
        const n = name.trim()
        if (!n) return ""
        const map: Array<[string, string]> = [
          ["起", "qi"],
          ["困", "kun"],
          ["升", "sheng"],
          ["反", "fan"],
          ["爽", "shuang"],
          ["合", "he"],
          ["结", "jie"]
        ]
        for (const [ch, key] of map) {
          if (n.includes(ch)) return key
        }
        return ""
      }

      const nextSix: Record<string, unknown> = {}
      const pushStage = (k: string, stage: Record<string, unknown>) => {
        const prev = pickObject(nextSix[k])
        if (!prev) {
          nextSix[k] = stage
          return
        }
        const prevEpisodes = Array.isArray((prev as any).episodes) ? ((prev as any).episodes as Array<unknown>) : []
        const nextEpisodes = Array.isArray((stage as any).episodes) ? ((stage as any).episodes as Array<unknown>) : []
        const merged = [...prevEpisodes, ...nextEpisodes]
        const dedup = new Map<number, unknown>()
        for (const e of merged) {
          const ep = pickObject(e)
          const n = Number(ep ? (ep as any).episode : NaN)
          if (!Number.isFinite(n)) continue
          dedup.set(Math.trunc(n), e)
        }
        const ordered = Array.from(dedup.entries())
          .sort((a, b) => a[0] - b[0])
          .map(([, v]) => v)

        nextSix[k] = {
          ...prev,
          ...stage,
          stage_name: typeof (prev as any).stage_name === "string" && (prev as any).stage_name.trim() ? (prev as any).stage_name : (stage as any).stage_name,
          episode_range:
            typeof (prev as any).episode_range === "string" && (prev as any).episode_range.trim()
              ? (prev as any).episode_range
              : (stage as any).episode_range,
          core_goal: typeof (prev as any).core_goal === "string" && (prev as any).core_goal.trim() ? (prev as any).core_goal : (stage as any).core_goal,
          episodes: ordered
        }
      }

      for (const [k, v] of Object.entries(six)) {
        const stage = pickObject(v)
        if (!stage) continue
        const name = typeof (stage as any).stage_name === "string" ? (stage as any).stage_name : ""
        const mapped = name ? stageKeyFromStageName(name) : ""
        const nextKey = mapped || k
        pushStage(nextKey, stage)
      }

      return { ...root, six_stage_outline: nextSix }
    }
    const stageKeyFromName = (name: string) => {
      const n = name.trim()
      if (!n) return ""
      const map: Array<[string, string]> = [
        ["起", "qi"],
        ["困", "kun"],
        ["升", "sheng"],
        ["反", "fan"],
        ["爽", "shuang"],
        ["合", "he"],
        ["结", "jie"]
      ]
      for (const [ch, key] of map) {
        if (n.includes(ch)) return key
      }
      return ""
    }

    const buildOutlineJsonFromOutlines = (): Record<string, unknown> | null => {
      if (!localOutlines.length) return null

      const parse = (text: string) => {
        const lines = text.replaceAll("\r\n", "\n").split("\n").map(normalizeLine).filter(Boolean)
        const pick = (key: string) => {
          const line = lines.find((l) => l.startsWith(`${key}：`) || l.startsWith(`${key}:`))
          if (!line) return ""
          return line.replace(/^.*[:：]\s*/u, "").trim()
        }
        const stageRaw = pick("阶段")
        const stageGoal = pick("阶段目标")
        const stageRangeMatch = stageRaw.match(/（([^）]+)）/u)
        const episodeRange = stageRangeMatch?.[1]?.trim() ?? ""
        const stageName = stageRaw.replace(/（[^）]+）/u, "").trim()

        const episodeIdx = lines.findIndex((l) => isEpisodeLine(l))
        const episodeNum = (() => {
          if (episodeIdx < 0) return null
          const m = lines[episodeIdx]?.match(/\d+/u)
          if (!m?.[0]) return null
          const n = Number(m[0])
          return Number.isFinite(n) ? Math.trunc(n) : null
        })()
        const corePlot = episodeIdx >= 0 ? lines.slice(episodeIdx + 1).join("\n").trim() : ""
        return {
          scriptName: pick("剧名"),
          theme: pick("主题"),
          coreConflict: pick("核心冲突"),
          stageName,
          episodeRange,
          stageGoal,
          episodeNum,
          corePlot
        }
      }

      const parsed = localOutlines.map((o) => {
        const base = parse(o.originalText || "")
        const fallbackPlot = (o.originalText || o.outlineText || "").trim()
        return {
          sequence: o.sequence,
          ...base,
          episodeNum: base.episodeNum ?? o.sequence,
          corePlot: base.corePlot || fallbackPlot
        }
      })

      const metaFrom = parsed.find((p) => p.scriptName || p.theme || p.coreConflict) ?? null
      const outline_meta = {
        script_name: metaFrom?.scriptName || storyId,
        total_episodes: Math.max(...parsed.map((p) => p.episodeNum ?? p.sequence), 0),
        theme: metaFrom?.theme || "",
        core_conflict: metaFrom?.coreConflict || ""
      }

      const six_stage_outline: Record<string, unknown> = {}
      const stageOrder: string[] = []
      for (const item of parsed) {
        const name = item.stageName || "阶段"
        const key = stageKeyFromName(name) || (() => `stage_${stageOrder.length + 1}`)()
        if (!six_stage_outline[key]) {
          stageOrder.push(key)
          six_stage_outline[key] = {
            stage_name: name,
            episode_range: item.episodeRange || "",
            core_goal: item.stageGoal || "",
            episodes: [] as Array<{ episode: number; core_plot: string }>
          }
        }
        const stageObj = six_stage_outline[key] as any
        const list = Array.isArray(stageObj.episodes) ? stageObj.episodes : []
        stageObj.episodes = list
        list.push({ episode: item.episodeNum ?? item.sequence, core_plot: item.corePlot })
      }

      return { outline_meta, six_stage_outline }
    }

    const shortDrama = (localStoryMetadata as any)?.shortDrama
    if (!shortDrama || typeof shortDrama !== "object") return null
    const candidate = normalizeSixStageOutlineKeys(normalizeOutlineJson((shortDrama as any).outlineJson))
    const hasSixStage = Boolean(candidate && pickObject(candidate) && pickObject((candidate as any).six_stage_outline))
    return {
      planning_result: (shortDrama as any).planningResult ?? null,
      world_setting: (shortDrama as any).worldSetting ?? null,
      character_settings: (shortDrama as any).characterSetting ?? null,
      outline_json: (hasSixStage ? candidate : buildOutlineJsonFromOutlines()) ?? null
    }
  }, [localOutlines, localStoryMetadata, storyId])

  const handleGenerateScriptBody = useCallback(async () => {
    if (!activeOutline) return
    if (generatingScriptBody) return
    setGeneratingScriptBody(true)
    try {
      const res = await fetch("/api/coze/storyboard/generate-script-body", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ storyId, ...scriptBodyInput, video_type: videoCategory, async: true })
      })
      const json = (await res.json().catch(() => null)) as ApiOk<any> | ApiErr | null
      if (!res.ok || !json || (json as ApiErr).ok === false) {
        const errJson = (json as ApiErr | null) ?? null
        const trace = errJson?.traceId ? `（traceId: ${errJson.traceId}）` : ""
        throw new Error(`${errJson?.error?.message ?? "生成正文失败，请稍后重试"}${trace}`)
      }
      const jobIdRaw = (json as ApiOk<any>).data?.jobId
      const jobId = typeof jobIdRaw === "string" ? jobIdRaw.trim() : ""
      if (!jobId) throw new Error("生成任务入队失败，请稍后重试")
      setScriptBodyJobId(jobId)
      setScriptBodyJobStage("queued")
      try {
        window.dispatchEvent(new Event("open_task_center"))
      } catch {}
      setToast({ type: "success", message: `已加入任务队列（jobId: ${jobId}），可在任务中心查看进度` })
    } catch (e) {
      const anyErr = e as { message?: string }
      setToast({ type: "error", message: anyErr?.message ?? "生成正文失败，请稍后重试" })
      setGeneratingScriptBody(false)
    } finally {
    }
  }, [activeOutline, generatingScriptBody, scriptBodyInput, setToast, storyId, videoCategory])

  useEffect(() => {
    const sid = storyId.trim()
    if (!sid) return
    let cancelled = false
    const tick = async () => {
      if (cancelled) return
      if (typeof document !== "undefined" && document.hidden) return
      try {
        const qs = new URLSearchParams({ storyId: sid, activeOnly: "true", limit: "20" })
        const res = await fetch(`/api/jobs?${qs.toString()}`, { method: "GET", cache: "no-store" })
        const json = (await res.json().catch(() => null)) as ApiOk<{ jobs?: any[] }> | ApiErr | null
        if (!res.ok || !json?.ok) return
        const jobs = Array.isArray((json as any)?.data?.jobs) ? ((json as any).data.jobs as any[]) : []
        const active = jobs.filter((j) => (j?.status === "queued" || j?.status === "running") && j?.type === SCRIPT_BODY_JOB_TYPE)
        const jid = active.length ? String(active[0]?.jobId ?? "").trim() : ""
        const snap = active.length && active[0] && typeof active[0] === "object" ? (active[0] as any).snapshot : null
        const stage = snap && typeof snap === "object" ? String((snap as any)?.stage ?? "").trim() : ""
        if (jid) {
          setScriptBodyJobId((prev) => prev || jid)
          setGeneratingScriptBody(true)
          setScriptBodyJobStage(stage || null)
        } else if (!scriptBodyJobId) {
          setGeneratingScriptBody(false)
          setScriptBodyJobStage(null)
        }
      } catch {}
    }
    void tick()
    const interval = window.setInterval(() => void tick(), 1500)
    return () => {
      cancelled = true
      window.clearInterval(interval)
    }
  }, [scriptBodyJobId, storyId])

  useEffect(() => {
    if (!scriptBodyJobId) return
    let cancelled = false
    const tick = async () => {
      try {
        const res = await fetch(`/api/jobs/${encodeURIComponent(scriptBodyJobId)}`, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as ApiOk<{ status?: string; snapshot?: any }> | ApiErr | null
        if (!res.ok || !json?.ok) throw new Error((json as any)?.error?.message ?? `HTTP ${res.status}`)
        if (cancelled) return
        const status = String((json as any)?.data?.status ?? "").trim()
        const snap = (json as any)?.data?.snapshot
        const stage = snap && typeof snap === "object" ? String((snap as any)?.stage ?? "").trim() : ""
        setScriptBodyJobStage(stage || null)
        if (status === "done") {
          console.log('[ScriptWorkspacePage] Job done, calling refreshStoryMetadata')
          setScriptBodyJobId(null)
          setScriptBodyJobStage(null)
          setGeneratingScriptBody(false)
          const refreshed = await refreshStoryMetadata()
          console.log('[ScriptWorkspacePage] refreshStoryMetadata returned:', refreshed)
          setPreviewModeWithUrl("body")
          router.refresh()
          setToast({
            type: refreshed ? "success" : "error",
            message: refreshed ? "剧本正文已生成" : "任务已完成，但页面刷新失败，请手动刷新页面查看正文"
          })
          return
        }
        if (status === "error") {
          const errMsg = snap && typeof snap === "object" && typeof (snap as any)?.errorMessage === "string" ? String((snap as any).errorMessage) : ""
          setScriptBodyJobId(null)
          setScriptBodyJobStage(null)
          setGeneratingScriptBody(false)
          setToast({ type: "error", message: errMsg || "生成正文失败，请稍后重试" })
          return
        }
      } catch {
        if (cancelled) return
      }
      if (!cancelled) setTimeout(() => void tick(), 2000)
    }
    void tick()
    return () => {
      cancelled = true
    }
  }, [refreshStoryMetadata, router, scriptBodyJobId, setPreviewModeWithUrl, setToast])

  return (
    <main className={styles.main}>
      <ProgressNav
        activeKey="script_body"
        steps={[
          { key: "script_setup", label: "剧本设置", href: `/script/short-drama/${encodeURIComponent(storyId)}` },
          { key: "script_body", label: "剧本正文", href: `/script/workspace/${encodeURIComponent(storyId)}?mode=${encodeURIComponent(mode)}` },
          {
            key: "storyboard_desc",
            label: "分镜描述",
            href: `/video/storyboard/description?${(() => {
              const qs = new URLSearchParams()
              qs.set("storyId", storyId)
              if (activeOutline?.outlineId) qs.set("outlineId", activeOutline.outlineId)
              return qs.toString()
            })()}`
          },
          {
            key: "storyboard_frames",
            label: "分镜镜头",
            href: `/video/storyboard/frames?${(() => {
              const qs = new URLSearchParams()
              qs.set("storyId", storyId)
              if (activeOutline?.outlineId) qs.set("outlineId", activeOutline.outlineId)
              return qs.toString()
            })()}`
          },
          {
            key: "storyboard_videos",
            label: "分镜视频",
            href: `/video/storyboard/videos?${(() => {
              const qs = new URLSearchParams()
              qs.set("storyId", storyId)
              if (activeOutline?.outlineId) qs.set("outlineId", activeOutline.outlineId)
              return qs.toString()
            })()}`
          },
        ]}
      />
      <section className={styles.gridFrame}>
        <div
          className={
            isCompact
              ? `${styles.grid} ${styles.gridCompact}`
              : hideChatSidebar
                ? `${styles.grid} ${styles.gridChatHidden}`
                : styles.grid
          }
          ref={gridRef}
        >
          <OutlineNav
            outlines={localOutlines}
            activeOutline={activeOutline}
            rewriteBySeq={rewriteBySeq}
            storyId={storyId}
            mode={mode}
            deleting={deleting}
            selectedOutlineIds={selectedOutlineIds}
            toggleSelected={toggleSelected}
            clearSelection={clearSelection}
            selectAll={selectAll}
            setConfirmDeleteOutlineIds={(ids) => setConfirmDeleteOutlineIds(ids)}
          />

          <PreviewPanel
            activeOutline={activeOutline}
            previewMode={previewMode}
            setPreviewMode={setPreviewModeWithUrl}
            canShowRewrite={canShowRewrite}
            activeRewrite={activeRewrite}
            activeDraft={activeDraft}
            generatingStoryboard={generatingStoryboard}
            handleGenerateStoryboardText={handleGenerateStoryboardText}
            handleOpenCanvasCreation={handleOpenCanvasCreation}
            storyId={storyId}
            scriptBody={scriptBody}
            scriptBodyRefExists={scriptBodyRefExists}
            voiceoverAudios={voiceoverAudios}
            voiceoverTts={voiceoverTts}
            manualTexts={manualTexts}
            refreshStoryMetadata={refreshStoryMetadata}
            generatingScriptBody={generatingScriptBody}
            generatingScriptBodyStage={scriptBodyJobStage}
            handleGenerateScriptBody={handleGenerateScriptBody}
            videoCategory={videoCategory}
          />

          {!isCompact && !hideChatSidebar ? <WorkspaceResizeHandle containerRef={gridRef} /> : null}

          {!isCompact && !hideChatSidebar ? (
            <ChatSidebar
              rewriteMessages={rewriteMessages}
              rewriteRequirements={rewriteRequirements}
              setRewriteRequirements={setRewriteRequirements}
              handleRewrite={handleRewrite}
              activeOutline={activeOutline}
              isRewriteStreaming={isRewriteStreaming}
              toast={toast}
              threadRef={threadRef}
              onScrollThread={() => {
                const el = threadRef.current
                if (!el) return
                const threshold = 24
                const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold
                shouldAutoScrollRef.current = atBottom
              }}
            />
          ) : null}
        </div>
      </section>

      {isCompact && !hideChatSidebar ? (
        <>
          <button type="button" className={styles.chatFab} onClick={() => setChatOpen(true)}>
            对话
          </button>
          {chatOpen ? (
            <div
              className={styles.drawerBackdrop}
              role="dialog"
              aria-modal="true"
              aria-label="对话助手"
              onMouseDown={(e) => {
                if (e.target === e.currentTarget) setChatOpen(false)
              }}
            >
              <div className={`${styles.drawer} ${styles.drawerRight}`}>
                <ChatSidebar
                  variant="drawer"
                  onClose={() => setChatOpen(false)}
                  rewriteMessages={rewriteMessages}
                  rewriteRequirements={rewriteRequirements}
                  setRewriteRequirements={setRewriteRequirements}
                  handleRewrite={handleRewrite}
                  activeOutline={activeOutline}
                  isRewriteStreaming={isRewriteStreaming}
                  toast={toast}
                  threadRef={threadRef}
                  onScrollThread={() => {
                    const el = threadRef.current
                    if (!el) return
                    const threshold = 24
                    const atBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - threshold
                    shouldAutoScrollRef.current = atBottom
                  }}
                />
              </div>
            </div>
          ) : null}
        </>
      ) : null}

      {confirmDeleteOutlineIds && confirmDeleteOutlineIds.length > 0 ? (
        <div
          className={styles.modalOverlay}
          role="dialog"
          aria-modal="true"
          aria-label="确认删除"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setConfirmDeleteOutlineIds(null)
          }}
        >
          <div className={styles.modal}>
            <div className={styles.modalTitle}>
              {confirmDeleteOutlineIds.length === 1 ? "删除该章节？" : `删除这 ${confirmDeleteOutlineIds.length} 个章节？`}
            </div>
            <div className={styles.modalDesc}>将同时删除该章节的原文与分镜数据，且无法恢复。</div>
            <div className={styles.modalActions}>
              <button
                type="button"
                className={styles.modalButton}
                onClick={() => setConfirmDeleteOutlineIds(null)}
                disabled={deleting}
              >
                取消
              </button>
              <button
                type="button"
                className={`${styles.modalButton} ${styles.modalButtonDanger}`}
                onClick={() => {
                  const ids = confirmDeleteOutlineIds
                  setConfirmDeleteOutlineIds(null)
                  if (ids.length === 1) void handleDeleteOutline(ids[0]!)
                  else void handleBatchDeleteOutlines(ids)
                }}
                disabled={deleting}
              >
                删除
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  )
}
