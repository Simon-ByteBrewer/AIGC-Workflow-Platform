import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { eq, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { userSecurity, users } from "@/shared/schema"
import { canManageTargetUser, requireAdminActor } from "@/server/domains/admin/services/adminRole"

export const runtime = "nodejs"

const bodySchema = z.object({
  confirmAccount: z.string().trim().min(1).max(100)
})

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor

  const { id } = await ctx.params
  const parsed = bodySchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ users, userSecurity })

  const rows = await db
    .select({
      id: users.id,
      account: users.name,
      email: users.email,
      isActive: users.isActive,
      roleKey: userSecurity.roleKey,
      groupId: userSecurity.groupId
    })
    .from(users)
    .leftJoin(userSecurity, eq(userSecurity.userId, users.id))
    .where(eq(users.id, id))
    .limit(1)

  const user = rows[0]
  if (!user?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "账号不存在"), { status: 404 })
  if (!canManageTargetUser(actor, { groupId: user.groupId ?? null })) {
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限操作该账号"), { status: 403 })
  }
  if (actor.roleKey === "group_admin" && (user.roleKey ?? "user") !== "user") {
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "组管理员只能管理组员账号"), { status: 403 })
  }

  if (parsed.data.confirmAccount !== user.account) {
    return NextResponse.json(makeApiErr(traceId, "CONFIRM_MISMATCH", "确认账号不匹配"), { status: 400 })
  }

  await db.update(users).set({ isActive: true, updatedAt: new Date() }).where(eq(users.id, id))

  const now = new Date()
  await db
    .insert(userSecurity)
    .values({ userId: id, tokenVersion: 2, disabledAt: null, disabledReason: null, updatedAt: now })
    .onConflictDoUpdate({
      target: userSecurity.userId,
      set: {
        tokenVersion: sql`${userSecurity.tokenVersion} + 1`,
        disabledAt: null,
        disabledReason: null,
        updatedAt: now
      }
    })

  await db.execute(sql`
    insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
    values (
      ${actor.userId},
      'user.enable',
      'user',
      ${id},
      ${id},
      ${JSON.stringify({ id, account: user.account, email: user.email, isActive: user.isActive })}::jsonb,
      ${JSON.stringify({ id, account: user.account, email: user.email, isActive: true })}::jsonb,
      ${actor.ip},
      ${actor.userAgent},
      ${traceId}
    )
  `)

  return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
}
