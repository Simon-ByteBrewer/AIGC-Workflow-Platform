import { Suspense } from "react"
import { cookies } from "next/headers"
import { eq } from "drizzle-orm"
import { BillingPage } from "@/features/admin/billing/BillingPage"
import { getDb } from "@/server/db/getDb"
import { userSecurity, users } from "@/shared/schema/auth"
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export default async function Page() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  const traceId = getTraceId(new Headers())
  let roleKey = "user"
  let userId = ""

  if (token) {
    const payload = await verifySessionToken(token, traceId).catch(() => null)
    if (payload?.userId) userId = payload.userId
  }

  if (userId) {
    const db = await getDb({ userSecurity, users })
    const rows = await db.select({ roleKey: userSecurity.roleKey }).from(userSecurity).where(eq(userSecurity.userId, userId)).limit(1)
    if (rows.length > 0) {
      roleKey = rows[0].roleKey === "admin" ? "super_admin" : rows[0].roleKey
    }
  }

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <BillingPage roleKey={roleKey} />
    </Suspense>
  )
}
