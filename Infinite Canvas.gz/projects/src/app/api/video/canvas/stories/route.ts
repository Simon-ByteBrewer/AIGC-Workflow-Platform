import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { stories, storyOutlines } from "@/shared/schema"
import { logger } from "@/shared/logger"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { createAssetGroup } from "@/server/domains/quick-generate/integrations/createAssetGroup"
import { isCanvasSeedance20AudEnabled } from "@/server/domains/video/canvas/copyright/canvasCopyrightCapability"

export const runtime = "nodejs"

const bodySchema = z
  .object({
    title: z.string().trim().min(1).max(100)
  })
  .strict()

/**
 * 组装画布项目默认 metadata，并写入素材审核 group_id。
 */
function buildCanvasStoryMetadata(groupId: string): Record<string, unknown> {
  return {
    canvasAssetReview: {
      groupId
    }
  }
}

/**
 * 创建画布项目与默认剧集，同时初始化版权审核所需的 group_id。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const db = await getDb({ stories, storyOutlines })
    const groupId = await (async () => {
      if (!isCanvasSeedance20AudEnabled()) return ""
      const group = await createAssetGroup({
        traceId,
        userId,
        projectName: parsed.data.title,
        videoCategory: "premium"
      })
      return String(group.assetGroupId ?? "").trim()
    })()
    if (isCanvasSeedance20AudEnabled() && !groupId) {
      return NextResponse.json(makeApiErr(traceId, "GROUP_ID_CREATE_FAILED", "创建项目失败：未拿到 group_id"), { status: 500 })
    }

    const [createdStory] = await db
      .insert(stories)
      .values({
        userId,
        title: parsed.data.title,
        storyType: "canvas",
        videoCategory: "premium",
        resolution: "1080p",
        aspectRatio: "16:9",
        storyText: "",
        shotStyle: "realistic",
        metadata: buildCanvasStoryMetadata(groupId)
      })
      .returning({ id: stories.id })

    const storyId = createdStory?.id ?? ""
    if (!storyId) return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "创建失败，请稍后重试"), { status: 500 })

    const [createdOutline] = await db
      .insert(storyOutlines)
      .values({
        storyId,
        sequence: 1,
        outlineText: "",
        originalText: ""
      })
      .returning({ id: storyOutlines.id })

    const outlineId = createdOutline?.id ?? ""
    if (!outlineId) return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "创建失败，请稍后重试"), { status: 500 })

    return NextResponse.json(makeApiOk(traceId, { storyId, outlineId }), { status: 200 })
  } catch (error) {
    logger.error({
      event: "canvas_story_create_failed",
      module: "video/canvas",
      traceId,
      message: "创建画布项目失败",
      errorMessage: error instanceof Error ? error.message : "unknown"
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "创建失败，请稍后重试"), { status: 500 })
  }
}
