import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, sql } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { publicCharacterCostumes, publicResources } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

const bodySchema = z
  .object({
    characterId: z.string().trim().min(1).max(200),
    name: z.string().trim().max(200).optional(),
    description: z.string().trim().max(10_000).optional(),
    previewStorageKey: z.string().trim().min(1).max(2000).optional(),
    originalStorageKey: z.string().trim().min(1).max(2000).optional(),
    previewUrl: z.string().trim().min(1).max(2000).optional(),
    originalUrl: z.string().trim().min(1).max(2000).optional(),
    setDefault: z.boolean().optional()
  })
  .refine((v) => Boolean(v.previewStorageKey || v.originalStorageKey || v.previewUrl || v.originalUrl), { message: "请提供图片资源" })

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const raw = await req.json().catch(() => null)
  const parsed = bodySchema.safeParse(raw)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const db = await getDb({ publicResources, publicCharacterCostumes })
  const character = await db
    .select({ id: publicResources.id })
    .from(publicResources)
    .where(and(eq(publicResources.id, parsed.data.characterId), eq(publicResources.userId, userId), eq(publicResources.type, "character")))
    .limit(1)
  if (character.length === 0) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "角色不存在"), { status: 404 })

  const maxRows = await db
    .select({ max: sql<number | null>`max(${publicCharacterCostumes.version})`.mapWith((v) => (v == null ? null : Number(v))) })
    .from(publicCharacterCostumes)
    .where(eq(publicCharacterCostumes.characterResourceId, parsed.data.characterId))
  const currentMax = maxRows?.[0]?.max ?? null
  const version = (currentMax ?? 0) + 1

  const shouldDefault = parsed.data.setDefault ?? currentMax == null
  if (shouldDefault) {
    await db
      .update(publicCharacterCostumes)
      .set({ isDefault: false })
      .where(eq(publicCharacterCostumes.characterResourceId, parsed.data.characterId))
  }

  const inserted = await db
    .insert(publicCharacterCostumes)
    .values({
      characterResourceId: parsed.data.characterId,
      version,
      isDefault: shouldDefault,
      name: parsed.data.name ?? "",
      description: parsed.data.description ?? "",
      previewStorageKey: parsed.data.previewStorageKey,
      originalStorageKey: parsed.data.originalStorageKey,
      previewUrl: parsed.data.previewUrl,
      originalUrl: parsed.data.originalUrl
    })
    .returning()

  const item = inserted[0]
  if (!item) return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", "创建失败"), { status: 500 })
  return NextResponse.json(makeApiOk(traceId, { item }), { status: 200 })
}

