import { NextResponse, type NextRequest } from "next/server"
import { sql } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { CozeTtsClient } from "@/server/integrations/coze/ttsClient"
import { downloadBinary } from "@/server/lib/http/downloadBinary"
import { uploadPublicBuffer } from "@/shared/storage"
import { ttsSpeakerSamples } from "@/shared/schema/generation"
import { DEFAULT_TTS_TEST_TEXT, TTS_SPEAKERS } from "@/features/tts/speakers"

export const runtime = "nodejs"

const initSamplesSchema = z.object({
  force: z.boolean().optional().default(false),
  offset: z.number().int().min(0).optional().default(0),
  limit: z.number().int().min(1).max(50).optional().default(10)
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const startedAt = Date.now()
  const parsedBody = initSamplesSchema.safeParse(await req.json().catch(() => ({})))
  const force = parsedBody.success ? parsedBody.data.force : false
  const offset = parsedBody.success ? parsedBody.data.offset : 0
  const limit = parsedBody.success ? parsedBody.data.limit : 10
  const runId = force ? "post-fix" : "pre-fix"
  const speakers = TTS_SPEAKERS.slice(offset, offset + limit)

  logger.info({
    event: "tts_seed_start",
    module: "tts",
    traceId,
    message: "开始批量生成音色样音并入库",
    speakerCount: speakers.length,
    totalSpeakerCount: TTS_SPEAKERS.length,
    offset,
    limit,
    force
  })

  try {
    const db = await getDb({ ttsSpeakerSamples })
    const results: Array<{ speaker: string; ok: boolean; id?: string; url?: string; message?: string }> = []

    for (const sp of speakers) {
      const existing = await db.execute(sql`
        SELECT id, url, storage_key
        FROM tts_speaker_samples
        WHERE speaker_id = ${sp.id}
        LIMIT 1
      `)
      const rows = (existing as any)?.rows ?? []
      const hit = rows?.[0]
      // #region debug-point D:seed-existing
      fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId,hypothesisId:"D",location:"src/app/api/tts/init-samples/route.ts:47",msg:"[DEBUG] tts seed existing sample lookup",data:{speakerId:sp.id,hasExisting:Boolean(hit?.id),hasStorageKey:Boolean(hit?.storage_key),hasUrl:Boolean(hit?.url),force},traceId,ts:Date.now()})}).catch(()=>{})
      // #endregion
      if (hit?.id && !force) {
        const stableUrl = `/api/tts/speakers/file/${String(hit.id)}`
        if (String(hit.url ?? "").trim() !== stableUrl) {
          await db.execute(sql`
            UPDATE tts_speaker_samples
            SET url = ${stableUrl}
            WHERE id = ${String(hit.id)}
          `)
        }
        results.push({ speaker: sp.id, ok: true, id: String(hit.id), url: stableUrl })
        continue
      }

      try {
        const tts = await CozeTtsClient.synthesize({ text: DEFAULT_TTS_TEST_TEXT, speaker: sp.id, speed: 1.0, traceId })
        // #region debug-point A:tts-source
        fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId,hypothesisId:"A",location:"src/app/api/tts/init-samples/route.ts:63",msg:"[DEBUG] tts synthesize returned source audio",data:{speakerId:sp.id,audioSize:tts.audioSize,audioUrlHost:(()=>{try{return new URL(tts.audioUrl).host}catch{return""}})(),audioUrlPath:(()=>{try{return new URL(tts.audioUrl).pathname}catch{return""}})(),force},traceId,ts:Date.now()})}).catch(()=>{})
        // #endregion
        const downloaded = await downloadBinary(tts.audioUrl, traceId, 120_000)
        const contentType = downloaded.contentType ?? "audio/mpeg"
        // #region debug-point B:downloaded-binary
        fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId,hypothesisId:"B",location:"src/app/api/tts/init-samples/route.ts:67",msg:"[DEBUG] tts sample binary downloaded",data:{speakerId:sp.id,contentType,bufferBytes:downloaded.buffer.length,bufferHeadHex:downloaded.buffer.subarray(0,16).toString("hex")},traceId,ts:Date.now()})}).catch(()=>{})
        // #endregion
        const fileExt = contentType.includes("wav") ? "wav" : contentType.includes("mpeg") || contentType.includes("mp3") ? "mp3" : "bin"
        const uploaded = await uploadPublicBuffer({ buffer: downloaded.buffer, prefix: "tts-samples", contentType, fileExt })
        // #region debug-point C:uploaded-binary
        fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId,hypothesisId:"C",location:"src/app/api/tts/init-samples/route.ts:71",msg:"[DEBUG] tts sample uploaded to storage",data:{speakerId:sp.id,uploadedKey:uploaded.key,uploadedUrlHost:(()=>{try{return new URL(uploaded.url).host}catch{return""}})(),uploadedUrlPath:(()=>{try{return new URL(uploaded.url).pathname}catch{return""}})(),audioSize:tts.audioSize},traceId,ts:Date.now()})}).catch(()=>{})
        // #endregion

        const upserted = await db.execute(sql`
          INSERT INTO tts_speaker_samples (speaker_id, speaker_name, sample_text, url, storage_key, audio_size)
          VALUES (${sp.id}, ${sp.name}, ${DEFAULT_TTS_TEST_TEXT}, ${uploaded.url}, ${uploaded.key}, ${tts.audioSize})
          ON CONFLICT (speaker_id)
          DO UPDATE SET
            speaker_name = EXCLUDED.speaker_name,
            sample_text = EXCLUDED.sample_text,
            url = EXCLUDED.url,
            storage_key = EXCLUDED.storage_key,
            audio_size = EXCLUDED.audio_size,
            created_at = now()
          RETURNING id
        `)

        const id = String(((upserted as any)?.rows?.[0]?.id ?? "") || "")
        if (id) {
          const stableUrl = `/api/tts/speakers/file/${id}`
          await db.execute(sql`
            UPDATE tts_speaker_samples
            SET url = ${stableUrl}
            WHERE id = ${id}
          `)
          results.push({ speaker: sp.id, ok: true, id, url: stableUrl })
          // #region debug-point D:seed-saved
          fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId,hypothesisId:"D",location:"src/app/api/tts/init-samples/route.ts:96",msg:"[DEBUG] tts sample persisted",data:{speakerId:sp.id,rowId:id,stableUrl,uploadedKey:uploaded.key,force},traceId,ts:Date.now()})}).catch(()=>{})
          // #endregion
        } else {
          results.push({ speaker: sp.id, ok: true, url: uploaded.url })
        }
      } catch (err) {
        const anyErr = err as { message?: string; name?: string }
        // #region debug-point A:seed-failed
        fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId,hypothesisId:"A",location:"src/app/api/tts/init-samples/route.ts:103",msg:"[DEBUG] tts sample seed failed",data:{speakerId:sp.id,errorName:anyErr?.name,errorMessage:anyErr?.message,force},traceId,ts:Date.now()})}).catch(()=>{})
        // #endregion
        results.push({ speaker: sp.id, ok: false, message: anyErr?.message || anyErr?.name || "failed" })
      }
    }

    logger.info({
      event: "tts_seed_success",
      module: "tts",
      traceId,
      message: "批量生成音色样音完成",
      durationMs: Date.now() - startedAt,
      offset,
      limit,
      processedCount: speakers.length,
      successCount: results.filter((r) => r.ok).length,
      failCount: results.filter((r) => !r.ok).length
    })

    return NextResponse.json(
      makeApiOk(traceId, {
        text: DEFAULT_TTS_TEST_TEXT,
        results,
        offset,
        limit,
        total: TTS_SPEAKERS.length,
        processedCount: speakers.length,
        nextOffset: offset + speakers.length,
        hasMore: offset + speakers.length < TTS_SPEAKERS.length,
        successCount: results.filter((r) => r.ok).length,
        failCount: results.filter((r) => !r.ok).length
      }),
      { status: 200 }
    )
  } catch (err) {
    const anyErr = err as { message?: string; name?: string; stack?: string }
    logger.error({
      event: "tts_seed_failed",
      module: "tts",
      traceId,
      message: "批量生成音色样音失败",
      durationMs: Date.now() - startedAt,
      offset,
      limit,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message
    })
    return NextResponse.json(makeApiErr(traceId, "TTS_SEED_FAILED", anyErr?.message || "批量生成失败"), { status: 500 })
  }
}
