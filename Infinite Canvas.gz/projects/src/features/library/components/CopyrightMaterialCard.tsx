"use client"

import type { ReactElement } from "react"
import { Film, Image as ImageIcon, Music2 } from "lucide-react"
import type { CopyrightLibraryItem } from "@/shared/contracts/library/copyrightLibrary"
import styles from "./CopyrightLibrary.module.css"

interface CopyrightMaterialCardProps {
  item: CopyrightLibraryItem
  view: "grid" | "list"
  onClick: () => void
}

function getMaterialTypeLabel(materialType: string): string {
  if (materialType === "scene") return "场景"
  if (materialType === "character") return "人物"
  if (materialType === "prop") return "物品"
  if (materialType === "video") return "视频"
  if (materialType === "audio") return "音频"
  return "素材"
}

function getReviewMeta(item: CopyrightLibraryItem): { label: string; className: string; detail: string } {
  const status = String(item.assetStatus ?? "").trim()
  const assetId = String(item.assetId ?? "").trim()
  const errorMessage = String(item.assetErrorMessage ?? "").trim()
  if (status === "Active") {
    return {
      label: "已通过",
      className: styles.statusReviewed,
      detail: assetId ? `assetId: ${assetId}` : "已通过审核"
    }
  }
  if (status === "Processing") {
    return {
      label: "审核中",
      className: styles.statusProcessing,
      detail: assetId ? `assetId: ${assetId}` : "等待审核结果"
    }
  }
  if (status === "Failed") {
    return {
      label: "审核失败",
      className: styles.statusFailed,
      detail: errorMessage || "审核未通过"
    }
  }
  return {
    label: "未审核",
    className: styles.statusUnreviewed,
    detail: "尚未提交审核"
  }
}

export function CopyrightMaterialCard({ item, view, onClick }: CopyrightMaterialCardProps): ReactElement {
  const mediaType = item.materialType === "video" ? "video" : item.materialType === "audio" ? "audio" : "image"
  const reviewMeta = getReviewMeta(item)

  return (
    <button type="button" className={`${styles.materialCard} ${view === "list" ? styles.materialCardList : ""}`} onClick={onClick}>
      <div className={styles.materialPreview}>
        {mediaType === "image" && item.sourceUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={item.sourceUrl} alt={item.title} className={styles.materialImage} />
        ) : mediaType === "video" && item.sourceUrl ? (
          <video className={styles.materialVideo} src={item.sourceUrl} muted />
        ) : (
          <div className={styles.materialPlaceholder}>
            {mediaType === "video" ? <Film size={28} /> : mediaType === "audio" ? <Music2 size={28} /> : <ImageIcon size={28} />}
            <span>{mediaType === "video" ? "视频素材" : mediaType === "audio" ? "音频素材" : "图片素材"}</span>
          </div>
        )}
      </div>
      <div className={styles.materialInfo}>
        <div className={styles.materialTitle}>{item.title}</div>
        <div className={styles.materialMetaRow}>
          <span className={styles.tag}>{getMaterialTypeLabel(item.materialType)}</span>
          {item.voiceSpeakerName?.trim() ? <span className={styles.tag}>{item.voiceSpeakerName.trim()}</span> : null}
        </div>
        <div className={styles.materialStatusRow}>
          <span className={`${styles.statusTag} ${reviewMeta.className}`}>{reviewMeta.label}</span>
        </div>
        <div className={styles.materialDetail}>{reviewMeta.detail}</div>
      </div>
    </button>
  )
}
