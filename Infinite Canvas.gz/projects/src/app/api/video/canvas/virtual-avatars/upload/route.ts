import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import crypto from "node:crypto"
import sharp from "sharp"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { logger } from "@/shared/logger"

export const runtime = "nodejs"

const formSchema = z.object({
  kind: z.enum(["ref_image"]).default("ref_image")
})

/**
 * 为虚拟人像库构造一个安全的 object key。
 */
function buildAvatarUploadKey(input: { userId: string; suffix: string; ext: string }): string {
  const ts = Date.now()
  const rand = crypto.randomBytes(4).toString("hex")
  const safeUserId = input.userId.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64)
  const safeSuffix = input.suffix.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 64)
  const safeExt = (input.ext ?? "bin").replace(/[^a-zA-Z0-9]/g, "").slice(0, 12) || "bin"
  return `virtual-avatars/${safeUserId}/${ts}-${rand}-${safeSuffix}.${safeExt}`
}

/**
 * 基于文件名与 mimeType 推断扩展名。
 */
function guessFileExt(fileName: string, mimeType: string): string {
  const fromName = (() => {
    const raw = (fileName ?? "").trim()
    if (!raw) return ""
    const idx = raw.lastIndexOf(".")
    if (idx <= 0 || idx >= raw.length - 1) return ""
    return raw.slice(idx + 1).toLowerCase()
  })()
  if (fromName) return fromName

  const t = (mimeType ?? "").toLowerCase()
  if (t === "image/jpeg") return "jpg"
  if (t === "image/png") return "png"
  if (t === "image/webp") return "webp"
  if (t === "image/gif") return "gif"
  return "bin"
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let form: FormData
  try {
    form = await req.formData()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_FORM", "请求体不是合法表单"), { status: 400 })
  }

  const parsed = formSchema.safeParse({ kind: form.get("kind") ?? "ref_image" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const file = form.get("file")
  if (!(file instanceof File)) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少文件"), { status: 400 })

  const mimeType = (file.type ?? "").trim().toLowerCase()
  if (!mimeType.startsWith("image/")) return NextResponse.json(makeApiErr(traceId, "INVALID_FILE", "仅支持上传图片文件"), { status: 400 })

  let bytes: Buffer
  try {
    bytes = Buffer.from(await file.arrayBuffer())
  } catch {
    return NextResponse.json(makeApiErr(traceId, "READ_FAILED", "读取文件失败"), { status: 400 })
  }

  const storage = getS3Storage()
  const ext = guessFileExt(file.name, mimeType)
  const storageKey = buildAvatarUploadKey({ userId, suffix: "original", ext })

  let previewKey: string | null = null
  try {
    const uploadedKey = await storage.uploadFile({
      fileContent: bytes,
      fileName: storageKey,
      contentType: mimeType || "application/octet-stream"
    })

    try {
      const previewBytes = await sharp(bytes).resize({ width: 512, height: 512, fit: "inside", withoutEnlargement: true }).jpeg({ quality: 86 }).toBuffer()
      const pk = buildAvatarUploadKey({ userId, suffix: "preview", ext: "jpg" })
      previewKey = await storage.uploadFile({ fileContent: previewBytes, fileName: pk, contentType: "image/jpeg" })
    } catch {}

    const url = await resolveStorageUrl(storage, uploadedKey)
    const previewUrl = previewKey ? await resolveStorageUrl(storage, previewKey).catch(() => "") : ""

    return NextResponse.json(
      makeApiOk(traceId, {
        objectKey: uploadedKey,
        previewObjectKey: previewKey || undefined,
        url,
        previewUrl: previewUrl || undefined
      }),
      { status: 200 }
    )
  } catch (e) {
    const anyErr = e as { message?: string }
    logger.error({
      event: "virtual_avatar_upload_failed",
      module: "video/canvas",
      traceId,
      message: "虚拟人像参考图上传失败",
      errorMessage: anyErr?.message ?? "unknown"
    })
    return NextResponse.json(makeApiErr(traceId, "UPLOAD_FAILED", "上传失败，请稍后重试"), { status: 500 })
  }
}

