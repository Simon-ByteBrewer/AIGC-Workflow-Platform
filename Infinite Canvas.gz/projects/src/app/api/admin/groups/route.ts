import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { asc, eq, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { userGroups } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"

export const runtime = "nodejs"

const createBodySchema = z.object({
  name: z.string().trim().min(1).max(100),
  code: z.string().trim().max(50).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor

  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  await ensurePublicSchema()
  const db = await getDb({ userGroups })
  const rows = await db
    .select({
      id: userGroups.id,
      name: userGroups.name,
      code: userGroups.code,
      isActive: userGroups.isActive,
      createdAt: userGroups.createdAt,
      updatedAt: userGroups.updatedAt
    })
    .from(userGroups)
    .orderBy(asc(userGroups.createdAt))

  return NextResponse.json(makeApiOk(traceId, { items: rows }), { status: 200 })
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor

  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  const parsed = createBodySchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ userGroups })
  const now = new Date()

  const code = (parsed.data.code ?? "").trim()
  const [created] = await db
    .insert(userGroups)
    .values({
      name: parsed.data.name.trim(),
      code: code || null,
      isActive: true,
      createdAt: now,
      updatedAt: now,
      createdBy: actor.userId,
      updatedBy: actor.userId
    })
    .returning()

  if (!created?.id) {
    return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建用户组失败"), { status: 500 })
  }

  // Optional: minimal audit log entry (reuse audit_logs table without strict schema import)
  try {
    await db.execute(sql`
      insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
      values (
        ${actor.userId},
        'user_group.create',
        'user_group',
        ${created.id},
        null,
        '{}'::jsonb,
        ${JSON.stringify({ id: created.id, name: created.name, code: created.code })}::jsonb,
        ${actor.ip},
        ${actor.userAgent},
        ${traceId}
      )
    `)
  } catch {}

  return NextResponse.json(makeApiOk(traceId, { group: { id: created.id, name: created.name, code: created.code } }), { status: 201 })
}

