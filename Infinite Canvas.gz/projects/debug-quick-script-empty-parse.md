# [OPEN] quick-script-empty-parse

## 背景
- 症状：quick script 的 `stream_run` 接口侧能看到非空结果，但本地落库或后续消费时解析为空。
- 范围：`quick-generate` 的整集剧本拆分链路，重点是 `callQuickScriptWorkflow`、`cozeStreamRunClient`、`quickGenerateEpisodeCreateWorker`。

## 当前证据
- 已抓到真实 SSE 样本：第 1 帧是业务结果，第 2 帧是 `{"type":"end","status":"completed"}`。
- 用户补充的接口侧业务结果包含：`script_text`、`type`、`shots`、`min_duration_minutes`、`max_duration_minutes`。

## 待验证假设
- H1：`stream_run` 的最终业务结果没有落在 `workflow_end.output`，而是落在非标准帧或非标准字段中，当前解析链路遗漏了它。
- H2：业务结果里的 `shots` 虽然存在，但元素是 JSON 字符串数组，后续 worker 需要对象数组，导致看起来“解析为空”。
- H3：`callQuickScriptWorkflow` 已拿到非空结果，但写入 `resultPayload.workflowResponse` 前被归一化逻辑覆盖或丢失。
- H4：日志里看到的“接口侧结果”与当前服务端真实收到的结果结构不完全一致，可能还包了一层未被展开的对象。
- H5：`outline` 链路新增的时长字段或其它字段没有导致接口失败，但改变了结果结构，当前提取规则未同步更新。

## 下一步
- 阅读现有日志与消费链路代码
- 补最小化运行时埋点，直接记录 quick script 收到的原始结果摘要与 worker 消费前摘要
- 复现一次并基于证据决定最小修复

## 已确认结论
- `H1`：部分成立，但不是当前主根因。SSE 结果帧能收到，且 `type=end` 已可作为合法结束。
- `H2`：成立。`shots` 为 JSON 字符串数组时，worker 与共享解析都把非对象项视为 `{}`，导致 `shot_text` 丢失。

## 本轮修复
- 在 `src/shared/quickGenerate/episodeShots.ts` 增加单条 shot 的统一归一化：
  - 对象项直接透传
  - 字符串项先 `JSON.parse` 再转对象
- 在 `quickGenerateEpisodeCreateWorker.ts` 落库前复用该归一化，确保 `resultPayload.workflowResponse.shots` 保存为对象数组。
- 保留现有调试日志，等待用户复测确认后再清理。
