export type OpenEpisodeTab = {
  id: string
  episodeNo: number
}

export function getOpenEpisodeTabsStorageKey(storyId: string): string {
  return `quick-generate-open-episode-tabs:${storyId}`
}

export function readOpenEpisodeTabs(storyId: string): OpenEpisodeTab[] {
  if (typeof window === "undefined") return []
  const raw = window.localStorage.getItem(getOpenEpisodeTabsStorageKey(storyId))
  if (!raw) return []
  try {
    const parsed = JSON.parse(raw) as unknown
    if (!Array.isArray(parsed)) return []
    return parsed
      .map((item) => {
        const row = item && typeof item === "object" && !Array.isArray(item) ? (item as Record<string, unknown>) : null
        const id = typeof row?.id === "string" ? row.id.trim() : ""
        const episodeNo = Number(row?.episodeNo)
        if (!id || !Number.isFinite(episodeNo)) return null
        return { id, episodeNo: Math.trunc(episodeNo) }
      })
      .filter(Boolean) as OpenEpisodeTab[]
  } catch {
    return []
  }
}

export function writeOpenEpisodeTabs(storyId: string, tabs: OpenEpisodeTab[]): void {
  if (typeof window === "undefined") return
  window.localStorage.setItem(getOpenEpisodeTabsStorageKey(storyId), JSON.stringify(tabs))
}

export function upsertOpenEpisodeTab(storyId: string, tab: OpenEpisodeTab): OpenEpisodeTab[] {
  const existing = readOpenEpisodeTabs(storyId)
  const next = existing.some((item) => item.id === tab.id) ? existing.map((item) => (item.id === tab.id ? tab : item)) : [...existing, tab]
  writeOpenEpisodeTabs(storyId, next)
  return next
}

export function updateOpenEpisodeTab(storyId: string, tab: OpenEpisodeTab): OpenEpisodeTab[] {
  const existing = readOpenEpisodeTabs(storyId)
  const next = existing.map((item) => (item.id === tab.id ? tab : item))
  writeOpenEpisodeTabs(storyId, next)
  return next
}

export function removeOpenEpisodeTab(storyId: string, episodeId: string): OpenEpisodeTab[] {
  const next = readOpenEpisodeTabs(storyId).filter((item) => item.id !== episodeId)
  writeOpenEpisodeTabs(storyId, next)
  return next
}
