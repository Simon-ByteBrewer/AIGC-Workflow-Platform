import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { generatedImages, stories } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

/**
 * 根据 `generated_images.storageKey` 生成预签名链接并 302 跳转。
 */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const raw = await ctx.params
  const parsed = paramsSchema.safeParse(raw)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const kind = req.nextUrl.searchParams.get("kind") === "thumbnail" ? "thumbnail" : "original"
  const db = await getDb({ generatedImages, stories })
  const rows = await db
    .select({
      id: generatedImages.id,
      url: generatedImages.url,
      storageKey: generatedImages.storageKey,
      thumbnailUrl: generatedImages.thumbnailUrl,
      thumbnailStorageKey: generatedImages.thumbnailStorageKey
    })
    .from(generatedImages)
    .innerJoin(stories, eq(generatedImages.storyId, stories.id))
    .where(and(eq(generatedImages.id, parsed.data.id), eq(stories.userId, userId), isNull(generatedImages.deletedAt)))
    .limit(1)

  const row = rows[0]
  if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "素材不存在"), { status: 404 })

  const storageKey =
    kind === "thumbnail"
      ? (row.thumbnailStorageKey || row.storageKey)
      : row.storageKey
  const fallbackUrl = kind === "thumbnail" ? (row.url || row.thumbnailUrl) : row.url
  if (!storageKey) {
    if (!fallbackUrl) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源链接不存在"), { status: 404 })
    return NextResponse.redirect(fallbackUrl)
  }

  const storage = getS3Storage()
  try {
    const url = await resolveStorageUrl(storage, storageKey)
    return NextResponse.redirect(url)
  } catch {
    if (!fallbackUrl) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源链接不存在"), { status: 404 })
    return NextResponse.redirect(fallbackUrl)
  }
}
