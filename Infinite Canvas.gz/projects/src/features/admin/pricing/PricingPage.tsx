"use client"

import { useEffect, useState, type ReactElement } from "react"
import styles from "./PricingPage.module.css"
import type { ApiErr, ApiOk } from "@/shared/api"
import type {
  OfficialPricingUpdateRequest,
  PricingTreeGroup,
  PricingTreeResponse,
  PricingUpdateRequest
} from "@/shared/contracts/pricing"

type TreeResponse = ApiOk<PricingTreeResponse> | ApiErr
type UpdateMode = "custom" | "official"

const OFFICIAL_PRICE_TOOLTIP =
  "需要和火山官网的模型价格保持一致，如果火山官网价格更新，如有差异，请及时联系火山侧更新"
const OFFICIAL_PRICE_DOC_URL = "https://www.volcengine.com/docs/82379/1544106?lang=zh"
const CUSTOM_PRICE_TOOLTIP =
  "1、设置自定义价格后，会按照此价格计算费用\n2、当官网价格发生变化时，请联系超级管理员及时更新自定义价格，确保价格合适"

function getReferenceVideoLabel(hasReference: boolean): string {
  return hasReference ? "有参考视频" : "无参考视频"
}

export function PricingPage({ roleKey }: { roleKey: string; userId: string }): ReactElement {
  const canManage = roleKey === "super_admin"
  const [groups, setGroups] = useState<PricingTreeGroup[]>([])
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({})
  const [showUpdate, setShowUpdate] = useState(false)
  const [updateMode, setUpdateMode] = useState<UpdateMode>("custom")
  const [target, setTarget] = useState<(PricingUpdateRequest & { officialPrice: string }) | null>(null)
  const [inputVal, setInputVal] = useState("")

  useEffect(() => {
    void fetchTree()
  }, [])

  const fetchTree = async () => {
    try {
      const res = await fetch("/api/admin/pricing/tree")
      const json = (await res.json()) as TreeResponse
      if (json.ok) {
        setGroups(json.data.groups)
      }
    } catch {
      alert("加载价格列表失败")
    } finally {
      setLoading(false)
    }
  }

  const toggleGroup = (groupId: string) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [groupId]: !prev[groupId]
    }))
  }

  const closeModal = (force = false) => {
    if (submitting && !force) return
    setShowUpdate(false)
    setTarget(null)
    setInputVal("")
  }

  const openCustomPriceModal = (params: PricingUpdateRequest) => {
    setUpdateMode("custom")
    setTarget({ ...params, officialPrice: "" })
    setInputVal(params.customPrice ?? "")
    setShowUpdate(true)
  }

  const openOfficialPriceModal = (params: PricingUpdateRequest & { officialPrice: string }) => {
    setUpdateMode("official")
    setTarget(params)
    setInputVal(params.officialPrice)
    setShowUpdate(true)
  }

  const handleUpdate = async () => {
    if (!target) return
    const trimmedValue = inputVal.trim()
    if (updateMode === "official" && trimmedValue === "") {
      alert("请输入官方价格")
      return
    }
    if (trimmedValue !== "" && !Number.isFinite(Number(trimmedValue))) {
      alert("请输入有效数字")
      return
    }

    setSubmitting(true)
    try {
      const payload: PricingUpdateRequest | OfficialPricingUpdateRequest =
        updateMode === "custom"
          ? {
              groupId: target.groupId,
              modelName: target.modelName,
              resolution: target.resolution,
              hasReference: target.hasReference,
              customPrice: trimmedValue === "" ? null : trimmedValue
            }
          : {
              modelName: target.modelName,
              resolution: target.resolution,
              hasReference: target.hasReference,
              officialPrice: trimmedValue
            }

      const res = await fetch(
        updateMode === "custom" ? "/api/admin/pricing/update" : "/api/admin/pricing/official/update",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        }
      )
      const json = (await res.json()) as ApiOk<{ success: true }> | ApiErr
      if (json.ok) {
        closeModal(true)
        await fetchTree()
      } else {
        alert(json.error.message || "更新失败")
      }
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) return <div style={{ padding: 20 }}>Loading...</div>

  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <div className={styles.topTitle}>价格管理</div>
      </div>

      <div className={styles.tableContainer}>
        <div className={styles.thead}>
          <div>分组</div>
          <div>模型类型</div>
          <div>模型来源</div>
          <div>模型名称</div>
          <div>参考条件</div>
          <div>分辨率</div>
          <div>计量单位</div>
          <div className={styles.headerWithTooltip}>
            <span>官方价格</span>
            <span className={styles.tooltipHost}>
              <button
                type="button"
                className={styles.helpIcon}
                aria-label="查看官方价格说明"
                title="查看官方价格说明"
              >
                ?
              </button>
              <span className={styles.tooltipText} role="tooltip">
                {OFFICIAL_PRICE_TOOLTIP}
              </span>
            </span>
          </div>
          <div className={styles.headerWithTooltip}>
            <span>自定义价格</span>
            <span className={styles.tooltipHost}>
              <button
                type="button"
                className={styles.helpIcon}
                aria-label="查看自定义价格说明"
                title="查看自定义价格说明"
              >
                ?
              </button>
              <span className={styles.tooltipText} role="tooltip">
                {CUSTOM_PRICE_TOOLTIP}
              </span>
            </span>
          </div>
          <div>操作</div>
        </div>
        <div className={styles.tbody}>
          {groups.map((group) => {
            const collapsed = collapsedGroups[group.id] ?? true

            return (
            <div key={group.id} className={styles.groupSection}>
              <div
                className={styles.groupHeader}
                onClick={() => toggleGroup(group.id)}
                aria-expanded={!collapsed}
              >
                <div className={styles.groupHeaderLeft}>
                  <span className={styles.groupChevron}>{collapsed ? "▸" : "▾"}</span>
                  <span className={styles.groupName}>{group.name}</span>
                </div>
                <div className={styles.groupMeta}>共 {group.rules.length} 条价格项</div>
              </div>
              {!collapsed && (
                <div className={styles.groupBody}>
                  {group.rules.map((rule) => (
                    <div
                      key={`${group.id}-${rule.sourceType}-${rule.modelName}-${rule.resolution}-${String(rule.hasReference)}`}
                      className={styles.ruleRow}
                    >
                      <div className={styles.muted}>{group.name}</div>
                      <div>{rule.modelType}</div>
                      <div>{rule.sourceType}</div>
                      <div className={styles.mono}>{rule.modelName}</div>
                      <div>{rule.referenceLabel}</div>
                      <div>{rule.resolutionLabel}</div>
                      <div>{rule.unit}</div>
                      <div>{rule.officialPrice}</div>
                      <div>{rule.customPrice ?? "-"}</div>
                      <div className={styles.actions}>
                        <button
                          className={styles.btn}
                          disabled={!canManage}
                          onClick={() => {
                            openCustomPriceModal({
                              groupId: group.id,
                              modelName: rule.modelName,
                              resolution: rule.resolution,
                              hasReference: rule.hasReference,
                              customPrice: rule.customPrice
                            })
                          }}
                        >
                          设置价格
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            )
          })}
        </div>
      </div>

      {showUpdate && target && (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            {updateMode === "official" ? (
              <>
                <div className={styles.modalTitle}>更新官方价格</div>
                <div className={styles.modalField}>
                  <div className={styles.modalLabel}>说明:</div>
                  <div className={styles.officialDescription}>当官网价格发生变化时，您可在此处更新官网价格</div>
                  <div className={styles.officialDocRow}>
                    <span>官网价格查询地址：</span>
                    <a
                      href={OFFICIAL_PRICE_DOC_URL}
                      target="_blank"
                      rel="noreferrer"
                      className={styles.officialLink}
                    >
                      {OFFICIAL_PRICE_DOC_URL}
                    </a>
                  </div>
                </div>

                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>当前的官网价格</label>
                  <div className={styles.officialPriceValue}>{target.officialPrice}</div>
                </div>

                <div className={styles.modalField}>
                  <label className={styles.modalLabel} htmlFor="official-price-input">
                    更新的官网价格
                  </label>
                  <input
                    id="official-price-input"
                    type="text"
                    className={styles.modalInput}
                    value={inputVal}
                    onChange={(e) => setInputVal(e.target.value)}
                    placeholder="请输入更新后的官网价格"
                  />
                </div>

                <div className={styles.modalActions}>
                  <button className={styles.btn} onClick={() => closeModal()} disabled={submitting}>取消</button>
                  <button className={styles.topBtnPrimary} onClick={handleUpdate} disabled={submitting}>
                    保存并关闭
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className={styles.modalTitle}>设置分组自定义价格</div>
                <div className={styles.modalField}>
                  <label className={styles.modalLabel}>
                    模型：{target.modelName} / {target.resolution} / {getReferenceVideoLabel(target.hasReference)}
                  </label>
                  <input
                    type="text"
                    className={styles.modalInput}
                    value={inputVal}
                    onChange={(e) => setInputVal(e.target.value)}
                    placeholder="留空则恢复默认"
                  />
                </div>
                <div className={styles.modalActions}>
                  <button className={styles.btn} onClick={() => closeModal()} disabled={submitting}>取消</button>
                  <button className={styles.topBtnPrimary} onClick={handleUpdate} disabled={submitting}>
                    保存
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
