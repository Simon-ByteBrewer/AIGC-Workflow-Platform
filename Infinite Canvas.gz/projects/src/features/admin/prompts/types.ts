export type PromptType = "storyboard" | "video" | "storyboard_panel"

export type PromptManagementGroup = {
  id: string
  name: string
  code: string | null
  isActive: boolean
}

export type PromptManagementUser = {
  id: string
  account: string
  groupId: string
  roleKey: string
}

export type PromptManagementItem = {
  id: string
  name: string
  content: string
  promptType: PromptType
  assignmentMode: "group" | "user"
  sourceLabel: string
  ownerGroupId: string | null
  ownerGroupName: string | null
  isActive: boolean
  assignedGroupIds: string[]
  assignedGroupNames: string[]
  assignedUserIds: string[]
  assignedUserAccounts: string[]
  updatedAt: string
  updatedByAccount: string | null
}
