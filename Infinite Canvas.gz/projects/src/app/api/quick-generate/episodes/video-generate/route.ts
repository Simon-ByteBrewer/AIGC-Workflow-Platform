import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { enqueueQuickGenerateEpisodeVideoGenerateJobs } from "@/server/domains/quick-generate/usecases/enqueueQuickGenerateEpisodeVideoGenerateJobs"

export const runtime = "nodejs"

const shotSchema = z
  .object({
    shotNo: z.number().int().min(1).max(10_000),
    shotText: z.string().max(50_000),
    roles: z.array(z.string().trim().max(200)).max(200),
    roleMaterialIdsByName: z.record(z.string(), z.string().trim().min(1).max(200)).optional().default({}),
    scenes: z.array(z.string().trim().max(200)).max(200),
    sceneMaterialIdsByName: z.record(z.string(), z.string().trim().min(1).max(200)).optional().default({}),
    items: z.array(z.string().trim().max(200)).max(200),
    itemMaterialIdsByName: z.record(z.string(), z.string().trim().min(1).max(200)).optional().default({}),
    optimizedText: z.string().max(50_000).optional().default(""),
    speakerList: z.array(z.string().trim().max(200)).max(200).optional().default([]),
    refAudioNames: z.array(z.string().trim().max(200)).max(200).optional().default([]),
    mutedAutoAudioNames: z.array(z.string().trim().max(200)).max(200).optional().default([]),
    refVideoIds: z.array(z.string().trim().min(1).max(200)).max(200).optional().default([]),
    duration: z.number().int().min(4).max(15).optional().default(10),
    generateAudio: z.boolean().optional().default(true),
    watermark: z.boolean().optional().default(false),
    aspectRatio: z.string().trim().max(20).optional().default(""),
    resolution: z.enum(["480p", "720p", "1080p"]),
    videoModel: z.string().trim().min(1).max(100),
    storyboardPanelPrompt: z.string().max(50_000).optional().default(""),
    storyboardPanelModel: z.string().max(100).optional().default(""),
    storyboardPanelImages: z.array(z.string().url()).max(100).optional().default([]),
    storyboardPanelImageStorageKeys: z.array(z.string().trim().min(1).max(500)).max(100).optional().default([]),
    selectedStoryboardPanelImage: z.string().url().optional().or(z.literal("")).default(""),
    selectedStoryboardPanelImageStorageKey: z.string().trim().max(500).optional().default("")
  })
  .strict()

const postSchema = z
  .object({
    episodeId: z.string().trim().min(1).max(200),
    shots: z.array(shotSchema).min(1).max(500)
  })
  .strict()

/**
 * 按当前剧集镜头批量入队视频生成任务。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    logger.info({
      event: "quick_generate_episode_video_enqueue_start",
      module: "quick_generate",
      traceId,
      message: "开始批量入队当前剧集视频任务",
      episodeId: parsed.data.episodeId,
      shotCount: parsed.data.shots.length
    })

    const result = await enqueueQuickGenerateEpisodeVideoGenerateJobs({
      traceId,
      userId,
      episodeId: parsed.data.episodeId,
      shots: parsed.data.shots
    })
    kickAllWorkers()

    logger.info({
      event: "quick_generate_episode_video_enqueue_success",
      module: "quick_generate",
      traceId,
      message: "当前剧集视频任务已批量入队",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      queuedCount: result.queuedCount,
      skippedCount: result.skippedCount
    })

    return NextResponse.json(makeApiOk(traceId, result), { status: 202 })
  } catch (e) {
    const err = e as { name?: string; message?: string; stack?: string; code?: string }
    const code = err?.code === "EPISODE_NOT_FOUND" ? "EPISODE_NOT_FOUND" : "UNKNOWN"
    const status = code === "EPISODE_NOT_FOUND" ? 404 : 500
    logger.error({
      event: "quick_generate_episode_video_enqueue_failed",
      module: "quick_generate",
      traceId,
      message: "当前剧集视频批量入队失败",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      errorName: err?.name,
      errorCode: code,
      errorMessage: err?.message,
      stack: err?.stack
    })
    return NextResponse.json(makeApiErr(traceId, code, err?.message?.trim() || "批量生成当前剧集视频失败"), { status })
  }
}
