import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { listAdminUsersGrouped } from "@/server/domains/admin/listAdminUsersGrouped"

export const runtime = "nodejs"

const groupedQuerySchema = z.object({
  q: z.string().trim().optional(),
  status: z.enum(["active", "inactive"]).optional(),
  role: z.string().trim().min(1).max(50).optional(),
  sort: z.enum(["createdAt", "lastLoginAt"]).optional(),
  order: z.enum(["asc", "desc"]).optional()
})

/**
 * 账号管理页的全量组视图接口。
 * 约束：返回可见组全集，以及各组下满足筛选条件的账号明细与统计。
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor

  const url = new URL(req.url)
  const parsed = groupedQuerySchema.safeParse(Object.fromEntries(url.searchParams.entries()))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  const result = await listAdminUsersGrouped(actor, parsed.data)
  return NextResponse.json(makeApiOk(traceId, { groups: result.groups, totalUsers: result.totalUsers, actor: { roleKey: actor.roleKey, groupId: actor.groupId } }), {
    status: 200
  })
}
