 "use client"

import Link from "next/link"
import { X, ArrowLeft } from "lucide-react"
import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import { useRouter } from "next/navigation"
import { EmptyState } from "@/components/empty-state/EmptyState"
import { parseQuickGenerateShotNodeId, type QuickGenerateShotVideoResolvedItem } from "@/shared/quickGenerate/videoResults"
import {
  QUICK_GENERATE_EPISODE_CREATE_JOB_TYPE,
  QUICK_GENERATE_VIDEO_PROMPT_JOB_TYPE,
  QUICK_GENERATE_PANEL_PROMPT_JOB_TYPE,
  QUICK_GENERATE_PANEL_IMAGE_JOB_TYPE,
  QUICK_GENERATE_STORYBOARD_PANEL_REVIEW_POLL_JOB_TYPE,
  QUICK_GENERATE_VIDEO_SUBTITLE_ERASE_JOB_TYPE
} from "@/shared/jobs/jobTypes"
import type { VideoModelOption } from "@/shared/contracts/videoModelAccess"
import type { ImageModelOption } from "@/shared/contracts/imageModelAccess"
import { ConfirmModal } from "@/shared/ui/ConfirmModal"
import { CanvasSelect } from "@/features/video/canvas/nodes/base/CanvasSelect"
import { exportQuickGenerateEpisodeToJianying, generateQuickGenerateEpisodeVideoPrompts, generateQuickGenerateEpisodePanelPrompts, generateQuickGenerateEpisodePanelImages, generateQuickGenerateEpisodeVideos, updateQuickGenerateEpisodeShots } from "../api-client"
import { removeOpenEpisodeTab, type OpenEpisodeTab, upsertOpenEpisodeTab } from "../openEpisodeTabs"
import {
  DEFAULT_QUICK_GENERATE_VIDEO_MODEL,
  getEpisodeDefaultVideoModel,
  getEpisodeShotVideoModels,
  setEpisodeDefaultVideoModel,
  setEpisodeShotVideoModels,
  type QuickGenerateVideoModel
} from "../videoModel"
import { QuickGenerateMaterialDetailDialog, type QuickGenerateMaterialPreview } from "./QuickGenerateMaterialDetailDialog"
import { getQuickGenerateStableMediaSrc, QuickGenerateLazyImage } from "./QuickGenerateLazyMedia"
import { QuickGenerateShotVideoPanel, type QuickGenerateShotVideoJobState } from "./QuickGenerateShotVideoPanel"
import { QuickGenerateEpisodeVideoPreviewModal, type EpisodeVideoPreviewItem } from "./QuickGenerateEpisodeVideoPreviewModal"
import { QuickGenerateVideoPromptMentionEditor, type QuickGenerateAllowedMention } from "./QuickGenerateVideoPromptMentionEditor"
import { openImagePreview } from "@/shared/ui/image-preview/store"
import { normalizeQuickGenerateEditorText } from "./quickGenerateEditorText"
import { buildMentionItems, extractMentionItemOccurrencesFromPrompt, extractMentionItemsFromPrompt } from "./quickGenerateMentions"
import { buildMentionOrderMap, buildOrderedReferencedMaterials } from "./quickGenerateReferencedMaterials"
import styles from "./QuickGenerateEpisodeResultPage.module.css"

type QuickGenerateShotView = {
  shotNo: number
  shotText: string
  roles: string[]
  scenes: string[]
  items: string[]
  optimizedText: string
  speakerList: string[]
  refAudioNames: string[]
  mutedAutoAudioNames: string[]
  refVideoIds: string[]
  duration?: number
  generateAudio?: boolean
  watermark?: boolean
  aspectRatio?: string
  resolution?: string
  videoModel?: QuickGenerateVideoModel
  storyboardPanelPrompt?: string
  storyboardPanelModel?: string
  storyboardPanelImages?: string[]
  storyboardPanelImageStorageKeys?: string[]
  selectedStoryboardPanelImage?: string
  selectedStoryboardPanelImageStorageKey?: string
}

export type QuickGenerateOption = { label: string; value: string; image?: string; materialId?: string }

type QuickGenerateEpisodeResultPageProps = {
  storyId: string
  storyTitle: string
  episodeId: string
  episodeNo: number
  episodeStatus: string
  episodes: Array<{ id: string; episodeNo: number; title: string | null }>
  shots: QuickGenerateShotView[]
  videoResultsByShotNo: Record<number, { videos: QuickGenerateShotVideoResolvedItem[]; selectedJobId: string }>
  parseError: string | null
  jobId?: string | null
  roleOptions: QuickGenerateOption[]
  sceneOptions: QuickGenerateOption[]
  itemOptions: QuickGenerateOption[]
  audioOptions: QuickGenerateOption[]
  videoOptions: QuickGenerateOption[]
  roleVoiceMap: Record<string, string>
  materials: QuickGenerateMaterialPreview[]
  storyAspectRatio?: string
  storyResolution?: string
  initialDefaultVideoModel?: string
  initialDefaultStoryboardPanelModel?: string
  initialStoryboardPanelPersonalPrompt?: string
}

type EditableShot = {
  clientId: string
  persistedShotNo: number | null
  shotNo: number
  shotText: string
  roles: string[]
  scenes: string[]
  items: string[]
  optimizedText: string
  speakerList: string[]
  refAudioNames: string[]
  mutedAutoAudioNames: string[]
  refVideoIds: string[]
  duration: number
  generateAudio: boolean
  watermark: boolean
  aspectRatio: string
  resolution: string
  videoModel: QuickGenerateVideoModel
  storyboardPanelPrompt: string
  storyboardPanelModel: string
  storyboardPanelImages: string[]
  storyboardPanelImageStorageKeys: string[]
  selectedStoryboardPanelImage: string
  selectedStoryboardPanelImageStorageKey: string
}

type StoryJobRow = {
  jobId?: unknown
  type?: unknown
  status?: unknown
  snapshot?: unknown
}

const DURATION_OPTIONS = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15] as const
const DEFAULT_DURATION = 10
const DEFAULT_GENERATE_AUDIO = true
const DEFAULT_WATERMARK = false
const DURATION_SELECT_OPTIONS = DURATION_OPTIONS.map((duration) => ({ value: String(duration), label: `${duration}s` }))
const RESOLUTION_OPTIONS = ["480p", "720p", "1080p"] as const
const RESOLUTION_SELECT_OPTIONS = RESOLUTION_OPTIONS.map((value) => ({ value, label: value }))
const ACTIVE_JOB_STATUSES = new Set(["queued", "running"])
const TERMINAL_JOB_STATUSES = new Set(["done", "error", "failed", "cancelled", "canceled"])
const ASPECT_RATIO_OPTIONS = [
  { value: "16:9", label: "16:9" },
  { value: "9:16", label: "9:16" },
  { value: "1:1", label: "1:1" },
  { value: "4:3", label: "4:3" },
  { value: "3:4", label: "3:4" },
  { value: "21:9", label: "21:9" },
  { value: "adaptive", label: "自适应" }
]

function normalizeDuration(input: unknown): number {
  const value = Number(input)
  return DURATION_OPTIONS.includes(value as (typeof DURATION_OPTIONS)[number]) ? value : DEFAULT_DURATION
}

/**
 * 统一任务状态语义，避免 done/error 后仍被前端当作进行中状态锁住按钮。
 */
function isQuickGenerateJobActiveStatus(status: string): boolean {
  return ACTIVE_JOB_STATUSES.has(status)
}

function isQuickGenerateJobTerminalStatus(status: string): boolean {
  return TERMINAL_JOB_STATUSES.has(status)
}

function normalizeVideoModel(
  input: unknown,
  availableModels: QuickGenerateVideoModel[],
  fallback: QuickGenerateVideoModel = DEFAULT_QUICK_GENERATE_VIDEO_MODEL
): QuickGenerateVideoModel {
  const current = typeof input === "string" ? input.trim() : ""
  if (availableModels.length === 0) return current || fallback
  if (current && availableModels.includes(current)) return current
  return fallback || availableModels[0] || ""
}

function normalizeImageModel(input: unknown, availableModels: string[], fallbackModel = ""): string {
  const current = typeof input === "string" ? input.trim() : ""
  const fallback = String(fallbackModel ?? "").trim()
  if (availableModels.length === 0) return current || fallback
  if (current && availableModels.includes(current)) return current
  if (fallback && availableModels.includes(fallback)) return fallback
  return availableModels[0] || fallback
}

function normalizeStoryboardPanelImages(input: unknown): string[] {
  if (!Array.isArray(input)) return []
  const seen = new Set<string>()
  const result: string[] = []
  for (const item of input) {
    const url = String(item ?? "").trim()
    if (!url || seen.has(url)) continue
    seen.add(url)
    result.push(url)
  }
  return result
}

function normalizeStoryboardPanelImageStorageKeys(input: unknown): string[] {
  if (!Array.isArray(input)) return []
  const result: string[] = []
  for (const item of input) {
    const key = String(item ?? "").trim()
    if (!key) continue
    result.push(key)
  }
  return result
}

function normalizeStoryboardPanelImageSelection(
  images: string[],
  storageKeys: string[],
  selectedUrl: unknown,
  selectedStorageKey: unknown
): { selectedStoryboardPanelImage: string; selectedStoryboardPanelImageStorageKey: string } {
  const normalizedSelectedUrl = String(selectedUrl ?? "").trim()
  const normalizedSelectedStorageKey = String(selectedStorageKey ?? "").trim()
  const selectedIndexByUrl = normalizedSelectedUrl ? images.indexOf(normalizedSelectedUrl) : -1
  if (selectedIndexByUrl >= 0) {
    return {
      selectedStoryboardPanelImage: normalizedSelectedUrl,
      selectedStoryboardPanelImageStorageKey: storageKeys[selectedIndexByUrl] ?? normalizedSelectedStorageKey
    }
  }
  const selectedIndexByKey = normalizedSelectedStorageKey ? storageKeys.indexOf(normalizedSelectedStorageKey) : -1
  if (selectedIndexByKey >= 0) {
    return {
      selectedStoryboardPanelImage: images[selectedIndexByKey] ?? "",
      selectedStoryboardPanelImageStorageKey: normalizedSelectedStorageKey
    }
  }
  return {
    selectedStoryboardPanelImage: images[0] ?? "",
    selectedStoryboardPanelImageStorageKey: storageKeys[0] ?? ""
  }
}

function normalizeSelectedStoryboardPanelImage(images: string[], selected: unknown): string {
  const normalizedSelected = String(selected ?? "").trim()
  if (normalizedSelected && images.includes(normalizedSelected)) return normalizedSelected
  return images[0] ?? ""
}

function normalizeResolution(input: unknown, fallback: string): string {
  const value = typeof input === "string" ? input.trim() : ""
  if (RESOLUTION_OPTIONS.includes(value as (typeof RESOLUTION_OPTIONS)[number])) return value
  const normalizedFallback = String(fallback ?? "").trim()
  if (RESOLUTION_OPTIONS.includes(normalizedFallback as (typeof RESOLUTION_OPTIONS)[number])) return normalizedFallback
  return "720p"
}

function createEditableShot(
  input?: Partial<QuickGenerateShotView>,
  defaultAspectRatio?: string,
  defaultVideoModel: QuickGenerateVideoModel = DEFAULT_QUICK_GENERATE_VIDEO_MODEL,
  overrideVideoModel?: QuickGenerateVideoModel,
  availableModels: QuickGenerateVideoModel[] = [],
  defaultResolution: string = "720p",
  overrideResolution?: string,
  availableImageModels: string[] = [],
  defaultStoryboardPanelModel = "",
  draftClientIdSeed?: string
): EditableShot {
  const persistedShotNo = typeof input?.shotNo === "number" && Number.isFinite(input.shotNo) ? Math.max(1, Math.trunc(input.shotNo)) : null
  const storyboardPanelImages = normalizeStoryboardPanelImages(input?.storyboardPanelImages)
  const storyboardPanelImageStorageKeys = normalizeStoryboardPanelImageStorageKeys(input?.storyboardPanelImageStorageKeys)
  const selection = normalizeStoryboardPanelImageSelection(
    storyboardPanelImages,
    storyboardPanelImageStorageKeys,
    input?.selectedStoryboardPanelImage,
    input?.selectedStoryboardPanelImageStorageKey
  )
  return {
    clientId:
      typeof (input as { clientId?: unknown } | undefined)?.clientId === "string" &&
      String((input as { clientId?: unknown }).clientId ?? "").trim()
        ? String((input as { clientId?: unknown }).clientId ?? "").trim()
        : persistedShotNo !== null
          ? `persisted:${persistedShotNo}`
          : draftClientIdSeed
            ? `draft:${draftClientIdSeed}`
          : `draft:${globalThis.crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2)}`,
    persistedShotNo,
    shotNo: input?.shotNo ?? 0,
    shotText: normalizeQuickGenerateEditorText(input?.shotText),
    roles: input?.roles ?? [],
    scenes: input?.scenes ?? [],
    items: input?.items ?? [],
    optimizedText: normalizeQuickGenerateEditorText(input?.optimizedText),
    speakerList: input?.speakerList ?? [],
    refAudioNames: input?.refAudioNames ?? [],
    mutedAutoAudioNames: input?.mutedAutoAudioNames ?? [],
    refVideoIds: input?.refVideoIds ?? [],
    duration: normalizeDuration(input?.duration),
    generateAudio: typeof input?.generateAudio === "boolean" ? input.generateAudio : DEFAULT_GENERATE_AUDIO,
    watermark: typeof input?.watermark === "boolean" ? input.watermark : DEFAULT_WATERMARK,
    aspectRatio: input?.aspectRatio || defaultAspectRatio || "16:9",
    resolution: normalizeResolution(overrideResolution ?? input?.resolution, defaultResolution),
    videoModel: normalizeVideoModel(overrideVideoModel ?? input?.videoModel, availableModels, defaultVideoModel),
    storyboardPanelPrompt: normalizeQuickGenerateEditorText(input?.storyboardPanelPrompt),
    storyboardPanelModel: normalizeImageModel(input?.storyboardPanelModel, availableImageModels, defaultStoryboardPanelModel),
    storyboardPanelImages,
    storyboardPanelImageStorageKeys,
    selectedStoryboardPanelImage: selection.selectedStoryboardPanelImage,
    selectedStoryboardPanelImageStorageKey: selection.selectedStoryboardPanelImageStorageKey
  }
}

function renumberShots(shots: EditableShot[]): EditableShot[] {
  return shots.map((shot, index) => ({ ...shot, shotNo: index + 1 }))
}

function buildDraftShotClientIdSeed(episodeId: string, index: number): string {
  return `${episodeId}-draft-${index}`
}

function buildStableDomId(...parts: Array<string | number | null | undefined>): string {
  const normalized = parts
    .map((part) => String(part ?? "").trim())
    .filter(Boolean)
    .join("-")
    .replace(/[^a-zA-Z0-9_-]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .toLowerCase()

  return normalized || "quick-generate-select"
}

function normalizeIdArray(values: string[]): string[] {
  const seen = new Set<string>()
  const result: string[] = []
  for (const value of values) {
    const next = String(value ?? "").trim()
    if (!next || seen.has(next)) continue
    seen.add(next)
    result.push(next)
  }
  return result
}

function normalizeEditableShot(
  shot: EditableShot,
  availableModels: QuickGenerateVideoModel[],
  fallbackModel: QuickGenerateVideoModel,
  fallbackResolution: string
): EditableShot {
  const storyboardPanelImages = normalizeStoryboardPanelImages(shot.storyboardPanelImages)
  const storyboardPanelImageStorageKeys = normalizeStoryboardPanelImageStorageKeys(shot.storyboardPanelImageStorageKeys)
  const selection = normalizeStoryboardPanelImageSelection(
    storyboardPanelImages,
    storyboardPanelImageStorageKeys,
    shot.selectedStoryboardPanelImage,
    shot.selectedStoryboardPanelImageStorageKey
  )
  return {
    ...shot,
    shotText: shot.shotText.trim(),
    optimizedText: shot.optimizedText.trim(),
    speakerList: normalizeIdArray(shot.speakerList),
    refAudioNames: shot.refAudioNames.map((value) => String(value ?? "").trim()).filter(Boolean).slice(0, 3),
    mutedAutoAudioNames: shot.mutedAutoAudioNames.map((value) => String(value ?? "").trim()).filter(Boolean),
    refVideoIds: normalizeIdArray(shot.refVideoIds),
    duration: normalizeDuration(shot.duration),
    generateAudio: Boolean(shot.generateAudio),
    watermark: Boolean(shot.watermark),
    aspectRatio: String(shot.aspectRatio || "16:9").trim(),
    resolution: normalizeResolution(shot.resolution, fallbackResolution),
    videoModel: normalizeVideoModel(shot.videoModel, availableModels, fallbackModel),
    storyboardPanelPrompt: shot.storyboardPanelPrompt.trim(),
    storyboardPanelModel: String(shot.storyboardPanelModel ?? "").trim(),
    storyboardPanelImages,
    storyboardPanelImageStorageKeys,
    selectedStoryboardPanelImage: selection.selectedStoryboardPanelImage,
    selectedStoryboardPanelImageStorageKey: selection.selectedStoryboardPanelImageStorageKey
  }
}

function hasStructuralChangesBetweenShots(current: EditableShot[], saved: EditableShot[]): boolean {
  if (current.length !== saved.length) return true
  for (let i = 0; i < current.length; i += 1) {
    const currentShot = current[i]
    const savedShot = saved[i]
    if (!currentShot || !savedShot) return true
    if (currentShot.persistedShotNo !== savedShot.persistedShotNo) return true
  }
  return false
}

function buildShotComparableValue(shot: EditableShot): string {
  return JSON.stringify({
    shotText: shot.shotText.trim(),
    roles: shot.roles,
    scenes: shot.scenes,
    items: shot.items,
    optimizedText: shot.optimizedText.trim(),
    speakerList: normalizeIdArray(shot.speakerList),
    refAudioNames: shot.refAudioNames.map((value) => String(value ?? "").trim()).filter(Boolean),
    mutedAutoAudioNames: shot.mutedAutoAudioNames.map((value) => String(value ?? "").trim()).filter(Boolean),
    refVideoIds: normalizeIdArray(shot.refVideoIds),
    duration: normalizeDuration(shot.duration),
    generateAudio: Boolean(shot.generateAudio),
    watermark: Boolean(shot.watermark),
    aspectRatio: String(shot.aspectRatio || "16:9").trim(),
    resolution: String(shot.resolution ?? "").trim(),
    videoModel: String(shot.videoModel ?? "").trim(),
    storyboardPanelPrompt: shot.storyboardPanelPrompt.trim(),
    storyboardPanelModel: String(shot.storyboardPanelModel ?? "").trim(),
    storyboardPanelImages: shot.storyboardPanelImages,
    storyboardPanelImageStorageKeys: shot.storyboardPanelImageStorageKeys,
    selectedStoryboardPanelImage: String(shot.selectedStoryboardPanelImage ?? "").trim(),
    selectedStoryboardPanelImageStorageKey: String(shot.selectedStoryboardPanelImageStorageKey ?? "").trim()
  })
}

/**
 * 根据当前最终确认的提示词，重算当前镜头实际采用的素材与音色状态。
 * 规则：
 * 1. 人物/场景/物品/视频全部以当前 prompt 中保留的 @ token 为准；
 * 2. 音色仅以当前 prompt 中保留的音频 token 为准；
 * 3. 若用户删掉了某个人物自动注入的音色 token，但保留人物 token，则仅传人物、不传音色；
 * 4. 若用户后来手动把音色 token 又加回来了，则自动解除 muted 状态。
 */
function derivePromptBindings(input: {
  optimizedText: string
  allMentionItems: ReturnType<typeof buildMentionItems>
  videoIdByLabel: Map<string, string>
  currentMutedAutoAudioNames: string[]
  currentRefAudioNames: string[]
  roleVoiceMap: Record<string, string>
}): Pick<EditableShot, "roles" | "scenes" | "items" | "refAudioNames" | "refVideoIds" | "mutedAutoAudioNames"> {
  const mentions = extractMentionItemsFromPrompt(input.optimizedText, input.allMentionItems)
  const occurrences = extractMentionItemOccurrencesFromPrompt(input.optimizedText, input.allMentionItems)

  const roles = mentions.filter((m) => m.kind === "role").map((m) => m.name)
  const scenes = mentions.filter((m) => m.kind === "scene").map((m) => m.name)
  const items = mentions.filter((m) => m.kind === "item").map((m) => m.name)
  const explicitAudioMentions = normalizeIdArray(occurrences.filter((m) => m.kind === "audio").map((m) => m.name)).slice(0, 3)
  const refVideoIds = mentions
    .filter((m) => m.kind === "video")
    .map((m) => input.videoIdByLabel.get(m.name) ?? "")
    .filter(Boolean)

  const activeAutoVoiceCandidates = new Set(
    normalizeIdArray(roles)
      .map((roleName) => String(input.roleVoiceMap[roleName] ?? "").trim())
      .filter(Boolean)
  )
  const explicitAudioSet = new Set(explicitAudioMentions)
  const inferredMutedAutoAudioNames = normalizeIdArray(input.currentRefAudioNames).filter(
    (name) => activeAutoVoiceCandidates.has(name) && !explicitAudioSet.has(name)
  )
  const mutedAutoAudioNames = normalizeIdArray([
    ...input.currentMutedAutoAudioNames,
    ...inferredMutedAutoAudioNames
  ]).filter(
    (name) => activeAutoVoiceCandidates.has(name) && !explicitAudioSet.has(name)
  )

  return {
    roles,
    scenes,
    items,
    refAudioNames: explicitAudioMentions,
    refVideoIds,
    mutedAutoAudioNames
  }
}

/**
 * 分镜板生图只解析图片类素材引用，避免把视频提示词的音频/视频引用带入图片模型。
 */
function derivePanelPromptMaterialBindings(input: {
  storyboardPanelPrompt: string
  allMentionItems: ReturnType<typeof buildMentionItems>
}): Pick<EditableShot, "roles" | "scenes" | "items"> {
  const mentions = extractMentionItemsFromPrompt(input.storyboardPanelPrompt, input.allMentionItems)
  return {
    roles: mentions.filter((m) => m.kind === "role").map((m) => m.name),
    scenes: mentions.filter((m) => m.kind === "scene").map((m) => m.name),
    items: mentions.filter((m) => m.kind === "item").map((m) => m.name)
  }
}

/**
 * “采用的素材（资产预览）”需要同时覆盖视频提示词和分镜板提示词中的引用。
 * 这里按出现顺序合并两侧 mention，并按 token 去重，确保只要任一侧 `@` 了素材，就会进入预览区。
 */
function mergeReferencedPromptMentions(input: {
  optimizedText: string
  storyboardPanelPrompt: string
  allMentionItems: ReturnType<typeof buildMentionItems>
}) {
  const merged: ReturnType<typeof extractMentionItemsFromPrompt> = []
  const seen = new Set<string>()
  const pushAll = (items: ReturnType<typeof extractMentionItemsFromPrompt>) => {
    for (const item of items) {
      const token = String(item?.token ?? "").trim()
      if (!token || seen.has(token)) continue
      seen.add(token)
      merged.push(item)
    }
  }

  pushAll(extractMentionItemsFromPrompt(input.optimizedText, input.allMentionItems))
  pushAll(extractMentionItemsFromPrompt(input.storyboardPanelPrompt, input.allMentionItems))
  return merged
}

function buildOptionPreviewMap(options: QuickGenerateOption[]): Map<string, string> {
  const map = new Map<string, string>()
  for (const opt of options) {
    const k1 = String(opt.label ?? "").trim()
    const k2 = String(opt.value ?? "").trim()
    const img = opt.image
    if (img) {
      if (k1) map.set(k1, img)
      if (k2) map.set(k2, img)
    }
  }
  return map
}

function buildMaterialIdMap(options: QuickGenerateOption[]): Map<string, string> {
  const map = new Map<string, string>()
  for (const opt of options) {
    const name = String(opt.label ?? "").trim()
    const materialId = String(opt.materialId ?? "").trim()
    if (!name || !materialId || map.has(name)) continue
    map.set(name, materialId)
  }
  return map
}

function pickMaterialIdsByNames(names: string[], idByName: Map<string, string>): Record<string, string> {
  const out: Record<string, string> = {}
  for (const name of names) {
    const normalizedName = String(name ?? "").trim()
    if (!normalizedName) continue
    const materialId = String(idByName.get(normalizedName) ?? "").trim()
    if (!materialId) continue
    out[normalizedName] = materialId
  }
  return out
}

function buildAllowedMentionsForAllMaterials(input: {
  roleOptions: QuickGenerateOption[]
  sceneOptions: QuickGenerateOption[]
  itemOptions: QuickGenerateOption[]
  audioOptions: QuickGenerateOption[]
  videoOptions: QuickGenerateOption[]
  previewMap: Map<string, string>
}): QuickGenerateAllowedMention[] {
  const out: QuickGenerateAllowedMention[] = []
  const seen = new Set<string>()
  const add = (name: string, kind: QuickGenerateAllowedMention["kind"], previewUrl?: string) => {
    const v = String(name ?? "").trim()
    if (!v) return
    const k = `${kind}:${v}`
    if (seen.has(k)) return
    seen.add(k)
    out.push({ name: v, kind, previewUrl })
  }

  input.roleOptions.forEach((opt) => add(opt.label, "role", input.previewMap.get(String(opt.label ?? "").trim())))
  input.sceneOptions.forEach((opt) => add(opt.label, "scene", input.previewMap.get(String(opt.label ?? "").trim())))
  input.itemOptions.forEach((opt) => add(opt.label, "item", input.previewMap.get(String(opt.label ?? "").trim())))
  input.audioOptions.forEach((opt) => add(opt.label, "audio"))
  input.videoOptions.forEach((opt) => add(opt.label, "video"))
  return out
}

export function QuickGenerateEpisodeResultPage(props: QuickGenerateEpisodeResultPageProps): ReactElement {
  const router = useRouter()
  const normalizedStatus = props.episodeStatus.trim().toLowerCase()
  const isProcessing = normalizedStatus === "processing" || normalizedStatus === "draft"
  const isError = normalizedStatus === "error"
  const [episodeDefaultVideoModel, setEpisodeDefaultVideoModelState] = useState<QuickGenerateVideoModel>(
    String(props.initialDefaultVideoModel ?? "").trim() || DEFAULT_QUICK_GENERATE_VIDEO_MODEL
  )
  const [videoModelOptions, setVideoModelOptions] = useState<VideoModelOption[]>([])
  const [imageModelOptions, setImageModelOptions] = useState<ImageModelOption[]>([])
  const [videoModelStorageReady, setVideoModelStorageReady] = useState(false)
  const storyResolution = useMemo(() => String(props.storyResolution ?? "").trim(), [props.storyResolution])
  const [editingShots, setEditingShots] = useState<EditableShot[]>(() =>
    renumberShots(
      props.shots.map((shot, index) =>
        createEditableShot(
          shot,
          props.storyAspectRatio,
          String(props.initialDefaultVideoModel ?? "").trim() || DEFAULT_QUICK_GENERATE_VIDEO_MODEL,
          undefined,
          [],
          storyResolution,
          undefined,
          [],
          String(props.initialDefaultStoryboardPanelModel ?? "").trim(),
          buildDraftShotClientIdSeed(props.episodeId, index)
        )
      )
    )
  )
  const [savedShots, setSavedShots] = useState<EditableShot[]>(() =>
    renumberShots(
      props.shots.map((shot, index) =>
        createEditableShot(
          shot,
          props.storyAspectRatio,
          String(props.initialDefaultVideoModel ?? "").trim() || DEFAULT_QUICK_GENERATE_VIDEO_MODEL,
          undefined,
          [],
          storyResolution,
          undefined,
          [],
          String(props.initialDefaultStoryboardPanelModel ?? "").trim(),
          buildDraftShotClientIdSeed(props.episodeId, index)
        )
      )
    )
  )
  const [saving, setSaving] = useState(false)
  const [optimizingPrompts, setOptimizingPrompts] = useState(false)
  const [generatingEpisodePanelPrompts, setGeneratingEpisodePanelPrompts] = useState(false)
  const [generatingEpisodePanelImages, setGeneratingEpisodePanelImages] = useState(false)
  const [generatingEpisodeVideos, setGeneratingEpisodeVideos] = useState(false)
  const [videoPromptJobId, setVideoPromptJobId] = useState<string | null>(null)
  const [panelPromptJobId, setPanelPromptJobId] = useState<string | null>(null)
  const [panelImageJobId, setPanelImageJobId] = useState<string | null>(null)
  const [savingShotNo, setSavingShotNo] = useState<number | null>(null)
  const [optimizingPromptShotNo, setOptimizingPromptShotNo] = useState<number | null>(null)
  const [generatingPanelPromptShotNo, setGeneratingPanelPromptShotNo] = useState<number | null>(null)
  const [generatingPanelImageShotNo, setGeneratingPanelImageShotNo] = useState<number | null>(null)
  const [generatingVideoShotNo, setGeneratingVideoShotNo] = useState<number | null>(null)
  const [saveError, setSaveError] = useState("")
  const [episodeVideoNotice, setEpisodeVideoNotice] = useState("")
  const [confirmDeleteShotNo, setConfirmDeleteShotNo] = useState<number | null>(null)
  const [confirmGenerateVideoShotNo, setConfirmGenerateVideoShotNo] = useState<number | null>(null)
  const [confirmGenerateEpisodeVideoOpen, setConfirmGenerateEpisodeVideoOpen] = useState(false)
  const [confirmRegenerateEpisodePromptsOpen, setConfirmRegenerateEpisodePromptsOpen] = useState(false)
  const [exportJianyingSubmitting, setExportJianyingSubmitting] = useState(false)
  const [openEpisodeTabs, setOpenEpisodeTabs] = useState<OpenEpisodeTab[]>([])
  const [floatingNotice, setFloatingNotice] = useState<string>("")
  const [previewAllOpen, setPreviewAllOpen] = useState(false)
  const [previewMaterial, setPreviewMaterial] = useState<QuickGenerateMaterialPreview | null>(null)
  
  const shotCount = editingShots.length
  const [promptJobRunning, setPromptJobRunning] = useState(false)
  const [promptJobTargets, setPromptJobTargets] = useState<Set<number | "all">>(new Set())
  const [panelPromptJobRunning, setPanelPromptJobRunning] = useState(false)
  const [panelPromptJobTargets, setPanelPromptJobTargets] = useState<Set<number | "all">>(new Set())
  const [panelImageJobRunning, setPanelImageJobRunning] = useState(false)
  const [panelImageJobTargets, setPanelImageJobTargets] = useState<Set<number | "all">>(new Set())
  const availableVideoModels = useMemo(
    () =>
      videoModelOptions
        .map((item) => String(item.modelName ?? "").trim())
        .filter(Boolean),
    [videoModelOptions]
  )
  const videoModelSelectOptions = useMemo(
    () => availableVideoModels.map((modelName) => ({ value: modelName, label: modelName })),
    [availableVideoModels]
  )
  const availableImageModels = useMemo(
    () =>
      imageModelOptions
        .map((item) => String(item.modelName ?? "").trim())
        .filter(Boolean),
    [imageModelOptions]
  )
  const imageModelSelectOptions = useMemo(
    () => imageModelOptions.map((item) => ({ value: item.modelName, label: item.label || item.modelName })),
    [imageModelOptions]
  )
  const serverDefaultVideoModel = useMemo(
    () => String(props.initialDefaultVideoModel ?? "").trim(),
    [props.initialDefaultVideoModel]
  )
  const serverDefaultStoryboardPanelModel = useMemo(
    () => String(props.initialDefaultStoryboardPanelModel ?? "").trim(),
    [props.initialDefaultStoryboardPanelModel]
  )
  const fallbackResolution = useMemo(() => normalizeResolution(storyResolution, "720p"), [storyResolution])
  
  // 整理出所有分镜中已确认（或默认最新）的视频列表，供预览全集使用
  const allPreviewItems = useMemo(() => {
    const items: EpisodeVideoPreviewItem[] = []
    for (const shot of editingShots) {
      const results = shot.persistedShotNo ? props.videoResultsByShotNo[shot.persistedShotNo] : undefined
      if (!results || results.videos.length === 0) continue
      
      const effectiveSelectedJobId = results.selectedJobId.trim()
      const video = effectiveSelectedJobId 
        ? results.videos.find(v => v.jobId === effectiveSelectedJobId) || results.videos[0]
        : results.videos[0]
        
      if (video?.url) {
        items.push({ shotNo: shot.shotNo, video })
      }
    }
    return items
  }, [editingShots, props.videoResultsByShotNo])
  
  const [shotVideoJobStates, setShotVideoJobStates] = useState<Record<number, QuickGenerateShotVideoJobState>>({})
  const [shotVideoInlineStates, setShotVideoInlineStates] = useState<Record<number, QuickGenerateShotVideoJobState>>({})
  const requestedVideoRefreshJobIdsRef = useRef<Set<string>>(new Set())
  const refreshedAfterEpisodeCreateDoneRef = useRef<Set<string>>(new Set())
  const handledPromptDoneJobIdsRef = useRef<Set<string>>(new Set())
  const pendingSinglePromptApplyShotNosRef = useRef<Set<number>>(new Set())
  const hydratedEpisodeIdRef = useRef<string>("")

  const patchShotVideoInlineStates = useCallback((
    entries: Array<{ shotNo: number; status?: QuickGenerateShotVideoJobState["status"] | null; message?: string | null }>
  ) => {
    if (entries.length === 0) return
    setShotVideoInlineStates((prev) => {
      let changed = false
      const next = { ...prev }
      for (const entry of entries) {
        const shotNo = Number.isFinite(entry.shotNo) ? Math.trunc(entry.shotNo) : 0
        if (shotNo <= 0) continue
        const message = String(entry.message ?? "").trim()
        const status = entry.status
        if (!message || !status) {
          if (shotNo in next) {
            delete next[shotNo]
            changed = true
          }
          continue
        }
        const nextState: QuickGenerateShotVideoJobState = {
          jobId: `inline-state-${props.episodeId}-${shotNo}`,
          jobType: "canvas_video_generate",
          status,
          stage: "",
          errorMessage: message
        }
        const prevState = next[shotNo]
        if (
          !prevState ||
          prevState.status !== nextState.status ||
          prevState.errorMessage !== nextState.errorMessage ||
          prevState.jobType !== nextState.jobType
        ) {
          next[shotNo] = nextState
          changed = true
        }
      }
      return changed ? next : prev
    })
  }, [props.episodeId])

  const clearShotVideoInlineStates = useCallback((shotNos: number[]) => {
    if (shotNos.length === 0) return
    patchShotVideoInlineStates(shotNos.map((shotNo) => ({ shotNo, status: null, message: "" })))
  }, [patchShotVideoInlineStates])

  const optionPreviewMap = useMemo(() => {
    const map = new Map<string, string>()
    for (const [k, v] of buildOptionPreviewMap(props.roleOptions)) map.set(k, v)
    for (const [k, v] of buildOptionPreviewMap(props.sceneOptions)) map.set(k, v)
    for (const [k, v] of buildOptionPreviewMap(props.itemOptions)) map.set(k, v)
    return map
  }, [props.itemOptions, props.roleOptions, props.sceneOptions])

  const allAllowedMentions = useMemo(() => {
    return buildAllowedMentionsForAllMaterials({
      roleOptions: props.roleOptions,
      sceneOptions: props.sceneOptions,
      itemOptions: props.itemOptions,
      audioOptions: props.audioOptions,
      videoOptions: props.videoOptions,
      previewMap: optionPreviewMap
    })
  }, [optionPreviewMap, props.audioOptions, props.itemOptions, props.roleOptions, props.sceneOptions, props.videoOptions])

  const panelAllowedMentions = useMemo(
    () => allAllowedMentions.filter((item) => item.kind === "role" || item.kind === "scene" || item.kind === "item"),
    [allAllowedMentions]
  )

  const videoIdByLabel = useMemo(() => {
    const map = new Map<string, string>()
    for (const opt of props.videoOptions) {
      const label = String(opt.label ?? "").trim()
      const id = String(opt.value ?? "").trim()
      if (!id || !label) continue
      map.set(label, id)
    }
    return map
  }, [props.videoOptions])
  const roleMaterialIdByName = useMemo(() => buildMaterialIdMap(props.roleOptions), [props.roleOptions])
  const sceneMaterialIdByName = useMemo(() => buildMaterialIdMap(props.sceneOptions), [props.sceneOptions])
  const itemMaterialIdByName = useMemo(() => buildMaterialIdMap(props.itemOptions), [props.itemOptions])

  const audioOptionNameSet = useMemo(
    () => new Set(props.audioOptions.map((opt) => String(opt.label ?? "").trim()).filter(Boolean)),
    [props.audioOptions]
  )
  useEffect(() => {
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch("/api/video/canvas/video-models", { method: "GET", cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok?: boolean; data?: { items?: VideoModelOption[] } } | null
        if (!res.ok || !json?.ok || cancelled) {
          if (!cancelled) setVideoModelOptions([])
          return
        }
        setVideoModelOptions(Array.isArray(json.data?.items) ? json.data.items : [])
      } catch {
        if (!cancelled) setVideoModelOptions([])
      }
    })()

    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch("/api/video/canvas/image-models", { method: "GET", cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok?: boolean; data?: { items?: ImageModelOption[] } } | null
        if (!res.ok || !json?.ok || cancelled) {
          if (!cancelled) setImageModelOptions([])
          return
        }
        setImageModelOptions(Array.isArray(json.data?.items) ? json.data.items : [])
      } catch {
        if (!cancelled) setImageModelOptions([])
      }
    })()

    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => {
    if (availableImageModels.length === 0) return
    const normalizeShots = (shots: EditableShot[]) =>
      shots.map((shot) => ({
        ...shot,
        storyboardPanelModel: normalizeImageModel(
          shot.storyboardPanelModel,
          availableImageModels,
          serverDefaultStoryboardPanelModel
        )
      }))
    setEditingShots((prev) => {
      const next = normalizeShots(prev)
      return next.some((shot, index) => shot.storyboardPanelModel !== prev[index]?.storyboardPanelModel) ? next : prev
    })
    setSavedShots((prev) => {
      const next = normalizeShots(prev)
      return next.some((shot, index) => shot.storyboardPanelModel !== prev[index]?.storyboardPanelModel) ? next : prev
    })
  }, [availableImageModels, serverDefaultStoryboardPanelModel])

  useEffect(() => {
    if (hydratedEpisodeIdRef.current === props.episodeId) return
    hydratedEpisodeIdRef.current = props.episodeId
    const storedDefaultModel = getEpisodeDefaultVideoModel(props.episodeId)
    const shotModels = getEpisodeShotVideoModels(props.episodeId)
    const defaultModel = storedDefaultModel || serverDefaultVideoModel
    const hydratedShots = renumberShots(
      props.shots.map((shot, index) =>
        createEditableShot(
          shot,
          props.storyAspectRatio,
          defaultModel,
          shot.videoModel || shotModels[shot.shotNo],
          availableVideoModels,
          fallbackResolution,
          undefined,
          availableImageModels,
          serverDefaultStoryboardPanelModel,
          buildDraftShotClientIdSeed(props.episodeId, index)
        )
      )
    )
    setEpisodeDefaultVideoModelState(defaultModel)
    setEditingShots(hydratedShots)
    setSavedShots(hydratedShots)
    setVideoModelStorageReady(true)
  }, [availableImageModels, availableVideoModels, fallbackResolution, props.episodeId, props.shots, props.storyAspectRatio, serverDefaultStoryboardPanelModel, serverDefaultVideoModel])

  useEffect(() => {
    if (!videoModelStorageReady) return
    const normalizedDefaultModel = normalizeVideoModel(
      episodeDefaultVideoModel || serverDefaultVideoModel,
      availableVideoModels,
      serverDefaultVideoModel || availableVideoModels[0] || ""
    )
    if (normalizedDefaultModel !== episodeDefaultVideoModel) {
      setEpisodeDefaultVideoModelState(normalizedDefaultModel)
    }
    setEditingShots((prev) => {
      const next = prev.map((shot) => normalizeEditableShot(shot, availableVideoModels, normalizedDefaultModel, fallbackResolution))
      return next.some((shot, index) => buildShotComparableValue(shot) !== buildShotComparableValue(prev[index]!)) ? next : prev
    })
    setSavedShots((prev) => {
      const next = prev.map((shot) => normalizeEditableShot(shot, availableVideoModels, normalizedDefaultModel, fallbackResolution))
      return next.some((shot, index) => buildShotComparableValue(shot) !== buildShotComparableValue(prev[index]!)) ? next : prev
    })
  }, [availableVideoModels, episodeDefaultVideoModel, fallbackResolution, serverDefaultVideoModel, videoModelStorageReady])

  useEffect(() => {
    if (!videoModelStorageReady) return
    setEpisodeDefaultVideoModel(props.episodeId, episodeDefaultVideoModel)
    setEpisodeShotVideoModels(
      props.episodeId,
      editingShots.map((shot) => ({ shotNo: shot.shotNo, videoModel: shot.videoModel }))
    )
  }, [editingShots, episodeDefaultVideoModel, props.episodeId, videoModelStorageReady])

  const allMentionItems = useMemo(() => buildMentionItems(allAllowedMentions), [allAllowedMentions])

  // Maintain "opened episode tabs" per story in localStorage so the tabs behave like real closable tabs.
  useEffect(() => {
    const currentNo = Number(props.episodeNo) || 0
    const next = upsertOpenEpisodeTab(props.storyId, { id: props.episodeId, episodeNo: Math.trunc(currentNo) })
    setOpenEpisodeTabs(next)
  }, [props.episodeId, props.episodeNo, props.storyId])

  // Track the previous props.shots to know when the backend actually returned newly generated prompts
  const prevPropsShotsRef = useRef(props.shots)

  useEffect(() => {
    setEditingShots((prevEditing) => {
      setSavedShots((prevSaved) => {
        const keepLocalStructure = hasStructuralChangesBetweenShots(prevEditing, prevSaved)
        if (keepLocalStructure) {
          prevPropsShotsRef.current = props.shots
          return prevSaved
        }
        
        const nextShots = renumberShots(
          props.shots.map((shot, index) =>
            createEditableShot(
              shot,
              props.storyAspectRatio,
              episodeDefaultVideoModel,
              shot.videoModel,
              availableVideoModels,
              fallbackResolution,
              undefined,
              availableImageModels,
              serverDefaultStoryboardPanelModel,
              buildDraftShotClientIdSeed(props.episodeId, index)
            )
          )
        )

        // If counts mismatch, just use new
        if (prevEditing.length !== nextShots.length) {
          setTimeout(() => setEditingShots(nextShots), 0)
          return nextShots
        }

        const prevSavedByShotNo = new Map(prevSaved.map((shot) => [shot.shotNo, shot]))
        const appliedPromptShotNos = new Set<number>()
        let hasChange = false
        const merged = prevEditing.map((oldShot, i) => {
          const newShot = nextShots[i]
          if (oldShot.shotNo !== newShot.shotNo) return newShot
          const savedShot = prevSavedByShotNo.get(oldShot.shotNo)
          const shouldForceApplyPromptResult = pendingSinglePromptApplyShotNosRef.current.has(oldShot.shotNo)
          const keepLocalOptimizedText = Boolean(
            !shouldForceApplyPromptResult && savedShot && oldShot.optimizedText !== savedShot.optimizedText
          )
          const keepLocalStoryboardPanelPrompt = Boolean(
            savedShot && oldShot.storyboardPanelPrompt !== savedShot.storyboardPanelPrompt
          )
          const keepLocalStoryboardPanelModel = Boolean(
            savedShot && oldShot.storyboardPanelModel !== savedShot.storyboardPanelModel
          )
          const keepLocalSelectedStoryboardPanelImage = Boolean(
            savedShot && oldShot.selectedStoryboardPanelImage !== savedShot.selectedStoryboardPanelImage
          )
          const keepLocalSelectedStoryboardPanelImageStorageKey = Boolean(
            savedShot && oldShot.selectedStoryboardPanelImageStorageKey !== savedShot.selectedStoryboardPanelImageStorageKey
          )
          const nextOptimizedText = keepLocalOptimizedText ? oldShot.optimizedText : newShot.optimizedText
          const nextStoryboardPanelPrompt = keepLocalStoryboardPanelPrompt
            ? oldShot.storyboardPanelPrompt
            : newShot.storyboardPanelPrompt
          const nextStoryboardPanelModel = keepLocalStoryboardPanelModel
            ? oldShot.storyboardPanelModel
            : newShot.storyboardPanelModel
          const preferredSelectedStoryboardPanelImage = keepLocalSelectedStoryboardPanelImage
            ? oldShot.selectedStoryboardPanelImage
            : newShot.selectedStoryboardPanelImage
          const preferredSelectedStoryboardPanelImageStorageKey = keepLocalSelectedStoryboardPanelImageStorageKey
            ? oldShot.selectedStoryboardPanelImageStorageKey
            : newShot.selectedStoryboardPanelImageStorageKey
          const normalizedStoryboardPanelSelection = normalizeStoryboardPanelImageSelection(
            newShot.storyboardPanelImages,
            newShot.storyboardPanelImageStorageKeys,
            preferredSelectedStoryboardPanelImage,
            preferredSelectedStoryboardPanelImageStorageKey
          )
          const nextSelectedStoryboardPanelImage = normalizedStoryboardPanelSelection.selectedStoryboardPanelImage
          const nextSelectedStoryboardPanelImageStorageKey =
            normalizedStoryboardPanelSelection.selectedStoryboardPanelImageStorageKey

          // 仅在当前分镜的提示词未被本地手动修改时，才允许外部新值覆盖正文，
          // 否则用户刚编辑的内容会被旧的 props.shots 回灌冲掉。
          if (
            oldShot.optimizedText !== nextOptimizedText ||
            oldShot.storyboardPanelPrompt !== nextStoryboardPanelPrompt ||
            oldShot.storyboardPanelModel !== nextStoryboardPanelModel ||
            JSON.stringify(oldShot.storyboardPanelImages) !== JSON.stringify(newShot.storyboardPanelImages) ||
            JSON.stringify(oldShot.storyboardPanelImageStorageKeys) !== JSON.stringify(newShot.storyboardPanelImageStorageKeys) ||
            oldShot.selectedStoryboardPanelImage !== nextSelectedStoryboardPanelImage ||
            oldShot.selectedStoryboardPanelImageStorageKey !== nextSelectedStoryboardPanelImageStorageKey ||
            JSON.stringify(oldShot.roles) !== JSON.stringify(newShot.roles) ||
            JSON.stringify(oldShot.scenes) !== JSON.stringify(newShot.scenes) ||
            JSON.stringify(oldShot.items) !== JSON.stringify(newShot.items) ||
            JSON.stringify(oldShot.refAudioNames) !== JSON.stringify(newShot.refAudioNames) ||
            JSON.stringify(oldShot.refVideoIds) !== JSON.stringify(newShot.refVideoIds) ||
            oldShot.duration !== newShot.duration ||
            oldShot.aspectRatio !== newShot.aspectRatio
          ) {
            hasChange = true
            if (shouldForceApplyPromptResult) {
              appliedPromptShotNos.add(oldShot.shotNo)
            }
            return {
              ...oldShot,
              optimizedText: nextOptimizedText,
              storyboardPanelPrompt: nextStoryboardPanelPrompt,
              storyboardPanelModel: nextStoryboardPanelModel,
              storyboardPanelImages: newShot.storyboardPanelImages,
              storyboardPanelImageStorageKeys: newShot.storyboardPanelImageStorageKeys,
              selectedStoryboardPanelImage: nextSelectedStoryboardPanelImage,
              selectedStoryboardPanelImageStorageKey: nextSelectedStoryboardPanelImageStorageKey,
              roles: newShot.roles,
              scenes: newShot.scenes,
              items: newShot.items,
              refAudioNames: newShot.refAudioNames,
              refVideoIds: newShot.refVideoIds,
              duration: newShot.duration,
              aspectRatio: newShot.aspectRatio
            }
          }
          if (shouldForceApplyPromptResult && nextOptimizedText.trim()) {
            appliedPromptShotNos.add(oldShot.shotNo)
          }
          return oldShot
        })
        
        if (appliedPromptShotNos.size > 0) {
          appliedPromptShotNos.forEach((shotNo) => pendingSinglePromptApplyShotNosRef.current.delete(shotNo))
        }
        if (hasChange) {
           setTimeout(() => setEditingShots(merged), 0)
        }
        return hasChange ? merged : prevSaved
      })
      return prevEditing // The actual update happens in setTimeout to avoid React warnings about nested updates
    })
    
    setSaving(false)
    setSavingShotNo(null)
  }, [props.shots, props.storyAspectRatio, episodeDefaultVideoModel, availableImageModels, availableVideoModels, fallbackResolution, serverDefaultStoryboardPanelModel])

  // Convert inline status text into a floating notice.
  useEffect(() => {
    const msg = saveError ? saveError : episodeVideoNotice || (videoPromptJobId ? `视频提示词任务已进入任务队列：${videoPromptJobId}` : "")
    if (!msg) return
    setFloatingNotice(msg)
  }, [episodeVideoNotice, saveError, videoPromptJobId])

  // Auto-dismiss floating notice after 3 seconds.
  useEffect(() => {
    if (!floatingNotice) return
    const t = window.setTimeout(() => setFloatingNotice(""), 3000)
    return () => window.clearTimeout(t)
  }, [floatingNotice])

  const closeEpisodeTab = (episodeId: string) => {
    // IMPORTANT: don't call router.push inside setState callback; it triggers
    // "Cannot update a component (Router) while rendering a different component".
    const next = removeOpenEpisodeTab(props.storyId, episodeId)
    setOpenEpisodeTabs(next)

    if (episodeId !== props.episodeId) return

    const fallback = next.length > 0 ? next[Math.max(0, next.length - 1)] : null
    if (fallback) {
      const qs = new URLSearchParams()
      qs.set("storyId", props.storyId)
      router.push(
        `/script/quick-generate/${encodeURIComponent(props.storyId)}/episodes/${encodeURIComponent(fallback.id)}?${qs.toString()}`
      )
      return
    }

    // No opened tabs left -> go back to episodes tab.
    router.push(`/script/quick-generate/${encodeURIComponent(props.storyId)}?tab=episodes`)
  }

  useEffect(() => {
    if (!isProcessing) return
    if (props.parseError) return
    if (props.shots.length > 0) return
    if (saving) return

    const timer = window.setTimeout(() => {
      router.refresh()
    }, 3000)

    return () => {
      window.clearTimeout(timer)
    }
  }, [isProcessing, props.parseError, props.shots.length, router, saving])

  useEffect(() => {
    if (!videoPromptJobId) return
    const timer = window.setInterval(() => {
      router.refresh()
    }, 3000)
    return () => {
      window.clearInterval(timer)
    }
  }, [router, videoPromptJobId])

  useEffect(() => {
    requestedVideoRefreshJobIdsRef.current = new Set()
    setShotVideoJobStates({})
    setShotVideoInlineStates({})
    setVideoPromptJobId(null)
    setPanelPromptJobId(null)
    setPanelImageJobId(null)
    setPromptJobRunning(false)
    setPromptJobTargets(new Set())
    pendingSinglePromptApplyShotNosRef.current = new Set()
    setPanelPromptJobRunning(false)
    setPanelPromptJobTargets(new Set())
    setPanelImageJobRunning(false)
    setPanelImageJobTargets(new Set())
  }, [props.episodeId])

  useEffect(() => {
    refreshedAfterEpisodeCreateDoneRef.current = new Set()
    handledPromptDoneJobIdsRef.current = new Set()
  }, [props.episodeId])

  const hasStructuralChanges = useMemo(() => hasStructuralChangesBetweenShots(editingShots, savedShots), [editingShots, savedShots])
  const structuralChangeNotice = "当前存在未保存的分镜结构调整，请先点击右上角“保存全部分镜”，保存后再生成提示词、分镜板或视频"
  const saveAllButtonLabel = saving ? "保存中..." : hasStructuralChanges ? "先保存全部分镜" : "保存全部分镜"
  const structuralChangeTitle = hasStructuralChanges ? structuralChangeNotice : undefined

  /**
   * 为镜头提交前补齐派生字段，并统一落到可持久化的标准结构。
   */
  const prepareShotForSubmit = useCallback((shot: EditableShot) => {
    const derived = derivePromptBindings({
      optimizedText: shot.optimizedText,
      allMentionItems,
      videoIdByLabel,
      currentMutedAutoAudioNames: shot.mutedAutoAudioNames,
      currentRefAudioNames: shot.refAudioNames,
      roleVoiceMap: props.roleVoiceMap
    })
    const normalized = normalizeEditableShot({
      ...shot,
      ...derived
    }, availableVideoModels, episodeDefaultVideoModel, fallbackResolution)
    return {
      ...normalized,
      storyboardPanelModel: normalizeImageModel(
        normalized.storyboardPanelModel,
        availableImageModels,
        serverDefaultStoryboardPanelModel
      )
    }
  }, [allMentionItems, availableImageModels, availableVideoModels, episodeDefaultVideoModel, fallbackResolution, props.roleVoiceMap, serverDefaultStoryboardPanelModel, videoIdByLabel])

  const preparePanelShotForSubmit = useCallback((shot: EditableShot) => {
    const panelDerived = derivePanelPromptMaterialBindings({
      storyboardPanelPrompt: shot.storyboardPanelPrompt,
      allMentionItems
    })
    const normalized = prepareShotForSubmit(shot)
    return {
      ...normalized,
      ...panelDerived,
      storyboardPanelModel: normalizeImageModel(
        normalized.storyboardPanelModel,
        availableImageModels,
        serverDefaultStoryboardPanelModel
      )
    }
  }, [allMentionItems, availableImageModels, prepareShotForSubmit, serverDefaultStoryboardPanelModel])

  /**
   * 视频提示词工作流除了镜头文本外，还会携带当前分镜板提示词，供下游工作流按需融合。
   */
  const buildVideoPromptJobShot = useCallback((shot: EditableShot) => ({
    shotNo: shot.shotNo,
    shotText: shot.shotText.trim(),
    roles: shot.roles,
    scenes: shot.scenes,
    items: shot.items,
    fenjingban_prompt: String(shot.storyboardPanelPrompt ?? "")
  }), [])

  /**
   * 为当前剧集提交分镜板提示词生成任务
   */
  const enqueueEpisodePanelPrompts = useCallback(async () => {
    if (saving || optimizingPrompts || generatingEpisodePanelPrompts || generatingEpisodePanelImages || generatingEpisodeVideos || editingShots.length === 0) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    setGeneratingEpisodePanelPrompts(true)
    setPanelPromptJobTargets((prev) => new Set(prev).add("all"))
    setSaveError("")
    try {
      const result = await generateQuickGenerateEpisodePanelPrompts({
        episodeId: props.episodeId,
        personalPrompt: props.initialStoryboardPanelPersonalPrompt,
        shots: editingShots.map((shot) => ({
          shotNo: shot.shotNo,
          shotText: shot.shotText.trim(),
          roles: shot.roles,
          scenes: shot.scenes,
          items: shot.items
        }))
      })
      setPanelPromptJobId(result.jobId)
      setEpisodeVideoNotice(`分镜板提示词任务已批量入队：${result.queuedCount} 个`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "生成分镜板提示词失败，请稍后重试")
    } finally {
      setGeneratingEpisodePanelPrompts(false)
    }
  }, [editingShots, generatingEpisodePanelPrompts, generatingEpisodePanelImages, generatingEpisodeVideos, hasStructuralChanges, optimizingPrompts, props.episodeId, props.initialStoryboardPanelPersonalPrompt, saving, structuralChangeNotice])

  /**
   * 为当前剧集提交分镜板图片生成任务
   */
  const enqueueEpisodePanelImages = useCallback(async () => {
    if (saving || optimizingPrompts || generatingEpisodePanelPrompts || generatingEpisodePanelImages || generatingEpisodeVideos || editingShots.length === 0) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    setGeneratingEpisodePanelImages(true)
    setPanelImageJobTargets((prev) => new Set(prev).add("all"))
    setSaveError("")
    try {
      const normalizedEditingShots = editingShots.map((shot) => preparePanelShotForSubmit(shot))
      const result = await generateQuickGenerateEpisodePanelImages({
        episodeId: props.episodeId,
        shots: normalizedEditingShots.map((shot) => ({
          shotNo: shot.shotNo,
          shotText: shot.shotText,
          roles: shot.roles,
          roleMaterialIdsByName: pickMaterialIdsByNames(shot.roles, roleMaterialIdByName),
          scenes: shot.scenes,
          sceneMaterialIdsByName: pickMaterialIdsByNames(shot.scenes, sceneMaterialIdByName),
          items: shot.items,
          itemMaterialIdsByName: pickMaterialIdsByNames(shot.items, itemMaterialIdByName),
          optimizedText: shot.optimizedText,
          speakerList: shot.speakerList,
          refAudioNames: shot.refAudioNames,
          mutedAutoAudioNames: shot.mutedAutoAudioNames,
          refVideoIds: shot.refVideoIds,
          duration: shot.duration,
          generateAudio: shot.generateAudio,
          watermark: shot.watermark,
          aspectRatio: shot.aspectRatio,
          resolution: shot.resolution,
          videoModel: shot.videoModel,
          storyboardPanelPrompt: shot.storyboardPanelPrompt,
          storyboardPanelModel: shot.storyboardPanelModel,
          storyboardPanelImageStorageKeys: shot.storyboardPanelImageStorageKeys,
          selectedStoryboardPanelImage: shot.selectedStoryboardPanelImage
          ,
          selectedStoryboardPanelImageStorageKey: shot.selectedStoryboardPanelImageStorageKey
        }))
      })
      setPanelImageJobId(result.jobId)
      setEpisodeVideoNotice(`分镜板图片任务已批量入队：${result.queuedCount} 个`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "生成分镜板图片失败，请稍后重试")
    } finally {
      setGeneratingEpisodePanelImages(false)
    }
  }, [editingShots, generatingEpisodePanelPrompts, generatingEpisodePanelImages, generatingEpisodeVideos, hasStructuralChanges, optimizingPrompts, props.episodeId, saving, structuralChangeNotice, preparePanelShotForSubmit, roleMaterialIdByName, sceneMaterialIdByName, itemMaterialIdByName])

  /**
   * 为当前剧集提交视频提示词生成任务，供自动编排和手动分镜操作复用。
   */
  const enqueueEpisodeVideoPrompts = useCallback(async () => {
    if (saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos || editingShots.length === 0) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    setOptimizingPrompts(true)
    setPromptJobTargets((prev) => new Set(prev).add("all"))
    setSaveError("")
    try {
      const result = await generateQuickGenerateEpisodeVideoPrompts({
        episodeId: props.episodeId,
        shots: editingShots.map((shot) => buildVideoPromptJobShot(shot))
      })
      setVideoPromptJobId(result.jobId)
      setEpisodeVideoNotice(`视频提示词任务已批量入队：${result.queuedCount} 个`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "生成视频提示词失败，请稍后重试")
    } finally {
      setOptimizingPrompts(false)
    }
  }, [buildVideoPromptJobShot, editingShots, generatingEpisodeVideos, hasStructuralChanges, optimizingPrompts, props.episodeId, saving, savingShotNo, structuralChangeNotice])

  useEffect(() => {
    if (isProcessing || props.parseError || shotCount === 0) return

    let cancelled = false
    const loadShotVideoJobs = async () => {
      try {
        const res = await fetch(
          `/api/jobs?storyId=${encodeURIComponent(props.storyId)}&activeOnly=false&limit=200`,
          { cache: "no-store" }
        )
        const json = (await res.json().catch(() => null)) as
          | {
              ok?: boolean
              data?: {
                jobs?: Array<{
                  jobId?: unknown
                  type?: unknown
                  status?: unknown
                  snapshot?: unknown
                }>
              }
            }
          | null
        if (!res.ok || !json?.ok) return

        const rows = Array.isArray(json.data?.jobs) ? json.data.jobs : []
        const nextStates: Record<number, QuickGenerateShotVideoJobState> = {}
        let shouldRefresh = false

        for (const row of rows) {
          const type = String(row?.type ?? "").trim()
          if (type !== "canvas_video_generate" && type !== QUICK_GENERATE_VIDEO_SUBTITLE_ERASE_JOB_TYPE) continue

          const snapshot =
            row?.snapshot && typeof row.snapshot === "object" && !Array.isArray(row.snapshot)
              ? (row.snapshot as Record<string, unknown>)
              : {}
          const nodeId = String(snapshot.nodeId ?? "").trim()
          const parsed = parseQuickGenerateShotNodeId(nodeId, props.episodeId)
          if (!parsed || nextStates[parsed.shotNo]) continue

          const jobId = String(row?.jobId ?? "").trim()
          const status = String(row?.status ?? "").trim()
          const stage = String(snapshot.stage ?? "").trim()
          const errorMessage = String(snapshot.errorMessage ?? "").trim()

          if (status === "queued" || status === "running" || status === "error") {
            nextStates[parsed.shotNo] = {
              jobId,
              jobType: type,
              status: status as QuickGenerateShotVideoJobState["status"],
              stage,
              errorMessage
            }
          }

          const latestPersistedJobId = props.videoResultsByShotNo[parsed.shotNo]?.videos?.[0]?.jobId ?? ""
          if (status === "done" && jobId && jobId !== latestPersistedJobId && !requestedVideoRefreshJobIdsRef.current.has(jobId)) {
            requestedVideoRefreshJobIdsRef.current.add(jobId)
            shouldRefresh = true
          }
        }

        if (!cancelled) {
          clearShotVideoInlineStates(
            Object.entries(nextStates)
              .filter(([, state]) => state.status === "queued" || state.status === "running")
              .map(([key]) => Number(key))
          )
          setShotVideoJobStates(nextStates)
        }
        if (!cancelled && shouldRefresh) router.refresh()
      } catch {
        // Ignore transient polling errors; the next tick can recover.
      }
    }

    void loadShotVideoJobs()
    const hasPendingLocalState = generatingEpisodeVideos || generatingVideoShotNo !== null
    const timer = window.setInterval(loadShotVideoJobs, hasPendingLocalState ? 3000 : 5000)
    return () => {
      cancelled = true
      window.clearInterval(timer)
    }
  }, [
    generatingEpisodeVideos,
    generatingVideoShotNo,
    isProcessing,
    props.episodeId,
    props.parseError,
    props.storyId,
    props.videoResultsByShotNo,
    router,
    shotCount
  ])

  useEffect(() => {
    if (props.parseError) return

    let cancelled = false

    const pollQuickGenerateJobs = async () => {
      try {
        const res = await fetch(
          `/api/jobs?storyId=${encodeURIComponent(props.storyId)}&activeOnly=false&limit=200`,
          { cache: "no-store" }
        )
        const json = (await res.json().catch(() => null)) as
          | {
              ok?: boolean
              data?: {
                jobs?: StoryJobRow[]
              }
            }
          | null
        if (!res.ok || !json?.ok || cancelled) return

        const rows = Array.isArray(json.data?.jobs) ? json.data.jobs : []
        let shouldRefreshForPromptDone = false
        let episodeCreateJobDone = false
        let anyPromptJobRunning = false
        const currentPromptTargets = new Set<number | "all">()
        let currentVideoPromptJobStatus: string | null = null
        
        let anyPanelPromptJobRunning = false
        const currentPanelPromptTargets = new Set<number | "all">()
        let currentPanelPromptJobStatus: string | null = null
        let anyPanelImageJobRunning = false
        const currentPanelImageTargets = new Set<number | "all">()
        let currentPanelImageJobStatus: string | null = null

        for (const row of rows) {
          const type = String(row?.type ?? "").trim()
          const status = String(row?.status ?? "").trim().toLowerCase()
          const rowJobId = String(row?.jobId ?? "").trim()
          const snapshot =
            row?.snapshot && typeof row.snapshot === "object" && !Array.isArray(row.snapshot)
              ? (row.snapshot as Record<string, unknown>)
              : {}
          const snapshotEpisodeId = String(snapshot.episodeId ?? "").trim()
          if (snapshotEpisodeId !== props.episodeId) continue

          if (type === QUICK_GENERATE_EPISODE_CREATE_JOB_TYPE && status === "done") {
            episodeCreateJobDone = true
          }

          if (type === QUICK_GENERATE_VIDEO_PROMPT_JOB_TYPE) {
            if (rowJobId && rowJobId === videoPromptJobId) currentVideoPromptJobStatus = status
            if (isQuickGenerateJobActiveStatus(status)) {
              anyPromptJobRunning = true
              const shotsArr = snapshot.shots
              if (Array.isArray(shotsArr)) {
                if (shotsArr.length === 1 && typeof shotsArr[0]?.shotNo === "number") {
                  currentPromptTargets.add(shotsArr[0].shotNo)
                } else {
                  currentPromptTargets.add("all")
                }
              } else {
                currentPromptTargets.add("all")
              }
            }

            if (
              status === "done" &&
              rowJobId &&
              !handledPromptDoneJobIdsRef.current.has(rowJobId)
            ) {
              handledPromptDoneJobIdsRef.current.add(rowJobId)
              shouldRefreshForPromptDone = true
            }
            if (status === "error") {
              const shotsArr = Array.isArray(snapshot.shots) ? snapshot.shots : []
              if (shotsArr.length === 1 && typeof shotsArr[0]?.shotNo === "number") {
                pendingSinglePromptApplyShotNosRef.current.delete(shotsArr[0].shotNo)
              }
            }
          } else if (type === QUICK_GENERATE_PANEL_PROMPT_JOB_TYPE) {
            if (rowJobId && rowJobId === panelPromptJobId) currentPanelPromptJobStatus = status
            if (isQuickGenerateJobActiveStatus(status)) {
              anyPanelPromptJobRunning = true
              const shotsArr = snapshot.shots
              if (Array.isArray(shotsArr)) {
                if (shotsArr.length === 1 && typeof shotsArr[0]?.shotNo === "number") {
                  currentPanelPromptTargets.add(shotsArr[0].shotNo)
                } else {
                  currentPanelPromptTargets.add("all")
                }
              } else {
                currentPanelPromptTargets.add("all")
              }
            }
            if (
              status === "done" &&
              rowJobId &&
              !handledPromptDoneJobIdsRef.current.has(rowJobId)
            ) {
              handledPromptDoneJobIdsRef.current.add(rowJobId)
              shouldRefreshForPromptDone = true
            }
          } else if (type === QUICK_GENERATE_PANEL_IMAGE_JOB_TYPE) {
            if (rowJobId && rowJobId === panelImageJobId) currentPanelImageJobStatus = status
            if (isQuickGenerateJobActiveStatus(status)) {
              anyPanelImageJobRunning = true
              const shotsArr = snapshot.shots
              if (Array.isArray(shotsArr)) {
                if (shotsArr.length === 1 && typeof shotsArr[0]?.shotNo === "number") {
                  currentPanelImageTargets.add(shotsArr[0].shotNo)
                } else {
                  currentPanelImageTargets.add("all")
                }
              } else {
                currentPanelImageTargets.add("all")
              }
            }
            if (
              status === "done" &&
              rowJobId &&
              !handledPromptDoneJobIdsRef.current.has(rowJobId)
            ) {
              handledPromptDoneJobIdsRef.current.add(rowJobId)
              shouldRefreshForPromptDone = true
            }
          } else if (type === QUICK_GENERATE_STORYBOARD_PANEL_REVIEW_POLL_JOB_TYPE) {
            if (
              (status === "done" || status === "error") &&
              rowJobId &&
              !handledPromptDoneJobIdsRef.current.has(rowJobId)
            ) {
              handledPromptDoneJobIdsRef.current.add(rowJobId)
              shouldRefreshForPromptDone = true
            }
          }
        }
        if (!cancelled) {
          setPromptJobRunning(anyPromptJobRunning)
          if (anyPromptJobRunning) {
            setPromptJobTargets(currentPromptTargets)
          } else if (!anyPromptJobRunning && !optimizingPrompts && optimizingPromptShotNo === null) {
            setPromptJobTargets(new Set())
          }
          
          setPanelPromptJobRunning(anyPanelPromptJobRunning)
          if (anyPanelPromptJobRunning) {
            setPanelPromptJobTargets(currentPanelPromptTargets)
          } else if (!anyPanelPromptJobRunning && !generatingEpisodePanelPrompts && generatingPanelPromptShotNo === null) {
            setPanelPromptJobTargets(new Set())
          }
          
          setPanelImageJobRunning(anyPanelImageJobRunning)
          if (anyPanelImageJobRunning) {
            setPanelImageJobTargets(currentPanelImageTargets)
          } else if (!anyPanelImageJobRunning && !generatingEpisodePanelImages && generatingPanelImageShotNo === null) {
            setPanelImageJobTargets(new Set())
          }

          if (videoPromptJobId && currentVideoPromptJobStatus && isQuickGenerateJobTerminalStatus(currentVideoPromptJobStatus)) {
            setVideoPromptJobId(null)
          }
          if (panelPromptJobId && currentPanelPromptJobStatus && isQuickGenerateJobTerminalStatus(currentPanelPromptJobStatus)) {
            setPanelPromptJobId(null)
          }
          if (panelImageJobId && currentPanelImageJobStatus && isQuickGenerateJobTerminalStatus(currentPanelImageJobStatus)) {
            setPanelImageJobId(null)
          }
        }

        const needsEpisodeRefresh = episodeCreateJobDone && (isProcessing || props.shots.length === 0)
        if (
          needsEpisodeRefresh &&
          !refreshedAfterEpisodeCreateDoneRef.current.has(props.episodeId)
        ) {
          refreshedAfterEpisodeCreateDoneRef.current.add(props.episodeId)
          router.refresh()
          return
        }

        if (shouldRefreshForPromptDone && !cancelled) {
          router.refresh()
        }
      } catch {
        // Ignore transient polling errors; the next tick can recover.
      }
    }

    void pollQuickGenerateJobs()
    const hasPendingQuickGenerateJob =
      Boolean(videoPromptJobId || panelPromptJobId || panelImageJobId) ||
      generatingEpisodePanelPrompts ||
      generatingEpisodePanelImages ||
      generatingPanelPromptShotNo !== null ||
      generatingPanelImageShotNo !== null
    const timer = window.setInterval(pollQuickGenerateJobs, hasPendingQuickGenerateJob ? 3000 : 5000)
    return () => {
      cancelled = true
      window.clearInterval(timer)
    }
  }, [
    generatingEpisodePanelImages,
    generatingEpisodePanelPrompts,
    generatingPanelImageShotNo,
    generatingPanelPromptShotNo,
    isProcessing,
    panelImageJobId,
    panelPromptJobId,
    props.episodeId,
    props.parseError,
    props.shots.length,
    props.storyId,
    router,
    videoPromptJobId
  ])

  const hasChanges = useMemo(() => {
    const current = JSON.stringify(editingShots.map((shot) => buildShotComparableValue(shot)))
    const initial = JSON.stringify(savedShots.map((shot) => buildShotComparableValue(shot)))
    return current !== initial
  }, [editingShots, savedShots])

  const dirtyShotNos = useMemo(() => {
    const initialByNo = new Map<number, EditableShot>()
    for (const shot of savedShots) initialByNo.set(shot.shotNo, shot)

    const dirty = new Set<number>()
    for (const shot of editingShots) {
      const initial = initialByNo.get(shot.shotNo)
      if (!initial) {
        // Newly inserted shots are dirty by default.
        dirty.add(shot.shotNo)
        continue
      }
      const currentComparable = buildShotComparableValue(shot)
      const initialComparable = buildShotComparableValue(initial)
      if (currentComparable !== initialComparable) dirty.add(shot.shotNo)
    }
    return dirty
  }, [editingShots, savedShots])

  // 单分镜保存仅在分镜结构完全对齐时启用，避免新增/删除/中间插入后的结构性变更被局部保存误覆盖。
  const supportsSingleShotSave = !hasStructuralChanges

  const updateShot = (shotNo: number, patch: Partial<EditableShot>) => {
    setEditingShots((prev) =>
      prev.map((shot) => {
        if (shot.shotNo !== shotNo) return shot
        const normalizedPatch: Partial<EditableShot> = {
          ...patch,
          ...(typeof patch.shotText === "string" ? { shotText: normalizeQuickGenerateEditorText(patch.shotText) } : {})
        }

        // When prompt text changes, sync bound materials from @ mentions. This is a
        // "quick preview" only: users no longer edit materials manually here.
        if (typeof patch.optimizedText === "string") {
          const normalizedOptimizedText = normalizeQuickGenerateEditorText(patch.optimizedText)
          const derived = derivePromptBindings({
            optimizedText: normalizedOptimizedText,
            allMentionItems,
            videoIdByLabel,
            currentMutedAutoAudioNames: shot.mutedAutoAudioNames,
            currentRefAudioNames: shot.refAudioNames,
            roleVoiceMap: props.roleVoiceMap
          })

          return {
            ...shot,
            ...normalizedPatch,
            optimizedText: normalizedOptimizedText,
            ...derived
          }
        }

        return { ...shot, ...normalizedPatch }
      })
    )
  }

  const removeAudioReference = (shotNo: number, audioName: string) => {
    const target = String(audioName ?? "").trim()
    if (!target) return
    setEditingShots((prev) =>
      prev.map((shot) => {
        if (shot.shotNo !== shotNo) return shot
        const esc = target.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
        const plainAudioRe = `${esc}(?:-音频)?`
        const inlineRe = new RegExp(`\\s*音色是\\s*@${plainAudioRe}(?=\\s|[，。！？、；：,.!?;:）)】」』]|$|\\n)`, "gu")
        const tailRe = new RegExp(`(?:^|\\n)\\s*@[^@\\n]+?\\s*音色是\\s*@${plainAudioRe}\\s*(?=\\n|$)`, "gu")
        const tokenTailRe = new RegExp(`(?:^|\\n)\\s*\\{\\{role:[^}]+\\}\\}\\s*音色是\\s*\\{\\{audio:${esc}\\}\\}\\s*(?=\\n|$)`, "gu")
        const nextText = shot.optimizedText
          .replace(tokenTailRe, "")
          .replace(tailRe, "")
          .replace(inlineRe, "")
          .replace(/\n{3,}/g, "\n\n")
          .trim()
        const idx = shot.refAudioNames.findIndex((item) => String(item ?? "").trim() === target)
        const nextRefAudioNames = idx >= 0 ? [...shot.refAudioNames.slice(0, idx), ...shot.refAudioNames.slice(idx + 1)] : shot.refAudioNames
        return {
          ...shot,
          optimizedText: nextText,
          refAudioNames: nextRefAudioNames,
          mutedAutoAudioNames: [...shot.mutedAutoAudioNames, target]
        }
      })
    )
  }

  const insertShotAfter = (shotNo: number | null) => {
    setSaveError("")
    setEditingShots((prev) => {
      const index = shotNo === null ? prev.length : prev.findIndex((shot) => shot.shotNo === shotNo) + 1
      const safeIndex = index < 0 ? prev.length : index
      const next = [...prev]
      next.splice(
        safeIndex,
        0,
        createEditableShot(
          undefined,
          props.storyAspectRatio,
          episodeDefaultVideoModel,
          undefined,
          availableVideoModels,
          fallbackResolution,
          undefined,
          availableImageModels,
          serverDefaultStoryboardPanelModel
        )
      )
      return renumberShots(next)
    })
  }

  const removeShot = (shotNo: number) => {
    setSaveError("")
    setEditingShots((prev) => {
      const next = prev.filter((shot) => shot.shotNo !== shotNo)
      return renumberShots(next)
    })
  }

  const saveShots = async () => {
    if (saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos) return
    setSaving(true)
    setSaveError("")
    try {
      const normalizedEditingShots = editingShots.map((shot) => prepareShotForSubmit(shot))
      await updateQuickGenerateEpisodeShots({
        episodeId: props.episodeId,
        shots: normalizedEditingShots.map((shot) => ({
          persistedShotNo: shot.persistedShotNo ?? undefined,
          shotText: shot.shotText.trim(),
          roles: shot.roles,
          scenes: shot.scenes,
          items: shot.items,
          optimizedText: shot.optimizedText.trim(),
          speakerList: shot.speakerList,
          refAudioNames: shot.refAudioNames,
          mutedAutoAudioNames: shot.mutedAutoAudioNames,
          refVideoIds: shot.refVideoIds,
          duration: shot.duration,
          generateAudio: shot.generateAudio,
          watermark: shot.watermark,
          aspectRatio: shot.aspectRatio,
          resolution: shot.resolution,
          videoModel: shot.videoModel,
          storyboardPanelPrompt: shot.storyboardPanelPrompt,
          storyboardPanelModel: shot.storyboardPanelModel,
          storyboardPanelImages: shot.storyboardPanelImages,
          storyboardPanelImageStorageKeys: shot.storyboardPanelImageStorageKeys,
          selectedStoryboardPanelImage: shot.selectedStoryboardPanelImage,
          selectedStoryboardPanelImageStorageKey: shot.selectedStoryboardPanelImageStorageKey
        }))
      })
      const persistedShots = normalizedEditingShots.map((shot) => ({ ...shot, persistedShotNo: shot.shotNo }))
      setEditingShots(persistedShots)
      setSavedShots(persistedShots)
      router.refresh()
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "保存失败，请稍后重试")
    } finally {
      setSaving(false)
    }
  }

  const saveSingleShot = async (shotNo: number) => {
    if (saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos) return
    if (!supportsSingleShotSave) return
    if (!dirtyShotNos.has(shotNo)) return

    const shot = editingShots.find((s) => s.shotNo === shotNo)
    if (!shot) return

    const normalizedShot = prepareShotForSubmit(shot)
    setSavingShotNo(shotNo)
    setSaveError("")
    try {
      await updateQuickGenerateEpisodeShots({
        episodeId: props.episodeId,
        shotNo,
        shot: {
          shotText: normalizedShot.shotText,
          roles: normalizedShot.roles,
          scenes: normalizedShot.scenes,
          items: normalizedShot.items,
          optimizedText: normalizedShot.optimizedText,
          speakerList: normalizedShot.speakerList,
          refAudioNames: normalizedShot.refAudioNames,
          mutedAutoAudioNames: normalizedShot.mutedAutoAudioNames,
          refVideoIds: normalizedShot.refVideoIds,
          duration: normalizedShot.duration,
          generateAudio: normalizedShot.generateAudio,
          watermark: normalizedShot.watermark,
          aspectRatio: normalizedShot.aspectRatio,
          resolution: normalizedShot.resolution,
          videoModel: normalizedShot.videoModel,
          storyboardPanelPrompt: normalizedShot.storyboardPanelPrompt,
          storyboardPanelModel: normalizedShot.storyboardPanelModel,
          storyboardPanelImages: normalizedShot.storyboardPanelImages,
          storyboardPanelImageStorageKeys: normalizedShot.storyboardPanelImageStorageKeys,
          selectedStoryboardPanelImage: normalizedShot.selectedStoryboardPanelImage,
          selectedStoryboardPanelImageStorageKey: normalizedShot.selectedStoryboardPanelImageStorageKey
        }
      })
      const persistedShot = { ...normalizedShot, persistedShotNo: normalizedShot.shotNo }
      setEditingShots((prev) => prev.map((item) => (item.shotNo === shotNo ? persistedShot : item)))
      setSavedShots((prev) => prev.map((item) => (item.shotNo === shotNo ? persistedShot : item)))
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "保存失败，请稍后重试")
    } finally {
      setSavingShotNo(null)
    }
  }

  const confirmStoryboardPanelImage = async (
    shotNo: number,
    selectedStoryboardPanelImage: string,
    selectedStoryboardPanelImageStorageKey: string
  ) => {
    if (saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos) return
    if (!supportsSingleShotSave) {
      setSaveError(structuralChangeNotice)
      return
    }

    const currentShot = editingShots.find((shot) => shot.shotNo === shotNo)
    if (!currentShot) return

    const nextShot = {
      ...currentShot,
      selectedStoryboardPanelImage,
      selectedStoryboardPanelImageStorageKey
    }
    const normalizedShot = prepareShotForSubmit(nextShot)
    const persistedShot = { ...normalizedShot, persistedShotNo: normalizedShot.shotNo }

    setSavingShotNo(shotNo)
    setSaveError("")
    setEditingShots((prev) => prev.map((item) => (item.shotNo === shotNo ? persistedShot : item)))

    try {
      await updateQuickGenerateEpisodeShots({
        episodeId: props.episodeId,
        shotNo,
        shot: {
          shotText: normalizedShot.shotText,
          roles: normalizedShot.roles,
          scenes: normalizedShot.scenes,
          items: normalizedShot.items,
          optimizedText: normalizedShot.optimizedText,
          speakerList: normalizedShot.speakerList,
          refAudioNames: normalizedShot.refAudioNames,
          mutedAutoAudioNames: normalizedShot.mutedAutoAudioNames,
          refVideoIds: normalizedShot.refVideoIds,
          duration: normalizedShot.duration,
          generateAudio: normalizedShot.generateAudio,
          watermark: normalizedShot.watermark,
          aspectRatio: normalizedShot.aspectRatio,
          resolution: normalizedShot.resolution,
          videoModel: normalizedShot.videoModel,
          storyboardPanelPrompt: normalizedShot.storyboardPanelPrompt,
          storyboardPanelModel: normalizedShot.storyboardPanelModel,
          storyboardPanelImages: normalizedShot.storyboardPanelImages,
          storyboardPanelImageStorageKeys: normalizedShot.storyboardPanelImageStorageKeys,
          selectedStoryboardPanelImage: normalizedShot.selectedStoryboardPanelImage,
          selectedStoryboardPanelImageStorageKey: normalizedShot.selectedStoryboardPanelImageStorageKey
        }
      })
      setSavedShots((prev) => prev.map((item) => (item.shotNo === shotNo ? persistedShot : item)))
    } catch (e) {
      const anyErr = e as { message?: string }
      setEditingShots((prev) => prev.map((item) => (item.shotNo === shotNo ? currentShot : item)))
      setSaveError(anyErr?.message?.trim() || "确认分镜板失败，请稍后重试")
    } finally {
      setSavingShotNo(null)
    }
  }

  /**
   * 仅为当前分镜生成视频提示词，复用整集接口但仅提交单条镜头数据。
   */
  const generateSingleShotPrompt = async (shotNo: number) => {
    if (saving || optimizingPrompts || optimizingPromptShotNo !== null || savingShotNo !== null || generatingEpisodeVideos || generatingVideoShotNo !== null) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    const shot = editingShots.find((item) => item.shotNo === shotNo)
    if (!shot) return

    pendingSinglePromptApplyShotNosRef.current.add(shotNo)
    setOptimizingPromptShotNo(shotNo)
    setPromptJobTargets((prev) => new Set(prev).add(shotNo))
    setSaveError("")
    try {
      const result = await generateQuickGenerateEpisodeVideoPrompts({
        episodeId: props.episodeId,
        shots: [
          buildVideoPromptJobShot(shot)
        ]
      })
      setVideoPromptJobId(result.jobId)
      setEpisodeVideoNotice(`分镜 ${shotNo} 的视频提示词任务已入队`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "生成分镜视频提示词失败，请稍后重试")
    } finally {
      setOptimizingPromptShotNo(null)
    }
  }

  const generateSingleShotPanelPrompt = async (shotNo: number) => {
    if (saving || optimizingPrompts || optimizingPromptShotNo !== null || savingShotNo !== null || generatingEpisodeVideos || generatingVideoShotNo !== null || generatingPanelPromptShotNo !== null || generatingPanelImageShotNo !== null) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    const shot = editingShots.find((item) => item.shotNo === shotNo)
    if (!shot) return

    setGeneratingPanelPromptShotNo(shotNo)
    setPanelPromptJobTargets((prev) => new Set(prev).add(shotNo))
    setSaveError("")
    try {
      const result = await generateQuickGenerateEpisodePanelPrompts({
        episodeId: props.episodeId,
        personalPrompt: props.initialStoryboardPanelPersonalPrompt,
        shots: [
          {
            shotNo: shot.shotNo,
            shotText: shot.shotText.trim(),
            roles: shot.roles,
            scenes: shot.scenes,
            items: shot.items
          }
        ]
      })
      setPanelPromptJobId(result.jobId)
      setEpisodeVideoNotice(`分镜 ${shotNo} 的分镜板提示词任务已入队`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "生成分镜板提示词失败，请稍后重试")
    } finally {
      setGeneratingPanelPromptShotNo(null)
    }
  }

  const generateSingleShotPanelImage = async (shotNo: number) => {
    if (saving || optimizingPrompts || optimizingPromptShotNo !== null || savingShotNo !== null || generatingEpisodeVideos || generatingVideoShotNo !== null || generatingPanelPromptShotNo !== null || generatingPanelImageShotNo !== null) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    const shot = editingShots.find((item) => item.shotNo === shotNo)
    if (!shot) return

    setGeneratingPanelImageShotNo(shotNo)
    setPanelImageJobTargets((prev) => new Set(prev).add(shotNo))
    setSaveError("")
    try {
      const preparedShot = preparePanelShotForSubmit(shot)
      const result = await generateQuickGenerateEpisodePanelImages({
        episodeId: props.episodeId,
        shots: [{
          shotNo: preparedShot.shotNo,
          shotText: preparedShot.shotText,
          roles: preparedShot.roles,
          roleMaterialIdsByName: pickMaterialIdsByNames(preparedShot.roles, roleMaterialIdByName),
          scenes: preparedShot.scenes,
          sceneMaterialIdsByName: pickMaterialIdsByNames(preparedShot.scenes, sceneMaterialIdByName),
          items: preparedShot.items,
          itemMaterialIdsByName: pickMaterialIdsByNames(preparedShot.items, itemMaterialIdByName),
          optimizedText: preparedShot.optimizedText,
          speakerList: preparedShot.speakerList,
          refAudioNames: preparedShot.refAudioNames,
          mutedAutoAudioNames: preparedShot.mutedAutoAudioNames,
          refVideoIds: preparedShot.refVideoIds,
          duration: preparedShot.duration,
          generateAudio: preparedShot.generateAudio,
          watermark: preparedShot.watermark,
          aspectRatio: preparedShot.aspectRatio,
          resolution: preparedShot.resolution,
          videoModel: preparedShot.videoModel,
          storyboardPanelPrompt: preparedShot.storyboardPanelPrompt,
          storyboardPanelModel: preparedShot.storyboardPanelModel,
          storyboardPanelImageStorageKeys: preparedShot.storyboardPanelImageStorageKeys,
          selectedStoryboardPanelImage: preparedShot.selectedStoryboardPanelImage,
          selectedStoryboardPanelImageStorageKey: preparedShot.selectedStoryboardPanelImageStorageKey
        }]
      })
      setPanelImageJobId(result.jobId)
      setEpisodeVideoNotice(`分镜 ${shotNo} 的分镜板图片任务已入队`)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "生成分镜板图片失败，请稍后重试")
    } finally {
      setGeneratingPanelImageShotNo(null)
    }
  }

  /**
   * 仅为当前分镜提交视频生成任务，复用整集接口但只传单条镜头。
   */
  const generateSingleShotVideo = async (shotNo: number) => {
    if (saving || optimizingPrompts || optimizingPromptShotNo !== null || savingShotNo !== null || generatingEpisodeVideos || generatingVideoShotNo !== null) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    const shot = editingShots.find((item) => item.shotNo === shotNo)
    if (!shot) return

    setGeneratingVideoShotNo(shotNo)
      clearShotVideoInlineStates([shotNo])
    setSaveError("")
    setEpisodeVideoNotice("")
    try {
      const normalizedShot = prepareShotForSubmit(shot)
      const result = await generateQuickGenerateEpisodeVideos({
        episodeId: props.episodeId,
        shots: [
          {
            shotNo: normalizedShot.shotNo,
            shotText: normalizedShot.shotText,
            roles: normalizedShot.roles,
            roleMaterialIdsByName: pickMaterialIdsByNames(normalizedShot.roles, roleMaterialIdByName),
            scenes: normalizedShot.scenes,
            sceneMaterialIdsByName: pickMaterialIdsByNames(normalizedShot.scenes, sceneMaterialIdByName),
            items: normalizedShot.items,
            itemMaterialIdsByName: pickMaterialIdsByNames(normalizedShot.items, itemMaterialIdByName),
            optimizedText: normalizedShot.optimizedText,
            speakerList: normalizedShot.speakerList,
            refAudioNames: normalizedShot.refAudioNames,
            mutedAutoAudioNames: normalizedShot.mutedAutoAudioNames,
            refVideoIds: normalizedShot.refVideoIds,
            duration: normalizedShot.duration,
            generateAudio: normalizedShot.generateAudio,
            watermark: normalizedShot.watermark,
            aspectRatio: normalizedShot.aspectRatio,
            resolution: normalizedShot.resolution,
            videoModel: normalizedShot.videoModel,
            storyboardPanelImageStorageKeys: normalizedShot.storyboardPanelImageStorageKeys,
            selectedStoryboardPanelImage: normalizedShot.selectedStoryboardPanelImage,
            selectedStoryboardPanelImageStorageKey: normalizedShot.selectedStoryboardPanelImageStorageKey
          }
        ]
      })

      const single = result.results[0]
      const nextNotice =
        single?.status === "processing"
          ? single?.errorMessage?.trim() || "当前分镜板正在送审，审核通过后会自动继续生成视频"
          : single?.ok !== false
            ? `分镜 ${String(shotNo).padStart(2, "0")} 视频任务已入队`
            : single?.errorMessage?.trim() || "当前分镜视频生成失败，请稍后重试"
      if (single?.status === "processing") {
        setEpisodeVideoNotice(nextNotice)
        patchShotVideoInlineStates([{ shotNo, status: "running", message: nextNotice }])
      } else if (single?.ok === false) {
        setSaveError(nextNotice)
        patchShotVideoInlineStates([{ shotNo, status: "error", message: nextNotice }])
      } else {
        setEpisodeVideoNotice(nextNotice)
      }
    } catch (e) {
      const anyErr = e as { message?: string }
      const nextMessage = anyErr?.message?.trim() || "生成分镜视频失败，请稍后重试"
      setSaveError(nextMessage)
      patchShotVideoInlineStates([{ shotNo, status: "error", message: nextMessage }])
    } finally {
      setGeneratingVideoShotNo(null)
    }
  }

  const confirmGenerateSingleShotVideo = async () => {
    if (confirmGenerateVideoShotNo === null) return
    const shotNo = confirmGenerateVideoShotNo
    await generateSingleShotVideo(shotNo)
    setConfirmGenerateVideoShotNo(null)
  }

  /**
   * 批量提交当前剧集的分镜视频生成任务。
   */
  const confirmGenerateEpisodeVideo = async () => {
    if (saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos || editingShots.length === 0) return
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      setConfirmGenerateEpisodeVideoOpen(false)
      return
    }
    await generateEpisodeVideos()
    setConfirmGenerateEpisodeVideoOpen(false)
  }

  const generateEpisodeVideos = async () => {
    if (hasStructuralChanges) {
      setSaveError(structuralChangeNotice)
      return
    }
    setGeneratingEpisodeVideos(true)
    setSaveError("")
    setEpisodeVideoNotice("")
    try {
      const normalizedEditingShots = editingShots.map((shot) => prepareShotForSubmit(shot))
      clearShotVideoInlineStates(normalizedEditingShots.map((shot) => shot.shotNo))
      const result = await generateQuickGenerateEpisodeVideos({
        episodeId: props.episodeId,
        shots: normalizedEditingShots.map((shot) => ({
          shotNo: shot.shotNo,
          shotText: shot.shotText,
          roles: shot.roles,
          roleMaterialIdsByName: pickMaterialIdsByNames(shot.roles, roleMaterialIdByName),
          scenes: shot.scenes,
          sceneMaterialIdsByName: pickMaterialIdsByNames(shot.scenes, sceneMaterialIdByName),
          items: shot.items,
          itemMaterialIdsByName: pickMaterialIdsByNames(shot.items, itemMaterialIdByName),
          optimizedText: shot.optimizedText,
          speakerList: shot.speakerList,
          refAudioNames: shot.refAudioNames,
          mutedAutoAudioNames: shot.mutedAutoAudioNames,
          refVideoIds: shot.refVideoIds,
          duration: shot.duration,
          generateAudio: shot.generateAudio,
          watermark: shot.watermark,
          aspectRatio: shot.aspectRatio,
          resolution: shot.resolution,
          videoModel: shot.videoModel,
          storyboardPanelImageStorageKeys: shot.storyboardPanelImageStorageKeys,
          selectedStoryboardPanelImage: shot.selectedStoryboardPanelImage,
          selectedStoryboardPanelImageStorageKey: shot.selectedStoryboardPanelImageStorageKey
        }))
      })

      const firstFailed = result.results.find((item) => item.status === "failed" && item.errorMessage)?.errorMessage ?? ""
      const nextNoticeParts = [`已入队 ${result.queuedCount} 个分镜视频任务`]
      if (result.processingCount > 0) nextNoticeParts.push(`${result.processingCount} 个分镜板送审中`)
      if (result.skippedCount > 0) nextNoticeParts.push(`失败 ${result.skippedCount} 个分镜${firstFailed ? `：${firstFailed}` : ""}`)
      const nextNotice = nextNoticeParts.join("，")
      patchShotVideoInlineStates(
        result.results.map((item) => ({
          shotNo: item.shotNo,
          status: item.status === "processing" ? "running" : item.status === "failed" ? "error" : null,
          message: item.status === "queued" ? "" : item.errorMessage
        }))
      )
      setEpisodeVideoNotice(nextNotice)
    } catch (e) {
      const anyErr = e as { message?: string }
      setSaveError(anyErr?.message?.trim() || "批量生成当前剧集视频失败，请稍后重试")
    } finally {
      setGeneratingEpisodeVideos(false)
    }
  }

  const openEpisodes = useMemo(() => {
    const map = new Map(props.episodes.map((e) => [e.id, e]))
    return openEpisodeTabs
      .map((t) => map.get(t.id))
      .filter(Boolean) as Array<{ id: string; episodeNo: number; title: string | null }>
  }, [openEpisodeTabs, props.episodes])

  return (
    <main className={styles.page}>
      <section className={styles.headerCard} aria-label="项目信息">
        <div className={styles.headerLeft}>
          <div className={styles.headerTag}>快速生成</div>
          <div className={styles.projectTitle}>{props.storyTitle.trim() || "未命名快速生成项目"}</div>
        </div>
      </section>
      <section className={styles.tabsHeader} aria-label="快速生成导航">
        <div className={styles.tabsLeft}>
          <div className={styles.tabs}>
            <button
              type="button"
              className={styles.tab}
              onClick={() => router.push(`/script/quick-generate/${encodeURIComponent(props.storyId)}?tab=materials`)}
            >
              素材
            </button>
            <button
              type="button"
              className={`${styles.tab} ${styles.tabActive}`}
              onClick={() => router.push(`/script/quick-generate/${encodeURIComponent(props.storyId)}?tab=episodes`)}
            >
              剧集
            </button>
          </div>
          <div className={styles.episodeTabs} aria-label="剧集标签">
            {openEpisodes.map((e) => {
              const isActive = e.id === props.episodeId
              const label = `第 ${e.episodeNo} 集`
              return (
                <div
                  key={e.id}
                  className={`${styles.episodeTab} ${isActive ? styles.episodeTabActive : ""}`}
                  role="button"
                  tabIndex={0}
                  onClick={() => {
                    const qs = new URLSearchParams()
                    qs.set("storyId", props.storyId)
                    router.push(
                      `/script/quick-generate/${encodeURIComponent(props.storyId)}/episodes/${encodeURIComponent(e.id)}?${qs.toString()}`
                    )
                  }}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault()
                      const qs = new URLSearchParams()
                      qs.set("storyId", props.storyId)
                      router.push(
                        `/script/quick-generate/${encodeURIComponent(props.storyId)}/episodes/${encodeURIComponent(e.id)}?${qs.toString()}`
                      )
                    }
                  }}
                >
                  <span className={styles.episodeTabText}>{label}</span>
                  <div
                    className={styles.episodeTabClose}
                    role="button"
                    tabIndex={0}
                    aria-label="关闭标签"
                    onClick={(event) => {
                      event.preventDefault()
                      event.stopPropagation()
                      closeEpisodeTab(e.id)
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        event.preventDefault()
                        event.stopPropagation()
                        closeEpisodeTab(e.id)
                      }
                    }}
                  >
                    <X size={14} />
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <section className={styles.header}>
        <div className={styles.titleWrap}>
          <Link className={styles.backBtn} href={`/script/quick-generate/${encodeURIComponent(props.storyId)}?tab=episodes`} aria-label="返回剧集列表">
            <ArrowLeft size={18} />
          </Link>
          <div className={styles.title}>第 {props.episodeNo} 集</div>
          <div className={styles.subtitle}>{shotCount > 0 ? `分镜数: ${shotCount}` : "等待拆分结果"}</div>
        </div>
        <div className={styles.actions}>
          {!isProcessing && !props.parseError ? (
            <button
              type="button"
              className={`${styles.btn} ${styles.primaryBtn}`}
              title={structuralChangeTitle}
              disabled={
                saving ||
                optimizingPrompts ||
                promptJobRunning ||
                panelPromptJobRunning ||
                panelImageJobRunning ||
                videoPromptJobId !== null ||
                panelPromptJobId !== null ||
                panelImageJobId !== null ||
                savingShotNo !== null ||
                generatingEpisodeVideos ||
                generatingEpisodePanelPrompts ||
                generatingEpisodePanelImages ||
                editingShots.length === 0 ||
                hasStructuralChanges
              }
              onClick={() => void enqueueEpisodePanelPrompts()}
            >
              {generatingEpisodePanelPrompts ? "生成中..." : "重新生成全部分镜板提示词"}
            </button>
          ) : null}
          {!isProcessing && !props.parseError ? (
            <button
              type="button"
              className={`${styles.btn} ${styles.primaryBtn}`}
              title={structuralChangeTitle}
              disabled={
                saving ||
                optimizingPrompts ||
                promptJobRunning ||
                panelPromptJobRunning ||
                panelImageJobRunning ||
                videoPromptJobId !== null ||
                panelPromptJobId !== null ||
                panelImageJobId !== null ||
                savingShotNo !== null ||
                generatingEpisodeVideos ||
                generatingEpisodePanelPrompts ||
                generatingEpisodePanelImages ||
                editingShots.length === 0 ||
                hasStructuralChanges
              }
              onClick={() => void enqueueEpisodePanelImages()}
            >
              {generatingEpisodePanelImages ? "生成中..." : "生成分镜板"}
            </button>
          ) : null}
          {!isProcessing && !props.parseError ? (
            <button
              type="button"
              className={styles.btn}
              title={structuralChangeTitle}
              disabled={
                saving ||
                optimizingPrompts ||
                promptJobRunning ||
                videoPromptJobId !== null ||
                savingShotNo !== null ||
                generatingEpisodeVideos ||
                editingShots.length === 0 ||
                hasStructuralChanges
              }
              onClick={() => setConfirmRegenerateEpisodePromptsOpen(true)}
            >
              {optimizingPrompts ? "重新生成中..." : "重新生成全部视频提示词"}
            </button>
          ) : null}
          {!isProcessing && !props.parseError ? (
            <button
              type="button"
              className={styles.btn}
              title={structuralChangeTitle}
              disabled={saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos || editingShots.length === 0 || hasStructuralChanges}
              onClick={() => setConfirmGenerateEpisodeVideoOpen(true)}
            >
              {generatingEpisodeVideos ? "入队中..." : "生成分镜视频"}
            </button>
          ) : null}
          {!isProcessing && !props.parseError ? (
            <button
              type="button"
              className={styles.btn}
              disabled={allPreviewItems.length === 0}
              onClick={() => {
                if (allPreviewItems.length > 0) {
                  setPreviewAllOpen(true)
                }
              }}
            >
              预览全部分镜
            </button>
          ) : null}
          {!isProcessing && !props.parseError ? (
            <>
              <button
                type="button"
                className={`${styles.btn} ${hasStructuralChanges ? styles.primaryBtn : ""}`}
                disabled={saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos || !hasChanges}
                onClick={() => void saveShots()}
              >
                {saveAllButtonLabel}
              </button>
              {hasStructuralChanges ? <div className={styles.actionInlineError}>{structuralChangeNotice}</div> : null}
            </>
          ) : null}
          {!isProcessing && !props.parseError ? (
            <button
              type="button"
              className={styles.btn}
              disabled={exportJianyingSubmitting}
              onClick={() => {
                if (exportJianyingSubmitting) return
                setExportJianyingSubmitting(true)
                setFloatingNotice("")
                void (async () => {
                  try {
                    const meRes = await fetch("/api/auth/me", { method: "GET", cache: "no-store" })
                    const meJson = (await meRes.json().catch(() => null)) as any
                    if (!meRes.ok || !meJson?.ok) throw new Error(meJson?.error?.message ?? `HTTP ${meRes.status}`)
                    const userId = String(meJson?.data?.user?.id ?? "").trim()
                    if (!userId) throw new Error("未获取到当前用户信息")

                    await exportQuickGenerateEpisodeToJianying({ storyId: props.storyId, episodeId: props.episodeId, userId })
                    setFloatingNotice("已提交剪映工程导出任务，请在任务中心查看进度并下载。")
                    if (typeof window !== "undefined") window.dispatchEvent(new Event("open_task_center"))
                  } catch (e) {
                    const anyErr = e as { message?: string }
                    setFloatingNotice(anyErr?.message ?? "导出剪映工程失败")
                  } finally {
                    setExportJianyingSubmitting(false)
                  }
                })()
              }}
            >
              {exportJianyingSubmitting ? "导出中..." : "导出成剪映文件"}
            </button>
          ) : null}
        </div>
      </section>

      {isProcessing ? (
        <section className={styles.panel}>
          <div className={styles.statusBox}>
            <div className={styles.statusTitle}>拆分中</div>
            <div className={styles.statusDesc}>
              当前剧集正在拆分分镜，请稍后刷新页面查看结果。
              {props.jobId ? ` 当前任务：${props.jobId}` : ""}
            </div>
          </div>
        </section>
      ) : null}

      {!isProcessing && props.parseError ? (
        <section className={styles.panel}>
          <div className={styles.statusBox}>
            <div className={styles.statusTitle}>结果解析失败</div>
            <div className={styles.statusDesc}>{props.parseError}</div>
          </div>
        </section>
      ) : null}

      {!isProcessing && isError && !props.parseError ? (
        <section className={styles.panel}>
          <div className={styles.statusBox}>
            <div className={styles.statusTitle}>拆分失败</div>
            <div className={styles.statusDesc}>工作流未成功返回可渲染的分镜结果，请检查任务中心或稍后重试。</div>
          </div>
        </section>
      ) : null}

      {!isProcessing && !props.parseError && shotCount === 0 ? (
        <section className={styles.panel}>
          <div className={styles.statusBox}>
            <EmptyState
              size="inline"
              title="暂未生成分镜"
              description="当前接口还没有返回 shots 数据，后续可重新触发拆分或直接新增镜头。"
              primaryAction={{ label: "新增镜头", onClick: () => insertShotAfter(null) }}
            />
          </div>
        </section>
      ) : null}

      {!isProcessing && !props.parseError && shotCount > 0 ? (
        <section className={styles.panel}>
          <div className={styles.listWrap}>
            <div className={styles.list} aria-label="分镜列表">
            {editingShots.map((shot, index) => (
              <div key={shot.clientId} className={styles.shotBlock}>
                {(() => {
                  const persistedShotNo = shot.persistedShotNo
                  const shotSelectIdBase = buildStableDomId("quick-generate-shot", props.episodeId, shot.clientId, shot.shotNo)
                  const videoResult = persistedShotNo ? props.videoResultsByShotNo[persistedShotNo] : undefined
                  const orderedRefs = buildOrderedReferencedMaterials({
                    promptRefs: mergeReferencedPromptMentions({
                      optimizedText: shot.optimizedText,
                      storyboardPanelPrompt: shot.storyboardPanelPrompt,
                      allMentionItems
                    }),
                    audioRefNames: shot.refAudioNames,
                    audioOptionNameSet,
                    materials: props.materials
                  })
                  const mentionOrderMap = buildMentionOrderMap(orderedRefs)

                  return (
                    <div className={styles.shotWrap}>
                      <div className={styles.shotCardLayout}>
                        <div className={styles.shotHeader}>
                          <div className={styles.shotHeaderLeft}>
                            <div className={styles.shotNoPill}>分镜 {String(shot.shotNo).padStart(2, "0")}</div>
                          </div>

                          <div className={styles.shotHeaderSettings}>
                            <div className={styles.headerSettingField}>
                              <div className={styles.editorLabel}>时长</div>
                              <div className={styles.headerDurationSelectWrap}>
                                <CanvasSelect
                                  id={`${shotSelectIdBase}-duration`}
                                  label="时长"
                                  value={String(shot.duration)}
                                  options={DURATION_SELECT_OPTIONS}
                                  onChange={(next) => updateShot(shot.shotNo, { duration: normalizeDuration(next) })}
                                  align="center"
                                />
                              </div>
                            </div>
                            <div className={styles.headerSettingField}>
                              <div className={styles.editorLabel}>视频比例</div>
                              <div className={styles.headerDurationSelectWrap}>
                                <CanvasSelect
                                  id={`${shotSelectIdBase}-aspect-ratio`}
                                  label="视频比例"
                                  value={String(shot.aspectRatio || "16:9")}
                                  options={ASPECT_RATIO_OPTIONS}
                                  onChange={(next) => updateShot(shot.shotNo, { aspectRatio: String(next) })}
                                  align="center"
                                />
                              </div>
                            </div>
                            <div className={styles.headerSettingField}>
                              <div className={styles.editorLabel}>分辨率</div>
                              <div className={styles.headerDurationSelectWrap}>
                                <CanvasSelect
                                  id={`${shotSelectIdBase}-resolution`}
                                  label="视频分辨率"
                                  value={shot.resolution}
                                  options={RESOLUTION_SELECT_OPTIONS}
                                  onChange={(next) =>
                                    updateShot(shot.shotNo, { resolution: normalizeResolution(next, fallbackResolution) })
                                  }
                                  align="center"
                                />
                              </div>
                            </div>
                            <div className={styles.headerSettingField}>
                              <div className={styles.editorLabel}>模型</div>
                              <div className={styles.headerDurationSelectWrap}>
                                <CanvasSelect
                                  id={`${shotSelectIdBase}-video-model`}
                                  label="视频模型"
                                  value={shot.videoModel}
                                  options={videoModelSelectOptions}
                                  onChange={(next) =>
                                    updateShot(shot.shotNo, {
                                      videoModel: normalizeVideoModel(next, availableVideoModels, episodeDefaultVideoModel)
                                    })
                                  }
                                  align="center"
                                />
                              </div>
                            </div>
                            <div className={styles.headerSettingField}>
                              <div className={styles.editorLabel}>声音</div>
                              <div className={styles.segmentedGroup} role="group" aria-label={`第 ${shot.shotNo} 个分镜的声音设置`}>
                                <button
                                  type="button"
                                  className={styles.segmentedBtn}
                                  data-active={shot.generateAudio ? "true" : "false"}
                                  onClick={() => updateShot(shot.shotNo, { generateAudio: true })}
                                >
                                  有声
                                </button>
                                <button
                                  type="button"
                                  className={styles.segmentedBtn}
                                  data-active={!shot.generateAudio ? "true" : "false"}
                                  onClick={() => updateShot(shot.shotNo, { generateAudio: false })}
                                >
                                  无声
                                </button>
                              </div>
                            </div>
                            <div className={styles.headerSettingField}>
                              <div className={styles.editorLabel}>水印</div>
                              <div className={styles.segmentedGroup} role="group" aria-label={`第 ${shot.shotNo} 个分镜的水印设置`}>
                                <button
                                  type="button"
                                  className={styles.segmentedBtn}
                                  data-active={!shot.watermark ? "true" : "false"}
                                  onClick={() => updateShot(shot.shotNo, { watermark: false })}
                                >
                                  无水印
                                </button>
                                <button
                                  type="button"
                                  className={styles.segmentedBtn}
                                  data-active={shot.watermark ? "true" : "false"}
                                  onClick={() => updateShot(shot.shotNo, { watermark: true })}
                                >
                                  有水印
                                </button>
                              </div>
                            </div>
                          </div>

                          <div className={styles.shotToolbar}>
                            <button type="button" className={styles.dangerBtn} onClick={() => setConfirmDeleteShotNo(shot.shotNo)} disabled={editingShots.length === 1 || optimizingPromptShotNo !== null || generatingVideoShotNo !== null}>
                              删除分镜
                            </button>
                          </div>
                        </div>

                        <div className={styles.shotBody}>
                          <div className={styles.shotEditorCol}>
                            <div className={styles.textareasRow}>
                              <div className={styles.textareaCol}>
                                <div className={styles.titleRow}>
                                  <div className={styles.editorLabel}>分镜剧本原文（可编辑）</div>
                                </div>
                                <div className={styles.textareaHost}>
                                  <textarea
                                    className={styles.textarea}
                                    rows={10}
                                    value={shot.shotText}
                                    onChange={(e) => updateShot(shot.shotNo, { shotText: e.target.value })}
                                    placeholder="请输入分镜文本"
                                  />
                                </div>
                              </div>
                              <div className={styles.textareaCol}>
                                <div className={styles.titleRow}>
                                  <div className={styles.editorLabel}>分镜板（可编辑）</div>
                                  <div className={styles.promptTitleActions}>
                                    <button
                                      type="button"
                                      className={styles.shotActionBtn}
                                      title={structuralChangeTitle}
                                      disabled={
                                        saving ||
                                        optimizingPrompts ||
                                        optimizingPromptShotNo !== null ||
                                        savingShotNo !== null ||
                                        generatingEpisodeVideos ||
                                        generatingVideoShotNo !== null ||
                                        generatingPanelPromptShotNo !== null ||
                                        generatingPanelImageShotNo !== null ||
                                        hasStructuralChanges
                                      }
                                      onClick={() => generateSingleShotPanelPrompt(shot.shotNo)}
                                    >
                                      {generatingPanelPromptShotNo === shot.shotNo ? "生成中..." : "生成分镜板提示词"}
                                    </button>
                                    <button
                                      type="button"
                                      className={styles.shotActionBtn}
                                      title={structuralChangeTitle}
                                      disabled={
                                        saving ||
                                        optimizingPrompts ||
                                        optimizingPromptShotNo !== null ||
                                        savingShotNo !== null ||
                                        generatingEpisodeVideos ||
                                        generatingVideoShotNo !== null ||
                                        generatingPanelPromptShotNo !== null ||
                                        generatingPanelImageShotNo !== null ||
                                        hasStructuralChanges
                                      }
                                      onClick={() => generateSingleShotPanelImage(shot.shotNo)}
                                    >
                                      {generatingPanelImageShotNo === shot.shotNo ||
                                      (panelImageJobRunning && panelImageJobTargets.has(shot.shotNo)) ||
                                      (panelImageJobRunning && panelImageJobTargets.has("all"))
                                        ? "生成中..."
                                        : "生成分镜板图片"}
                                    </button>
                                    <div className={styles.headerDurationSelectWrap}>
                                      <CanvasSelect
                                        id={`${shotSelectIdBase}-image-model`}
                                        label="生图模型"
                                        value={shot.storyboardPanelModel || ""}
                                        options={imageModelSelectOptions}
                                        onChange={(next) =>
                                          updateShot(shot.shotNo, {
                                            storyboardPanelModel: String(next)
                                          })
                                        }
                                        align="center"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className={styles.panelWorkspace}>
                                  <div className={styles.panelPromptSide}>
                                    <div className={styles.panelPromptEditorHost}>
                                      <QuickGenerateVideoPromptMentionEditor
                                        value={shot.storyboardPanelPrompt}
                                        onChange={(next) => updateShot(shot.shotNo, { storyboardPanelPrompt: next })}
                                        mode="storyboardPanel"
                                        placeholder="此处展示生成分镜版的提示词"
                                        allowedMentions={panelAllowedMentions}
                                        roleVoiceMap={{}}
                                        autoVoiceRoleNames={[]}
                                        mutedAutoAudioNames={[]}
                                        mentionOrderMap={buildMentionOrderMap(
                                          buildOrderedReferencedMaterials({
                                            promptRefs: extractMentionItemsFromPrompt(shot.storyboardPanelPrompt, allMentionItems),
                                            audioRefNames: [],
                                            audioOptionNameSet,
                                            materials: props.materials
                                          })
                                        )}
                                        loading={
                                          generatingPanelPromptShotNo === shot.shotNo ||
                                          (panelPromptJobRunning && panelPromptJobTargets.has(shot.shotNo)) ||
                                          (panelPromptJobRunning && panelPromptJobTargets.has("all"))
                                        }
                                      />
                                    </div>
                                  </div>
                                  <div className={styles.panelImagesSide}>
                                    {shot.storyboardPanelImages.length > 0 ? (
                                      <div className={styles.panelImageGrid}>
                                        {shot.storyboardPanelImages.map((url, i) => {
                                          const selected = shot.selectedStoryboardPanelImage === url
                                          const imageCacheKey = shot.storyboardPanelImageStorageKeys[i] ?? url
                                          const imagePreviewSrc = getQuickGenerateStableMediaSrc({
                                            cacheKey: imageCacheKey,
                                            src: url
                                          })
                                          return (
                                            <div
                                              key={`${url}-${i}`}
                                              className={styles.panelImageCard}
                                              data-selected={selected}
                                            >
                                              <button
                                                type="button"
                                                className={styles.panelImagePreviewBtn}
                                                onClick={() =>
                                                  openImagePreview({ src: imagePreviewSrc, alt: `分镜板候选 ${i + 1}` })
                                                }
                                                title="点击放大预览"
                                              >
                                                <QuickGenerateLazyImage
                                                  src={url}
                                                  cacheKey={imageCacheKey}
                                                  alt={`分镜板候选 ${i + 1}`}
                                                  className={styles.panelImage}
                                                  placeholderClassName={styles.panelImagePlaceholder}
                                                />
                                                <span className={styles.panelImageName}>图片 {i + 1}</span>
                                                <span className={styles.panelImagePreviewHint}>点击预览</span>
                                              </button>
                                              <button
                                                type="button"
                                                className={styles.panelImageConfirmBtn}
                                                data-selected={selected}
                                                disabled={
                                                  saving ||
                                                  optimizingPrompts ||
                                                  savingShotNo !== null ||
                                                  generatingEpisodeVideos ||
                                                  generatingVideoShotNo !== null ||
                                                  generatingPanelPromptShotNo !== null ||
                                                  generatingPanelImageShotNo !== null
                                                }
                                                onClick={() =>
                                                  void confirmStoryboardPanelImage(
                                                    shot.shotNo,
                                                    url,
                                                    shot.storyboardPanelImageStorageKeys[i] ?? ""
                                                  )
                                                }
                                                title={selected ? "已确认为视频参考图" : "点击确认为视频参考图"}
                                              >
                                                <span className={styles.panelImageConfirm}>{selected ? "已确认" : "确认使用"}</span>
                                              </button>
                                            </div>
                                          )
                                        })}
                                      </div>
                                    ) : (
                                      <div className={styles.panelImageEmpty}>生成后会在这里展示多张分镜板候选图，确认后将作为右侧视频生成的参考图。</div>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <div className={styles.textareaCol}>
                                <div className={styles.titleRow}>
                                  <div className={styles.editorLabel}>视频提示词</div>
                                  <div className={styles.promptTitleActions}>
                                    <button
                                      type="button"
                                      className={styles.shotActionBtn}
                                      title={structuralChangeTitle}
                                      disabled={
                                        saving ||
                                        optimizingPrompts ||
                                        optimizingPromptShotNo !== null ||
                                        savingShotNo !== null ||
                                        generatingEpisodeVideos ||
                                        generatingVideoShotNo !== null ||
                                        generatingPanelPromptShotNo !== null ||
                                        generatingPanelImageShotNo !== null ||
                                        hasStructuralChanges
                                      }
                                      onClick={() => void generateSingleShotPrompt(shot.shotNo)}
                                    >
                                      {optimizingPromptShotNo === shot.shotNo ? "生成中..." : "生成视频提示词"}
                                    </button>
                                    <button
                                      type="button"
                                      className={styles.shotSaveBtn}
                                      title={structuralChangeTitle}
                                      disabled={saving || optimizingPrompts || savingShotNo !== null || generatingEpisodeVideos || generatingVideoShotNo !== null || generatingPanelPromptShotNo !== null || generatingPanelImageShotNo !== null || !supportsSingleShotSave || !dirtyShotNos.has(shot.shotNo)}
                                      onClick={() => void saveSingleShot(shot.shotNo)}
                                    >
                                      {savingShotNo === shot.shotNo ? "保存中..." : "保存修改"}
                                    </button>
                                  </div>
                                </div>
                                <div className={styles.promptEditorHost}>
                                  <QuickGenerateVideoPromptMentionEditor
                                    value={shot.optimizedText}
                                    onChange={(next) => updateShot(shot.shotNo, { optimizedText: next })}
                                    mode="videoPrompt"
                                    placeholder="点击上方按钮重新生成..."
                                    allowedMentions={allAllowedMentions}
                                    roleVoiceMap={props.roleVoiceMap}
                                    autoVoiceRoleNames={shot.speakerList}
                                    mutedAutoAudioNames={shot.mutedAutoAudioNames}
                                    mentionOrderMap={mentionOrderMap}
                                    loading={
                                      optimizingPromptShotNo === shot.shotNo ||
                                      (optimizingPrompts && optimizingPromptShotNo === null) ||
                                      (promptJobRunning && promptJobTargets.has(shot.shotNo)) ||
                                      (promptJobRunning && promptJobTargets.has("all"))
                                    }
                                  />
                                </div>
                              </div>
                            </div>

                            <div className={styles.referencePanel}>
                              <div className={styles.referencePanelHeader}>
                                <div className={styles.referencePanelTitle}>采用的素材（资产预览）</div>
                                <div className={styles.referencePanelHint}>提示词胶囊编号与下方素材编号一一对应，点击可查看详情</div>
                              </div>
                              <div className={styles.refMaterialsRow} aria-label="参考素材">
                                {orderedRefs.length === 0 ? (
                                  <div className={styles.refEmpty}>生成 Prompt 后会自动带出说话人样音，也可在提示词里输入 @ 修改音色</div>
                                ) : (
                                  orderedRefs.map((ref) => (
                                    <button
                                      key={ref.token}
                                      type="button"
                                      className={styles.refChip}
                                      data-kind={ref.kind}
                                      onClick={() => ref.material && setPreviewMaterial(ref.material)}
                                      disabled={!ref.material}
                                      title={ref.label}
                                    >
                                      <span className={styles.refChipNo}>{ref.orderNo}</span>
                                      {ref.material?.sourceUrl && (ref.kind === "role" || ref.kind === "scene" || ref.kind === "item") ? (
                                        <img className={styles.refChipThumb} src={ref.material.sourceUrl} alt={ref.label} />
                                      ) : (
                                        <span className={styles.refChipPlaceholder}>{ref.kind === "audio" ? "试听" : "预览"}</span>
                                      )}
                                      <span className={styles.refChipText}>{ref.label}</span>
                                      {ref.removableAudio ? (
                                        <span
                                          role="button"
                                          tabIndex={0}
                                          className={styles.refChipRemoveBtn}
                                          onClick={(e) => {
                                            e.stopPropagation()
                                            removeAudioReference(shot.shotNo, ref.name)
                                          }}
                                          onKeyDown={(e) => {
                                            if (e.key === "Enter" || e.key === " ") {
                                              e.preventDefault()
                                              removeAudioReference(shot.shotNo, ref.name)
                                            }
                                          }}
                                          aria-label={`删除音色 ${ref.label}`}
                                        >
                                          ×
                                        </span>
                                      ) : null}
                                    </button>
                                  ))
                                )}
                              </div>
                            </div>
                          </div>

                          <div className={styles.shotVideoCol}>
                            <QuickGenerateShotVideoPanel
                              episodeId={props.episodeId}
                              shotNo={shot.shotNo}
                              videos={videoResult?.videos ?? []}
                              selectedJobId={videoResult?.selectedJobId ?? ""}
                              jobState={
                                (shotVideoInlineStates[shot.shotNo]
                                  ? {
                                      ...shotVideoInlineStates[shot.shotNo]
                                    }
                                  : shotVideoJobStates[shot.shotNo] ?? null)
                              }
                              onSelected={() => router.refresh()}
                              onGenerate={hasStructuralChanges ? undefined : () => setConfirmGenerateVideoShotNo(shot.shotNo)}
                              generating={generatingVideoShotNo === shot.shotNo}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })()}

                {index < editingShots.length - 1 ? (
                  <div className={styles.insertRow}>
                    <button
                      type="button"
                      className={styles.insertBtn}
                      onClick={() => insertShotAfter(shot.shotNo)}
                      aria-label={`在分镜 ${String(shot.shotNo).padStart(2, "0")} 后新增分镜`}
                    >
                      新增分镜
                    </button>
                  </div>
                ) : null}
              </div>
            ))}
            <button type="button" className={styles.addTailBtn} onClick={() => insertShotAfter(null)}>
              新增分镜
            </button>
            </div>
          </div>
        </section>
      ) : null}

      <ConfirmModal
        open={confirmRegenerateEpisodePromptsOpen}
        title={`确认重新生成第 ${props.episodeNo} 集视频提示词？`}
        message="确认后会按当前页面的分镜内容重新入队提示词生成任务，并覆盖原有提示词结果。"
        confirmText="确认重新生成"
        cancelText="取消"
        onCancel={() => setConfirmRegenerateEpisodePromptsOpen(false)}
        onConfirm={() => {
          setConfirmRegenerateEpisodePromptsOpen(false)
          void enqueueEpisodeVideoPrompts()
        }}
      />

      <ConfirmModal
        open={confirmGenerateEpisodeVideoOpen}
        title={`确认生成第 ${props.episodeNo} 集视频？`}
        message="确认后将按当前页面中的分镜顺序，逐个镜头批量入队视频生成任务。素材会优先传审核完成的 assetId，未审核完成则回退传 url；人物若绑定了音色，会自动补参考音频。"
        confirmText="确认生成"
        cancelText="取消"
        confirming={generatingEpisodeVideos}
        onCancel={() => setConfirmGenerateEpisodeVideoOpen(false)}
        onConfirm={() => void confirmGenerateEpisodeVideo()}
      />

      <ConfirmModal
        open={confirmGenerateVideoShotNo !== null}
        title={`确认生成分镜 ${String(confirmGenerateVideoShotNo || 0).padStart(2, "0")} 视频？`}
        message="确认后会按当前分镜的提示词、参考素材和基础设置，单独提交视频生成任务。"
        confirmText="确认生成"
        cancelText="取消"
        confirming={generatingVideoShotNo !== null}
        onCancel={() => setConfirmGenerateVideoShotNo(null)}
        onConfirm={() => void confirmGenerateSingleShotVideo()}
      />

      <ConfirmModal
        open={confirmDeleteShotNo !== null}
        title="删除分镜"
        message={`确定要删除分镜 ${String(confirmDeleteShotNo || 0).padStart(2, "0")} 吗？`}
        confirmText="确认删除"
        cancelText="取消"
        onCancel={() => setConfirmDeleteShotNo(null)}
        onConfirm={() => {
          if (confirmDeleteShotNo !== null) {
            removeShot(confirmDeleteShotNo)
            setConfirmDeleteShotNo(null)
          }
        }}
      />

      <QuickGenerateMaterialDetailDialog material={previewMaterial} onClose={() => setPreviewMaterial(null)} />

      {floatingNotice ? (
        <div className={styles.floatingNotice} role="status" aria-live="polite">
          {floatingNotice}
        </div>
      ) : null}

      {previewAllOpen && allPreviewItems.length > 0 ? (
        <QuickGenerateEpisodeVideoPreviewModal
          episodeNo={props.episodeNo}
          items={allPreviewItems}
          onClose={() => setPreviewAllOpen(false)}
        />
      ) : null}
    </main>
  )
}
