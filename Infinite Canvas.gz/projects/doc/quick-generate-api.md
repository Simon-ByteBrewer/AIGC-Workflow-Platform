# 快速生成接口说明

## 1. 文档目的

本文档只整理当前 quick-generate 相关后端接口与依赖接口，重点包括：

- 接口用途
- 输入参数
- 输出参数
- 调用时机

本文档不再重复说明产品入口和页面结构，功能侧说明请查看：

- [quick-generate-overview.md](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/doc/quick-generate-overview.md)

## 2. 接口返回约定

quick-generate 相关接口大多数遵循统一返回结构。

### 2.1 成功返回

```json
{
  "ok": true,
  "data": {},
  "traceId": "xxx"
}
```

### 2.2 失败返回

```json
{
  "ok": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "错误信息"
  },
  "traceId": "xxx"
}
```

### 2.3 鉴权说明

本文档中的接口默认都要求登录态；未登录通常返回：

- HTTP `401`
- `code` 常见为 `AUTH_REQUIRED` 或 `UNAUTHORIZED`

## 3. 项目创建与入口链路

### 3.1 创建快速生成项目

- 接口：`POST /api/quick-generate/projects`
- 作用：从“新建剧本 -> 快速生成”入口创建一个独立项目
- 调用时机：`ScriptCreationDialog` 的 `quick` 模式点击“创建项目”

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `title` | `string` | 是 | 项目标题，1-100 字 |
| `ratio` | `string` | 否 | 视频比例 |
| `resolution` | `string` | 否 | 分辨率 |
| `style` | `string` | 否 | 画风 |
| `videoCategory` | `"premium" \| "commentary"` | 否 | 视频类别 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `storyId` | `string` | 新建 story 主键 |
| `projectId` | `string` | quick-generate 项目主键 |
| `groupId` | `string \| null` | 素材送审分组 ID，能力关闭时可能为空 |

### 3.2 从已有剧本创建快速生成项目

- 接口：`POST /api/quick-generate/projects/from-script`
- 作用：基于已有剧本快速创建项目，并导入源剧本最新一批素材
- 调用时机：剧本工作台预览区的“快速开始”

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `sourceStoryId` | `string` | 是 | 源剧本 ID |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `storyId` | `string` | 新 quick-generate 项目的 storyId |
| `projectId` | `string` | 新项目 ID |
| `groupId` | `string \| null` | 素材分组 ID |
| `importedCount` | `number` | 自动同步进 quick-generate 的素材数量 |

## 4. 素材相关接口

### 4.1 上传素材

- 接口：`POST /api/quick-generate/materials/upload`
- 作用：上传文件到 quick-generate 素材区
- 请求体类型：`multipart/form-data`

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `storyId` | `string` | 是 | quick-generate storyId |
| `materialType` | `"all" \| "scene" \| "character" \| "prop" \| "video" \| "audio"` | 是 | 素材类型 |
| `file` | `File` | 是 | 上传文件 |

输出参数：

- 返回新增后的 `quickGenerateMaterial` 记录
- 关键字段包括：
  - `id`
  - `projectId`
  - `storyId`
  - `materialType`
  - `title`
  - `sourceUrl`
  - `storageKey`
  - `status`

### 4.2 删除素材

- 接口：`DELETE /api/quick-generate/materials`
- 作用：批量删除素材

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `ids` | `string[]` | 是 | 素材 ID 列表 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `deletedCount` | `number` | 删除数量 |

### 4.3 更新单个素材标题

- 接口：`PATCH /api/quick-generate/materials`
- 作用：更新单个素材标题

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 素材 ID |
| `title` | `string` | 是 | 新标题，1-200 字 |

输出参数：

- 返回更新后的 `quickGenerateMaterial` 记录

### 4.4 批量更新素材

- 接口：`PUT /api/quick-generate/materials/batch-update`
- 作用：批量更新素材信息，并同步修正已生成剧集中引用的素材名称

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `items` | `Array<object>` | 是 | 批量更新项 |

`items` 子项字段：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `id` | `string` | 是 | 素材 ID |
| `title` | `string \| null` | 否 | 新标题 |
| `materialType` | `string` | 否 | 新素材类型 |
| `voiceSpeakerId` | `string \| null` | 否 | 绑定音色 ID |
| `voiceSpeakerName` | `string \| null` | 否 | 绑定音色名称 |
| `assetId` | `string \| null` | 否 | 送审资产 ID |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `updatedCount` | `number` | 更新条数 |

### 4.5 AI 生成素材

- 接口：`POST /api/quick-generate/materials/ai-generate`
- 作用：为当前 quick-generate 项目生成 AI 素材

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `storyId` | `string` | 是 | 当前 quick-generate 项目 storyId |
| `materialType` | `"scene" \| "character" \| "prop"` | 是 | 生成类型 |
| `name` | `string` | 是 | 素材名称 |
| `prompt` | `string` | 是 | 生成提示词，1-20000 字 |
| `style` | `string` | 否 | 风格描述 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `createdCount` | `number` | 新增素材数量 |

补充说明：

- `character` 会走人物三视图生成，一次最多落 3 条素材
- `scene` / `prop` 当前落单张图素材

### 4.6 从版权库导入素材

- 接口：`POST /api/quick-generate/materials/import-copyright-library`
- 作用：把版权库素材复制到当前 quick-generate 项目中

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `storyId` | `string` | 是 | 当前 quick-generate 项目 storyId |
| `items` | `Array<object>` | 是 | 待导入素材列表，1-100 条 |

`items` 子项字段：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `projectType` | `"quick_generate" \| "canvas"` | 是 | 来源项目类型 |
| `sourceMaterialId` | `string` | 是 | 来源素材 ID |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `importedCount` | `number` | 成功导入数量 |

### 4.7 批量提交素材审核

- 接口：`POST /api/quick-generate/materials/batch-review`
- 作用：批量把素材送到资产审核链路

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `materialIds` | `string[]` | 是 | 素材 ID 列表 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `jobId` | `string \| null` | 轮询审核状态任务 ID |
| `items` | `Array<object>` | 每条素材的送审结果 |

`items` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `id` | `string` | 素材 ID |
| `assetId` | `string \| null` | 送审资产 ID |
| `assetStatus` | `string` | 当前审核状态，常见为 `Processing` / `Failed` |
| `assetErrorMessage` | `string \| null` | 错误信息 |

补充说明：

- 该接口依赖项目存在 `groupId`
- 仅在送审能力开启时可用

### 4.8 刷新素材审核状态

- 接口：`POST /api/quick-generate/materials/batch-review-status`
- 作用：主动刷新指定素材的审核状态

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `materialIds` | `string[]` | 是 | 素材 ID 列表 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `items` | `Array<object>` | 刷新后的审核结果 |

`items` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `id` | `string` | 素材 ID |
| `assetId` | `string \| null` | 审核资产 ID |
| `assetStatus` | `string` | 审核状态 |
| `assetErrorMessage` | `string \| null` | 审核错误信息 |

## 5. 剧集相关接口

### 5.1 创建剧集并入队

- 接口：`POST /api/quick-generate/episodes`
- 作用：创建单集记录并提交剧集创作任务

输入参数：

公共字段：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `storyId` | `string` | 是 | 当前 quick-generate storyId |
| `episodeNo` | `number` | 是 | 剧集编号，项目内唯一 |
| `videoModel` | `string` | 是 | 默认视频模型 |
| `type` | `"outline" \| "storyboard" \| "drama"` | 是 | 解析类型 |

当 `type=outline` 时：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `content` | `string` | 是 | 剧本文本，1-50000 字 |
| `minDurationMinutes` | `number` | 是 | 单集最短时长，当前范围 1-5 分钟 |
| `maxDurationMinutes` | `number` | 是 | 单集最长时长，当前范围 1-5 分钟，且必须大于等于最短时长 |

当 `type=storyboard` 时：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `content` | `string` | 是 | 剧本文本，1-50000 字 |

当 `type=drama` 时：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `prompt` | `string` | 是 | Prompt 文本，1-50000 字 |
| `shotsNum` | `number` | 否 | 期望镜头数 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `episodeId` | `string` | 新剧集 ID |
| `projectId` | `string` | 所属 quick-generate 项目 ID |
| `jobId` | `string` | 剧集创建任务 ID |

常见错误：

- `EPISODE_NO_EXISTS`：同项目下剧集编号重复

### 5.2 删除剧集

- 接口：`DELETE /api/quick-generate/episodes`
- 作用：批量删除剧集

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `episodeIds` | `string[]` | 是 | 剧集 ID 列表 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `deletedCount` | `number` | 删除数量 |

### 5.3 更新剧集分镜

- 接口：`PUT /api/quick-generate/episodes`
- 作用：保存整集分镜或单条分镜

输入参数有两种模式。

模式一：整集批量更新

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `episodeId` | `string` | 是 | 剧集 ID |
| `shots` | `Array<object>` | 是 | 全量分镜列表 |

模式二：单条更新

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `episodeId` | `string` | 是 | 剧集 ID |
| `shotNo` | `number` | 是 | 分镜号 |
| `shot` | `object` | 是 | 单条分镜内容 |

`shot` / `shots[]` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `persistedShotNo` | `number` | 已持久化分镜号 |
| `shotText` | `string` | 分镜原文 |
| `roles` | `string[]` | 角色列表 |
| `scenes` | `string[]` | 场景列表 |
| `items` | `string[]` | 物品列表 |
| `optimizedText` | `string` | 优化后提示词 |
| `speakerList` | `string[]` | 音色列表 |
| `refAudioNames` | `string[]` | 参考音频名称 |
| `mutedAutoAudioNames` | `string[]` | 静音自动音频列表 |
| `refVideoIds` | `string[]` | 参考视频素材 ID |
| `duration` | `number` | 时长，4-15 |
| `generateAudio` | `boolean` | 是否生成音频 |
| `watermark` | `boolean` | 是否加水印 |
| `aspectRatio` | `string` | 画幅比例 |
| `resolution` | `"480p" \| "720p" \| "1080p"` | 分辨率 |
| `videoModel` | `string` | 视频模型 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `updatedCount` | `number` | 更新数量 |

常见错误：

- `EPISODE_NOT_FOUND`

### 5.4 导入剧集源文件文本

- 接口：`POST /api/quick-generate/episodes/import-text`
- 作用：上传剧本文件并提取纯文本，供新增剧集弹窗回填内容
- 请求体类型：`multipart/form-data`

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `file` | `File` | 是 | 源文件 |

当前支持文件类型：

- `.pdf`
- `.docx`
- `.txt`
- `.text`
- `.xlsx`
- `.xls`

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `fileName` | `string` | 文件名 |
| `sourceKind` | `"pdf" \| "docx" \| "txt" \| "excel"` | 识别出的文件类型 |
| `content` | `string` | 提取出的纯文本 |
| `charCount` | `number` | 字符数 |

## 6. 单集创作接口

### 6.1 生成视频提示词

- 接口：`POST /api/quick-generate/episodes/video-prompts`
- 作用：为当前剧集的分镜批量生成视频提示词

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `episodeId` | `string` | 是 | 剧集 ID |
| `shots` | `Array<object>` | 是 | 待生成提示词的分镜列表 |

`shots` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `shotNo` | `number` | 分镜号 |
| `shotText` | `string` | 分镜文本 |
| `roles` | `string[]` | 角色列表 |
| `scenes` | `string[]` | 场景列表 |
| `items` | `string[]` | 物品列表 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `jobId` | `string` | 提示词生成任务 ID |
| `queuedCount` | `number` | 入队数量 |
| `skippedCount` | `number` | 跳过数量 |

常见错误：

- `EPISODE_NOT_FOUND`
- `EMPTY_SHOTS`
- `ACTIVE_SHOT_JOBS_EXIST`

### 6.2 批量生成视频

- 接口：`POST /api/quick-generate/episodes/video-generate`
- 作用：按当前分镜配置批量生成视频

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `episodeId` | `string` | 是 | 剧集 ID |
| `shots` | `Array<object>` | 是 | 待生成视频的分镜列表，最多 500 条 |

`shots` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `shotNo` | `number` | 分镜号 |
| `shotText` | `string` | 分镜文本 |
| `roles` | `string[]` | 角色列表 |
| `roleMaterialIdsByName` | `Record<string,string>` | 角色名到素材 ID 的映射 |
| `scenes` | `string[]` | 场景列表 |
| `sceneMaterialIdsByName` | `Record<string,string>` | 场景名到素材 ID 的映射 |
| `items` | `string[]` | 物品列表 |
| `itemMaterialIdsByName` | `Record<string,string>` | 物品名到素材 ID 的映射 |
| `optimizedText` | `string` | 生成提示词 |
| `speakerList` | `string[]` | 音色列表 |
| `refAudioNames` | `string[]` | 参考音频名称 |
| `mutedAutoAudioNames` | `string[]` | 需要静音的自动音频名称 |
| `refVideoIds` | `string[]` | 参考视频素材 ID |
| `duration` | `number` | 时长 |
| `generateAudio` | `boolean` | 是否生成音频 |
| `watermark` | `boolean` | 是否加水印 |
| `aspectRatio` | `string` | 画幅比例 |
| `resolution` | `"480p" \| "720p" \| "1080p"` | 分辨率 |
| `videoModel` | `string` | 视频模型 |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `queuedCount` | `number` | 成功入队数量 |
| `skippedCount` | `number` | 跳过数量 |
| `results` | `Array<object>` | 每个分镜的处理结果 |

`results` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `shotNo` | `number` | 分镜号 |
| `ok` | `boolean` | 是否成功 |
| `jobId` | `string` | 任务 ID |
| `errorMessage` | `string` | 失败原因 |

常见错误：

- `EPISODE_NOT_FOUND`

### 6.3 确认分镜采用视频

- 接口：`POST /api/quick-generate/episodes/video-selection`
- 作用：把某个分镜的某个视频版本设为最终选中版本

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `episodeId` | `string` | 是 | 剧集 ID |
| `shotNo` | `number` | 是 | 分镜号 |
| `selectedJobId` | `string` | 是 | 选中的视频任务 ID |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `selectedJobId` | `string` | 最终确认的视频任务 ID |

常见错误：

- `EPISODE_NOT_FOUND`
- `VIDEO_VERSION_NOT_FOUND`

### 6.4 导出剪映工程

- 接口：`POST /api/quick-generate/episodes/exports/jianying`
- 作用：异步导出当前剧集的剪映工程

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `storyId` | `string` | 是 | storyId |
| `episodeId` | `string` | 是 | 剧集 ID |
| `userId` | `string` | 是 | 当前登录用户 ID，必须与会话一致 |
| `async` | `boolean` | 否 | 当前仅支持传 `true` |

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `jobId` | `string` | 导出任务 ID |
| `status` | `string` | 任务初始状态 |

常见错误：

- `FORBIDDEN`
- `ASYNC_REQUIRED`

## 7. 依赖接口

以下接口不是 `quick-generate` 命名空间下的主接口，但当前链路会直接依赖。

### 7.1 获取视频模型列表

- 接口：`GET /api/video/canvas/video-models`
- 调用位置：新增剧集弹窗
- 作用：返回当前用户可用的视频模型

输入参数：

- 无

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `items` | `Array<object>` | 视频模型列表 |

`items` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `modelName` | `string` | 模型名 |
| `enabled` | `boolean` | 是否启用 |

### 7.2 获取音色列表

- 接口：`GET /api/tts/speakers`
- 调用位置：快速生成素材页
- 作用：用于人物素材绑定音色

输入参数：

- 无

输出参数：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `speakers` | `Array<object>` | 音色列表 |

`speakers` 子项字段：

| 参数 | 类型 | 说明 |
| --- | --- | --- |
| `id` | `string` | 音色 ID |
| `name` | `string` | 音色名 |
| `sampleText` | `string` | 样音文案 |
| `sampleUrl` | `string \| null` | 样音地址 |

### 7.3 查询版权库项目列表

- 接口：`GET /api/library/copyright-projects`
- 调用位置：快速生成素材上传弹窗中的“从版权库导入”
- 作用：按项目维度返回可导入版权素材

输入参数：

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `category` | `string` | 否 | 素材分类筛选 |
| `reviewFilter` | `string` | 否 | 审核状态筛选 |
| `search` | `string` | 否 | 关键字搜索 |
| `excludeStoryId` | `string` | 否 | 排除当前 storyId |
| `includeEmpty` | `"true" \| "false"` | 否 | 是否返回空项目 |

输出参数：

- 返回 `projects` 列表
- 每个项目包含：
  - `storyId`
  - `title`
  - `projectType`
  - `items`
- 每个 `items` 元素包含：
  - `id`
  - `title`
  - `materialType`
  - `sourceUrl`
  - `assetStatus`
