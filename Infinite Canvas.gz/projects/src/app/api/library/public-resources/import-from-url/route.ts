import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { and, desc, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { publicResources } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { fetchBinaryBuffer } from "@/server/domains/tvc/vibeCreating/tooling/assets/fetchAsset"
import { uploadPublicBuffer } from "@/shared/storage"

export const runtime = "nodejs"

const bodySchema = z.object({
  type: z.enum(["character", "background", "props", "audio", "music", "effect", "transition", "video"]),
  name: z.string().trim().min(1).max(200),
  sourceUrl: z.string().trim().min(1).max(4000),
  overwrite: z.boolean().optional()
})

function normalizeContentType(input: string): string {
  const raw = (input ?? "").trim().toLowerCase()
  const base = raw.split(";")[0]?.trim() || ""
  return base || "application/octet-stream"
}

function fileExtFromContentType(contentType: string, fallbackUrl: string): string {
  const ct = normalizeContentType(contentType)
  if (ct === "image/png") return "png"
  if (ct === "image/webp") return "webp"
  if (ct === "image/gif") return "gif"
  if (ct === "image/avif") return "avif"
  if (ct === "image/jpeg" || ct === "image/jpg") return "jpg"
  if (ct === "video/mp4") return "mp4"
  if (ct === "video/webm") return "webm"
  if (ct === "video/quicktime") return "mov"
  if (ct === "audio/mpeg") return "mp3"
  if (ct === "audio/mp4") return "m4a"
  if (ct === "audio/aac") return "aac"
  if (ct === "audio/ogg") return "ogg"
  if (ct === "audio/wav" || ct === "audio/x-wav") return "wav"
  if (ct === "audio/webm") return "webm"

  try {
    const u = new URL(fallbackUrl)
    const last = u.pathname.split("/").pop() ?? ""
    const ext = last.includes(".") ? last.split(".").pop() ?? "" : ""
    const cleaned = ext.toLowerCase().replace(/[^a-z0-9]/g, "")
    if (cleaned) return cleaned.slice(0, 10)
  } catch {
    // ignore
  }
  return "bin"
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const type = parsed.data.type
  const name = parsed.data.name.trim()
  const sourceUrl = parsed.data.sourceUrl.trim()
  const overwrite = parsed.data.overwrite === true

  const db = await getDb({ publicResources })
  const existed = await db
    .select({ id: publicResources.id })
    .from(publicResources)
    .where(and(eq(publicResources.userId, userId), eq(publicResources.type, type), eq(publicResources.name, name)))
    .orderBy(desc(publicResources.createdAt))
    .limit(1)
  const existedId = existed[0]?.id ?? null
  if (existedId && !overwrite) {
    return NextResponse.json(
      makeApiErr(traceId, "NAME_CONFLICT", "当前名称资源已存在"),
      { status: 409 }
    )
  }

  let downloaded: { buffer: Buffer; contentType: string }
  try {
    const init = (() => {
      const cookie = req.headers.get("cookie") ?? ""
      if (!cookie) return undefined
      try {
        const reqUrl = new URL(req.url)
        const resolved = new URL(sourceUrl, reqUrl.origin)
        if (resolved.origin !== reqUrl.origin) return undefined
        return { headers: { cookie } } satisfies RequestInit
      } catch {
        return undefined
      }
    })()
    downloaded = await fetchBinaryBuffer(sourceUrl, init)
  } catch (e) {
    const msg = (e as any)?.message ?? "下载资源失败"
    return NextResponse.json(makeApiErr(traceId, "ASSET_DOWNLOAD_FAILED", String(msg)), { status: 400 })
  }

  const contentType = normalizeContentType(downloaded.contentType)
  const fileExt = fileExtFromContentType(contentType, sourceUrl)
  const uploaded = await uploadPublicBuffer({
    buffer: downloaded.buffer,
    contentType,
    fileExt,
    prefix: `public/${type}`
  })

  const stablePreview = existedId ? `/api/library/public-resources/file/${existedId}?kind=preview` : null
  const stableOriginal = existedId ? `/api/library/public-resources/file/${existedId}?kind=original` : null
  if (existedId) {
    await db
      .update(publicResources)
      .set({
        source: "upload",
        previewUrl: stablePreview ?? uploaded.url,
        previewStorageKey: uploaded.key,
        originalUrl: stableOriginal ?? uploaded.url,
        originalStorageKey: uploaded.key
      })
      .where(eq(publicResources.id, existedId))

    return NextResponse.json(
      makeApiOk(traceId, {
        id: existedId,
        overwritten: true,
        url: `/api/library/public-resources/file/${existedId}?kind=original`,
        storageKey: uploaded.key
      }),
      { status: 200 }
    )
  }

  const [row] = await db
    .insert(publicResources)
    .values({
      userId,
      type,
      source: "upload",
      name,
      description: "",
      previewUrl: uploaded.url,
      previewStorageKey: uploaded.key,
      originalUrl: uploaded.url,
      originalStorageKey: uploaded.key,
      durationMs: null,
      tags: [],
      applicableScenes: []
    } as any)
    .returning({ id: publicResources.id })
  const id = row?.id ?? null
  if (id) {
    await db
      .update(publicResources)
      .set({
        previewUrl: `/api/library/public-resources/file/${id}?kind=preview`,
        originalUrl: `/api/library/public-resources/file/${id}?kind=original`
      })
      .where(eq(publicResources.id, id))
  }

  return NextResponse.json(
    makeApiOk(traceId, {
      id,
      overwritten: false,
      url: id ? `/api/library/public-resources/file/${id}?kind=original` : uploaded.url,
      storageKey: uploaded.key
    }),
    { status: 200 }
  )
}
