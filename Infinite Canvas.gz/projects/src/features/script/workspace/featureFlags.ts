export const enableScriptSourceEntry = false
