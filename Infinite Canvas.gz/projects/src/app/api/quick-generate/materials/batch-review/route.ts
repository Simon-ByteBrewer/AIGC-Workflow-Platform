import { NextResponse, type NextRequest } from "next/server"
import { getDb } from "coze-coding-dev-sdk"
import { inArray, eq } from "drizzle-orm"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { quickGenerateMaterials, quickGenerateProjects } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { isSeedance20AudEnabled } from "@/server/capabilities/seedance20Aud"
import {
  resolveAssetReviewSourceUrl,
  submitAssetReview,
  type ReviewAssetType
} from "@/server/domains/assets/assetReviewService"
import { enqueueQuickGenerateMaterialReviewPollJob } from "@/server/domains/quick-generate/jobs/quickGenerateMaterialReviewPollWorker"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"

export const runtime = "nodejs"

const requestSchema = z.object({
  materialIds: z.array(z.string().trim().min(1)).min(1)
})

function mapMaterialTypeToAssetType(materialType: string): ReviewAssetType {
  if (materialType === "video") return "Video"
  if (materialType === "audio") return "Audio"
  return "Image"
}

export async function POST(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  try {
    const session = await getSessionFromRequest(req)
    if (!session?.userId) {
      return NextResponse.json(makeApiErr(traceId, "UNAUTHORIZED", "未登录"), { status: 401 })
    }
    if (!isSeedance20AudEnabled()) {
      return NextResponse.json(makeApiErr(traceId, "FEATURE_DISABLED", "当前环境未开启送审能力"), { status: 403 })
    }

    const body = await req.json().catch(() => ({}))
    const parsed = requestSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "参数错误"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ quickGenerateMaterials, quickGenerateProjects })
    const rows = await db
      .select({
        id: quickGenerateMaterials.id,
        storyId: quickGenerateMaterials.storyId,
        title: quickGenerateMaterials.title,
        materialType: quickGenerateMaterials.materialType,
        sourceUrl: quickGenerateMaterials.sourceUrl,
        storageKey: quickGenerateMaterials.storageKey,
        projectId: quickGenerateMaterials.projectId
      })
      .from(quickGenerateMaterials)
      .where(inArray(quickGenerateMaterials.id, parsed.data.materialIds))

    if (!rows.length) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到要审核的素材"), { status: 404 })
    }

    const projectIds = Array.from(new Set(rows.map((item) => item.projectId)))
    const projectRows = await db
      .select({
        id: quickGenerateProjects.id,
        groupId: quickGenerateProjects.groupId
      })
      .from(quickGenerateProjects)
      .where(inArray(quickGenerateProjects.id, projectIds))
    const projectGroupMap = new Map(projectRows.map((item) => [item.id, item.groupId?.trim() || ""]))

    const results: Array<{
      id: string
      assetId: string | null
      assetStatus: string
      assetErrorMessage: string | null
    }> = []

    const storyIds = Array.from(new Set(rows.map((r) => String(r.storyId ?? "").trim()).filter(Boolean)))
    if (storyIds.length !== 1) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_STATE", "跨项目素材不支持批量审核"), { status: 400 })
    }
    const storyId = storyIds[0]

    for (const item of rows) {
      const groupId = projectGroupMap.get(item.projectId) ?? ""
      if (!groupId) {
        const errorMessage = "当前项目缺少 group_id，无法提交审核"
        await db
          .update(quickGenerateMaterials)
          .set({
            assetStatus: "Failed",
            assetErrorMessage: errorMessage,
            updatedAt: new Date()
          })
          .where(eq(quickGenerateMaterials.id, item.id))
        results.push({ id: item.id, assetId: null, assetStatus: "Failed", assetErrorMessage: errorMessage })
        continue
      }

      try {
        const sourceUrl = await resolveAssetReviewSourceUrl({
          storageKey: item.storageKey,
          fallbackUrl: item.sourceUrl
        })
        const submitResult = await submitAssetReview({
          traceId,
          userId: session.userId,
          groupId,
          url: sourceUrl,
          assetType: mapMaterialTypeToAssetType(item.materialType),
          name: (item.title ?? "").trim() || "未命名素材"
        })
        const assetStatus = submitResult.assetId && !submitResult.errorMessage ? "Processing" : "Failed"
        await db
          .update(quickGenerateMaterials)
          .set({
            assetId: submitResult.assetId,
            assetStatus,
            assetErrorMessage: submitResult.errorMessage,
            updatedAt: new Date()
          })
          .where(eq(quickGenerateMaterials.id, item.id))

        results.push({
          id: item.id,
          assetId: submitResult.assetId,
          assetStatus,
          assetErrorMessage: submitResult.errorMessage
        })
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "提交审核失败"
        await db
          .update(quickGenerateMaterials)
          .set({
            assetStatus: "Failed",
            assetErrorMessage: errorMessage,
            updatedAt: new Date()
          })
          .where(eq(quickGenerateMaterials.id, item.id))
        results.push({
          id: item.id,
          assetId: null,
          assetStatus: "Failed",
          assetErrorMessage: errorMessage
        })
      }
    }

    const processingIds = results.filter((r) => r.assetStatus === "Processing" && r.assetId).map((r) => r.id)
    let jobId: string | null = null
    if (processingIds.length > 0) {
      const enq = await enqueueQuickGenerateMaterialReviewPollJob({
        userId: session.userId,
        traceId,
        storyId,
        materialIds: processingIds
      })
      jobId = enq.jobId
      // Best-effort kick so it starts immediately.
      kickAllWorkers()
    }

    return NextResponse.json(makeApiOk(traceId, { jobId, items: results }), { status: 202 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "批量审核提交失败"
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", message), { status: 500 })
  }
}
