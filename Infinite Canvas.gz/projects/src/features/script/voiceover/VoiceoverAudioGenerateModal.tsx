"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"
import styles from "@/features/script/materials/EpisodeMaterialGalleryPage.module.css"

type Speaker = { id: string; name: string; sampleUrl: string | null; sampleText: string }

type Props = {
  storyId: string
  scope: "all" | "episode"
  episodeNo?: number
  initialSpeakerId?: string
  initialSpeed?: number
  onClose: () => void
  onSubmitted: (jobId: string) => void
}

const SPEED_OPTIONS: Array<{ value: string; label: string; speed: number }> = [
  { value: "0.8", label: "0.8x", speed: 0.8 },
  { value: "1.0", label: "1.0x", speed: 1 },
  { value: "1.2", label: "1.2x", speed: 1.2 },
  { value: "1.5", label: "1.5x", speed: 1.5 }
]

export function VoiceoverAudioGenerateModal({
  storyId,
  scope,
  episodeNo,
  initialSpeakerId,
  initialSpeed,
  onClose,
  onSubmitted
}: Props): ReactElement {
  const sid = (storyId ?? "").trim()
  const [speakers, setSpeakers] = useState<Speaker[]>([])
  const [speakerId, setSpeakerId] = useState("")
  const [speedValue, setSpeedValue] = useState("")
  const [preview, setPreview] = useState<{ name: string; src: string } | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [previewing, setPreviewing] = useState(false)

  useEffect(() => {
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch("/api/tts/speakers", { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { speakers?: Speaker[] } } | null
        const list = Array.isArray(json?.data?.speakers) ? (json?.data?.speakers ?? []) : []
        if (!cancelled) setSpeakers(list)
      } catch {
        if (!cancelled) setSpeakers([])
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  const defaultSpeakerId = useMemo(() => speakers[0]?.id ?? "", [speakers])
  useEffect(() => {
    if (!defaultSpeakerId) return
    setSpeakerId((prev) => {
      const next = (prev || initialSpeakerId || defaultSpeakerId).trim()
      return next
    })
  }, [defaultSpeakerId, initialSpeakerId])

  useEffect(() => {
    setSpeedValue(() => {
      const init = typeof initialSpeed === "number" && Number.isFinite(initialSpeed) ? initialSpeed : 1
      const hit = SPEED_OPTIONS.find((o) => o.speed === init) ?? SPEED_OPTIONS.find((o) => o.speed === 1) ?? SPEED_OPTIONS[0]
      return hit?.value ?? "1.0"
    })
  }, [initialSpeed])

  const speed = useMemo(() => {
    const hit = SPEED_OPTIONS.find((o) => o.value === speedValue)
    return hit?.speed ?? 1
  }, [speedValue])

  const title = useMemo(() => {
    if (scope === "episode") return `生成口播语音：第${episodeNo ?? "-"}集`
    return "生成口播语音：全部剧集"
  }, [episodeNo, scope])

  const speakerOptions = useMemo(() => speakers.map((s) => ({ value: s.id, label: s.name })), [speakers])
  const selectedSpeaker = useMemo(() => speakers.find((s) => s.id === speakerId) ?? null, [speakerId, speakers])

  const canSubmit = Boolean(sid && speakerId.trim())

  const handlePreview = useCallback(async () => {
    const id = speakerId.trim()
    if (!id) return
    const speaker = selectedSpeaker
    setPreviewing(true)
    try {
      if (speaker?.sampleUrl) {
        setPreview({ name: `${speaker.name}（样音）`, src: speaker.sampleUrl })
        return
      }
      const res = await fetch("/api/tts/preview", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ speakerId: id, speed })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { audioUrl?: string }; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const url = String(json.data?.audioUrl ?? "").trim()
      if (url) setPreview({ name: `${speaker?.name ?? id}（试听）`, src: url })
    } catch (e) {
      const anyErr = e as { message?: string }
      alert(anyErr?.message ?? "试听失败")
    } finally {
      setPreviewing(false)
    }
  }, [selectedSpeaker, speakerId, speed])

  const submit = useCallback(async () => {
    if (!canSubmit) return
    if (submitting) return
    setSubmitting(true)
    try {
      const res = await fetch("/api/script/voiceover-audios/generate", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          storyId: sid,
          scope,
          episodeNo: scope === "episode" ? episodeNo : undefined,
          speakerId: speakerId.trim(),
          speed
        })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { jobId?: string }; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const jobId = String(json.data?.jobId ?? "").trim()
      if (!jobId) throw new Error("未获取到 jobId")
      onSubmitted(jobId)
      window.dispatchEvent(new Event("open_task_center"))
      onClose()
    } catch (e) {
      const anyErr = e as { message?: string }
      alert(anyErr?.message ?? "提交失败")
    } finally {
      setSubmitting(false)
    }
  }, [canSubmit, episodeNo, onClose, onSubmitted, scope, sid, speakerId, speed, submitting])

  return (
    <div
      className={styles.modalOverlay}
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>{title}</div>
          <button type="button" className={styles.btn} onClick={onClose}>
            关闭
          </button>
        </div>

        <div className={styles.row}>
          <div className={styles.field}>
            <div className={styles.fieldLabel}>音色</div>
            <ListboxSelect
              className={styles.btn}
              value={speakerId || defaultSpeakerId || ""}
              ariaLabel="选择音色"
              options={speakerOptions}
              onChange={(v) => setSpeakerId(v)}
              disabled={speakerOptions.length === 0}
            />
          </div>
          <div className={styles.field}>
            <div className={styles.fieldLabel}>语速</div>
            <ListboxSelect
              className={styles.btn}
              value={speedValue || "1.0"}
              ariaLabel="选择语速"
              options={SPEED_OPTIONS.map((o) => ({ value: o.value, label: o.label }))}
              onChange={(v) => setSpeedValue(v)}
              disabled={SPEED_OPTIONS.length === 0}
            />
          </div>
        </div>

        <div className={styles.cardActions}>
          <button type="button" className={styles.btn} onClick={() => void handlePreview()} disabled={previewing || !speakerId.trim()}>
            {previewing ? "试听中…" : "试听"}
          </button>
          <button
            type="button"
            className={`${styles.btn} ${styles.btnPrimary}`}
            onClick={() => void submit()}
            disabled={!canSubmit || submitting}
          >
            {submitting ? "提交中…" : "一键生成"}
          </button>
        </div>

        {preview?.src ? (
          <div className={styles.field}>
            <div className={styles.fieldLabel}>{preview.name}</div>
            <audio controls src={preview.src} />
          </div>
        ) : null}

        <div className={styles.hint}>提交后会进入任务中心队列，生成完成后会自动刷新语音结果。</div>
      </div>
    </div>
  )
}

