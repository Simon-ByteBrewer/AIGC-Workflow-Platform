import { Suspense } from "react"
import { PricingPage } from "@/features/admin/pricing/PricingPage"
import { getDb } from "@/server/db/getDb"
import { userSecurity, users } from "@/shared/schema/auth"
import { eq } from "drizzle-orm"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export default async function Page() {
  const c = await cookies()
  const token = c.get(SESSION_COOKIE_NAME)?.value
  let roleKey = "user"
  let userId = ""

  if (token) {
    const traceId = getTraceId(new Headers())
    const payload = await verifySessionToken(token, traceId).catch(() => null)
    if (payload?.userId) {
      userId = payload.userId
      const db = await getDb({ userSecurity, users })
      const rows = await db.select({ roleKey: userSecurity.roleKey }).from(userSecurity).where(eq(userSecurity.userId, userId)).limit(1)
      if (rows.length > 0) {
        if (rows[0].roleKey === "group_admin") {
          redirect("/admin")
        }
        if (rows[0].roleKey === "admin") {
          roleKey = "super_admin"
        } else {
          roleKey = rows[0].roleKey
        }
      }
    }
  }

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <PricingPage roleKey={roleKey} userId={userId} />
    </Suspense>
  )
}
