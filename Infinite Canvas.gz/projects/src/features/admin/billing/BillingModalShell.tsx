"use client"

import { useEffect, type PropsWithChildren } from "react"
import { createPortal } from "react-dom"
import styles from "./BillingPage.module.css"

type BillingModalShellProps = PropsWithChildren<{
  title: string
  hint: string
  onClose: () => void
}>

/**
 * 账单模块通用弹窗外壳。
 * 说明：统一复用详情弹窗的遮罩、头部和滚动区域，避免任务查询再复制一份样式结构。
 */
export function BillingModalShell({ title, hint, onClose, children }: BillingModalShellProps) {
  const canUsePortal = typeof document !== "undefined"

  useEffect(() => {
    if (!canUsePortal) return
    const previousOverflow = document.body.style.overflow
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose()
    }
    document.body.style.overflow = "hidden"
    window.addEventListener("keydown", handleKeyDown)
    return () => {
      document.body.style.overflow = previousOverflow
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [canUsePortal, onClose])

  if (!canUsePortal) return null

  return createPortal(
    <div className={styles.modalOverlay} onMouseDown={onClose}>
      <div className={styles.modalContent} onMouseDown={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader}>
          <div className={styles.modalHeaderText}>
            <div className={styles.modalTitle}>{title}</div>
            <div className={styles.modalHint}>{hint}</div>
          </div>
          <button className={styles.btn} onClick={onClose}>
            关闭
          </button>
        </div>
        <div className={styles.modalBody}>{children}</div>
      </div>
    </div>,
    document.body
  )
}
