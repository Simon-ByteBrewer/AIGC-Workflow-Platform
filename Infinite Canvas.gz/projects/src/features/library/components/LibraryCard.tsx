"use client"

import type { ReactElement } from "react"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { Pencil, Film, FileText, Image as ImageIcon, Eye, Music, LayoutGrid } from "lucide-react"
import Image from "next/image"
import styles from "./LibraryCard.module.css"
import type { LibraryItem } from "@/shared/contracts/library/libraryItem"
import { CharacterVariantModal } from "./CharacterVariantModal"
import { useResolvedImageUrl } from "@/shared/hooks/useResolvedImageUrl"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"
import { getLibraryCardMyMeta } from "./libraryCardMyMeta"

export type { LibraryItem } from "@/shared/contracts/library/libraryItem"

interface LibraryCardProps {
  item: LibraryItem
  view: "grid" | "list"
  onClick?: () => void
  selected?: boolean
  onToggleSelected?: () => void
  onViewContent?: () => void
  onRenameSaved?: () => void | Promise<void>
}

type VoiceSpeaker = { id: string; name: string; sampleUrl: string | null; sampleText: string }

let cachedSpeakers: VoiceSpeaker[] | null = null
let pendingSpeakers: Promise<VoiceSpeaker[]> | null = null

async function loadSpeakers(): Promise<VoiceSpeaker[]> {
  if (cachedSpeakers) return cachedSpeakers
  if (pendingSpeakers) return pendingSpeakers
  pendingSpeakers = (async () => {
    try {
      const res = await fetch("/api/tts/speakers", { cache: "no-store" })
      const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { speakers?: VoiceSpeaker[] } } | null
      const list = Array.isArray(json?.data?.speakers) ? (json?.data?.speakers ?? []) : []
      cachedSpeakers = list
      return list
    } catch {
      cachedSpeakers = []
      return []
    } finally {
      pendingSpeakers = null
    }
  })()
  return pendingSpeakers
}

function ResolvedImage(props: {
  src?: string | null
  alt: string
  className?: string
  sizes?: string
  fill?: boolean
  unoptimized?: boolean
  onError?: () => void
}): ReactElement | null {
  const resolved = useResolvedImageUrl(props.src ?? "")
  if (!resolved) return null
  return (
    <Image
      src={resolved}
      alt={props.alt}
      className={props.className}
      fill={props.fill}
      sizes={props.sizes}
      unoptimized={props.unoptimized}
      onError={props.onError}
    />
  )
}

export function LibraryCard({ item, view, onClick, selected, onToggleSelected, onViewContent, onRenameSaved }: LibraryCardProps): ReactElement {
  const variant = item.scope === "public" ? "library" : item.scope ?? "my"
  const showMyCheckbox = variant === "my" && Boolean(onToggleSelected)
  const renameInputRef = useRef<HTMLInputElement | null>(null)

  const previewUrl = item.thumbnail
  const isHttpPreviewUrl = Boolean(previewUrl?.startsWith("http://") || previewUrl?.startsWith("https://"))
  const previewKind = (() => {
    if (!previewUrl) return "none"
    if (variant === "library" || variant === "shared") {
      if (item.publicCategory === "videos") return "video"
      if (item.publicCategory === "audios") return "audio"
      return "image"
    }
    if (previewUrl.startsWith("data:image/")) return "image"
    const noHash = previewUrl.split("#")[0] ?? previewUrl
    const noQuery = noHash.split("?")[0] ?? noHash
    const lower = noQuery.toLowerCase()
    if (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".webp") || lower.endsWith(".gif") || lower.endsWith(".svg")) {
      return "image"
    }
    if (lower.endsWith(".mp4") || lower.endsWith(".webm") || lower.endsWith(".mov")) return "video"
    if (lower.endsWith(".mp3") || lower.endsWith(".wav") || lower.endsWith(".m4a") || lower.endsWith(".aac") || lower.endsWith(".ogg")) return "audio"
    return "unknown"
  })()
  const isAudio = previewKind === "audio"
  const isList = view === "list" || isAudio

  const isStablePublicResourceUrl = Boolean(
    previewUrl?.startsWith("/api/library/public-resources/file/") ||
      previewUrl?.startsWith("/api/library/shared-resources/file/") ||
      previewUrl?.startsWith("/api/library/public-background-cameras/file/") ||
      previewUrl?.startsWith("/api/library/shared-background-cameras/file/")
  )
  const shouldUnoptimized = isStablePublicResourceUrl || isHttpPreviewUrl

  const isRoleCard = useMemo(() => {
    if (variant !== "library" && variant !== "shared") return false
    return item.publicCategory === "roles"
  }, [item.publicCategory, variant])

  const isBackgroundCard = useMemo(() => {
    if (variant !== "library" && variant !== "shared") return false
    return item.publicCategory === "backgrounds"
  }, [item.publicCategory, variant])

  const backCameraPreviewUrl = useMemo(() => {
    if (!isBackgroundCard) return null
    const base = variant === "shared" ? "/api/library/shared-background-cameras/file" : "/api/library/public-background-cameras/file"
    return `${base}/${encodeURIComponent(item.id)}?camera=back&kind=preview`
  }, [isBackgroundCard, item.id, variant])

  const [variantModalOpen, setVariantModalOpen] = useState(false)
  const [variantTab, setVariantTab] = useState<"look" | "costume">("look")
  const [hideBackCamera, setHideBackCamera] = useState(false)

  const hasVersions = isRoleCard && Array.isArray(item.versions) && item.versions.length > 1
  const [selectedVersionId, setSelectedVersionId] = useState<string | null>(null)
  const activeVersionId = useMemo(() => {
    if (!hasVersions) return item.id
    if (!selectedVersionId) return item.id
    const exists = item.versions!.some((v) => v.id === selectedVersionId)
    return exists ? selectedVersionId : item.id
  }, [hasVersions, item.id, item.versions, selectedVersionId])
  const activeVersion = hasVersions ? item.versions!.find((v) => v.id === activeVersionId) : null
  const effectivePreviewUrl = activeVersion?.thumbnail ?? previewUrl
  const activeVoiceSpeakerId = activeVersion?.voiceSpeakerId ?? item.voiceSpeakerId ?? ""
  const activeVoiceSpeakerName = activeVersion?.voiceSpeakerName ?? item.voiceSpeakerName ?? ""
  const activeVoiceStorageKey = activeVersion?.voiceAudioStorageKey ?? item.voiceAudioStorageKey ?? ""
  const canBindVoice = isRoleCard && variant === "library"
  const [speakers, setSpeakers] = useState<VoiceSpeaker[]>([])
  const [voiceSpeakerId, setVoiceSpeakerId] = useState("")
  const [voicePreview, setVoicePreview] = useState<{ name: string; src: string } | null>(null)
  const [voicePreviewing, setVoicePreviewing] = useState(false)
  const [voiceBinding, setVoiceBinding] = useState(false)
  const [titleEditing, setTitleEditing] = useState(false)
  const [titleDraft, setTitleDraft] = useState(item.title)
  const [titleSaving, setTitleSaving] = useState(false)
  const [boundVoice, setBoundVoice] = useState<{ speakerId: string; speakerName: string; storageKey: string }>({
    speakerId: activeVoiceSpeakerId,
    speakerName: activeVoiceSpeakerName,
    storageKey: activeVoiceStorageKey
  })
  
  const TypeIcon = {
    draft: Pencil,
    video: Film,
    storyboard: FileText,
    material: ImageIcon,
    tvc: LayoutGrid,
  }[item.type]

  useEffect(() => {
    if (!canBindVoice) return
    let cancelled = false
    void loadSpeakers().then((list) => {
      if (!cancelled) setSpeakers(list)
    })
    return () => {
      cancelled = true
    }
  }, [canBindVoice])

  const defaultVoiceSpeakerId = useMemo(() => speakers[0]?.id ?? "", [speakers])
  useEffect(() => {
    const next = (activeVoiceSpeakerId || defaultVoiceSpeakerId).trim()
    if (!next) return
    setVoiceSpeakerId(next)
    setVoicePreview(null)
  }, [activeVersionId, activeVoiceSpeakerId, defaultVoiceSpeakerId])

  useEffect(() => {
    setBoundVoice({
      speakerId: activeVoiceSpeakerId,
      speakerName: activeVoiceSpeakerName,
      storageKey: activeVoiceStorageKey
    })
  }, [activeVoiceSpeakerId, activeVoiceSpeakerName, activeVoiceStorageKey])

  useEffect(() => {
    setTitleDraft(item.title)
  }, [item.title])

  useEffect(() => {
    if (!titleEditing) return
    const timer = window.setTimeout(() => {
      renameInputRef.current?.focus()
      renameInputRef.current?.select()
    }, 0)
    return () => window.clearTimeout(timer)
  }, [titleEditing])

  const speakerOptions = useMemo(() => speakers.map((s) => ({ value: s.id, label: s.name })), [speakers])
  const selectedSpeaker = useMemo(() => speakers.find((s) => s.id === voiceSpeakerId) ?? null, [speakers, voiceSpeakerId])
  const voicePreviewText = useMemo(() => `我叫${item.title || "角色"}，这是我的专属音色。`, [item.title])
  const boundVoiceSrc = boundVoice.storageKey && canBindVoice ? `/api/library/public-resources/voice-file/${encodeURIComponent(activeVersionId)}` : ""

  const openTitleEditor = useCallback(() => {
    setTitleDraft(item.title)
    setTitleEditing(true)
  }, [item.title])

  const cancelTitleEditing = useCallback(() => {
    if (titleSaving) return
    setTitleDraft(item.title)
    setTitleEditing(false)
  }, [item.title, titleSaving])

  const saveTitle = useCallback(async () => {
    if (titleSaving) return
    const nextTitle = titleDraft.trim()
    if (!nextTitle) {
      alert("名称不能为空")
      renameInputRef.current?.focus()
      return
    }
    if (nextTitle === item.title.trim()) {
      setTitleEditing(false)
      return
    }

    setTitleSaving(true)
    try {
      const res = await fetch(`/api/library/stories/${encodeURIComponent(item.id)}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ title: nextTitle })
      })
      const json = (await res.json().catch(() => null)) as
        | { ok: true; data?: { story?: { title?: string } } }
        | { ok: false; error?: { message?: string } }
        | null
      if (!res.ok || !json?.ok) throw new Error((json as { ok: false; error?: { message?: string } } | null)?.error?.message ?? "保存失败")
      setTitleDraft(nextTitle)
      setTitleEditing(false)
      await onRenameSaved?.()
    } catch (error) {
      alert(error instanceof Error ? error.message : "保存失败")
    } finally {
      setTitleSaving(false)
    }
  }, [item.id, item.title, onRenameSaved, titleDraft, titleSaving])

  const requestVoicePreview = useCallback(async (): Promise<string> => {
    const sid = voiceSpeakerId.trim()
    if (!sid) return ""
    setVoicePreviewing(true)
    try {
      const res = await fetch("/api/tts/preview", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ speakerId: sid, text: voicePreviewText })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { audioUrl?: string }; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const url = String(json.data?.audioUrl ?? "").trim()
      if (url) setVoicePreview({ name: `${selectedSpeaker?.name ?? sid}（试听）`, src: url })
      return url
    } catch (e) {
      const anyErr = e as { message?: string }
      alert(anyErr?.message ?? "试听失败")
      return ""
    } finally {
      setVoicePreviewing(false)
    }
  }, [selectedSpeaker?.name, voicePreviewText, voiceSpeakerId])

  const bindVoice = useCallback(async () => {
    if (!canBindVoice) return
    if (voiceBinding) return
    const sid = voiceSpeakerId.trim()
    if (!sid) return
    setVoiceBinding(true)
    try {
      const previewUrl = await requestVoicePreview()
      if (!previewUrl) throw new Error("试听失败")
      const res = await fetch("/api/library/public-resources/voice-bind", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          resourceId: activeVersionId,
          speakerId: sid,
          speakerName: selectedSpeaker?.name ?? sid,
          audioUrl: previewUrl
        })
      })
      const json = (await res.json().catch(() => null)) as {
        ok: boolean
        data?: { voiceSpeakerId?: string; voiceSpeakerName?: string; voiceAudioStorageKey?: string }
        error?: { message?: string }
      } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const voiceSpeakerName = String(json.data?.voiceSpeakerName ?? selectedSpeaker?.name ?? sid).trim()
      const voiceAudioStorageKey = String(json.data?.voiceAudioStorageKey ?? "").trim()
      setBoundVoice({ speakerId: sid, speakerName: voiceSpeakerName, storageKey: voiceAudioStorageKey })
    } catch (e) {
      const anyErr = e as { message?: string }
      alert(anyErr?.message ?? "绑定失败")
    } finally {
      setVoiceBinding(false)
    }
  }, [activeVersionId, canBindVoice, requestVoicePreview, selectedSpeaker?.name, voiceBinding, voiceSpeakerId])


  const stageLabel =
    item.type === "tvc"
      ? null
      :
    item.progressStage === "outline"
      ? "大纲"
      : item.progressStage === "storyboard_text"
        ? "分镜文本"
        : item.progressStage === "video_script"
          ? "脚本"
          : item.progressStage === "image_assets"
            ? "图片素材"
            : item.progressStage === "video_assets"
              ? "视频生成"
              : item.progressStage === "done"
                ? "完成"
                : item.progressStage
                  ? "未知"
                  : null

  const normalizedVideoCategory = item.videoCategory === "commentary" ? "commentary" : item.videoCategory === "premium" ? "premium" : null
  const myMeta = variant === "my" ? getLibraryCardMyMeta(item) : null
  const createdAtText = item.createdAt?.trim() || "--"

  return (
    <div 
      className={`${styles.card} ${isList ? styles.cardList : ""} ${isAudio ? styles.cardAudioFlat : ""} ${variant === "my" && isList ? styles.cardMyList : ""}`} 
      onClick={titleEditing ? undefined : onClick}
    >
      <div
        className={`${styles.preview} ${previewKind === "audio" ? styles.previewAudio : ""} ${previewKind === "video" ? styles.previewVideo : ""}`}
      >
        {previewUrl && previewKind === "image" ? (
          isBackgroundCard ? (
            <div className={styles.sceneSplit}>
              <div className={styles.sceneMain}>
                <ResolvedImage
                  src={previewUrl}
                  alt={item.title}
                  className={styles.previewImage}
                  fill
                  sizes={isList ? "160px" : "320px"}
                  unoptimized={shouldUnoptimized}
                />
              </div>
              <div className={styles.sceneSide}>
                {!hideBackCamera && backCameraPreviewUrl ? (
                  <div className={styles.sceneSideItem}>
                    <ResolvedImage
                      src={backCameraPreviewUrl}
                      alt={`${item.title} 后置机位`}
                      className={styles.previewImage}
                      fill
                      sizes={isList ? "64px" : "96px"}
                      unoptimized
                      onError={() => setHideBackCamera(true)}
                    />
                    <div className={styles.sceneSideBadge}>后置</div>
                  </div>
                ) : null}
              </div>
            </div>
          ) : hasVersions ? (
            <div className={styles.roleSplit}>
              <div className={styles.roleMain}>
                <ResolvedImage
                  src={effectivePreviewUrl ?? previewUrl}
                  alt={item.title}
                  className={styles.previewImage}
                  fill
                  sizes={isList ? "160px" : "280px"}
                  unoptimized
                />
                <div className={styles.roleBadgeActions}>
                  <button
                    type="button"
                    className={styles.roleBadgeBtn}
                    onClick={(e) => {
                      e.stopPropagation()
                      setVariantModalOpen(true)
                    }}
                  >
                    形象
                  </button>
                </div>
              </div>
              <div className={styles.roleSide}>
                {item.versions!.map((v, i) => (
                  <button
                    key={v.id}
                    type="button"
                    className={`${styles.roleSideItem} ${v.id === activeVersionId ? styles.roleSideItemActive : ""}`}
                    onClick={(e) => {
                      e.stopPropagation()
                      setSelectedVersionId(v.id)
                    }}
                  >
                    <ResolvedImage
                      src={v.thumbnail}
                      alt={`${item.title} V${i + 1}`}
                      className={styles.previewImage}
                      fill
                      sizes="48px"
                      unoptimized
                    />
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <ResolvedImage
              src={previewUrl}
              alt={item.title}
              className={styles.previewImage}
              fill
              sizes={isList ? "160px" : "320px"}
              unoptimized={shouldUnoptimized}
            />
          )
        ) : previewUrl && previewKind === "video" ? (
          <div className={`${styles.placeholder} ${styles.placeholderVideo}`}>
            <Film size={isList ? 24 : 32} strokeWidth={1.5} />
          </div>
        ) : previewUrl && previewKind === "audio" ? (
          <div className={`${styles.placeholder} ${styles.placeholderAudio}`}>
            <Music size={isList ? 24 : 32} strokeWidth={1.5} />
          </div>
        ) : (
          <div className={styles.placeholder}>
            <TypeIcon size={isList ? 24 : 32} strokeWidth={1.5} />
          </div>
        )}

        {variant === "my" && onViewContent && item.type !== "tvc" ? (
          <button
            type="button"
            className={`${styles.viewContentBtn} ${item.specs ? styles.viewContentBtnShift : ""}`}
            onClick={(e) => {
              e.stopPropagation()
              onViewContent()
            }}
          >
            <Eye size={14} strokeWidth={2} />
            查看内容
          </button>
        ) : null}
        
        {variant === "my" ? (
          <>
            <div className={`${styles.typeTag} ${showMyCheckbox ? styles.typeTagShift : ""}`} title={`progressStage: ${item.progressStage ?? ""}`}>
              <TypeIcon size={12} strokeWidth={2} />
              <span className={styles.typeTagText}>
                {item.type === "tvc" ? "类型：TVC" : stageLabel ? `阶段：${stageLabel}` : ""}
              </span>
            </div>
            {item.storyType === "canvas" ? (
              <div className={`${styles.videoCategoryBadge} ${styles.videoCategoryBadgeCanvas}`}>无限画布</div>
            ) : normalizedVideoCategory ? (
              <div
                className={`${styles.videoCategoryBadge} ${normalizedVideoCategory === "commentary" ? styles.videoCategoryBadgeCommentary : styles.videoCategoryBadgePremium}`}
              >
                {normalizedVideoCategory === "commentary" ? "解说剧" : "精品剧"}
              </div>
            ) : null}
            {item.specs ? <div className={styles.specTag}>{item.specs}</div> : null}
            {showMyCheckbox ? (
              <input
                type="checkbox"
                className={styles.checkbox}
                checked={Boolean(selected)}
                onChange={() => onToggleSelected?.()}
                onClick={(e) => e.stopPropagation()}
              />
            ) : null}
          </>
        ) : null}

        {variant === "library" ? (
          <input
            type="checkbox"
            className={`${styles.checkbox} ${styles.alwaysShowCheckbox}`}
            checked={Boolean(selected)}
            onChange={() => onToggleSelected?.()}
            onClick={(e) => e.stopPropagation()}
          />
        ) : null}

        {isRoleCard && !hasVersions ? (
          <div className={styles.roleBadgeActions}>
            <button
              type="button"
              className={styles.roleBadgeBtn}
              onClick={(e) => {
                e.stopPropagation()
                setVariantModalOpen(true)
              }}
            >
              形象
            </button>
          </div>
        ) : null}
        {item.status === "generating" ? <div className={styles.statusBadge}>生成中</div> : null}
      </div>
      
      <div className={styles.info}>
        {variant === "my" ? (
          <>
            <div className={styles.titleRow}>
              {titleEditing ? (
                <>
                  <div className={styles.titleEditor} onClick={(e) => e.stopPropagation()}>
                    <input
                      ref={renameInputRef}
                      type="text"
                      className={styles.titleInput}
                      value={titleDraft}
                      maxLength={120}
                      onChange={(e) => setTitleDraft(e.target.value)}
                      onClick={(e) => e.stopPropagation()}
                      onKeyDown={(e) => {
                        e.stopPropagation()
                        if (e.key === "Enter") {
                          e.preventDefault()
                          void saveTitle()
                        }
                        if (e.key === "Escape") {
                          e.preventDefault()
                          cancelTitleEditing()
                        }
                      }}
                    />
                  </div>
                  <div className={styles.titleActions} onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      className={styles.saveButton}
                      onClick={(e) => {
                        e.stopPropagation()
                        void saveTitle()
                      }}
                      disabled={titleSaving}
                    >
                      {titleSaving ? "保存中..." : "保存"}
                    </button>
                    <button
                      type="button"
                      className={styles.cancelButton}
                      onClick={(e) => {
                        e.stopPropagation()
                        cancelTitleEditing()
                      }}
                      disabled={titleSaving}
                    >
                      取消
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <h3 className={styles.title}>{item.title}</h3>
                  <button
                    type="button"
                    className={styles.editButton}
                    onClick={(e) => {
                      e.stopPropagation()
                      openTitleEditor()
                    }}
                  >
                    编辑
                  </button>
                </>
              )}
            </div>
            <div className={styles.myMeta}>
              <div className={styles.myMetaRow}>
                <span className={styles.myMetaLabel}>创建时间</span>
                <span className={styles.myMetaValue}>{createdAtText}</span>
              </div>
              <div className={styles.myMetaRow}>
                <span className={styles.myMetaLabel}>创建方式</span>
                <span className={styles.myMetaValue}>{myMeta?.createMethod ?? "未知"}</span>
              </div>
            </div>
          </>
        ) : (
          <div className={styles.metaPublic}>
            {isRoleCard ? (
              <div className={styles.roleMetaSplit}>
                <div className={styles.roleMetaDescription}>{item.subtitle ?? ""}</div>
                <div
                  className={styles.roleVoicePanel}
                  onClick={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                >
                  <div className={styles.roleVoiceRow}>
                    <ListboxSelect
                      className={styles.roleVoiceSelect}
                      value={voiceSpeakerId || defaultVoiceSpeakerId || ""}
                      ariaLabel="选择音色"
                      options={speakerOptions}
                      onChange={(v) => setVoiceSpeakerId(v)}
                      disabled={!canBindVoice || speakerOptions.length === 0}
                    />
                    <div className={styles.roleVoiceActions}>
                      <button
                        type="button"
                        className={styles.roleVoiceBtn}
                        onClick={() => void requestVoicePreview()}
                        disabled={!canBindVoice || !voiceSpeakerId.trim() || voicePreviewing}
                      >
                        {voicePreviewing ? "试听中…" : "试听"}
                      </button>
                      <button
                        type="button"
                        className={`${styles.roleVoiceBtn} ${styles.roleVoiceBtnPrimary}`}
                        onClick={() => void bindVoice()}
                        disabled={!canBindVoice || !voiceSpeakerId.trim() || voiceBinding}
                      >
                        {voiceBinding ? "绑定中…" : "绑定"}
                      </button>
                    </div>
                  </div>
                  <div className={styles.roleVoiceMeta}>已绑定：{boundVoice.speakerName || "未绑定"}</div>
                  {voicePreview?.src || boundVoiceSrc ? (
                    <audio
                      key={voicePreview?.src || boundVoiceSrc}
                      className={styles.roleVoiceAudio}
                      src={voicePreview?.src || boundVoiceSrc}
                      controls
                      autoPlay={Boolean(voicePreview?.src)}
                    />
                  ) : null}
                </div>
              </div>
            ) : (
              <div className={styles.subtitle}>{item.subtitle ?? ""}</div>
            )}
          </div>
        )}
      </div>

      {isRoleCard ? (
        <CharacterVariantModal
          open={variantModalOpen}
          defaultKind={variantTab}
          onKindChange={setVariantTab}
          scope={variant as "library" | "shared"}
          characterId={activeVersionId}
          characterName={item.title}
          onOpenChange={(nextOpen) => {
            if (nextOpen) return
            setVariantModalOpen(false)
          }}
        />
      ) : null}
    </div>
  )
}
