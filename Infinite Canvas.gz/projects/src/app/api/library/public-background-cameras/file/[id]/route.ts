import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { makeApiErr } from "@/shared/api"
import { publicBackgroundCameras, publicResources } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

const cameraSchema = z.enum(["front", "back"])

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const rawParams = await ctx.params
  const parsed = paramsSchema.safeParse(rawParams)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const kind = req.nextUrl.searchParams.get("kind") === "original" ? "original" : "preview"
  const cameraParsed = cameraSchema.safeParse((req.nextUrl.searchParams.get("camera") ?? "back").toLowerCase())
  if (!cameraParsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "camera 参数不正确"), { status: 400 })
  const camera = cameraParsed.data

  if (camera === "front") {
    return NextResponse.redirect(`/api/library/public-resources/file/${encodeURIComponent(parsed.data.id)}?kind=${encodeURIComponent(kind)}`)
  }

  const db = await getDb({ publicResources, publicBackgroundCameras })
  const bgRows = await db
    .select({
      id: publicResources.id,
      previewUrl: publicResources.previewUrl,
      previewStorageKey: publicResources.previewStorageKey,
      originalUrl: publicResources.originalUrl,
      originalStorageKey: publicResources.originalStorageKey
    })
    .from(publicResources)
    .where(and(eq(publicResources.id, parsed.data.id), eq(publicResources.userId, userId), eq(publicResources.type, "background")))
    .limit(1)
  const bg = bgRows[0]
  if (!bg) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "场景不存在"), { status: 404 })

  const camRows = await db
    .select({
      id: publicBackgroundCameras.id,
      previewUrl: publicBackgroundCameras.previewUrl,
      originalUrl: publicBackgroundCameras.originalUrl,
      previewStorageKey: publicBackgroundCameras.previewStorageKey,
      originalStorageKey: publicBackgroundCameras.originalStorageKey
    })
    .from(publicBackgroundCameras)
    .where(and(eq(publicBackgroundCameras.backgroundResourceId, bg.id), eq(publicBackgroundCameras.camera, "back")))
    .limit(1)

  const row = camRows[0]
  if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "后置机位不存在"), { status: 404 })
  const storageKey = kind === "preview" ? row?.previewStorageKey : row?.originalStorageKey
  const fallbackUrl = kind === "preview" ? row?.previewUrl : (row?.originalUrl || row?.previewUrl)

  if (!storageKey) {
    if (!fallbackUrl) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源链接不存在"), { status: 404 })
    return NextResponse.redirect(fallbackUrl)
  }

  const storage = getS3Storage()
  try {
    const url = await resolveStorageUrl(storage, storageKey)
    return NextResponse.redirect(url)
  } catch {
    if (!fallbackUrl) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源链接不存在"), { status: 404 })
    return NextResponse.redirect(fallbackUrl)
  }
}
