import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { stories, videoCanvasAssets } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

const paramsSchema = z.object({ id: z.string().trim().min(1).max(200) })

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id?: string | string[] }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const p = await ctx.params
  const idValue = p.id
  const id = Array.isArray(idValue) ? idValue[0] : idValue
  const parsed = paramsSchema.safeParse({ id: id ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, videoCanvasAssets })

  const rows = await db
    .select({ assetId: videoCanvasAssets.id, storyId: videoCanvasAssets.storyId, owner: stories.userId })
    .from(videoCanvasAssets)
    .innerJoin(stories, eq(stories.id, videoCanvasAssets.storyId))
    .where(eq(videoCanvasAssets.id, parsed.data.id))
    .limit(1)

  if (rows.length === 0) return NextResponse.json(makeApiErr(traceId, "ASSET_NOT_FOUND", "资源不存在"), { status: 404 })
  if (rows[0].owner !== userId) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限操作该资源"), { status: 403 })

  await db.delete(videoCanvasAssets).where(and(eq(videoCanvasAssets.id, parsed.data.id), eq(videoCanvasAssets.storyId, rows[0].storyId)))
  return NextResponse.json(makeApiOk(traceId, { deleted: true }), { status: 200 })
}

