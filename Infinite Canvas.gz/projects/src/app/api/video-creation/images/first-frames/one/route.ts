import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq } from "drizzle-orm"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"
import { enqueueFirstFrameJob, kickFirstFrameWorker } from "@/server/domains/video-creation/jobs/firstFrameWorker"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  storyboardId: z.string().trim().min(1).max(200),
  referenceImages: z
    .array(
      z.object({
        name: z.string().trim().min(1).max(200),
        url: z.string().trim().min(1).max(4000)
      })
    )
    .max(10)
    .default([])
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { storyId, outlineId, storyboardId, referenceImages } = parsed.data
  const db = await getDb({ stories, storyOutlines, storyboards })

  const allowed = await db
    .select({ id: storyboards.id, episodeNo: storyOutlines.sequence, sceneNo: storyboards.sequence })
    .from(storyboards)
    .innerJoin(storyOutlines, eq(storyboards.outlineId, storyOutlines.id))
    .innerJoin(stories, eq(storyOutlines.storyId, stories.id))
    .where(and(eq(stories.userId, userId), eq(stories.id, storyId), eq(storyOutlines.id, outlineId), eq(storyboards.id, storyboardId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到分镜"), { status: 403 })
  const episodeNo = Number((allowed[0] as any)?.episodeNo ?? 0) || null
  const sceneNo = Number((allowed[0] as any)?.sceneNo ?? 0) || null

  const { jobId } = await enqueueFirstFrameJob({
    userId,
    traceId,
    storyId,
    outlineId,
    storyboardId,
    referenceImages,
    ...(episodeNo ? { episodeNo } : {}),
    ...(sceneNo ? { sceneNo } : {}),
    ...((episodeNo && sceneNo) ? { label: `第 ${episodeNo} 集 · 镜 ${sceneNo}` } : sceneNo ? { label: `镜 ${sceneNo}` } : {}),
    count: 3
  })
  kickFirstFrameWorker()

  return NextResponse.json(makeApiOk(traceId, { jobId }), { status: 200 })
}
