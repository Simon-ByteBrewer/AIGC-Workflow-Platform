import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { episodeMaterialImages } from "@/shared/schema/generation"
import { and, desc, eq } from "drizzle-orm"
import { createCozeS3Storage } from "@/server/integrations/storage/s3"
import { resolveStorageUrl } from "@/shared/storageUrl"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ storyId: url.searchParams.get("storyId") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialImages })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const row = await db
    .select({
      id: episodeMaterialImages.id,
      name: episodeMaterialImages.name,
      url: episodeMaterialImages.url,
      storageKey: episodeMaterialImages.storageKey,
      meta: episodeMaterialImages.meta,
      createdAt: episodeMaterialImages.createdAt
    })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.storyId, parsed.data.storyId))
    .orderBy(desc(episodeMaterialImages.createdAt))
    .limit(1)

  const storage = createCozeS3Storage()
  const raw = row[0] ?? null
  const latest =
    raw && raw.storageKey
      ? await (async () => {
          try {
            const url = await resolveStorageUrl(storage, raw.storageKey)
            return { ...raw, url }
          } catch {
            return raw
          }
        })()
      : raw
  return NextResponse.json(makeApiOk(traceId, { item: latest }), { status: 200 })
}
