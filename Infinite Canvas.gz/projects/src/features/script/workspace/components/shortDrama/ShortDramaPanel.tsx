"use client"

import { useState } from "react"
import styles from "./ShortDramaPanel.module.css"
import { ShortDramaPlanningCard } from "./ShortDramaPlanningCard"
import { ShortDramaWorldSettingCard } from "./ShortDramaWorldSettingCard"
import { ShortDramaCharacterSettingsCard } from "./ShortDramaCharacterSettingsCard"
import type { ShortDramaStepKey } from "./ShortDramaStepsNav"
import { ShortDramaStepsNav } from "./ShortDramaStepsNav"

type ShortDramaPanelProps = Readonly<{
  storyId: string
  videoCategory?: string
  userTitle?: string
  shotStyle?: string
  isParsing?: boolean
  shortDrama: any
  onShortDramaUpdate?: (next: any) => void
  active?: ShortDramaStepKey
  onActiveChange?: (next: ShortDramaStepKey) => void
  showNav?: boolean
  onExposeConfirmAndGenerate?: (fn: (() => void) | null) => void
  onConfirmGeneratingChange?: (next: boolean) => void
  hideWorldSetting?: boolean
}>

export function ShortDramaPanel({
  storyId,
  videoCategory,
  userTitle,
  shotStyle,
  isParsing,
  shortDrama,
  onShortDramaUpdate,
  active: activeProp,
  onActiveChange,
  showNav = true,
  onExposeConfirmAndGenerate,
  onConfirmGeneratingChange,
  hideWorldSetting
}: ShortDramaPanelProps) {
  const shortDramaObj = shortDrama && typeof shortDrama === "object" ? (shortDrama as any) : {}
  const planningResult = shortDramaObj?.planningResult ?? null
  const worldSetting = shortDramaObj?.worldSetting ?? null
  const characterSetting = shortDramaObj?.characterSetting ?? null
  const roleImageDraws = shortDramaObj?.roleImageDraws ?? null
  const planningConfirmedAt = typeof shortDramaObj?.planningConfirmedAt === "number" ? shortDramaObj.planningConfirmedAt : null
  const confirmed = Boolean(typeof planningConfirmedAt === "number" || (planningResult && worldSetting && characterSetting))
  const worldVisible = confirmed ? worldSetting : null
  const characterVisible = confirmed ? characterSetting : null
  const [innerActive, setInnerActive] = useState<ShortDramaStepKey>("planning")
  const activeRaw = activeProp ?? innerActive
  const active = hideWorldSetting && activeRaw === "world" ? "character" : activeRaw
  const setActive = onActiveChange ?? setInnerActive

  return (
    <div className={showNav ? styles.root : styles.rootNoNav} aria-label="短剧信息">
      {showNav ? <ShortDramaStepsNav shortDrama={shortDramaObj} active={active} onChange={setActive} hideWorldSetting={hideWorldSetting} /> : null}

      <section className={styles.detail} aria-label="短剧详情">
        {active === "planning" ? (
          <ShortDramaPlanningCard
            storyId={storyId}
            videoCategory={videoCategory}
            userTitle={userTitle}
            shotStyle={shotStyle}
            isParsing={isParsing}
            planningResult={planningResult}
            worldSetting={worldSetting}
            characterSetting={characterSetting}
            planningConfirmedAt={planningConfirmedAt ?? undefined}
            onExposeConfirmAndGenerate={onExposeConfirmAndGenerate}
            onConfirmGeneratingChange={onConfirmGeneratingChange}
            skipWorldSetting={hideWorldSetting}
            onSaved={(nextPlanningResult) =>
              onShortDramaUpdate?.({
                ...shortDramaObj,
                planningResult: nextPlanningResult,
                ...(hideWorldSetting ? {} : { worldSetting: null, characterSetting: null })
              })
            }
            onShortDramaUpdate={onShortDramaUpdate}
          />
        ) : active === "world" && !hideWorldSetting ? (
          <ShortDramaWorldSettingCard
            storyId={storyId}
            planningResult={planningResult}
            planningConfirmedAt={planningConfirmedAt ?? undefined}
            worldSetting={worldVisible}
            characterSetting={characterSetting}
            onSaved={(nextWorldSetting) => onShortDramaUpdate?.({ ...shortDramaObj, worldSetting: nextWorldSetting })}
          />
        ) : (
          <ShortDramaCharacterSettingsCard
            storyId={storyId}
            planningResult={planningResult}
            planningConfirmedAt={planningConfirmedAt ?? undefined}
            worldSetting={worldVisible}
            characterSetting={characterVisible}
            shotStyle={shotStyle}
            roleImageDraws={roleImageDraws}
            onSaved={(nextCharacterSetting, nextRoleImageDraws) => onShortDramaUpdate?.({ ...shortDramaObj, characterSetting: nextCharacterSetting, ...(nextRoleImageDraws !== undefined ? { roleImageDraws: nextRoleImageDraws } : {}) })}
          />
        )}
      </section>
    </div>
  )
}
