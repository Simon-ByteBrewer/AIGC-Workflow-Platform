import { redirect } from "next/navigation"

export const runtime = "nodejs"

type Props = { params: Promise<{ storyId: string }> }

export default async function ScriptWorkspaceMaterialsPage({ params }: Props): Promise<never> {
  const { storyId } = await params
  redirect(`/script/workspace/${encodeURIComponent(storyId)}?materials=1`)
}

