"use client"

import { useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import type { QuickGenerateShotVideoResolvedItem } from "@/shared/quickGenerate/videoResults"
import styles from "./QuickGenerateEpisodeVideoPreviewModal.module.css"

export type EpisodeVideoPreviewItem = {
  shotNo: number
  video: QuickGenerateShotVideoResolvedItem
}

type QuickGenerateEpisodeVideoPreviewModalProps = {
  episodeNo: number
  items: EpisodeVideoPreviewItem[]
  onClose: () => void
}

/**
 * 剧集全览视频弹窗组件。
 * 接收一系列已经确认或最新的分镜视频，支持连续自动播放。
 */
export function QuickGenerateEpisodeVideoPreviewModal(props: QuickGenerateEpisodeVideoPreviewModalProps): ReactElement | null {
  const { items, onClose, episodeNo } = props
  const [currentIndex, setCurrentIndex] = useState(0)

  // 保证 currentIndex 在合理范围内
  const validIndex = Math.max(0, Math.min(currentIndex, items.length - 1))
  const activeItem = items[validIndex]

  // 重置状态
  useEffect(() => {
    // 移除导致 Warning: Cannot update a component (`QuickGenerateEpisodeResultPage`) while rendering a different component (`QuickGenerateEpisodeVideoPreviewModal`) 的同步副作用
    // setCurrentIndex(0)
  }, [items.length])

  if (items.length === 0 || !activeItem) {
    return null
  }

  const handleVideoEnded = () => {
    if (validIndex < items.length - 1) {
      setCurrentIndex(validIndex + 1)
    }
  }

  return (
    <div className={styles.modal} role="dialog" aria-modal="true" aria-label={`第 ${episodeNo} 集视频预览`}>
      <div className={styles.modalCard}>
        <div className={styles.playerWrap}>
          <div className={styles.modalHeader}>
            <div className={styles.modalTitle}>
              第 {episodeNo} 集 · 分镜 {String(activeItem.shotNo).padStart(2, "0")}
            </div>
            <button type="button" className={styles.closeBtn} onClick={onClose} aria-label="关闭">
              ×
            </button>
          </div>
          <video
            key={activeItem.video.jobId}
            className={styles.modalVideo}
            src={activeItem.video.url}
            controls
            autoPlay
            playsInline
            preload="metadata"
            onEnded={handleVideoEnded}
          />
        </div>

        <div className={styles.historyList}>
          {items.map((item, index) => (
            <button
              key={item.video.jobId}
              type="button"
              className={styles.historyItem}
              data-active={index === validIndex ? "true" : "false"}
              onClick={() => setCurrentIndex(index)}
            >
              <div className={styles.historyTitle}>分镜 {String(item.shotNo).padStart(2, "0")}</div>
              <div className={styles.historyMeta}>
                {item.video.durationSeconds > 0 ? `${item.video.durationSeconds}s` : "未知时长"} · {item.video.settings.mode || "reference"}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}
