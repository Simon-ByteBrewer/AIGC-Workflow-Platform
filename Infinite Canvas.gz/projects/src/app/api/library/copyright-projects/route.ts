import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import {
  COPYRIGHT_LIBRARY_CATEGORY_IDS,
  COPYRIGHT_LIBRARY_REVIEW_FILTER_IDS
} from "@/shared/contracts/library/copyrightLibrary"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { listCopyrightProjects } from "@/server/domains/library/usecases/listCopyrightProjects"

export const runtime = "nodejs"

const querySchema = z
  .object({
    category: z.enum(COPYRIGHT_LIBRARY_CATEGORY_IDS).optional(),
    reviewFilter: z.enum(COPYRIGHT_LIBRARY_REVIEW_FILTER_IDS).optional(),
    search: z.string().trim().max(100).optional(),
    excludeStoryId: z.string().trim().min(1).optional(),
    includeEmpty: z.enum(["true", "false"]).optional()
  })
  .strict()

/**
 * 按项目返回“版权库”素材列表，供内容库文件夹卡片视图消费。
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({
    category: req.nextUrl.searchParams.get("category") ?? undefined,
    reviewFilter: req.nextUrl.searchParams.get("reviewFilter") ?? undefined,
    search: req.nextUrl.searchParams.get("search") ?? undefined,
    excludeStoryId: req.nextUrl.searchParams.get("excludeStoryId") ?? undefined,
    includeEmpty: req.nextUrl.searchParams.get("includeEmpty") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    logger.info({
      event: "library_copyright_projects_list_start",
      module: "library",
      traceId,
      message: "开始加载版权库项目列表",
      category: parsed.data.category ?? "all",
      reviewFilter: parsed.data.reviewFilter ?? "all"
    })

    const result = await listCopyrightProjects({
      userId,
      category: parsed.data.category ?? "all",
      reviewFilter: parsed.data.reviewFilter ?? "all",
      search: parsed.data.search,
      excludeStoryId: parsed.data.excludeStoryId,
      includeEmptyProjects: parsed.data.includeEmpty !== "false"
    })

    logger.info({
      event: "library_copyright_projects_list_success",
      module: "library",
      traceId,
      message: "版权库项目列表加载成功",
      durationMs: Date.now() - start,
      projectCount: result.projects.length
    })

    return NextResponse.json(makeApiOk(traceId, result), { status: 200 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "加载版权库失败"
    logger.error({
      event: "library_copyright_projects_list_failed",
      module: "library",
      traceId,
      message: "版权库项目列表加载失败",
      durationMs: Date.now() - start,
      errorName: error instanceof Error ? error.name : "UnknownError",
      errorMessage: message,
      stack: error instanceof Error ? error.stack : undefined
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "加载版权库失败"), { status: 500 })
  }
}
