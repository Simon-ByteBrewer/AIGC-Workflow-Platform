"use client"

import type { ReactElement } from "react"
import { ChevronDown, Image as ImageIcon, X } from "lucide-react"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/shared/ui/shadcn/dialog"
import type { ImageModelKind, ImageModelOption } from "@/shared/contracts/imageModelAccess"
import styles from "./RoleImageModelDialog.module.css"

type RoleImageModelDialogProps = {
  open: boolean
  title: string
  description: string
  loading?: boolean
  submitting?: boolean
  errorText?: string | null
  kindOptions: Array<{ value: ImageModelKind; label: string }>
  selectedKind: ImageModelKind
  selectedModelName: string
  items: ImageModelOption[]
  onOpenChange: (open: boolean) => void
  onChangeKind: (kind: ImageModelKind) => void
  onChangeModelName: (modelName: string) => void
  onConfirm: () => void
}

export function RoleImageModelDialog(props: RoleImageModelDialogProps): ReactElement {
  const modelOptions = props.items
    .filter((item) => item.kind === props.selectedKind)
    .map((item) => ({ value: item.modelName, label: item.label }))

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className={`!z-[180] ${styles.content}`} overlayClassName="!z-[179] bg-black/70">
        <DialogHeader className={styles.header}>
          <div className={styles.icon}>
            <ImageIcon className="h-[18px] w-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <DialogTitle className={styles.title}>{props.title}</DialogTitle>
            <div className={styles.hint}>请选择本次生成要使用的图片模型</div>
          </div>
          <DialogClose asChild>
            <button type="button" className={styles.closeBtn} aria-label="关闭" disabled={props.submitting}>
              <X className="h-4 w-4" />
            </button>
          </DialogClose>
        </DialogHeader>

        <div className={styles.body}>
          <div>{props.description}</div>

          <div className={styles.fields}>
            <div className={styles.field}>
              <div className={styles.label}>模型来源</div>
              <div className={styles.selectWrap}>
                <select
                  className={styles.select}
                  aria-label="模型来源"
                  value={props.selectedKind}
                  onChange={(e) => props.onChangeKind(e.currentTarget.value === "external" ? "external" : "internal")}
                  disabled={props.loading || props.submitting || props.kindOptions.length === 0}
                >
                  {props.kindOptions.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className={styles.selectChevron} aria-hidden="true" />
              </div>
            </div>

            <div className={styles.field}>
              <div className={styles.label}>图片模型</div>
              <div className={styles.selectWrap}>
                <select
                  className={styles.select}
                  aria-label="图片模型"
                  value={props.selectedModelName}
                  onChange={(e) => props.onChangeModelName(e.currentTarget.value)}
                  disabled={props.loading || props.submitting || modelOptions.length === 0}
                >
                  {modelOptions.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className={styles.selectChevron} aria-hidden="true" />
              </div>
            </div>

            {props.loading ? <div className={styles.helper}>正在加载可用图片模型...</div> : null}
            {!props.loading && modelOptions.length === 0 ? <div className={styles.helper}>当前来源下没有可用模型</div> : null}
            {props.errorText ? <div className={styles.error}>{props.errorText}</div> : null}
          </div>
        </div>

        <div className={styles.footer}>
          <button
            type="button"
            className={`${styles.btn} ${styles.btnSecondary}`}
            onClick={() => props.onOpenChange(false)}
            disabled={props.submitting}
            autoFocus
          >
            取消
          </button>
          <button
            type="button"
            className={`${styles.btn} ${styles.btnPrimary}`}
            onClick={props.onConfirm}
            disabled={props.loading || props.submitting || !props.selectedModelName}
          >
            {props.submitting ? "提交中..." : "确认生成"}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
