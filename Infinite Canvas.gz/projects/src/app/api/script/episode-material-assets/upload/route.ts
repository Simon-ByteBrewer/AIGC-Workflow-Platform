import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { uploadPublicBuffer } from "@/shared/storage"
import { generateThumbnailInside } from "@/server/lib/thumbnail"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { episodeMaterialAssets, episodeMaterialImages } from "@/shared/schema/generation"
import { stories } from "@/shared/schema/story"
 
const formSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  kind: z.enum(["scene", "role", "item"]),
  name: z.string().trim().min(1).max(200),
  prompt: z.string().trim().max(20_000).optional(),
  cameraOne: z.string().trim().max(2000).optional(),
  cameraTwo: z.string().trim().max(2000).optional(),
  roleName: z.string().trim().max(200).optional(),
  characterId: z.string().trim().max(200).optional(),
  makeupName: z.string().trim().max(200).optional(),
  costumeName: z.string().trim().max(200).optional()
})
 
export const runtime = "nodejs"
 
const MAX_IMAGE_BYTES = 10 * 1024 * 1024
 
function isImageFile(file: File): boolean {
  const type = (file.type || "").trim().toLowerCase()
  return type.startsWith("image/")
}
 
async function uploadImageFile(input: { file: File; prefix: string }): Promise<{ key: string; buffer: Buffer }> {
  if (!isImageFile(input.file)) throw new Error("仅支持上传图片文件")
  if (input.file.size <= 0) throw new Error("上传文件为空")
  if (input.file.size > MAX_IMAGE_BYTES) throw new Error("图片过大（单张最多 10MB）")
 
  const fileName = input.file.name || "image"
  const fileExt = (fileName.split(".").pop() ?? "png").toLowerCase()
  const buffer = Buffer.from(await input.file.arrayBuffer())
  const { key } = await uploadPublicBuffer({
    buffer,
    contentType: input.file.type || "application/octet-stream",
    fileExt,
    prefix: input.prefix
  })
  return { key, buffer }
}

async function uploadThumbnailFromBuffer(input: { buffer: Buffer; prefix: string }): Promise<string> {
  const thumb = await generateThumbnailInside(input.buffer, 300)
  const { key } = await uploadPublicBuffer({
    buffer: thumb,
    contentType: "image/jpeg",
    fileExt: "jpg",
    prefix: input.prefix
  })
  return key
}
 
async function ensureLatestMaterialBatchId(db: any, storyId: string): Promise<string> {
  const latest = await db
    .select({ id: episodeMaterialImages.id })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.storyId, storyId))
    .orderBy(desc(episodeMaterialImages.createdAt))
    .limit(1)
 
  const materialId = latest[0]?.id ?? ""
  if (materialId) return materialId
 
  const inserted = await db
    .insert(episodeMaterialImages)
    .values({
      storyId,
      outlineId: "",
      name: "manual-upload",
      url: "",
      storageKey: "",
      meta: { source: "manual-upload" } as any,
      createdAt: new Date()
    } as any)
    .returning({ id: episodeMaterialImages.id })
  const nextId = inserted[0]?.id ?? ""
  if (!nextId) throw new Error("创建素材批次失败")
  return nextId
}
 
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })
 
  const formData = await req.formData().catch(() => null)
  if (!formData) return NextResponse.json(makeApiErr(traceId, "INVALID_FORM", "上传表单解析失败"), { status: 400 })
 
  const parsed = formSchema.safeParse({
    storyId: formData.get("storyId") ?? "",
    kind: formData.get("kind") ?? "",
    name: formData.get("name") ?? "",
    prompt: formData.get("prompt") ?? undefined,
    cameraOne: formData.get("cameraOne") ?? undefined,
    cameraTwo: formData.get("cameraTwo") ?? undefined,
    roleName: formData.get("roleName") ?? undefined,
    characterId: formData.get("characterId") ?? undefined,
    makeupName: formData.get("makeupName") ?? undefined,
    costumeName: formData.get("costumeName") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
 
  const kind = parsed.data.kind
  const prefix = `episode-material/${parsed.data.storyId}/${kind}`
 
  const primaryFile = kind === "scene" ? formData.get("front") : formData.get("file")
  const secondaryFile = kind === "scene" ? formData.get("back") : null
  if (!(primaryFile instanceof File)) {
    return NextResponse.json(
      makeApiErr(traceId, "VALIDATION_FAILED", kind === "scene" ? "缺少场景正视图（front）" : "缺少上传文件（file）"),
      { status: 400 }
    )
  }
  if (secondaryFile != null && !(secondaryFile instanceof File)) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "上传文件格式不正确（back）"), { status: 400 })
  }
 
  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialImages, episodeMaterialAssets })
 
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })
 
  let mainKey = ""
  let backKey = ""
  let mainThumbKey = ""
  let backThumbKey = ""
  try {
    const uploaded = await uploadImageFile({ file: primaryFile, prefix })
    mainKey = uploaded.key
    try {
      mainThumbKey = await uploadThumbnailFromBuffer({
        buffer: uploaded.buffer,
        prefix: `episode-material-thumb/${parsed.data.storyId}/${kind}`
      })
    } catch {}
    if (kind === "scene") {
      if (secondaryFile instanceof File) {
        const uploadedBack = await uploadImageFile({ file: secondaryFile, prefix })
        backKey = uploadedBack.key
        try {
          backThumbKey = await uploadThumbnailFromBuffer({
            buffer: uploadedBack.buffer,
            prefix: `episode-material-thumb/${parsed.data.storyId}/${kind}`
          })
        } catch {}
      } else {
        backKey = mainKey
        backThumbKey = mainThumbKey
      }
    }
  } catch (e) {
    const anyErr = e as { message?: string }
    const msg = anyErr?.message?.trim() || "上传失败"
    return NextResponse.json(makeApiErr(traceId, "UPLOAD_FAILED", msg), { status: 400 })
  }
 
  let materialId = ""
  try {
    materialId = await ensureLatestMaterialBatchId(db, parsed.data.storyId)
  } catch (e) {
    const anyErr = e as { message?: string }
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", anyErr?.message ?? "创建素材批次失败"), { status: 500 })
  }
 
  const createdAt = new Date()
  const isRole = kind === "role"
  const roleName = isRole ? (parsed.data.roleName ?? parsed.data.name).trim() : null
  const characterId = isRole ? (parsed.data.characterId ?? "").trim() || null : null
  const makeupName = isRole ? (parsed.data.makeupName ?? "").trim() || null : null
  const costumeName = isRole ? (parsed.data.costumeName ?? "").trim() || null : null
  const cameraOne = kind === "scene" ? (parsed.data.cameraOne ?? "").trim() : ""
  const cameraTwo = kind === "scene" ? (parsed.data.cameraTwo ?? "").trim() : ""
  const prompt = (parsed.data.prompt ?? "").trim() || null
 
  const meta: any = {
    source: "upload",
    generationStatus: "uploaded",
    ...(kind === "scene"
      ? {
          cameraOne,
          cameraTwo,
          forceDualViews: !(secondaryFile instanceof File),
          views: [
            { view: "front", storageKey: mainKey, thumbnailStorageKey: mainThumbKey || undefined },
            { view: "back", storageKey: backKey, thumbnailStorageKey: backThumbKey || undefined }
          ]
        }
      : {}),
    ...(kind !== "scene" ? { thumbnailStorageKey: mainThumbKey || null } : {}),
    ...(kind === "role" && characterId ? { characterId } : {})
  }
 
  const inserted = await db
    .insert(episodeMaterialAssets)
    .values({
      storyId: parsed.data.storyId,
      materialId,
      kind,
      name: parsed.data.name,
      roleName,
      makeupName,
      costumeName,
      prompt,
      url: "",
      storageKey: mainKey,
      meta,
      createdAt
    } as any)
    .returning({ id: episodeMaterialAssets.id })
 
  const assetId = inserted[0]?.id ?? ""
  if (!assetId) return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "创建素材失败"), { status: 500 })
 
  return NextResponse.json(makeApiOk(traceId, { assetId }), { status: 200 })
}
