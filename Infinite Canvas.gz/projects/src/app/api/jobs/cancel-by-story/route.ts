import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { ensureJobsTable } from "@/server/db/ensureJobsTable"
import { logger } from "@/shared/logger"
import { cancelJobsByStoryWithPolicy } from "@/server/framework/jobs/usecases/cancelJobsByStoryWithPolicy"

export const runtime = "nodejs"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensureJobsTable()
  const startedAt = Date.now()
  logger.info({
    event: "jobs_cancel_by_story_start",
    module: "jobs",
    traceId,
    message: "开始终止当前剧本活跃任务",
    storyId: parsed.data.storyId
  })
  let count = 0
  try {
    const result = await cancelJobsByStoryWithPolicy({
      traceId,
      userId,
      storyId: parsed.data.storyId
    })
    if (!result.ok) {
      if (result.canceled > 0) kickAllWorkers()
      return NextResponse.json(makeApiErr(traceId, result.code, result.message), { status: result.httpStatus })
    }
    count = result.canceled
  } catch (e) {
    logger.error({
      event: "jobs_cancel_by_story_failed",
      module: "jobs",
      traceId,
      message: "终止当前剧本活跃任务失败",
      storyId: parsed.data.storyId,
      errorName: (e as any)?.name,
      errorMessage: (e as any)?.message,
      stack: (e as any)?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "CANCEL_FAILED", "终止任务失败"), { status: 500 })
  }
  kickAllWorkers()
  logger.info({
    event: "jobs_cancel_by_story_success",
    module: "jobs",
    traceId,
    message: "终止当前剧本活跃任务成功",
    storyId: parsed.data.storyId,
    canceled: count,
    durationMs: Date.now() - startedAt
  })

  return NextResponse.json(makeApiOk(traceId, { canceled: count }), { status: 200 })
}
