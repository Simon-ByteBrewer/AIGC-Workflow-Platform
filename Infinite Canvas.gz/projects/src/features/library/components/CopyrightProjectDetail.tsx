"use client"

import type { ReactElement } from "react"
import { ArrowLeft } from "lucide-react"
import type { CopyrightLibraryItem, CopyrightLibraryProject } from "@/shared/contracts/library/copyrightLibrary"
import { CopyrightMaterialCard } from "./CopyrightMaterialCard"
import styles from "./CopyrightLibrary.module.css"

interface CopyrightProjectDetailProps {
  project: CopyrightLibraryProject | null
  view: "grid" | "list"
  onBack: () => void
  onPreview: (item: CopyrightLibraryItem) => void
}

function getProjectTypeLabel(projectType: CopyrightLibraryProject["projectType"]): string {
  return projectType === "canvas" ? "画布项目" : "快速开始项目"
}

export function CopyrightProjectDetail({ project, view, onBack, onPreview }: CopyrightProjectDetailProps): ReactElement {
  if (!project) {
    return (
      <div className={styles.projectDetailWrap}>
        <div className={styles.projectDetailHeader}>
          <button type="button" className={styles.backBtn} onClick={onBack}>
            <ArrowLeft size={16} />
            返回项目列表
          </button>
        </div>
        <div className={styles.projectEmpty}>当前项目不存在或已被移除</div>
      </div>
    )
  }

  return (
    <div className={styles.projectDetailWrap}>
      <div className={styles.projectDetailHeader}>
        <div className={styles.projectDetailTop}>
          <button type="button" className={styles.backBtn} onClick={onBack}>
            <ArrowLeft size={16} />
            返回项目列表
          </button>
          <div className={styles.projectBreadcrumb}>版权库 / {project.title}</div>
        </div>
        <div className={styles.projectDetailTitleRow}>
          <div>
            <div className={styles.projectDetailTitle}>{project.title}</div>
            <div className={styles.projectDetailMeta}>共 {project.items.length} 个版权素材，点击素材可预览详情</div>
          </div>
          <div
            className={`${styles.folderSourceBadge} ${
              project.projectType === "canvas" ? styles.folderSourceBadgeCanvas : styles.folderSourceBadgeQuick
            }`}
          >
            {getProjectTypeLabel(project.projectType)}
          </div>
        </div>
      </div>
      <div className={styles.projectDetailBody}>
        {project.items.length === 0 ? (
          <div className={styles.projectEmpty}>当前项目下暂无符合条件的版权素材</div>
        ) : (
          <div className={view === "list" ? styles.materialsList : styles.materialsGrid}>
            {project.items.map((item) => (
              <CopyrightMaterialCard key={item.id} item={item} view={view} onClick={() => onPreview(item)} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
