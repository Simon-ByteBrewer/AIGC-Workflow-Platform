import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { createQuickGenerateProject } from "@/server/domains/quick-generate/usecases/createQuickGenerateProject"

export const runtime = "nodejs"

const postSchema = z
  .object({
    title: z.string().trim().min(1).max(100),
    ratio: z.string().trim().max(20).optional(),
    resolution: z.string().trim().max(20).optional(),
    style: z.string().trim().max(50).optional(),
    videoCategory: z.enum(["premium", "commentary"]).optional()
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    logger.info({
      event: "quick_generate_project_create_start",
      module: "quick_generate",
      traceId,
      message: "开始创建快速生成项目"
    })

    const result = await createQuickGenerateProject({
      traceId,
      userId,
      title: parsed.data.title,
      ratio: parsed.data.ratio,
      resolution: parsed.data.resolution,
      style: parsed.data.style,
      videoCategory: parsed.data.videoCategory
    })
    logger.info({
      event: "quick_generate_project_create_success",
      module: "quick_generate",
      traceId,
      message: "快速生成项目创建成功",
      durationMs: Date.now() - start,
      storyId: result.storyId,
      projectId: result.projectId,
      groupId: result.groupId
    })
    return NextResponse.json(makeApiOk(traceId, result), { status: 200 })
  } catch (error) {
    const anyErr = error as { message?: string }
    logger.error({
      event: "quick_generate_project_create_failed",
      module: "quick_generate",
      traceId,
      message: "快速生成项目创建失败",
      durationMs: Date.now() - start,
      errorMessage: anyErr?.message
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", anyErr?.message?.trim() || "创建快速生成项目失败"), { status: 500 })
  }
}
