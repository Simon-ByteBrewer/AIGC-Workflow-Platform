import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { storyAssetLibrary } from "@/shared/schema/generation"
import { createCozeS3Storage } from "@/server/integrations/storage/s3"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsed = paramsSchema.safeParse(rawParams)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const kind = req.nextUrl.searchParams.get("kind") === "thumbnail" ? "thumbnail" : "original"

  const db = await getDb({ stories, storyAssetLibrary })
  const rows = await db
    .select({
      id: storyAssetLibrary.id,
      storyId: storyAssetLibrary.storyId,
      url: storyAssetLibrary.url,
      storageKey: storyAssetLibrary.storageKey,
      thumbnailUrl: storyAssetLibrary.thumbnailUrl,
      thumbnailStorageKey: storyAssetLibrary.thumbnailStorageKey
    })
    .from(storyAssetLibrary)
    .innerJoin(stories, eq(storyAssetLibrary.storyId, stories.id))
    .where(and(eq(storyAssetLibrary.id, parsed.data.id), eq(stories.userId, userId)))
    .limit(1)

  const row = rows[0]
  if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

  const storageKey = (kind === "thumbnail" ? row.thumbnailStorageKey : row.storageKey) ?? ""
  const fallbackUrl = (kind === "thumbnail" ? row.thumbnailUrl : row.url) ?? ""

  if (!String(storageKey).trim() && String(fallbackUrl).trim()) return NextResponse.json(makeApiOk(traceId, { url: fallbackUrl }), { status: 200 })
  if (!String(storageKey).trim()) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源链接不存在"), { status: 404 })

  const storage = createCozeS3Storage()
  try {
    const url = await resolveStorageUrl(storage, String(storageKey).trim())
    return NextResponse.json(makeApiOk(traceId, { url }), { status: 200 })
  } catch {
    if (!String(fallbackUrl).trim()) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源链接不存在"), { status: 404 })
    return NextResponse.json(makeApiOk(traceId, { url: fallbackUrl }), { status: 200 })
  }
}

