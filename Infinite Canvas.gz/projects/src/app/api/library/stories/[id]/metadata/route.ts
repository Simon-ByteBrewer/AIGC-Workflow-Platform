import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { updateStoryMetadata } from "@/server/domains/library/usecases/updateStoryMetadata"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq } from "drizzle-orm"
import { stories } from "@/shared/schema"
import { hydrateShortDramaScriptBodyIfNeeded } from "@/server/shared/story/shortDramaScriptBodyStorage"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

const patchSchema = z.object({
  shortDrama: z
    .object({
      planningResult: z.any(),
      planningConfirmedAt: z.number().int().nonnegative().optional(),
      worldSetting: z.any(),
      characterSetting: z.any(),
      roleImageDraws: z.any().optional(),
      setupSource: z.string().trim().max(50).optional()
    })
    .optional(),
  videoCreation: z
     .object({
      videoCount: z.coerce.number().int().min(1).max(3).optional(),
      firstFrameCount: z.coerce.number().int().min(1).max(3).optional(),
      creationMode: z.enum(["first_frame", "reference"]).optional(),
      // Video model name selected by user; resolved to endpoint/api_key server-side.
      creationModel: z.string().trim().min(1).max(100).optional()
    })
    .optional()
}).refine((v) => v.shortDrama !== undefined || v.videoCreation !== undefined, { message: "必须至少提供 shortDrama 或 videoCreation" })

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const db = await getDb({ stories })
  const rows = await db
    .select({ metadata: stories.metadata })
    .from(stories)
    .where(and(eq(stories.id, parsedParams.data.id), eq(stories.userId, userId)))
    .limit(1)
  const row = rows[0]
  if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "剧本不存在"), { status: 404 })

  const hydrated = await hydrateShortDramaScriptBodyIfNeeded({ metadata: (row.metadata ?? {}) as Record<string, unknown> })
  return NextResponse.json(makeApiOk(traceId, { storyId: parsedParams.data.id, metadata: hydrated.metadata }), { status: 200 })
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsedBody = patchSchema.safeParse(body)
  if (!parsedBody.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const updated = await updateStoryMetadata({
      userId,
      storyId: parsedParams.data.id,
      patch: {
        ...(parsedBody.data.shortDrama ? { shortDrama: parsedBody.data.shortDrama } : {}),
        ...(parsedBody.data.videoCreation ? { videoCreation: parsedBody.data.videoCreation } : {})
      }
    })
    return NextResponse.json(makeApiOk(traceId, updated), { status: 200 })
  } catch (e) {
    const msg = String((e as any)?.message ?? "")
    if (msg === "STORY_NOT_FOUND") {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "剧本不存在"), { status: 404 })
    }
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "写入失败，请稍后重试"), { status: 500 })
  }
}
