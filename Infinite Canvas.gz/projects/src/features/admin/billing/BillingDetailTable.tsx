"use client"

import type { BillingDetailItem } from "@/shared/contracts/billing"
import { formatBillingUnitPrice, formatBillingUsageLines, formatModelSourceLabel, formatResourceTypeLabel, formatTaskTypeLabel } from "./billingPresentation"
import styles from "./BillingPage.module.css"

type BillingDetailTableProps = {
  items: BillingDetailItem[]
  emptyText?: string
  showEmpty?: boolean
}

/**
 * 账单明细表格。
 * 说明：统一任务查询结果与详情弹窗的列口径，避免两个入口展示规则漂移。
 */
export function BillingDetailTable({ items, emptyText = "暂无明细", showEmpty = true }: BillingDetailTableProps) {
  return (
    <>
      <div className={styles.detailTableScroll}>
        <div className={styles.detailTable}>
          <div className={styles.detailHeader}>
            <div className={styles.detailHeaderCell}>时间</div>
            <div className={styles.detailHeaderCell}>任务 ID</div>
            <div className={styles.detailHeaderCell}>外部任务 ID</div>
            <div className={styles.detailHeaderCell}>任务类型</div>
            <div className={styles.detailHeaderCell}>资源类型</div>
            <div className={styles.detailHeaderCell}>模型来源</div>
            <div className={styles.detailHeaderCell}>模型名称</div>
            <div className={styles.detailHeaderCell}>计量明细</div>
            <div className={styles.detailHeaderCell}>单价</div>
            <div className={styles.detailHeaderCell}>花费</div>
          </div>
          <div className={styles.detailList}>
            {items.map((item) => {
              const usageLines = formatBillingUsageLines(item)
              const displayName = item.modelDisplayName ?? item.modelName
              const showModelAlias = Boolean(item.modelDisplayName) && item.modelDisplayName !== item.modelName
              return (
                <div key={item.id} className={styles.detailRow}>
                  <div className={styles.detailCell}>{new Date(item.createdAt).toLocaleString()}</div>
                  <div className={`${styles.detailCell} ${styles.monoCell}`} title={item.jobId}>
                    <span className={styles.monoValue}>{item.jobId}</span>
                  </div>
                  <div className={`${styles.detailCell} ${styles.monoCell}`} title={item.videoTaskId ?? ""}>
                    <span className={item.videoTaskId ? styles.monoValue : styles.placeholderValue}>{item.videoTaskId ?? "-"}</span>
                  </div>
                  <div className={styles.detailCell}>{formatTaskTypeLabel(item.requestType)}</div>
                  <div className={styles.detailCell}>{formatResourceTypeLabel(item.resourceType)}</div>
                  <div className={styles.detailCell}>{formatModelSourceLabel(item)}</div>
                  <div className={styles.detailCell}>
                    <div className={styles.detailStack}>
                      <span>{displayName}</span>
                      {showModelAlias ? <span className={styles.detailSubtle}>{item.modelName}</span> : null}
                    </div>
                  </div>
                  <div className={styles.detailCell}>
                    <div className={styles.detailStack}>
                      {usageLines.map((line) => (
                        <span key={line} className={styles.detailMetricLine}>
                          {line}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className={styles.detailCell}>{formatBillingUnitPrice(item)}</div>
                  <div className={styles.detailCell}>{item.totalCost} 元</div>
                </div>
              )
            })}
            {showEmpty && items.length === 0 ? <div className={styles.empty}>{emptyText}</div> : null}
          </div>
        </div>
      </div>
    </>
  )
}
