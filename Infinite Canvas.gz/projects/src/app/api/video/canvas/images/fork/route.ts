import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { generatedImages, publicResources, sharedResources, stories, videoCanvasAssets } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  scope: z.enum(["library", "shared", "generated", "canvas"]),
  id: z.string().trim().min(1).max(200)
})

function mapPublicTypeToGeneratedCategory(type: string): string {
  if (type === "character") return "role"
  if (type === "props") return "item"
  if (type === "background") return "reference"
  return "reference"
}

/**
 * 将任意来源图片 fork 为一条新的 generated_images（不下载、不转存）。
 * 用于：画布节点内部使用统一的 generated_images 来承载生成/派生历史。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "入参格式不正确"), { status: 400 })

  await ensurePublicSchema()

  const db = await getDb({ generatedImages, publicResources, sharedResources, stories, videoCanvasAssets })

  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的项目"), { status: 404 })

  const makeStable = (id: string) => ({
    url: `/api/video-creation/images/file/${id}`,
    thumbnailUrl: `/api/video-creation/images/file/${id}?kind=thumbnail`
  })

  const storage = getS3Storage()

  if (parsed.data.scope === "library") {
    const rows = await db
      .select({
        id: publicResources.id,
        userId: publicResources.userId,
        type: publicResources.type,
        name: publicResources.name,
        description: publicResources.description,
        previewStorageKey: publicResources.previewStorageKey,
        originalStorageKey: publicResources.originalStorageKey
      })
      .from(publicResources)
      .where(and(eq(publicResources.id, parsed.data.id)))
      .limit(1)

    const src = rows[0] ?? null
    if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
    if (src.userId !== userId) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

    const storageKey = (src.originalStorageKey ?? src.previewStorageKey ?? "").trim()
    if (!storageKey) return NextResponse.json(makeApiErr(traceId, "INVALID_RESOURCE", "资源缺少存储信息"), { status: 400 })
    const thumbKey = (src.previewStorageKey ?? src.originalStorageKey ?? "").trim() || null

    const [created] = await db
      .insert(generatedImages)
      .values({
        storyId: parsed.data.storyId,
        storyboardId: null,
        name: src.name,
        description: src.description ?? "",
        url: makeStable("tmp").url,
        storageKey,
        thumbnailUrl: makeStable("tmp").thumbnailUrl,
        thumbnailStorageKey: thumbKey,
        category: mapPublicTypeToGeneratedCategory(src.type),
        prompt: null,
        deletedAt: null
      } as any)
      .returning({ id: generatedImages.id })

    const id = created?.id ?? null
    if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
    await db.update(generatedImages).set(makeStable(id)).where(eq(generatedImages.id, id))
    const signedUrl = storageKey ? await resolveStorageUrl(storage, storageKey).catch(() => "") : ""
    const signedThumb = thumbKey ? await resolveStorageUrl(storage, thumbKey).catch(() => "") : ""
    return NextResponse.json(
      makeApiOk(traceId, {
        id,
        url: signedUrl || makeStable(id).url,
        thumbnailUrl: signedThumb || makeStable(id).thumbnailUrl
      }),
      { status: 200 }
    )
  }

  if (parsed.data.scope === "shared") {
    const rows = await db
      .select({
        id: sharedResources.id,
        type: sharedResources.type,
        name: sharedResources.name,
        description: sharedResources.description,
        previewStorageKey: sharedResources.previewStorageKey,
        originalStorageKey: sharedResources.originalStorageKey
      })
      .from(sharedResources)
      .where(and(eq(sharedResources.id, parsed.data.id)))
      .limit(1)

    const src = rows[0] ?? null
    if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })

    const storageKey = (src.originalStorageKey ?? src.previewStorageKey ?? "").trim()
    if (!storageKey) return NextResponse.json(makeApiErr(traceId, "INVALID_RESOURCE", "资源缺少存储信息"), { status: 400 })
    const thumbKey = (src.previewStorageKey ?? src.originalStorageKey ?? "").trim() || null

    const [created] = await db
      .insert(generatedImages)
      .values({
        storyId: parsed.data.storyId,
        storyboardId: null,
        name: src.name,
        description: src.description ?? "",
        url: makeStable("tmp").url,
        storageKey,
        thumbnailUrl: makeStable("tmp").thumbnailUrl,
        thumbnailStorageKey: thumbKey,
        category: mapPublicTypeToGeneratedCategory(src.type),
        prompt: null,
        deletedAt: null
      } as any)
      .returning({ id: generatedImages.id })

    const id = created?.id ?? null
    if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
    await db.update(generatedImages).set(makeStable(id)).where(eq(generatedImages.id, id))
    const signedUrl = storageKey ? await resolveStorageUrl(storage, storageKey).catch(() => "") : ""
    const signedThumb = thumbKey ? await resolveStorageUrl(storage, thumbKey).catch(() => "") : ""
    return NextResponse.json(
      makeApiOk(traceId, {
        id,
        url: signedUrl || makeStable(id).url,
        thumbnailUrl: signedThumb || makeStable(id).thumbnailUrl
      }),
      { status: 200 }
    )
  }

  if (parsed.data.scope === "canvas") {
    const rows = await db
      .select({
        id: videoCanvasAssets.id,
        storyId: videoCanvasAssets.storyId,
        kind: videoCanvasAssets.kind,
        storageKey: videoCanvasAssets.storageKey,
        previewStorageKey: videoCanvasAssets.previewStorageKey,
        sourceRef: videoCanvasAssets.sourceRef
      })
      .from(videoCanvasAssets)
      .where(and(eq(videoCanvasAssets.id, parsed.data.id), eq(videoCanvasAssets.storyId, parsed.data.storyId)))
      .limit(1)

    const src = rows[0] ?? null
    if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
    if (String(src.kind ?? "").trim() !== "image") {
      return NextResponse.json(makeApiErr(traceId, "INVALID_RESOURCE", "仅支持图片资源转换"), { status: 400 })
    }

    const storageKey = String(src.storageKey ?? "").trim()
    if (!storageKey) return NextResponse.json(makeApiErr(traceId, "INVALID_RESOURCE", "资源缺少存储信息"), { status: 400 })
    const thumbKey = (src.previewStorageKey ? String(src.previewStorageKey).trim() : "") || null

    const fileName = typeof (src.sourceRef as any)?.fileName === "string" ? String((src.sourceRef as any).fileName).trim() : ""
    const name = fileName || "画布上传图片"

    const [created] = await db
      .insert(generatedImages)
      .values({
        storyId: parsed.data.storyId,
        storyboardId: null,
        name,
        description: "",
        url: makeStable("tmp").url,
        storageKey,
        thumbnailUrl: makeStable("tmp").thumbnailUrl,
        thumbnailStorageKey: thumbKey,
        category: "reference",
        prompt: null,
        deletedAt: null
      } as any)
      .returning({ id: generatedImages.id })

    const id = created?.id ?? null
    if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
    await db.update(generatedImages).set(makeStable(id)).where(eq(generatedImages.id, id))
    const signedUrl = storageKey ? await resolveStorageUrl(storage, storageKey).catch(() => "") : ""
    const signedThumb = thumbKey ? await resolveStorageUrl(storage, thumbKey).catch(() => "") : ""
    return NextResponse.json(
      makeApiOk(traceId, {
        id,
        url: signedUrl || makeStable(id).url,
        thumbnailUrl: signedThumb || makeStable(id).thumbnailUrl
      }),
      { status: 200 }
    )
  }

  const rows = await db
    .select({
      id: generatedImages.id,
      storyId: generatedImages.storyId,
      name: generatedImages.name,
      description: generatedImages.description,
      storageKey: generatedImages.storageKey,
      thumbnailStorageKey: generatedImages.thumbnailStorageKey,
      category: generatedImages.category,
      prompt: generatedImages.prompt
    })
    .from(generatedImages)
    .innerJoin(stories, eq(generatedImages.storyId, stories.id))
    .where(and(eq(generatedImages.id, parsed.data.id), eq(stories.userId, userId), isNull(generatedImages.deletedAt)))
    .limit(1)

  const src = rows[0] ?? null
  if (!src) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到图片或无权限"), { status: 404 })

  const [created] = await db
    .insert(generatedImages)
    .values({
      storyId: parsed.data.storyId,
      storyboardId: null,
      name: src.name,
      description: src.description ?? "",
      url: makeStable("tmp").url,
      storageKey: src.storageKey,
      thumbnailUrl: makeStable("tmp").thumbnailUrl,
      thumbnailStorageKey: src.thumbnailStorageKey,
      category: src.category ?? "reference",
      prompt: src.prompt ?? null,
      deletedAt: null
    } as any)
    .returning({ id: generatedImages.id })

  const id = created?.id ?? null
  if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
  await db.update(generatedImages).set(makeStable(id)).where(eq(generatedImages.id, id))
  const signedUrl = src.storageKey ? await resolveStorageUrl(storage, src.storageKey).catch(() => "") : ""
  const signedThumb = src.thumbnailStorageKey ? await resolveStorageUrl(storage, src.thumbnailStorageKey).catch(() => "") : ""
  return NextResponse.json(
    makeApiOk(traceId, {
      id,
      url: signedUrl || makeStable(id).url,
      thumbnailUrl: signedThumb || makeStable(id).thumbnailUrl
    }),
    { status: 200 }
  )
}
