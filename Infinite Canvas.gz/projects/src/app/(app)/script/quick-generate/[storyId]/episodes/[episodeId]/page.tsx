import type { ReactElement } from "react"
import { cookies } from "next/headers"
import { and, asc, eq } from "drizzle-orm"
import { notFound } from "next/navigation"
import { createCozeS3Storage } from "@/server/integrations/storage/s3"
import { QuickGenerateEpisodeResultPage } from "@/features/script/quickGenerate/components/QuickGenerateEpisodeResultPage"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getQuickGenerateEpisodeAccess } from "@/server/domains/quick-generate/access"
import { logger } from "@/shared/logger"
import { parseQuickGenerateEpisodeShots } from "@/shared/quickGenerate/episodeShots"
import { normalizeQuickGenerateEpisodeVideoResults, type QuickGenerateShotVideoResolvedItem } from "@/shared/quickGenerate/videoResults"
import { quickGenerateEpisodes, quickGenerateMaterials, stories } from "@/shared/schema"
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/shared/session"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { getTraceId } from "@/shared/trace"

export const dynamic = "force-dynamic"


type ShotVideoView = QuickGenerateShotVideoResolvedItem
type ShotVideoBucketView = {
  videos: ShotVideoView[]
  selectedJobId: string
}

function normalizeIndexedStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map((item) => String(item ?? "").trim()) : []
}

async function resolveStoryboardPanelImageUrls(shots: ReturnType<typeof parseQuickGenerateEpisodeShots>["shots"]) {
  const storage = createCozeS3Storage()
  return await Promise.all(
    shots.map(async (shot) => {
      const sourceUrls = normalizeIndexedStringArray(shot.storyboardPanelImages)
      const sourceKeys = normalizeIndexedStringArray(shot.storyboardPanelImageStorageKeys)
      if (sourceUrls.length === 0 && sourceKeys.length === 0) return shot

      const pairCount = Math.max(sourceUrls.length, sourceKeys.length)
      const resolvedPairs = await Promise.all(
        Array.from({ length: pairCount }, async (_, index) => {
          const storageKey = sourceKeys[index] ?? ""
          const fallbackUrl = sourceUrls[index] ?? ""
          if (!storageKey) {
            return fallbackUrl
              ? { originalUrl: fallbackUrl, resolvedUrl: fallbackUrl, storageKey: "" }
              : null
          }
          try {
            const resolvedUrl = await resolveStorageUrl(storage, storageKey)
            return {
              originalUrl: fallbackUrl,
              resolvedUrl: resolvedUrl || fallbackUrl,
              storageKey
            }
          } catch {
            return fallbackUrl
              ? { originalUrl: fallbackUrl, resolvedUrl: fallbackUrl, storageKey }
              : null
          }
        })
      )

      const dedupedPairs: Array<{ originalUrl: string; resolvedUrl: string; storageKey: string }> = []
      const seen = new Set<string>()
      for (const pair of resolvedPairs) {
        if (!pair?.resolvedUrl) continue
        if (seen.has(pair.resolvedUrl)) continue
        seen.add(pair.resolvedUrl)
        dedupedPairs.push(pair)
      }

      const resolvedUrls = dedupedPairs.map((pair) => pair.resolvedUrl)
      const resolvedKeys = dedupedPairs.map((pair) => pair.storageKey)
      const selectedKey = String(shot.selectedStoryboardPanelImageStorageKey ?? "").trim()
      const selectedUrl = String(shot.selectedStoryboardPanelImage ?? "").trim()
      const selectedIndex = dedupedPairs.findIndex((pair) => {
        if (selectedKey && pair.storageKey === selectedKey) return true
        if (selectedUrl && (pair.originalUrl === selectedUrl || pair.resolvedUrl === selectedUrl)) return true
        return false
      })

      return {
        ...shot,
        storyboardPanelImages: resolvedUrls,
        storyboardPanelImageStorageKeys: resolvedKeys,
        selectedStoryboardPanelImage:
          selectedIndex >= 0 ? resolvedUrls[selectedIndex] ?? "" : resolvedUrls[0] ?? selectedUrl,
        selectedStoryboardPanelImageStorageKey:
          selectedIndex >= 0 ? resolvedKeys[selectedIndex] ?? "" : resolvedKeys[0] ?? selectedKey
      }
    })
  )
}

type EpisodeTabView = {
  id: string
  episodeNo: number
  title: string | null
}

function uniqueNonEmpty(values: string[]): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const v of values) {
    const s = String(v ?? "").trim()
    if (!s || seen.has(s)) continue
    seen.add(s)
    out.push(s)
  }
  return out
}

function truncateForLog(value: string, maxChars = 120): string {
  const text = String(value ?? "").trim()
  if (text.length <= maxChars) return text
  return `${text.slice(0, maxChars)}...`
}

/**
 * 将 quick-generate 分镜视频历史解析并补全当前可播放的签名 URL。
 */
async function resolveEpisodeShotVideoResults(videoResultsPayload: unknown): Promise<Record<number, ShotVideoBucketView>> {
  const normalized = normalizeQuickGenerateEpisodeVideoResults(videoResultsPayload)
  const storage = createCozeS3Storage()
  const resultEntries = await Promise.all(
    Object.entries(normalized).map(async ([shotNoKey, bucket]) => {
      const shotNo = Number(shotNoKey)
      if (!Number.isFinite(shotNo) || shotNo <= 0) return null

      const videos = (
        await Promise.all(
          bucket.videos.map(async (video) => {
            try {
              const url = await resolveStorageUrl(storage, video.storageKey)
              if (!url) return null
              return { ...video, url }
            } catch {
              return null
            }
          })
        )
      ).filter(Boolean) as ShotVideoView[]

      if (videos.length === 0) return null
      const selectedJobId = bucket.selectedJobId?.trim() ?? ""
      const safeSelectedJobId = videos.some((video) => video.jobId === selectedJobId) ? selectedJobId : ""
      return [Math.trunc(shotNo), { videos, selectedJobId: safeSelectedJobId }] as const
    })
  )

  return Object.fromEntries(resultEntries.filter(Boolean) as Array<readonly [number, ShotVideoBucketView]>)
}

export default async function Page({
  params,
  searchParams
}: {
  params: { storyId: string; episodeId: string } | Promise<{ storyId: string; episodeId: string }>
  searchParams?: Record<string, string | string[] | undefined> | Promise<Record<string, string | string[] | undefined>>
}): Promise<ReactElement> {
  const { storyId, episodeId } = await Promise.resolve(params)
  const resolvedSearchParams = await Promise.resolve(searchParams)
  if (!storyId?.trim() || !episodeId?.trim()) notFound()
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  if (!token) notFound()
  const session = await verifySessionToken(token, getTraceId(new Headers()))
  if (!session?.userId) notFound()
  const access = await getQuickGenerateEpisodeAccess(session.userId, episodeId)
  if (!access || access.storyId !== storyId) notFound()

  await ensurePublicSchema()
  const db = await getDb({ stories, quickGenerateEpisodes, quickGenerateMaterials })
  const rows = await db
    .select({
      id: quickGenerateEpisodes.id,
      episodeNo: quickGenerateEpisodes.episodeNo,
      status: quickGenerateEpisodes.status,
      requestPayload: quickGenerateEpisodes.requestPayload,
      resultPayload: quickGenerateEpisodes.resultPayload,
      videoPromptPayload: quickGenerateEpisodes.videoPromptPayload,
      videoResults: quickGenerateEpisodes.videoResults,
      storyTitle: stories.title,
      storyAspectRatio: stories.aspectRatio,
      storyResolution: stories.resolution
    })
    .from(quickGenerateEpisodes)
    .innerJoin(stories, eq(stories.id, quickGenerateEpisodes.storyId))
    .where(and(eq(quickGenerateEpisodes.id, episodeId), eq(quickGenerateEpisodes.storyId, storyId)))
    .limit(1)

  const row = rows[0]
  if (!row?.id) notFound()

  const episodeTabRows = await db
    .select({
      id: quickGenerateEpisodes.id,
      episodeNo: quickGenerateEpisodes.episodeNo,
      title: quickGenerateEpisodes.title
    })
    .from(quickGenerateEpisodes)
    .where(eq(quickGenerateEpisodes.storyId, storyId))
    .orderBy(asc(quickGenerateEpisodes.episodeNo))

  const materialRows = await db
    .select({
      id: quickGenerateMaterials.id,
      title: quickGenerateMaterials.title,
      materialType: quickGenerateMaterials.materialType,
      sourceUrl: quickGenerateMaterials.sourceUrl,
      voiceSpeakerId: quickGenerateMaterials.voiceSpeakerId,
      voiceSpeakerName: quickGenerateMaterials.voiceSpeakerName,
      metadata: quickGenerateMaterials.metadata
    })
    .from(quickGenerateMaterials)
    .where(eq(quickGenerateMaterials.storyId, storyId))

  const toOption = (m: typeof materialRows[0]) => ({
    label: m.title ?? "",
    value: m.title ?? "",
    image: m.sourceUrl ?? undefined,
    materialId: String(m.id)
  })

  const toVideoOption = (m: typeof materialRows[0]) => ({
    label: (m.title ?? "").trim() || `视频 ${String(m.id).slice(0, 8)}`,
    value: String(m.id),
    // Do not pass video url as <img> src.
    image: undefined as string | undefined
  })

  const roleOptions = uniqueNonEmpty(materialRows.filter((m) => m.materialType === "character").map((m) => m.title ?? ""))
    .map(name => toOption(materialRows.find(m => m.title === name)!))
  const sceneOptions = uniqueNonEmpty(materialRows.filter((m) => m.materialType === "scene").map((m) => m.title ?? ""))
    .map(name => toOption(materialRows.find(m => m.title === name)!))
  const itemOptions = uniqueNonEmpty(materialRows.filter((m) => m.materialType === "prop").map((m) => m.title ?? ""))
    .map(name => toOption(materialRows.find(m => m.title === name)!))

  const roleVoiceMap: Record<string, string> = {}
  for (const row of materialRows) {
    if (row.materialType !== "character") continue
    const roleName = String(row.title ?? "").trim()
    const voiceName = String(row.voiceSpeakerName ?? "").trim()
    if (!roleName || !voiceName) continue
    if (roleVoiceMap[roleName]) continue
    roleVoiceMap[roleName] = voiceName
  }

  const audioOptionNames = uniqueNonEmpty([
    ...materialRows.filter((m) => m.materialType === "audio").map((m) => m.title ?? ""),
    ...materialRows.filter((m) => m.materialType === "character").map((m) => m.voiceSpeakerName ?? "")
  ])
  const audioOptions = audioOptionNames.map((name) => ({
    label: name,
    value: name
  }))

  const videoOptions = materialRows.filter((m) => m.materialType === "video").map(toVideoOption)

  const jobIdRaw = resolvedSearchParams?.jobId
  const jobId = Array.isArray(jobIdRaw) ? jobIdRaw[0] : jobIdRaw
  const safeJobId = typeof jobId === "string" ? jobId.trim() : ""
  const initialDefaultVideoModel =
    row.requestPayload && typeof row.requestPayload === "object" && !Array.isArray(row.requestPayload)
      ? String((row.requestPayload as Record<string, unknown>).videoModel ?? "").trim()
      : ""
  const initialDefaultStoryboardPanelModel =
    row.requestPayload && typeof row.requestPayload === "object" && !Array.isArray(row.requestPayload)
      ? String((row.requestPayload as Record<string, unknown>).storyboardPanelModel ?? "").trim()
      : ""
  const initialStoryboardPanelPersonalPrompt =
    row.requestPayload && typeof row.requestPayload === "object" && !Array.isArray(row.requestPayload)
      ? String((row.requestPayload as Record<string, unknown>).storyboardPanelPersonalPrompt ?? "").trim()
      : ""
  const parsedEpisodeShots = parseQuickGenerateEpisodeShots(row.resultPayload, row.videoPromptPayload)
  const shots = await resolveStoryboardPanelImageUrls(parsedEpisodeShots.shots)
  const parseError = parsedEpisodeShots.parseError
  const promptPayloadRows =
    row.videoPromptPayload && typeof row.videoPromptPayload === "object" && !Array.isArray(row.videoPromptPayload)
      ? Array.isArray((row.videoPromptPayload as Record<string, unknown>).optimization_result)
        ? ((row.videoPromptPayload as Record<string, unknown>).optimization_result as unknown[])
        : []
      : []
  logger.info({
    event: "quick_generate_episode_page_prompt_payload_summary",
    module: "quick_generate",
    traceId: `episode-page:${episodeId}`,
    message: "剧集结果页读取视频提示词摘要",
    storyId,
    episodeId,
    promptPayloadRowCount: promptPayloadRows.length,
    parsedShotCount: shots.length,
    parseError,
    parsedRows: shots.slice(0, 10).map((shot) => ({
      shotNo: shot.shotNo,
      optimizedTextLength: shot.optimizedText.trim().length,
      optimizedTextSnippet: truncateForLog(shot.optimizedText, 100)
    }))
  })
  const videoResultsByShotNo = await resolveEpisodeShotVideoResults(row.videoResults)

  return (
    <QuickGenerateEpisodeResultPage
      storyId={storyId}
      storyTitle={row.storyTitle ?? ""}
      episodeId={row.id}
      episodeNo={row.episodeNo}
      episodeStatus={row.status}
      episodes={episodeTabRows as EpisodeTabView[]}
      shots={shots}
      videoResultsByShotNo={videoResultsByShotNo}
      parseError={parseError}
      jobId={safeJobId || null}
      roleOptions={roleOptions}
      sceneOptions={sceneOptions}
      itemOptions={itemOptions}
      audioOptions={audioOptions}
      videoOptions={videoOptions}
      roleVoiceMap={roleVoiceMap}
      materials={materialRows}
      storyAspectRatio={row.storyAspectRatio}
      storyResolution={row.storyResolution ?? undefined}
      initialDefaultVideoModel={initialDefaultVideoModel}
      initialDefaultStoryboardPanelModel={initialDefaultStoryboardPanelModel}
      initialStoryboardPanelPersonalPrompt={initialStoryboardPanelPersonalPrompt}
    />
  )
}
