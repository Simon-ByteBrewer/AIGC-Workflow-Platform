"use client"

import { useState, useRef, useEffect, type ReactElement } from "react"
import { Pencil } from "lucide-react"

export function InlineEdit({
  value,
  onSave,
  className,
  forceEdit,
  onCancelForceEdit
}: {
  value: string
  onSave: (val: string) => Promise<void> | void
  className?: string
  forceEdit?: boolean
  onCancelForceEdit?: () => void
}): ReactElement {
  const [editing, setEditing] = useState(false)
  const [current, setCurrent] = useState(value)
  const [saving, setSaving] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  // 内部维护强制编辑状态，当外部控制 forceEdit 开启时，忽略内部点击触发逻辑
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    setCurrent(value)
  }, [value])

  useEffect(() => {
    if (editing || forceEdit) {
      inputRef.current?.focus()
    }
  }, [editing, forceEdit])

  const handleSave = async () => {
    if (current.trim() === value || !current.trim()) {
      setCurrent(value)
      setEditing(false)
      onCancelForceEdit?.()
      return
    }
    try {
      setSaving(true)
      await onSave(current.trim())
      setEditing(false)
      onCancelForceEdit?.()
    } catch (err) {
      alert("保存失败")
      setCurrent(value)
    } finally {
      setSaving(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      void handleSave()
    } else if (e.key === "Escape") {
      setCurrent(value)
      setEditing(false)
      onCancelForceEdit?.()
    }
  }

  if (editing || forceEdit) {
    return (
      <input
        ref={inputRef}
        type="text"
        className={className}
        style={{
          background: "rgba(0,0,0,0.4)",
          border: "1px solid rgba(255,255,255,0.2)",
          color: "#fff",
          padding: "4px 8px", // 增加 padding 防误触
          borderRadius: "6px",
          outline: "none",
          width: "100%",
          fontSize: "14px",
          fontWeight: 600,
        }}
        value={current}
        onChange={(e) => setCurrent(e.target.value)}
        onBlur={() => void handleSave()}
        onKeyDown={handleKeyDown}
        disabled={saving}
        onClick={(e) => e.stopPropagation()} // 阻止事件冒泡，避免触发外层弹窗
      />
    )
  }

  return (
    <div
      className={className}
      style={{ display: "flex", alignItems: "center", gap: "6px", cursor: "pointer", padding: "4px 8px", margin: "-4px -8px", borderRadius: "6px", background: isHovered ? "rgba(255,255,255,0.06)" : "transparent", transition: "background 0.2s" }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={(e) => {
        e.stopPropagation() // 阻止事件冒泡，避免触发外层弹窗
        setEditing(true)
      }}
      title="点击修改名称"
    >
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{current}</span>
      <Pencil size={12} style={{ opacity: isHovered ? 0.8 : 0.4, flexShrink: 0, transition: "opacity 0.2s" }} />
    </div>
  )
}