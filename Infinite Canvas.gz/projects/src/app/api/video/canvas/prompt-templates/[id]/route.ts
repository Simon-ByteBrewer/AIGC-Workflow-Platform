import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { promptTemplates } from "@/shared/schema"

export const runtime = "nodejs"

const paramsSchema = z
  .object({
    id: z.string().trim().min(1).max(200)
  })
  .strict()

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ promptTemplates })

  const now = new Date()
  const updated = await db
    .update(promptTemplates)
    .set({ deletedAt: now, updatedAt: now })
    .where(and(eq(promptTemplates.id, parsedParams.data.id), eq(promptTemplates.userId, userId), eq(promptTemplates.type, "custom"), isNull(promptTemplates.deletedAt)))
    .returning({ id: promptTemplates.id })

  if (updated.length === 0) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "提示词不存在或已删除"), { status: 404 })

  return NextResponse.json(makeApiOk(traceId, { id: updated[0].id }), { status: 200 })
}

