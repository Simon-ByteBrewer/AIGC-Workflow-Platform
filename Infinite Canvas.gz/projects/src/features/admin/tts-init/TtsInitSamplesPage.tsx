"use client"

import Link from "next/link"
import { useCallback, useMemo, useState, type ReactElement } from "react"
import styles from "./TtsInitSamplesPage.module.css"

type InitSamplesResultItem = {
  speaker: string
  ok: boolean
  id?: string
  url?: string
  message?: string
}

type InitSamplesResponse = {
  ok?: boolean
  data?: {
    text?: string
    results?: InitSamplesResultItem[]
    total?: number
    offset?: number
    limit?: number
    nextOffset?: number
    hasMore?: boolean
    processedCount?: number
  }
  error?: { message?: string }
}

const BATCH_SIZE = 10

export function TtsInitSamplesPage(): ReactElement {
  const [running, setRunning] = useState(false)
  const [lastRunAt, setLastRunAt] = useState<number | null>(null)
  const [lastResult, setLastResult] = useState<InitSamplesResultItem[] | null>(null)
  const [lastText, setLastText] = useState<string>("")
  const [error, setError] = useState<string>("")
  const [progress, setProgress] = useState<{ processed: number; total: number }>({ processed: 0, total: 0 })

  const summary = useMemo(() => {
    const results = lastResult ?? []
    const successCount = results.filter((r) => r.ok).length
    const failCount = results.filter((r) => !r.ok).length
    return { successCount, failCount, total: results.length }
  }, [lastResult])

  const runInit = useCallback(async () => {
    if (running) return
    setRunning(true)
    setError("")
    setLastResult([])
    setLastText("")
    setProgress({ processed: 0, total: 0 })

    try {
      const aggregatedResults: InitSamplesResultItem[] = []
      let offset = 0
      let total = 0

      while (true) {
        const res = await fetch("/api/tts/init-samples", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ force: true, offset, limit: BATCH_SIZE })
        })
        const json = (await res.json().catch(() => ({}))) as InitSamplesResponse
        if (!res.ok || !json?.ok) {
          throw new Error(json?.error?.message || `第 ${Math.floor(offset / BATCH_SIZE) + 1} 批初始化失败`)
        }

        const batchResults = Array.isArray(json?.data?.results) ? json.data.results : []
        aggregatedResults.push(...batchResults)
        setLastResult([...aggregatedResults])
        setLastText(String(json?.data?.text ?? "").trim())

        total = Number(json?.data?.total ?? total ?? 0)
        const nextOffset = Number(json?.data?.nextOffset ?? (offset + batchResults.length))
        const processed = Math.min(aggregatedResults.length, total || aggregatedResults.length)
        setProgress({ processed, total: total || aggregatedResults.length })

        if (!json?.data?.hasMore || nextOffset <= offset) break
        offset = nextOffset
      }

      const successCount = aggregatedResults.filter((r) => r.ok).length
      if (successCount === 0) {
        throw new Error("音色初始化失败，未生成任何可用样音")
      }

      setProgress({ processed: aggregatedResults.length, total: total || aggregatedResults.length })
      setLastRunAt(Date.now())
    } catch (e) {
      const msg = (e as any)?.message || "初始化失败"
      setError(String(msg))
    } finally {
      setRunning(false)
    }
  }, [running])

  return (
    <main className={styles.page}>
      <div className={styles.topBar}>
        <div className={styles.topLeft}>
          <div className={styles.topTitle}>初始化音色</div>
          <div className={styles.topMeta}>
            按批生成/更新 TTS 音色样音并入库（强制覆盖）
            {" · "}
            当前样音文案：你好，这是我的音色
            {" · "}
            当前批大小：{BATCH_SIZE}
            {" · "}
            <Link className={styles.link} href="/admin">
              返回后台首页
            </Link>
          </div>
        </div>
        <div className={styles.topActions}>
          <button type="button" className={styles.topBtn} onClick={() => void runInit()} disabled={running}>
            {running ? "初始化中…" : "初始化音色"}
          </button>
        </div>
      </div>

      {error ? <div className={styles.error}>{error}</div> : null}

      <div className={styles.panel}>
        <div className={styles.panelHeader}>
          <div className={styles.panelTitle}>执行结果</div>
          <div className={styles.panelMeta}>
            {lastRunAt ? `最近一次：${new Date(lastRunAt).toLocaleString()}` : "未执行"}
          </div>
        </div>
        <div className={styles.panelBody}>
          {lastResult ? (
            <>
              <div className={styles.statGrid}>
                <div className={styles.stat}>
                  <div className={styles.statLabel}>进度</div>
                  <div className={styles.statVal}>
                    {progress.total > 0 ? `${progress.processed}/${progress.total}` : summary.total}
                  </div>
                </div>
                <div className={styles.stat}>
                  <div className={styles.statLabel}>成功</div>
                  <div className={styles.statVal}>{summary.successCount}</div>
                </div>
                <div className={styles.stat}>
                  <div className={styles.statLabel}>失败</div>
                  <div className={styles.statVal}>{summary.failCount}</div>
                </div>
              </div>
              {lastText ? <div className={styles.empty}>本次样音文案：{lastText}</div> : null}
              <pre className={styles.pre}>{JSON.stringify(lastResult, null, 2)}</pre>
            </>
          ) : (
            <div className={styles.empty}>点击右上角按钮开始初始化。</div>
          )}
        </div>
      </div>
    </main>
  )
}
