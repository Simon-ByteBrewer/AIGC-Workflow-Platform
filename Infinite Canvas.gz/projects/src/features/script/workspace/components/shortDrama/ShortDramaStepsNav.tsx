"use client"

import { type ReactNode, useMemo } from "react"
import styles from "./ShortDramaStepsNav.module.css"

export type ShortDramaStepKey = "planning" | "world" | "character"

type ShortDramaStepsNavProps = Readonly<{
  shortDrama: any
  active: ShortDramaStepKey
  onChange: (next: ShortDramaStepKey) => void
  extraItems?: ReactNode
  hideWorldSetting?: boolean
}>

export function ShortDramaStepsNav({ shortDrama, active, onChange, extraItems, hideWorldSetting }: ShortDramaStepsNavProps) {
  const shortDramaObj = shortDrama && typeof shortDrama === "object" ? (shortDrama as any) : {}
  const planningResult = shortDramaObj?.planningResult ?? null
  const worldSetting = shortDramaObj?.worldSetting ?? null
  const characterSetting = shortDramaObj?.characterSetting ?? null
  const roleImageDraws = shortDramaObj?.roleImageDraws ?? null
  const planningConfirmedAt = typeof shortDramaObj?.planningConfirmedAt === "number" ? shortDramaObj.planningConfirmedAt : null
  const confirmed = Boolean(typeof planningConfirmedAt === "number" || (planningResult && worldSetting && characterSetting))
  const roleAssetsConfirmed = useMemo(() => {
    const base = roleImageDraws && typeof roleImageDraws === "object" && !Array.isArray(roleImageDraws) ? (roleImageDraws as any) : null
    if (!base) return false

    let inner = characterSetting
    if (inner && typeof inner === "object" && !Array.isArray(inner)) {
      if ((inner as any).character_settings) inner = (inner as any).character_settings
      else if ((inner as any).character_setting) inner = (inner as any).character_setting
    }
    if (typeof inner === "string") {
      try { inner = JSON.parse(inner) } catch {}
    }
    const characters = inner && typeof inner === "object" && Array.isArray((inner as any).characters) ? (inner as any).characters : []

    const checkValue = (v: any) => {
      if (!v || typeof v !== "object" || Array.isArray(v)) return false
      const selectedUrl = typeof (v as any).selectedUrl === "string" ? (v as any).selectedUrl.trim() : ""
      if (selectedUrl) return true

      const assetSelection = (v as any).assetSelection
      if (assetSelection && typeof assetSelection === "object") {
        const characterId = typeof (assetSelection as any).characterId === "string" ? (assetSelection as any).characterId.trim() : ""
        const lookId = typeof (assetSelection as any).lookId === "string" ? (assetSelection as any).lookId.trim() : ""
        const costumeId = typeof (assetSelection as any).costumeId === "string" ? (assetSelection as any).costumeId.trim() : ""
        const lookIdByVariant = (assetSelection as any).lookIdByVariant
        const costumeIdByVariant = (assetSelection as any).costumeIdByVariant
        const selectedLookCandidateKeyByVariant = (assetSelection as any).selectedLookCandidateKeyByVariant
        const selectedCostumeCandidateKeyByVariant = (assetSelection as any).selectedCostumeCandidateKeyByVariant
        const hasLookVariant = lookIdByVariant && typeof lookIdByVariant === "object" && Object.keys(lookIdByVariant).length > 0
        const hasCostumeVariant = costumeIdByVariant && typeof costumeIdByVariant === "object" && Object.keys(costumeIdByVariant).length > 0
        const hasSelectedLook = selectedLookCandidateKeyByVariant && typeof selectedLookCandidateKeyByVariant === "object" && Object.keys(selectedLookCandidateKeyByVariant).length > 0
        const hasSelectedCostume = selectedCostumeCandidateKeyByVariant && typeof selectedCostumeCandidateKeyByVariant === "object" && Object.keys(selectedCostumeCandidateKeyByVariant).length > 0
        if (characterId || lookId || costumeId || hasLookVariant || hasCostumeVariant || hasSelectedLook || hasSelectedCostume) return true
      }

      const assetSelectionByFrontImageUrl = (v as any).assetSelectionByFrontImageUrl
      if (assetSelectionByFrontImageUrl && typeof assetSelectionByFrontImageUrl === "object") {
        const keys = Object.keys(assetSelectionByFrontImageUrl)
        if (keys.length > 0) return true
      }

      return false
    }

    if (characters.length > 0) {
      return characters.every((c: any, idx: number) => {
        const id = typeof c?.character_id === "string" ? c.character_id.trim() : ""
        const name = typeof c?.character_name === "string" ? c.character_name.trim() : ""
        const key = id || name || `角色${idx + 1}`
        const dispName = name || `角色${idx + 1}`
        const a = base[key]
        const b = base[dispName]
        const v = (a && typeof a === "object" ? a : null) || (b && typeof b === "object" ? b : null)
        return checkValue(v)
      })
    }

    const values = Object.values(base).filter((v) => v && typeof v === "object" && !Array.isArray(v)) as any[]
    if (values.length === 0) return false
    return values.every(checkValue)
  }, [roleImageDraws, characterSetting])

  const steps = useMemo(() => {
    const hasPlanning = Boolean(planningResult)
    const hasWorld = confirmed && Boolean(worldSetting)
    const hasCharacter = confirmed && Boolean(characterSetting)
    const base = [
      {
        key: "planning" as const,
        title: "剧本策划",
        desc: "前置条件",
        badge: hasPlanning ? (confirmed ? "已确认" : "未确认") : "未生成"
      },
      {
        key: "character" as const,
        title: "角色设定",
        desc: "基于策划并行",
        badge: !confirmed ? "待确认" : hasCharacter ? (roleAssetsConfirmed ? "已生成" : "待选择") : "未生成"
      }
    ]
    if (hideWorldSetting) return base
    return [
      base[0],
      {
        key: "world" as const,
        title: "世界观设定",
        desc: "基于策划并行",
        badge: !confirmed ? "待确认" : hasWorld ? "已生成" : "未生成"
      },
      base[1]
    ]
  }, [characterSetting, confirmed, hideWorldSetting, planningResult, roleAssetsConfirmed, worldSetting])

  return (
    <div className={styles.nav} aria-label="短剧步骤">
      {steps.map((s) => (
        <button
          key={s.key}
          type="button"
          className={active === s.key ? `${styles.navItem} ${styles.navItemActive}` : styles.navItem}
          onClick={() => onChange(s.key)}
        >
          <div className={styles.navRow}>
            <div className={styles.navTitle}>{s.title}</div>
            <div
              className={
                s.badge === "已确认" || s.badge === "已生成"
                  ? styles.badgeOk
                  : s.badge === "待选择"
                    ? styles.badgeWarn
                    : styles.badgeMuted
              }
            >
              {s.badge}
            </div>
          </div>
          <div className={styles.navDesc}>{s.desc}</div>
        </button>
      ))}
      {extraItems}
    </div>
  )
}
