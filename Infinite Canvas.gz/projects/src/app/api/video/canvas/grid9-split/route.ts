import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { generatedImages, publicResources, sharedResources, stories, videoCanvasAssets } from "@/shared/schema"
import { enqueueCanvasGrid9SplitJob } from "@/server/domains/video/canvas/jobs/canvasGrid9SplitWorker"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const SOURCE_PARSE_FAILED_MESSAGE = "无法解析图片来源"

const bodySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200),
    outlineId: z.string().trim().min(1).max(200),
    nodeId: z.string().trim().min(1).max(200),
    imageUrl: z.string().trim().min(1).max(4000),
    assetId: z.string().trim().min(1).max(2000).optional()
  })
  .strict()

function extractGeneratedImageIdFromUrl(rawUrl: string): string {
  try {
    const u = new URL(rawUrl, "http://local")
    const match = u.pathname.match(/^\/api\/video-creation\/images\/file\/([^/]+)$/)
    if (!match) return ""
    return decodeURIComponent(match[1] ?? "")
  } catch {
    return ""
  }
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  logger.info({
    event: "canvas_api_request",
    module: "video/canvas",
    traceId,
    message: "POST /api/video/canvas/grid9-split",
    body: parsed.data
  })

  await ensurePublicSchema()
  const db = await getDb({ stories, generatedImages })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

  const imageUrl = parsed.data.imageUrl.trim()
  const assetId = typeof parsed.data.assetId === "string" ? parsed.data.assetId.trim() : ""
  const generatedId = extractGeneratedImageIdFromUrl(imageUrl)
  let sourceStorageKey: string | undefined
  let sourceUrl: string | undefined
  const storage = getS3Storage()

  if (generatedId) {
    const rows = await db
      .select({ id: generatedImages.id, storageKey: generatedImages.storageKey })
      .from(generatedImages)
      .innerJoin(stories, eq(generatedImages.storyId, stories.id))
      .where(
        and(
          eq(generatedImages.id, generatedId),
          eq(generatedImages.storyId, parsed.data.storyId),
          eq(stories.userId, userId),
          isNull(generatedImages.deletedAt)
        )
      )
      .limit(1)
    const row = rows[0]
    if (!row?.storageKey) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "图片资源不存在或不可访问"), { status: 404 })
    sourceStorageKey = row.storageKey
  } else {
    if (assetId.startsWith("canvas:")) {
      const id = assetId.slice("canvas:".length).trim()
      const rows = await db
        .select({ storageKey: videoCanvasAssets.storageKey, previewStorageKey: videoCanvasAssets.previewStorageKey, kind: videoCanvasAssets.kind })
        .from(videoCanvasAssets)
        .where(and(eq(videoCanvasAssets.id, id), eq(videoCanvasAssets.storyId, parsed.data.storyId)))
        .limit(1)
      const row = rows[0] ?? null
      if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "图片资源不存在或不可访问"), { status: 404 })
      if (String(row.kind ?? "").trim() !== "image") {
        return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "仅支持图片资源"), { status: 400 })
      }
      const key = String(row.storageKey ?? row.previewStorageKey ?? "").trim()
      if (!key) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
      sourceUrl = await resolveStorageUrl(storage, key).catch(() => "")
      if (!sourceUrl) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
    } else if (assetId.startsWith("library:")) {
      const id = assetId.slice("library:".length).trim()
      const rows = await db
        .select({ userId: publicResources.userId, originalStorageKey: publicResources.originalStorageKey, previewStorageKey: publicResources.previewStorageKey })
        .from(publicResources)
        .where(and(eq(publicResources.id, id), eq(publicResources.userId, userId)))
        .limit(1)
      const row = rows[0] ?? null
      if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "图片资源不存在或不可访问"), { status: 404 })
      const key = String(row.originalStorageKey ?? row.previewStorageKey ?? "").trim()
      if (!key) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
      sourceUrl = await resolveStorageUrl(storage, key).catch(() => "")
      if (!sourceUrl) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
    } else if (assetId.startsWith("shared:")) {
      const id = assetId.slice("shared:".length).trim()
      const rows = await db
        .select({ originalStorageKey: sharedResources.originalStorageKey, previewStorageKey: sharedResources.previewStorageKey })
        .from(sharedResources)
        .where(and(eq(sharedResources.id, id)))
        .limit(1)
      const row = rows[0] ?? null
      if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "图片资源不存在或不可访问"), { status: 404 })
      const key = String(row.originalStorageKey ?? row.previewStorageKey ?? "").trim()
      if (!key) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
      sourceUrl = await resolveStorageUrl(storage, key).catch(() => "")
      if (!sourceUrl) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
    } else {
      const libMatch = imageUrl.match(/\/api\/library\/public-resources\/file\/([^/?#]+)(?:\?|$)/u)
      const sharedMatch = imageUrl.match(/\/api\/library\/shared-resources\/file\/([^/?#]+)(?:\?|$)/u)
      if (libMatch?.[1]) {
        const id = (() => {
          try {
            return decodeURIComponent(String(libMatch[1]))
          } catch {
            return String(libMatch[1])
          }
        })()
        const rows = await db
          .select({ userId: publicResources.userId, originalStorageKey: publicResources.originalStorageKey, previewStorageKey: publicResources.previewStorageKey })
          .from(publicResources)
          .where(and(eq(publicResources.id, id), eq(publicResources.userId, userId)))
          .limit(1)
        const row = rows[0] ?? null
        if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "图片资源不存在或不可访问"), { status: 404 })
        const key = String(row.originalStorageKey ?? row.previewStorageKey ?? "").trim()
        if (!key) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
        sourceUrl = await resolveStorageUrl(storage, key).catch(() => "")
        if (!sourceUrl) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
      } else if (sharedMatch?.[1]) {
        const id = (() => {
          try {
            return decodeURIComponent(String(sharedMatch[1]))
          } catch {
            return String(sharedMatch[1])
          }
        })()
        const rows = await db
          .select({ originalStorageKey: sharedResources.originalStorageKey, previewStorageKey: sharedResources.previewStorageKey })
          .from(sharedResources)
          .where(and(eq(sharedResources.id, id)))
          .limit(1)
        const row = rows[0] ?? null
        if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "图片资源不存在或不可访问"), { status: 404 })
        const key = String(row.originalStorageKey ?? row.previewStorageKey ?? "").trim()
        if (!key) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
        sourceUrl = await resolveStorageUrl(storage, key).catch(() => "")
        if (!sourceUrl) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
      } else {
        if (!imageUrl.startsWith("http")) {
          return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", SOURCE_PARSE_FAILED_MESSAGE), { status: 400 })
        }
        sourceUrl = imageUrl
      }
    }
  }

  const { jobId, snapshot } = await enqueueCanvasGrid9SplitJob({
    userId,
    traceId,
    storyId: parsed.data.storyId,
    outlineId: parsed.data.outlineId,
    nodeId: parsed.data.nodeId,
    sourceUrl,
    sourceStorageKey
  })

  kickAllWorkers()
  logger.info({
    event: "canvas_api_response",
    module: "video/canvas",
    traceId,
    message: "POST /api/video/canvas/grid9-split accepted",
    jobId
  })
  return NextResponse.json(makeApiOk(traceId, { jobId, snapshot }), { status: 202 })
}
