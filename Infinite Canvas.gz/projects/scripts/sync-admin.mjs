import { Client } from "pg"

const oldUrl = process.env.OLD_PGDATABASE_URL
const newUrl = process.env.PGDATABASE_URL || process.env.DATABASE_URL || process.env.POSTGRES_URL

if (!oldUrl || !newUrl) {
  throw new Error("Missing OLD_PGDATABASE_URL or PGDATABASE_URL")
}

const oldClient = new Client({ connectionString: oldUrl })
const newClient = new Client({ connectionString: newUrl })

const adminUsersQuery =
  "SELECT u.id, u.name, u.email, u.is_active, u.metadata, u.created_at, u.updated_at, u.password FROM users u JOIN user_security s ON s.user_id = u.id WHERE s.role_key = 'admin'"
const adminSecurityQuery =
  "SELECT s.user_id, s.role_key, s.token_version, s.last_login_at, s.password_updated_at, s.failed_login_count, s.locked_until, s.disabled_at, s.disabled_reason, s.created_at, s.updated_at FROM user_security s WHERE s.role_key = 'admin'"

const buildValues = (rows, columns, offset = 0) => {
  const values = []
  const params = rows.flatMap((row) => {
    return columns.map((column) => {
      values.push(row[column])
      return `$${values.length + offset}`
    })
  })
  return { values, params }
}

const run = async () => {
  await oldClient.connect()
  await newClient.connect()

  const adminUsers = await oldClient.query(adminUsersQuery)
  const adminSecurity = await oldClient.query(adminSecurityQuery)

  if (adminUsers.rows.length === 0) {
    await oldClient.end()
    await newClient.end()
    console.log("No admin users found in source database.")
    return
  }

  await newClient.query("BEGIN")

  const userColumns = [
    "id",
    "name",
    "email",
    "is_active",
    "metadata",
    "created_at",
    "updated_at",
    "password"
  ]
  const securityColumns = [
    "user_id",
    "role_key",
    "token_version",
    "last_login_at",
    "password_updated_at",
    "failed_login_count",
    "locked_until",
    "disabled_at",
    "disabled_reason",
    "created_at",
    "updated_at"
  ]

  const { values: userValues, params: userParams } = buildValues(adminUsers.rows, userColumns)
  const usersValuesSql = adminUsers.rows
    .map((_, index) => {
      const start = index * userColumns.length
      const placeholders = userColumns.map((_, colIndex) => userParams[start + colIndex])
      return `(${placeholders.join(", ")})`
    })
    .join(", ")

  const usersSql = `
    INSERT INTO users (${userColumns.join(", ")})
    VALUES ${usersValuesSql}
    ON CONFLICT (id) DO UPDATE SET
      name = EXCLUDED.name,
      email = EXCLUDED.email,
      is_active = EXCLUDED.is_active,
      metadata = EXCLUDED.metadata,
      updated_at = EXCLUDED.updated_at,
      password = EXCLUDED.password
  `

  await newClient.query(usersSql, userValues)

  const { values: securityValues, params: securityParams } = buildValues(
    adminSecurity.rows,
    securityColumns
  )
  const securityValuesSql = adminSecurity.rows
    .map((_, index) => {
      const start = index * securityColumns.length
      const placeholders = securityColumns.map((_, colIndex) => securityParams[start + colIndex])
      return `(${placeholders.join(", ")})`
    })
    .join(", ")

  const securitySql = `
    INSERT INTO user_security (${securityColumns.join(", ")})
    VALUES ${securityValuesSql}
    ON CONFLICT (user_id) DO UPDATE SET
      role_key = EXCLUDED.role_key,
      token_version = EXCLUDED.token_version,
      last_login_at = EXCLUDED.last_login_at,
      password_updated_at = EXCLUDED.password_updated_at,
      failed_login_count = EXCLUDED.failed_login_count,
      locked_until = EXCLUDED.locked_until,
      disabled_at = EXCLUDED.disabled_at,
      disabled_reason = EXCLUDED.disabled_reason,
      updated_at = EXCLUDED.updated_at
  `

  await newClient.query(securitySql, securityValues)
  await newClient.query("COMMIT")

  await oldClient.end()
  await newClient.end()

  console.log(
    `Synced ${adminUsers.rows.length} admin user(s) and ${adminSecurity.rows.length} security record(s).`
  )
}

run().catch(async (error) => {
  try {
    await newClient.query("ROLLBACK")
  } catch {}
  try {
    await oldClient.end()
  } catch {}
  try {
    await newClient.end()
  } catch {}
  console.error(error)
  process.exit(1)
})
