import { createHash } from "crypto"
import { and, eq, sql } from "drizzle-orm"
import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { ensureJobsTable } from "@/server/db/ensureJobsTable"
import { getDb } from "@/server/db/getDb"
import { listEnabledImageModelsForUser, normalizeImageModelKind } from "@/server/domains/image/imageModelResolver"
import { enqueueShortDramaRoleImageDrawJob, kickShortDramaRoleImageDrawWorker } from "@/server/domains/short-drama/jobs/shortDramaRoleImageDrawWorker"
import { createStartedJobEventStreamResponse } from "@/server/framework/jobs/createStartedJobEventStreamResponse"
import { stories } from "@/shared/schema"
import { jobs } from "@/shared/schema/jobs"
import { SHORT_DRAMA_ROLE_IMAGE_DRAW_JOB_TYPE } from "@/shared/jobs/jobTypes"

export const runtime = "nodejs"

const promptItemSchema = z.object({
  key: z.string().trim().min(1).max(200),
  name: z.string().trim().min(1).max(200),
  prompt: z.string().trim().min(1).max(50_000)
})

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  mode: z.union([z.literal("all"), z.literal("one")]),
  forceRegenerate: z.boolean(),
  drawCount: z.number().int().min(1).max(5),
  modelKind: z.union([z.literal("internal"), z.literal("external")]).optional(),
  modelName: z.string().trim().min(1).max(100).optional(),
  style: z.string().trim().max(200).optional(),
  requestKey: z.string().trim().min(1).max(200).optional(),
  prompts: z.array(promptItemSchema).min(1).max(50)
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  await ensureJobsTable()
  const db = await getDb({ stories, jobs })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const modelOptions = await listEnabledImageModelsForUser(userId)
  if (modelOptions.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号未配置可用的图片模型"), { status: 400 })
  }
  const normalizedModelKind = normalizeImageModelKind(parsed.data.modelKind)
  const selectedModelByInput = String(parsed.data.modelName ?? "").trim()
  const matchedByKind = modelOptions.filter((item) => item.kind === normalizedModelKind)
  if (matchedByKind.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", `当前账号没有可用的${normalizedModelKind === "external" ? "外部" : "内部"}图片模型`), {
      status: 400
    })
  }
  const selectedModel = matchedByKind.find((item) => item.modelName === selectedModelByInput)?.modelName ?? matchedByKind[0]!.modelName

  const reqKey =
    (parsed.data.requestKey ?? "").trim() ||
    `sd_role_image:${createHash("sha1")
      .update(
        JSON.stringify({
          storyId: parsed.data.storyId,
          mode: parsed.data.mode,
          modelKind: normalizedModelKind,
          modelName: selectedModel,
          forceRegenerate: parsed.data.forceRegenerate,
          drawCount: parsed.data.drawCount,
          prompts: parsed.data.prompts.map((p) => ({ key: p.key, prompt: p.prompt }))
        })
      )
      .digest("hex")
      .slice(0, 16)}`

  return createStartedJobEventStreamResponse({
    req,
    traceId,
    userId,
    startJob: async () => {
      const existed = await db
        .select({ id: jobs.id })
        .from(jobs)
        .where(
          and(
            eq(jobs.userId, userId),
            eq(jobs.storyId, parsed.data.storyId),
            eq(jobs.type, SHORT_DRAMA_ROLE_IMAGE_DRAW_JOB_TYPE),
            sql`${jobs.status} in ('queued','running')`,
            sql`${jobs.payload} ->> 'requestKey' = ${reqKey}`
          )
        )
        .limit(1)
      const existedId = String(existed[0]?.id ?? "").trim()
      if (existedId) {
        kickShortDramaRoleImageDrawWorker()
        return { jobId: existedId }
      }

      const { jobId } = await enqueueShortDramaRoleImageDrawJob({
        userId,
        traceId,
        storyId: parsed.data.storyId,
        mode: parsed.data.mode,
        forceRegenerate: parsed.data.forceRegenerate,
        drawCount: parsed.data.drawCount,
        modelKind: normalizedModelKind,
        modelName: selectedModel,
        style: parsed.data.style,
        requestKey: reqKey,
        prompts: parsed.data.prompts
      })
      kickShortDramaRoleImageDrawWorker()
      return { jobId }
    }
  })
}
