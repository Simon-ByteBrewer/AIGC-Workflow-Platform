import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getBillingByTaskId } from "@/server/domains/admin/billingAdmin"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"

export const runtime = "nodejs"

const querySchema = z.object({
  taskId: z.string().trim().min(1),
  from: z.string().trim().optional(),
  to: z.string().trim().optional(),
  groupId: z.string().trim().optional(),
  userId: z.string().trim().optional(),
  modelName: z.string().trim().optional(),
  requestType: z.string().trim().optional(),
  referenceMode: z.enum(["all", "with", "without"]).optional(),
  videoResolution: z.enum(["1080p", "480p/720p"]).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const startedAt = Date.now()
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    const parsed = querySchema.safeParse(Object.fromEntries(new URL(req.url).searchParams.entries()))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    const data = await getBillingByTaskId(actor, parsed.data.taskId, parsed.data)
    logger.info({
      module: "admin/billing-api",
      event: "billing_task_request_success",
      traceId,
      message: "任务账单查询成功",
      actorUserId: actor.userId,
      actorRoleKey: actor.roleKey,
      taskId: parsed.data.taskId,
      durationMs: Date.now() - startedAt,
      resultSummary: { mode: data.mode, items: data.items.length, completedTasks: data.completedTaskCount, taskStatus: data.taskStatus }
    } as any)
    return NextResponse.json(makeApiOk(traceId, data), { status: 200 })
  } catch (error: any) {
    logger.error({
      module: "admin/billing-api",
      event: "billing_task_request_failed",
      traceId,
      message: "任务账单查询失败",
      durationMs: Date.now() - startedAt,
      errorName: error?.name,
      errorMessage: error?.message ?? "unknown",
      stack: error?.stack
    } as any)
    return NextResponse.json(makeApiErr(traceId, "BILLING_TASK_FAILED", error?.message ?? "查询任务账单失败"), { status: 500 })
  }
}
