import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { eq } from "drizzle-orm"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ttsSpeakerSamples } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

async function resolveSampleRedirect(req: NextRequest, ctx: { params: Promise<{ id: string }> }, method: "GET" | "HEAD"): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsed = paramsSchema.safeParse(rawParams)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const db = await getDb({ ttsSpeakerSamples })
  const rows = await db
    .select({ storageKey: ttsSpeakerSamples.storageKey, url: ttsSpeakerSamples.url })
    .from(ttsSpeakerSamples)
    .where(eq(ttsSpeakerSamples.id, parsed.data.id))
    .limit(1)

  const row = rows[0]
  if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "音色样音不存在"), { status: 404 })

  const storageKey = row.storageKey
  const fallbackUrl = row.url
  // #region debug-point D:file-route-hit
  fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId:"pre-fix",hypothesisId:"D",location:"src/app/api/tts/speakers/file/[id]/route.ts:42",msg:"[DEBUG] tts sample file route resolved row",data:{sampleId:parsed.data.id,hasStorageKey:Boolean(storageKey),hasFallbackUrl:Boolean(fallbackUrl),method},traceId,ts:Date.now()})}).catch(()=>{})
  // #endregion
  if (!storageKey) {
    if (!fallbackUrl) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "样音链接不存在"), { status: 404 })
    return NextResponse.redirect(fallbackUrl, { status: method === "HEAD" ? 302 : 307 })
  }

  const storage = getS3Storage()
  try {
    const url = await resolveStorageUrl(storage, storageKey)
    // #region debug-point D:file-route-redirect
    fetch("http://127.0.0.1:7777/event",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({sessionId:"quick-generate-voice-silence",runId:"pre-fix",hypothesisId:"D",location:"src/app/api/tts/speakers/file/[id]/route.ts:52",msg:"[DEBUG] tts sample file route redirecting to storage",data:{sampleId:parsed.data.id,method,redirectHost:(()=>{try{return new URL(url).host}catch{return""}})(),redirectPath:(()=>{try{return new URL(url).pathname}catch{return""}})()},traceId,ts:Date.now()})}).catch(()=>{})
    // #endregion
    return NextResponse.redirect(url, { status: method === "HEAD" ? 302 : 307 })
  } catch {
    if (!fallbackUrl) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "样音链接不存在"), { status: 404 })
    return NextResponse.redirect(fallbackUrl, { status: method === "HEAD" ? 302 : 307 })
  }
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  return resolveSampleRedirect(req, ctx, "GET")
}

export async function HEAD(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  return resolveSampleRedirect(req, ctx, "HEAD")
}
