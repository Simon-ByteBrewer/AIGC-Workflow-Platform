import { Suspense, type ReactElement } from "react"
import { StoryboardStageClient } from "../StoryboardStageClient"

export const dynamic = "force-dynamic"

export default async function Page({
  searchParams
}: {
  searchParams:
    | Record<string, string | string[] | undefined>
    | Promise<Record<string, string | string[] | undefined>>
}): Promise<ReactElement> {
  const resolved = await Promise.resolve(searchParams)
  const storyIdRaw = resolved.storyId
  const storyId = Array.isArray(storyIdRaw) ? storyIdRaw[0] : storyIdRaw
  const outlineIdRaw = resolved.outlineId
  const outlineId = Array.isArray(outlineIdRaw) ? outlineIdRaw[0] : outlineIdRaw

  return (
    <Suspense fallback={null}>
      <StoryboardStageClient stage="frames" initialStoryId={storyId} initialOutlineId={outlineId} />
    </Suspense>
  )
}

