# `stream_run` 流式工作流接入说明

## 1. 文档目的

本文档整理当前项目中 `stream_run` 类工作流的统一调用方式，供后续图片生成、文本生成、素材规划等长耗时工作流复用。

重点说明：

- 什么时候使用 `stream_run`
- 请求头和请求体如何组织
- `text/event-stream` 如何解析
- 如何从 `workflow_end` 中拿到最终结果
- 当前项目已有的可复用实现在哪里

本文档只总结当前仓库已经采用的实现方式，不新增第三套协议或解析规则。

## 2. 适用场景

当工作流执行耗时较长、普通一次性 JSON 返回容易超时时，优先使用 `stream_run`。

典型场景：

- 外部图片模型生成图片
- 长耗时文本生成
- 多节点工作流编排

核心原则：

- 请求 body 通常不需要因为“是否流式”而重构
- 改的是“响应接收方式”，不是业务字段含义
- 最终业务结果一般仍然是一个 JSON，只是被包在流式事件里返回

## 3. 请求约定

### 3.1 请求方法

- HTTP 方法：`POST`
- 请求体类型：`application/json`

### 3.2 请求头

调用 `stream_run` 时，至少保证以下请求头：

```http
Content-Type: application/json
Accept: text/event-stream
Authorization: Bearer <token>
```

说明：

- `Accept: text/event-stream` 用于告诉服务端当前客户端按 SSE 接收响应
- `Authorization` 是否需要，取决于具体工作流
- 不要把敏感 token 写进日志或文档示例

### 3.3 请求体

请求体由具体业务工作流决定，不因为切换到流式就改字段语义。

例如外部图片工作流的请求体仍然是：

```json
{
  "prompt": "生成提示词",
  "model": "gpt-image-2",
  "model_apikey": "<redacted>",
  "images": ["https://example.com/a.png"],
  "background": "auto",
  "n": 1,
  "output_format": "png",
  "quality": "auto",
  "size": "3648x2048",
  "stream": false
}
```

注意：

- `stream_run` 是否返回 SSE，由接口能力和请求头决定
- 不要把业务字段 `stream` 直接等同于“本次是否走流式解析”

## 4. 响应格式

`stream_run` 返回 `text/event-stream`，每一帧通常由若干行组成，常见结构如下：

```text
id: 0
event: message
data: {"data":{"type":"workflow_start","timestamp":1770110599741,"log_id":"xxx","run_id":"xxx"}}

id: 1
event: message
data: {"data":{"type":"node_end","node_name":"图片生成","output":{"image_url":"https://example.com/result.png"}}}

id: 2
event: message
data: {"data":{"type":"workflow_end","output":{"image_url":"https://example.com/result.png"}}}
```

项目当前按 SSE 标准方式解析：

- 使用空行分帧
- 每帧读取 `event:`、`id:`、`data:`
- `data:` 解析为 JSON
- 再从 JSON 中拿 `data.type`

## 5. 事件类型约定

当前项目重点关心以下事件：

| 事件类型 | 用途 | 是否作为最终结果 |
| --- | --- | --- |
| `workflow_start` | 工作流开始，记录 `run_id` / `log_id` | 否 |
| `node_start` | 节点开始执行，通常用于日志 | 否 |
| `node_end` | 节点结束，可用于调试节点输出 | 否 |
| `ping` | 心跳事件 | 否 |
| `error` | 工作流执行失败 | 否，直接报错 |
| `workflow_end` | 工作流完成 | 是 |

统一原则：

- `ping` 直接忽略
- `error` 立即中断并返回失败
- 最终结果优先从 `workflow_end.output` 获取

## 6. 当前项目的统一解析器

项目已经有统一的流式解析器：

- [cozeStreamRunClient.ts](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/src/server/integrations/coze/cozeStreamRunClient.ts)

核心入口：

- [readCozeStreamRunOutput](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/src/server/integrations/coze/cozeStreamRunClient.ts#L73-L193)

该方法负责：

- 读取 `Response.body`
- 按 `\n\n` 分割 SSE 帧
- 解析 `data:` 对应 JSON
- 识别 `workflow_end`
- 识别 `error`
- 返回统一结果：

```ts
{ ok: true, output: unknown }
```

或

```ts
{ ok: false, message: string }
```

建议：

- 新的 `stream_run` 工作流优先复用这个方法
- 不要为每个新工作流重复手写一套 SSE 解析器

## 7. 统一解析流程

推荐接法如下：

1. 发起 `fetch`
2. 检查 `content-type`
3. 若包含 `text/event-stream`，则调用 `readCozeStreamRunOutput(...)`
4. 从返回值中取 `output`
5. 若 `output` 是 JSON 字符串，再 `JSON.parse` 一次
6. 再按业务类型提取最终字段

参考代码：

```ts
const res = await fetch(apiUrl, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Accept: "text/event-stream",
    ...(token ? { Authorization: `Bearer ${token}` } : {})
  },
  body: JSON.stringify(request),
  signal: controller.signal
})

const ctype = (res.headers.get("content-type") ?? "").toLowerCase()
const rawOutput = ctype.includes("text/event-stream")
  ? await readCozeStreamRunOutput({ traceId, module: "your-module", apiUrl, res })
  : await res.json()
```

## 8. 最终结果提取

流式解析器只负责拿到 `workflow_end.output`，真正业务结果字段可能因工作流不同而变化。

### 8.1 图片工作流

图片工作流当前使用递归提图逻辑，参考：

- [extractImageUrlsFromCozeRes](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/src/server/domains/video/canvas/jobs/canvasImageGenerateWorker.ts#L226-L284)

该逻辑会递归尝试从这些常见字段中提取 URL：

- `image_url`
- `image_urls`
- `url`
- `urls`
- `data`
- `response`
- `result`
- `output`

### 8.2 文本或结构化工作流

对于非图片工作流，建议直接处理 `workflow_end.output`：

- 若是对象，直接读业务字段
- 若是字符串且看起来像 JSON，先 `JSON.parse`
- 若最终结构不稳定，先打印摘要日志，再补业务层适配

## 9. 外部图片工作流示例

当前画布 external 图片工作流已接入这套方式，参考：

- [callExternalCanvasImageGenerate](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/src/server/domains/video/canvas/jobs/canvasImageGenerateWorker.ts#L394-L478)

它的实现要点：

- 请求头增加 `Accept: text/event-stream`
- 响应为 `text/event-stream` 时复用 `readCozeStreamRunOutput(...)`
- `workflow_end.output` 若是字符串则尝试 `JSON.parse`
- 最终通过 `extractImageUrlsFromCozeRes(...)` 提取图片 URL

这条实现同时适用于：

- 普通 external 生图节点
- 360 相机使用 external 图片模型的情况

## 10. 图片输入约束

对图片类 external 工作流，输入图片必须满足“外部服务可访问”。

当前项目已有的处理原则：

- 直接的 `http(s)` URL 可以直接传
- 内部文件路由需要先解析成真实可访问 URL
- 不要直接把站内相对路径 `/api/...` 原样发给外部服务
- 生图场景不要传 `asset://...`

现有可参考逻辑：

- [imageCompositionService.ts](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/src/server/domains/video-creation/services/imageCompositionService.ts)
- [canvasImageGenerateWorker.ts](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/src/server/domains/video/canvas/jobs/canvasImageGenerateWorker.ts)

## 11. 日志建议

接入新的 `stream_run` 工作流时，至少记录以下日志节点：

- 请求开始
- `workflow_end`
- `error`
- 超时
- 最终结果提取成功或失败

当前项目已有的关键日志事件可参考：

- `coze_stream_run_end`
- `coze_stream_run_error`
- `coze_stream_run_unfinished`

日志要求：

- 记录 `traceId`
- 记录 `apiUrl`
- 记录耗时
- 日志里对长文本做截断
- 不记录敏感 token、apikey

## 12. 常见坑

- 不要把业务字段 `stream` 当成是否采用 SSE 的唯一依据
- 不要对 `text/event-stream` 直接使用 `res.json()`
- 不要把 `node_end` 当成最终结果，优先等 `workflow_end`
- 不要把相对路径图片地址直接发给外部工作流
- 不要为每个模块再复制一套 SSE 解析代码

## 13. 推荐接入清单

新增 `stream_run` 工作流时，按下面清单自检：

- 接口地址是否为 `.../stream_run`
- 请求头是否包含 `Accept: text/event-stream`
- 是否复用 `readCozeStreamRunOutput(...)`
- 是否正确处理 `error` / `workflow_end`
- 是否有最终结果字段提取逻辑
- 图片输入是否已转换为外部可访问 URL
- 日志是否包含 `traceId`、耗时和失败原因

## 14. 结论

当前项目对 `stream_run` 的统一思路是：

- 保持业务请求体稳定
- 用统一 SSE 解析器读取响应
- 从 `workflow_end.output` 取最终结果
- 再由业务层做结果字段提取

后续新工作流若需要接入流式返回，优先复用现有实现，不再重复发明解析方式。
