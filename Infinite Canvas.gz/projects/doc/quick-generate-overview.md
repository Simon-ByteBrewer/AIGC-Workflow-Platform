# 快速生成功能说明

## 1. 文档目的

本文档只说明当前仓库内已经落地的“新建剧本 -> 快速生成”功能链路，重点包括：

- 入口位置
- 页面结构
- 功能模块
- 异步任务机制

本文档不展开接口字段，接口参数请查看：

- [quick-generate-api.md](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/doc/quick-generate-api.md)

## 2. 链路入口

### 2.1 新建剧本入口

- 页面入口：`/script/workspace`
- 入口组件：`src/features/script/workspace/ScriptWorkspaceLanding.tsx`
- 弹窗组件：`src/features/script/workspace/components/ScriptCreationDialog.tsx`

当前“新建剧本”面板中包含多个入口，其中一个是“快速生成”：

- 卡片标题：`快速生成`
- 适用场景：先创建项目，后续再补充剧情与设定
- 打开后进入 `ScriptCreationDialog` 的 `quick` 模式

### 2.2 快速生成创建链路

用户点击“快速生成”后，当前链路如下：

1. 在 `ScriptCreationDialog` 中填写项目基础信息：
   - 故事标题
   - 视频比例
   - 分辨率
   - 画风
   - 视频类别
2. 前端调用 `POST /api/quick-generate/projects`
3. 服务端创建：
   - `stories` 记录，`storyType=quick_generate`
   - `quickGenerateProjects` 记录
   - 如果环境开启送审能力，则同步创建素材分组并回写 `groupId`
4. 创建成功后，前端跳转到：
   - `/script/quick-generate/{storyId}`

### 2.3 从已有剧本快速开始

除了“新建剧本 -> 快速生成”外，当前还存在一条补充入口：

- 来源组件：`src/features/script/workspace/components/PreviewPanel.tsx`
- 调用接口：`POST /api/quick-generate/projects/from-script`

这条链路的作用是：

- 基于已有剧本创建一个新的快速生成项目
- 自动继承源剧本的比例、分辨率、画风、视频类别
- 自动同步源剧本最新一批可复用素材到 quick-generate 素材区

## 3. 页面与模块结构

### 3.1 主页面

- 快速生成工作区页面：`/script/quick-generate/{storyId}`
- 页面文件：`src/app/(app)/script/quick-generate/[storyId]/page.tsx`
- 页面组件：`src/features/script/quickGenerate/QuickGeneratePage.tsx`

当前工作区包含两个主 Tab：

- `素材`
- `剧集`

### 3.2 剧集详情页

- 路由：`/script/quick-generate/{storyId}/episodes/{episodeId}`
- 页面文件：`src/app/(app)/script/quick-generate/[storyId]/episodes/[episodeId]/page.tsx`
- 页面组件：`src/features/script/quickGenerate/components/QuickGenerateEpisodeResultPage.tsx`

该页面用于承载单集的：

- 分镜结果查看
- 分镜编辑
- 提示词生成
- 视频生成
- 视频定版
- 剪映导出

## 4. 当前功能介绍

### 4.1 项目创建

当前快速生成项目支持在创建时保存以下基础配置：

- 标题
- 视频比例
- 分辨率
- 画风
- 视频类别

创建后会生成一条独立的 quick-generate 项目，不依赖短剧前置设定页面。

### 4.2 素材管理

素材页当前支持以下能力：

- 手动上传素材
- 从版权库导入素材
- AI 生成素材
- 按类型筛选素材
- 按审核状态筛选素材
- 批量编辑素材
- 单个/批量删除素材
- 素材送审
- 刷新素材审核状态
- 为人物素材绑定音色

当前素材分类包括：

- `scene`
- `character`
- `prop`
- `video`
- `audio`

### 4.3 剧集管理

剧集页当前支持以下能力：

- 新增剧集
- 删除剧集
- 从文件导入剧本文本
- 选择解析类型创建剧集
- 自动带出默认视频模型
- 进入单集结果页继续编辑和生成

当前剧集创建支持的解析类型：

- `outline`：整集剧本拆分
- `storyboard`：分镜剧本文本
- `drama`：集剧提示词拆分

### 4.4 单集创作能力

单集结果页当前支持以下能力：

- 保存整集或单条分镜内容
- 为分镜生成视频提示词
- 批量生成分镜视频
- 选择某个分镜最终采用的视频版本
- 导出剪映工程

### 4.5 任务与异步处理

当前 quick-generate 中多项能力是异步任务：

- 剧集创建
- 视频提示词生成
- 视频生成
- 素材审核轮询
- 剪映导出

这些能力统一走 jobs 体系，前端拿到的关键结果通常是 `jobId`。

## 5. 当前链路总结

“新建剧本 -> 快速生成”当前已经形成一条独立工作流，核心特点如下：

- 入口轻量，先建项目再补内容
- 项目和短剧前置设定链路解耦
- 素材、剧集、分镜、视频生成都集中在 quick-generate 工作区
- 从已有剧本可以一键派生 quick-generate 项目并同步素材
- 关键操作普遍已接入异步任务体系
- 接口基本都具备统一的 `ok/data/traceId` 返回结构
