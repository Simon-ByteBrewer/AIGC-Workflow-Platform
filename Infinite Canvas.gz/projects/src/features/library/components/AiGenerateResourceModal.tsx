"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import { X } from "lucide-react"
import styles from "./AiGenerateResourceModal.module.css"
import type { AiResourceType } from "../utils/libraryUtils"

type VariantInput = {
  id: string
  text: string
  tags: string
}

interface AiGenerateResourceModalProps {
  open: boolean
  onClose: () => void
  onGenerateBase: (input: {
    type: AiResourceType
    prompt: string
    name?: string
    description?: string
  }) => Promise<{ id: string; url: string; storageKey: string } | null>
  onGenerate: (input: {
    type: AiResourceType
    prompt: string
    backPrompt?: string
    name?: string
    description?: string
    tags?: string
    applicableScenes?: string
    lookItems?: VariantInput[]
    costumeItems?: VariantInput[]
    itemId?: string
    baseCharacterId?: string
    baseImageUrl?: string
    baseImageStorageKey?: string
  }) => Promise<void>
}

export function AiGenerateResourceModal({ open, onClose, onGenerate, onGenerateBase }: AiGenerateResourceModalProps): ReactElement | null {
  const [type, setType] = useState<AiResourceType>("character")
  const [prompt, setPrompt] = useState("")
  const [backPrompt, setBackPrompt] = useState("")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [tags, setTags] = useState("")
  const [scenes, setScenes] = useState("")
  
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [aiError, setAiError] = useState<string | null>(null)
  
  const [bulkSubmitting, setBulkSubmitting] = useState(false)
  const [itemSubmittingById, setItemSubmittingById] = useState<Record<string, boolean>>({})
  const [individualExtracted, setIndividualExtracted] = useState(false)
  const [lookItems, setLookItems] = useState<VariantInput[]>([])
  const [costumeItems, setCostumeItems] = useState<VariantInput[]>([])

  const [generatingBase, setGeneratingBase] = useState(false)
  const [baseCharacterInfo, setBaseCharacterInfo] = useState<{ id: string; url: string; storageKey: string } | null>(null)

  const createVariantInput = useCallback((): VariantInput => {
    const id =
      typeof globalThis.crypto?.randomUUID === "function"
        ? globalThis.crypto.randomUUID()
        : `variant_${Date.now()}_${Math.random().toString(16).slice(2)}`
    return { id, text: "", tags: "" }
  }, [])

  useEffect(() => {
    if (!open) return
    setLookItems([createVariantInput()])
    setCostumeItems([createVariantInput()])
    setItemSubmittingById({})
    setIndividualExtracted(false)
    setAiError(null)
    setError(null)
    setPrompt("")
    setBackPrompt("")
    setName("")
    setDescription("")
    setTags("")
    setScenes("")
    setBaseCharacterInfo(null)
    setGeneratingBase(false)
  }, [createVariantInput, open, type])

  const isCharacterType = type === "character"
  const isBackgroundType = type === "background"
  
  const canGenerateBase = useMemo(() => {
    return isCharacterType && prompt.trim() && name.trim() && !generatingBase && !submitting && !bulkSubmitting && !baseCharacterInfo
  }, [isCharacterType, prompt, name, generatingBase, submitting, bulkSubmitting, baseCharacterInfo])

  const handleGenerateBase = async () => {
    try {
      setGeneratingBase(true)
      setAiError(null)
      const res = await onGenerateBase({
        type: "character",
        prompt: prompt.trim(),
        name: name.trim(),
        description: description.trim()
      })
      if (res) {
        setBaseCharacterInfo(res)
      }
    } catch (e) {
      setAiError(e instanceof Error ? e.message : "生成基础图失败")
    } finally {
      setGeneratingBase(false)
    }
  }

  const canSubmit = useMemo(() => {
    if (submitting || bulkSubmitting || generatingBase) return false
    if (isBackgroundType) {
      return prompt.trim().length > 0 || backPrompt.trim().length > 0
    }
    if (isCharacterType) {
      if (!baseCharacterInfo) return false
      const allLookReady = lookItems.length > 0 && lookItems.every((it) => it.text.trim() && it.tags.trim())
      const allCostumeReady = costumeItems.length > 0 && costumeItems.every((it) => it.text.trim() && it.tags.trim())
      return allLookReady && allCostumeReady
    }
    return prompt.trim().length > 0
  }, [submitting, bulkSubmitting, generatingBase, isBackgroundType, prompt, backPrompt, isCharacterType, baseCharacterInfo, lookItems, costumeItems])

  const submit = async (itemId?: string) => {
    try {
      if (itemId) {
        setItemSubmittingById((prev) => ({ ...prev, [itemId]: true }))
      } else {
        setBulkSubmitting(true)
        setSubmitting(true)
      }
      setError(null)
      setAiError(null)
      
      const filteredLooks = lookItems.map((it) => ({ ...it, text: it.text.trim(), tags: it.tags.trim() }))
      const filteredCostumes = costumeItems.map((it) => ({ ...it, text: it.text.trim(), tags: it.tags.trim() }))
      
      if (isCharacterType && !itemId) {
        const anyMissing = filteredLooks.some((it) => !it.text || !it.tags) || filteredCostumes.some((it) => !it.text || !it.tags)
        if (anyMissing) {
          setAiError("妆造与服装的描述、标签均为必填")
          return
        }
      }
      
      await onGenerate({
        type,
        prompt: prompt.trim(),
        backPrompt: backPrompt.trim() ? backPrompt.trim() : undefined,
        name: name.trim() ? name.trim() : undefined,
        description: description.trim() ? description.trim() : undefined,
        tags: tags.trim() ? tags.trim() : undefined,
        applicableScenes: scenes.trim() ? scenes.trim() : undefined,
        lookItems: isCharacterType ? filteredLooks : undefined,
        costumeItems: isCharacterType ? filteredCostumes : undefined,
        itemId,
        baseCharacterId: baseCharacterInfo?.id,
        baseImageUrl: baseCharacterInfo?.url,
        baseImageStorageKey: baseCharacterInfo?.storageKey
      })
      
      if (!itemId) {
        onClose()
      } else {
        setIndividualExtracted(true)
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "生成失败"
      if (isCharacterType) setAiError(msg)
      else setError(msg)
    } finally {
      if (itemId) {
        setItemSubmittingById((prev) => ({ ...prev, [itemId]: false }))
      } else {
        setBulkSubmitting(false)
        setSubmitting(false)
      }
    }
  }

  const updateLookItem = useCallback((id: string, patch: Partial<VariantInput>) => {
    setLookItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)))
  }, [])

  const updateCostumeItem = useCallback((id: string, patch: Partial<VariantInput>) => {
    setCostumeItems((prev) => prev.map((it) => (it.id === id ? { ...it, ...patch } : it)))
  }, [])

  const addLookItem = useCallback(() => {
    setLookItems((prev) => [...prev, createVariantInput()])
  }, [createVariantInput])

  const addCostumeItem = useCallback(() => {
    setCostumeItems((prev) => [...prev, createVariantInput()])
  }, [createVariantInput])

  const removeLookItem = useCallback((id: string) => {
    setLookItems((prev) => prev.filter((it) => it.id !== id))
  }, [])

  const removeCostumeItem = useCallback((id: string) => {
    setCostumeItems((prev) => prev.filter((it) => it.id !== id))
  }, [])

  if (!open) return null

  return (
    <>
      <div className={styles.overlay} onClick={() => (submitting || bulkSubmitting ? undefined : onClose())} />
      <div className={styles.modal}>
        <div className={styles.header}>
          <div className={styles.title}>AI 生成公共资源</div>
          <button type="button" className={styles.closeBtn} onClick={() => (submitting || bulkSubmitting ? undefined : onClose())} aria-label="关闭">
            <X size={20} />
          </button>
        </div>

        <div className={styles.body}>
          <div className={styles.row}>
            <div className={styles.field}>
              <label className={styles.label}>类型</label>
              <select className={styles.select} value={type} onChange={(e) => setType(e.target.value as AiResourceType)} disabled={submitting || bulkSubmitting || generatingBase}>
                <option value="character">角色库</option>
                <option value="background">场景库</option>
                <option value="props">物品库</option>
              </select>
            </div>
            {isCharacterType ? (
              <div className={styles.field}>
                <label className={styles.label}>人物姓名</label>
                <input className={styles.input} placeholder="必填" value={name} onChange={(e) => setName(e.target.value)} disabled={submitting || bulkSubmitting || generatingBase || !!baseCharacterInfo} />
              </div>
            ) : (
              <div className={styles.field}>
                <label className={styles.label}>名称</label>
                <input className={styles.input} placeholder="可选" value={name} onChange={(e) => setName(e.target.value)} disabled={submitting || bulkSubmitting} />
              </div>
            )}
          </div>

          {isCharacterType ? (
            <div className={styles.field}>
              <label className={styles.label}>人物描述</label>
              <input className={styles.input} placeholder="可选" value={description} onChange={(e) => setDescription(e.target.value)} disabled={submitting || bulkSubmitting || generatingBase || !!baseCharacterInfo} />
            </div>
          ) : (
            <div className={styles.row}>
              <div className={styles.field}>
                <label className={styles.label}>标签</label>
                <input className={styles.input} placeholder="逗号分隔，如：商务,正式" value={tags} onChange={(e) => setTags(e.target.value)} disabled={submitting || bulkSubmitting} />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>适用场景</label>
                <input className={styles.input} placeholder="逗号分隔，如：广告,宣传片" value={scenes} onChange={(e) => setScenes(e.target.value)} disabled={submitting || bulkSubmitting} />
              </div>
            </div>
          )}

          {!isCharacterType && !isBackgroundType ? (
            <div className={styles.field}>
              <label className={styles.label}>描述</label>
              <input className={styles.input} placeholder="可选" value={description} onChange={(e) => setDescription(e.target.value)} disabled={submitting || bulkSubmitting} />
            </div>
          ) : null}

          {isBackgroundType ? (
            <div className={styles.row}>
              <div className={styles.field}>
                <label className={styles.label}>正视图提示词</label>
                <textarea
                  className={styles.textarea}
                  placeholder="输入用于生成场景正视图的提示词..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  disabled={submitting || bulkSubmitting}
                />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>反视图提示词</label>
                <textarea
                  className={styles.textarea}
                  placeholder="输入用于生成场景反视图的提示词..."
                  value={backPrompt}
                  onChange={(e) => setBackPrompt(e.target.value)}
                  disabled={submitting || bulkSubmitting}
                />
              </div>
            </div>
          ) : (
            <div className={styles.field}>
              <label className={styles.label}>{isCharacterType ? "基础图像提示词" : "提示词"}</label>
              <textarea
                className={styles.textarea}
                placeholder={`输入用于生成${isCharacterType ? "人物基础图" : "图片"}的提示词...`}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                disabled={submitting || bulkSubmitting || generatingBase || !!baseCharacterInfo}
              />
            </div>
          )}

          {isCharacterType ? (
            <div className={styles.aiSection}>
              <div className={styles.aiActions} style={{ borderTop: "none", paddingTop: 0, marginTop: 0 }}>
                <div className={styles.sectionTitle}>基础图像</div>
                {!baseCharacterInfo && (
                  <button
                    type="button"
                    className={styles.generateBaseBtn}
                    onClick={handleGenerateBase}
                    disabled={!canGenerateBase}
                  >
                    {generatingBase ? "生成中..." : "生成基础图"}
                  </button>
                )}
              </div>
              
              {baseCharacterInfo ? (
                <div className={styles.baseImagePreview}>
                  <img src={baseCharacterInfo.url} alt="基础图像" />
                </div>
              ) : (
                <div className={styles.baseImagePreview}>
                  <div className={styles.baseImagePlaceholder}>
                    {generatingBase ? "生成基础图像中..." : "请先输入提示词并生成基础图"}
                  </div>
                </div>
              )}
            </div>
          ) : null}

          {isCharacterType ? (
            <div className={styles.aiSection} style={{ opacity: baseCharacterInfo ? 1 : 0.5, pointerEvents: baseCharacterInfo ? "auto" : "none" }}>
              <div className={styles.sectionHeader}>
                <div className={styles.sectionTitle}>妆造</div>
                <button type="button" className={styles.addBtn} onClick={addLookItem} disabled={bulkSubmitting || submitting}>
                  + 添加妆造
                </button>
              </div>
              <div className={styles.variantList}>
                {lookItems.map((it, idx) => {
                  const loading = Boolean(itemSubmittingById[it.id])
                  const canSingle = prompt.trim() && name.trim() && it.text.trim() && it.tags.trim() && !bulkSubmitting && !submitting && !loading
                  const canRemove = lookItems.length > 1 && !bulkSubmitting && !submitting && !loading
                  return (
                    <div key={it.id} className={styles.variantCard}>
                      <div className={styles.variantTitle}>妆造 {idx + 1}</div>
                      <div className={styles.variantInputs}>
                        <input
                          className={styles.input}
                          placeholder="标签（必填）"
                          value={it.tags}
                          onChange={(e) => updateLookItem(it.id, { tags: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                        <input
                          className={styles.input}
                          placeholder="描述（必填）"
                          value={it.text}
                          onChange={(e) => updateLookItem(it.id, { text: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                      </div>
                      <div className={styles.variantActions}>
                        <button type="button" className={styles.removeBtn} disabled={!canRemove} onClick={() => removeLookItem(it.id)}>
                          删除
                        </button>
                        <button type="button" className={styles.smallBtn} disabled={!canSingle} onClick={() => submit(it.id)}>
                          {loading ? "抽取中..." : "抽取"}
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className={styles.sectionHeader}>
                <div className={styles.sectionTitle}>服装</div>
                <button type="button" className={styles.addBtn} onClick={addCostumeItem} disabled={bulkSubmitting || submitting}>
                  + 添加服装
                </button>
              </div>
              <div className={styles.variantList}>
                {costumeItems.map((it, idx) => {
                  const loading = Boolean(itemSubmittingById[it.id])
                  const canSingle = prompt.trim() && name.trim() && it.text.trim() && it.tags.trim() && !bulkSubmitting && !submitting && !loading
                  const canRemove = costumeItems.length > 1 && !bulkSubmitting && !submitting && !loading
                  return (
                    <div key={it.id} className={styles.variantCard}>
                      <div className={styles.variantTitle}>服装 {idx + 1}</div>
                      <div className={styles.variantInputs}>
                        <input
                          className={styles.input}
                          placeholder="标签（必填）"
                          value={it.tags}
                          onChange={(e) => updateCostumeItem(it.id, { tags: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                        <input
                          className={styles.input}
                          placeholder="描述（必填）"
                          value={it.text}
                          onChange={(e) => updateCostumeItem(it.id, { text: e.target.value })}
                          disabled={bulkSubmitting || submitting}
                        />
                      </div>
                      <div className={styles.variantActions}>
                        <button type="button" className={styles.removeBtn} disabled={!canRemove} onClick={() => removeCostumeItem(it.id)}>
                          删除
                        </button>
                        <button type="button" className={styles.smallBtn} disabled={!canSingle} onClick={() => submit(it.id)}>
                          {loading ? "抽取中..." : "抽取"}
                        </button>
                      </div>
                    </div>
                  )
                })}
              </div>
              
              {individualExtracted && <div className={styles.helperText}>已进行单项抽取，一键生成已禁用</div>}
              {aiError && <div className={styles.error}>{aiError}</div>}
            </div>
          ) : null}

          {error && !isCharacterType && <div className={styles.error}>{error}</div>}
        </div>

        <div className={styles.footer}>
          <button type="button" className={styles.cancelBtn} onClick={onClose} disabled={submitting || bulkSubmitting || generatingBase}>
            取消
          </button>
          <button type="button" className={styles.submitBtn} onClick={() => submit()} disabled={!canSubmit || (isCharacterType && individualExtracted)}>
            {submitting || bulkSubmitting ? "生成中..." : "AI 生成"}
          </button>
        </div>
      </div>
    </>
  )
}
