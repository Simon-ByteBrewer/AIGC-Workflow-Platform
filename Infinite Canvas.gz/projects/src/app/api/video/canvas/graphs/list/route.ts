import { NextResponse, type NextRequest } from "next/server"
import { and, eq, isNull } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories, storyOutlines, videoCanvasGraphs } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

function safeArray<T>(v: unknown): T[] {
  return Array.isArray(v) ? (v as T[]) : []
}

function isGeneratedAssetId(v: unknown): v is string {
  if (typeof v !== "string") return false
  return v.startsWith("generated:image:") || v.startsWith("generated:video:")
}

function dedupeGenerated(items: Array<{ kind: "image" | "video"; assetId: string; url: string }>): Array<{ kind: "image" | "video"; assetId: string; url: string }> {
  const map = new Map<string, { kind: "image" | "video"; assetId: string; url: string }>()
  for (const it of items) {
    const k = `${it.kind}:${it.assetId}`
    if (map.has(k)) continue
    map.set(k, it)
  }
  return Array.from(map.values())
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ storyId: url.searchParams.get("storyId") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, storyOutlines, videoCanvasGraphs })

  const storyRows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

  const outlines = await db
    .select({ id: storyOutlines.id, sequence: storyOutlines.sequence })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.storyId, parsed.data.storyId), isNull(storyOutlines.deletedAt)))
    .orderBy(storyOutlines.sequence)

  const graphs = await db
    .select({ outlineId: videoCanvasGraphs.outlineId, version: videoCanvasGraphs.version, graphJson: videoCanvasGraphs.graphJson, updatedAt: videoCanvasGraphs.updatedAt })
    .from(videoCanvasGraphs)
    .where(and(eq(videoCanvasGraphs.storyId, parsed.data.storyId), isNull(videoCanvasGraphs.deletedAt)))

  const graphByOutlineId = new Map(graphs.map((g) => [g.outlineId, g]))

  const items = outlines.map((o) => {
    const g = graphByOutlineId.get(o.id)
    const rawGraph = (g?.graphJson ?? null) as any
    const nodes = safeArray<any>(rawGraph?.nodes)
    const edges = safeArray<any>(rawGraph?.edges)
    const nodeCount = nodes.length
    const edgeCount = edges.length
    const isEmpty = nodeCount === 0 && edgeCount === 0

    const previewNodes = nodes
      .slice(0, 40)
      .map((n) => ({
        id: typeof n?.id === "string" ? n.id : "",
        type: typeof n?.type === "string" ? n.type : "",
        x: typeof n?.position?.x === "number" ? n.position.x : 0,
        y: typeof n?.position?.y === "number" ? n.position.y : 0
      }))
      .filter((n) => n.id)
    const previewEdges = edges
      .slice(0, 60)
      .map((e) => ({
        source: typeof e?.source === "string" ? e.source : "",
        target: typeof e?.target === "string" ? e.target : ""
      }))
      .filter((e) => e.source && e.target)

    const generatedRaw = nodes
      .filter((n) => typeof n?.type === "string" && (n.type === "image_resource" || n.type === "video_resource"))
      .map((n) => {
        const params = (n?.params ?? {}) as Record<string, unknown>
        const assetId = params.assetId
        const url = params.url
        if (!isGeneratedAssetId(assetId)) return null
        if (typeof url !== "string" || !url.trim()) return null
        return {
          kind: n.type === "image_resource" ? "image" : "video",
          assetId,
          url
        }
      })
      .filter((v): v is { kind: "image" | "video"; assetId: string; url: string } => Boolean(v))

    const generated = dedupeGenerated(generatedRaw)

    return {
      outlineId: o.id,
      sequence: o.sequence,
      hasGraph: Boolean(g),
      version: g?.version ?? null,
      updatedAt: g?.updatedAt ?? null,
      nodeCount,
      edgeCount,
      isEmpty,
      preview: { nodes: previewNodes, edges: previewEdges },
      generatedPreview: { count: generated.length, items: generated.slice(0, 4) }
    }
  })

  return NextResponse.json(makeApiOk(traceId, { storyId: parsed.data.storyId, items }), { status: 200 })
}
