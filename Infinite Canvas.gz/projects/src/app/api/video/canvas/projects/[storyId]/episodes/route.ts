import { NextResponse, type NextRequest } from "next/server"
import { and, eq, isNull } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories, storyOutlines } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

const paramsSchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

export async function GET(req: NextRequest, ctx: { params: Promise<{ storyId: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, storyOutlines })

  const allowed = await db
    .select({ id: stories.id, storyType: stories.storyType, title: stories.title })
    .from(stories)
    .where(and(eq(stories.id, parsedParams.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的项目"), { status: 404 })

  const outlines = await db
    .select({ id: storyOutlines.id, sequence: storyOutlines.sequence })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.storyId, parsedParams.data.storyId), isNull(storyOutlines.deletedAt)))
    .orderBy(storyOutlines.sequence)

  return NextResponse.json(
    makeApiOk(traceId, {
      storyId: parsedParams.data.storyId,
      storyType: allowed[0]?.storyType ?? null,
      title: allowed[0]?.title || "未命名",
      items: outlines
    }),
    { status: 200 }
  )
}

