import type { LibraryItem } from "@/shared/contracts/library/libraryItem"

/** 返回我的项目卡片的创建方式与可编辑内容摘要。 */
export function getLibraryCardMyMeta(
  item: Pick<LibraryItem, "type" | "storyType" | "progressStage">
): { createMethod: string; editableInfo: string } {
  if (item.type === "tvc") {
    return {
      createMethod: "TVC 创作",
      editableInfo: "标题、Brief、时长、画幅、清晰度"
    }
  }

  if (item.storyType === "canvas") {
    return {
      createMethod: "无限画布",
      editableInfo: "节点、提示词、素材、导出参数"
    }
  }

  if (item.storyType === "quick_generate") {
    return {
      createMethod: "快速生成",
      editableInfo: "项目设定、分集内容、素材生成"
    }
  }

  if (item.progressStage === "outline") {
    return {
      createMethod: "大纲创作",
      editableInfo: "标题、大纲、项目信息"
    }
  }

  return {
    createMethod: "标准创作",
    editableInfo: "剧本、分镜、视频参数"
  }
}
