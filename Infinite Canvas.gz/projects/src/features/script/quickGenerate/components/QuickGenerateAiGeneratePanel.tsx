"use client"

import { useMemo, useState, type ReactElement } from "react"
import { aiGenerateQuickGenerateMaterials } from "../api-client"
import styles from "./QuickGenerateAiGeneratePanel.module.css"

type SupportedAiMaterialType = "scene" | "character" | "prop"

interface QuickGenerateAiGeneratePanelProps {
  storyId: string
  onGenerated: (createdCount: number) => Promise<void> | void
}

const TYPE_OPTIONS: Array<{ id: SupportedAiMaterialType; label: string }> = [
  { id: "scene", label: "场景" },
  { id: "character", label: "人物" },
  { id: "prop", label: "物品" }
]

function getPromptHint(materialType: SupportedAiMaterialType): string {
  if (materialType === "character") return "人物会直接复用现有三视图链路，一次生成 3 张人物图。"
  if (materialType === "scene") return "场景会复用现有 AI 生图能力，生成 1 张素材图。"
  return "物品会复用现有 AI 生图能力，生成 1 张素材图。"
}

export function QuickGenerateAiGeneratePanel({
  storyId,
  onGenerated
}: QuickGenerateAiGeneratePanelProps): ReactElement {
  const [materialType, setMaterialType] = useState<SupportedAiMaterialType>("scene")
  const [name, setName] = useState("")
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState("写实")
  const [submitting, setSubmitting] = useState(false)

  const canSubmit = useMemo(() => name.trim() && prompt.trim() && !submitting, [name, prompt, submitting])

  const handleSubmit = async () => {
    if (!canSubmit) return
    try {
      setSubmitting(true)
      const result = await aiGenerateQuickGenerateMaterials({
        storyId,
        materialType,
        name: name.trim(),
        prompt: prompt.trim(),
        style: style.trim() || "写实"
      })
      await onGenerated(result.createdCount)
      setName("")
      setPrompt("")
    } catch (error) {
      alert(error instanceof Error ? error.message : "AI 生成素材失败")
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className={styles.panel}>
      <div className={styles.hint}>{getPromptHint(materialType)}</div>

      <div className={styles.typeRow}>
        {TYPE_OPTIONS.map((option) => (
          <button
            key={option.id}
            type="button"
            className={`${styles.typeBtn} ${materialType === option.id ? styles.typeBtnActive : ""}`}
            onClick={() => setMaterialType(option.id)}
            disabled={submitting}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className={styles.field}>
        <label className={styles.label}>素材名称</label>
        <input
          className={styles.input}
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder={materialType === "character" ? "例如：女主-三视图" : "请输入素材名称"}
          disabled={submitting}
        />
      </div>

      <div className={styles.field}>
        <label className={styles.label}>风格</label>
        <input
          className={styles.input}
          value={style}
          onChange={(event) => setStyle(event.target.value)}
          placeholder="默认写实"
          disabled={submitting}
        />
      </div>

      <div className={styles.field}>
        <label className={styles.label}>提示词</label>
        <textarea
          className={styles.textarea}
          value={prompt}
          onChange={(event) => setPrompt(event.target.value)}
          placeholder={materialType === "character" ? "请输入人物外观描述，系统会直接生成三视图" : "请输入生成提示词"}
          disabled={submitting}
        />
      </div>

      <div className={styles.footer}>
        <button type="button" className={styles.primaryBtn} disabled={!canSubmit} onClick={() => void handleSubmit()}>
          {submitting ? (materialType === "character" ? "三视图生成中..." : "生成中...") : materialType === "character" ? "生成三视图" : "开始生成"}
        </button>
      </div>
    </div>
  )
}
