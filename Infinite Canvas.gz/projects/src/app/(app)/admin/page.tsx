import type { ReactElement } from "react"
import { cookies, headers } from "next/headers"
import { AuthService } from "@/server/domains/auth/services/authService"
import { AdminHomePage } from "@/features/admin/home/AdminHomePage"
import { SESSION_COOKIE_NAME } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export default async function AdminPage(): Promise<ReactElement> {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  const hdrs = await headers()
  const traceId = getTraceId(new Headers(hdrs as any))

  let role = "user"
  try {
    const user = await AuthService.getCurrentUser(token, false, traceId)
    role = user.role
  } catch {}

  return (
    <AdminHomePage role={role} />
  )
}
