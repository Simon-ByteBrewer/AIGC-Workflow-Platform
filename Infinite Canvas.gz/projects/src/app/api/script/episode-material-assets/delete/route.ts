import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { getDb } from "@/server/db/getDb"
import { episodeMaterialAssets } from "@/shared/schema/generation"
import { stories } from "@/shared/schema/story"
import { publicBackgroundCameras, publicResources } from "@/shared/schema/library"
import { generatedImages } from "@/shared/schema/generation"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  assetId: z.string().trim().min(1).max(200)
})

function normalizeKind(raw: string): "background" | "props" | "character" | null {
  const k = (raw ?? "").trim().toLowerCase()
  if (k === "scene" || k === "background") return "background"
  if (k === "item" || k === "props") return "props"
  if (k === "role" || k === "character") return "character"
  return null
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const db = await getDb({ stories, episodeMaterialAssets, publicResources, publicBackgroundCameras, generatedImages })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const rows = await db
    .select({
      id: episodeMaterialAssets.id,
      kind: episodeMaterialAssets.kind,
      meta: episodeMaterialAssets.meta
    })
    .from(episodeMaterialAssets)
    .where(and(eq(episodeMaterialAssets.id, parsed.data.assetId), eq(episodeMaterialAssets.storyId, parsed.data.storyId)))
    .limit(1)
  const asset = rows[0] ?? null
  if (!asset) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "素材不存在"), { status: 404 })

  const libraryType = normalizeKind(asset.kind)
  const publicResourceId = typeof (asset.meta as any)?.library?.publicResourceId === "string" ? String((asset.meta as any).library.publicResourceId).trim() : ""
  const generatedImageId =
    typeof (asset.meta as any)?.library?.generatedImageId === "string" ? String((asset.meta as any).library.generatedImageId).trim() : ""

  if (publicResourceId && libraryType) {
    const owned = await db
      .select({ id: publicResources.id })
      .from(publicResources)
      .where(and(eq(publicResources.id, publicResourceId), eq(publicResources.userId, userId), eq(publicResources.type, libraryType)))
      .limit(1)
    if (owned[0]) {
      if (libraryType === "background") {
        try {
          await db.delete(publicBackgroundCameras).where(eq(publicBackgroundCameras.backgroundResourceId, publicResourceId))
        } catch {
        }
      }
      try {
        await db.delete(publicResources).where(eq(publicResources.id, publicResourceId))
      } catch {
      }
    }
  }

  if (generatedImageId) {
    try {
      await db.delete(generatedImages).where(eq(generatedImages.id, generatedImageId))
    } catch {
    }
  }

  await db.delete(episodeMaterialAssets).where(eq(episodeMaterialAssets.id, parsed.data.assetId))

  return NextResponse.json(makeApiOk(traceId, { assetId: parsed.data.assetId, deletedLibrary: Boolean(publicResourceId) }), { status: 200 })
}
