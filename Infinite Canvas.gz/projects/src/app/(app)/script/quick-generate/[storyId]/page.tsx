import type { ReactElement } from "react"
import { cookies } from "next/headers"
import { notFound } from "next/navigation"
import { asc, eq } from "drizzle-orm"
import { quickGenerateEpisodes, quickGenerateMaterials, quickGenerateProjects, stories } from "@/shared/schema"
import { QuickGeneratePage } from "@/features/script/quickGenerate/QuickGeneratePage"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getQuickGenerateStoryAccess } from "@/server/domains/quick-generate/access"
import { parseQuickGenerateEpisodeShots } from "@/shared/quickGenerate/episodeShots"
import { normalizeQuickGenerateEpisodeVideoResults } from "@/shared/quickGenerate/videoResults"
import { isSeedance20AudEnabled } from "@/server/capabilities/seedance20Aud"
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export const dynamic = "force-dynamic"

function computeEpisodeStats(input: {
  resultPayload: unknown
  videoPromptPayload: unknown
  videoResults: unknown
}): { totalShots: number; promptCount: number; videoTotalCount: number; videoShotCount: number } {
  const { shots } = parseQuickGenerateEpisodeShots(input.resultPayload, input.videoPromptPayload)
  const totalShots = shots.length
  const promptCount = shots.filter((s) => Boolean(String(s.optimizedText ?? "").trim())).length

  const normalized = normalizeQuickGenerateEpisodeVideoResults(input.videoResults)
  const buckets = Object.values(normalized)
  const videoShotCount = buckets.length
  const videoTotalCount = buckets.reduce((acc, b) => acc + (Array.isArray(b.videos) ? b.videos.length : 0), 0)
  return { totalShots, promptCount, videoTotalCount, videoShotCount }
}

export default async function Page({
  params,
  searchParams
}: {
  params: { storyId: string } | Promise<{ storyId: string }>
  searchParams?: Promise<Record<string, string | string[] | undefined>> | Record<string, string | string[] | undefined>
}): Promise<ReactElement> {
  const resolvedParams = await Promise.resolve(params)
  const resolvedSearchParams = await Promise.resolve(searchParams)
  const storyId = resolvedParams.storyId?.trim()
  if (!storyId) notFound()
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  if (!token) notFound()
  const session = await verifySessionToken(token, getTraceId(new Headers()))
  if (!session?.userId) notFound()
  const access = await getQuickGenerateStoryAccess(session.userId, storyId)
  if (!access) notFound()
  const rawTab = resolvedSearchParams?.tab
  const tabValue = Array.isArray(rawTab) ? rawTab[0] : rawTab
  const preferredActiveTab = tabValue === "episodes" ? "episodes" : tabValue === "materials" ? "materials" : null

  await ensurePublicSchema()
  const db = await getDb({ stories, quickGenerateProjects, quickGenerateEpisodes, quickGenerateMaterials })

  const storyRows = await db
    .select({ id: stories.id, title: stories.title })
    .from(stories)
    .where(eq(stories.id, storyId))
    .limit(1)
  const story = storyRows[0]
  if (!story) notFound()

  const projectRows = await db
    .select({
      id: quickGenerateProjects.id,
      groupId: quickGenerateProjects.groupId,
      status: quickGenerateProjects.status,
      activeTab: quickGenerateProjects.activeTab
    })
    .from(quickGenerateProjects)
    .where(eq(quickGenerateProjects.storyId, storyId))
    .limit(1)
  const project = projectRows[0] ?? null

  const episodeRows = await db
    .select({
      id: quickGenerateEpisodes.id,
      episodeNo: quickGenerateEpisodes.episodeNo,
      title: quickGenerateEpisodes.title,
      status: quickGenerateEpisodes.status,
      resultPayload: quickGenerateEpisodes.resultPayload,
      videoPromptPayload: quickGenerateEpisodes.videoPromptPayload,
      videoResults: quickGenerateEpisodes.videoResults
    })
    .from(quickGenerateEpisodes)
    .where(eq(quickGenerateEpisodes.storyId, storyId))
    .orderBy(asc(quickGenerateEpisodes.episodeNo))

  const materialRows = await db
    .select({
      id: quickGenerateMaterials.id,
      materialType: quickGenerateMaterials.materialType,
      title: quickGenerateMaterials.title,
      status: quickGenerateMaterials.status,
      sourceUrl: quickGenerateMaterials.sourceUrl,
      voiceSpeakerId: quickGenerateMaterials.voiceSpeakerId,
      voiceSpeakerName: quickGenerateMaterials.voiceSpeakerName,
      assetId: quickGenerateMaterials.assetId,
      assetStatus: quickGenerateMaterials.assetStatus,
      assetErrorMessage: quickGenerateMaterials.assetErrorMessage,
      metadata: quickGenerateMaterials.metadata
    })
    .from(quickGenerateMaterials)
    .where(eq(quickGenerateMaterials.storyId, storyId))
    .orderBy(asc(quickGenerateMaterials.createdAt))

  return (
    <QuickGeneratePage
      storyId={storyId}
      storyTitle={story.title ?? ""}
      preferredActiveTab={preferredActiveTab}
      enableBatchReview={isSeedance20AudEnabled()}
      project={
        project
          ? {
              id: project.id,
              groupId: project.groupId ?? null,
              status: project.status,
              activeTab: project.activeTab === "episodes" ? "episodes" : "materials"
            }
          : null
      }
      episodes={episodeRows.map((r) => {
        const stats = computeEpisodeStats({
          resultPayload: r.resultPayload,
          videoPromptPayload: r.videoPromptPayload,
          videoResults: r.videoResults
        })
        return {
          id: r.id,
          episodeNo: r.episodeNo,
          title: r.title ?? null,
          status: r.status,
          ...stats
        }
      })}
      materials={materialRows.map((r) => ({ 
        id: r.id, 
        materialType: r.materialType, 
        title: r.title ?? null, 
        status: r.status,
        sourceUrl: r.sourceUrl ?? null,
        voiceSpeakerId: r.voiceSpeakerId ?? null,
        voiceSpeakerName: r.voiceSpeakerName ?? null,
        assetId: (r as any).assetId ?? null,
        assetStatus: (r as any).assetStatus ?? null,
        assetErrorMessage: (r as any).assetErrorMessage ?? null,
        metadata: r.metadata
      }))}
    />
  )
}
