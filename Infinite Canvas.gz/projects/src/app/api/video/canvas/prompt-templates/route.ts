import { NextResponse, type NextRequest } from "next/server"
import { and, desc, eq, isNull, sql } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { promptTemplates } from "@/shared/schema"

const createSchema = z.object({
  title: z.string().trim().min(1).max(200),
  content: z.string().trim().min(1)
})

function normalizeTemplateRow(row: any): Record<string, unknown> {
  const tags = Array.isArray(row.tags) ? row.tags : []
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    tags,
    isActive: Boolean(row.isActive),
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  }
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  const db = await getDb({ promptTemplates })

  await db.execute(sql`
    create table if not exists public.prompt_templates (
      id text primary key default gen_random_uuid(),
      user_id text references public.users(id) on delete cascade,
      type text not null default 'custom',
      title text not null,
      content text not null,
      tags jsonb not null default '[]'::jsonb,
      is_active boolean not null default true,
      deleted_at timestamptz,
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now(),
      check (type in ('system', 'custom'))
    );
  `)

  const rows = await db
    .select({
      id: promptTemplates.id,
      title: promptTemplates.title,
      content: promptTemplates.content,
      tags: promptTemplates.tags,
      isActive: promptTemplates.isActive,
      createdAt: promptTemplates.createdAt,
      updatedAt: promptTemplates.updatedAt
    })
    .from(promptTemplates)
    .where(and(eq(promptTemplates.userId, userId), eq(promptTemplates.type, "custom"), isNull(promptTemplates.deletedAt)))
    .orderBy(desc(promptTemplates.createdAt))

  return NextResponse.json(makeApiOk(traceId, { items: rows.map(normalizeTemplateRow) }), { status: 200 })
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = createSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ promptTemplates })

  await db.execute(sql`
    create table if not exists public.prompt_templates (
      id text primary key default gen_random_uuid(),
      user_id text references public.users(id) on delete cascade,
      type text not null default 'custom',
      title text not null,
      content text not null,
      tags jsonb not null default '[]'::jsonb,
      is_active boolean not null default true,
      deleted_at timestamptz,
      created_at timestamptz not null default now(),
      updated_at timestamptz not null default now(),
      check (type in ('system', 'custom'))
    );
  `)

  const inserted = await db
    .insert(promptTemplates)
    .values({
      userId,
      type: "custom",
      title: parsed.data.title,
      content: parsed.data.content,
      tags: []
    })
    .returning({
      id: promptTemplates.id,
      title: promptTemplates.title,
      content: promptTemplates.content,
      tags: promptTemplates.tags,
      isActive: promptTemplates.isActive,
      createdAt: promptTemplates.createdAt,
      updatedAt: promptTemplates.updatedAt
    })

  const rec = inserted[0]
  return NextResponse.json(makeApiOk(traceId, { item: normalizeTemplateRow(rec) }), { status: 200 })
}
