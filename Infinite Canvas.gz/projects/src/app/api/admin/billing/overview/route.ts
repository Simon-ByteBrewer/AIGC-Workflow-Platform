import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getBillingOverview } from "@/server/domains/admin/billingAdmin"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"

export const runtime = "nodejs"

const querySchema = z.object({
  from: z.string().trim().optional(),
  to: z.string().trim().optional(),
  groupId: z.string().trim().optional(),
  userId: z.string().trim().optional(),
  modelName: z.string().trim().optional(),
  taskId: z.string().trim().optional(),
  requestType: z.string().trim().optional(),
  referenceMode: z.enum(["all", "with", "without"]).optional(),
  videoResolution: z.enum(["1080p", "480p/720p"]).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const startedAt = Date.now()
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    const parsed = querySchema.safeParse(Object.fromEntries(new URL(req.url).searchParams.entries()))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    const data = await getBillingOverview(actor, parsed.data)
    logger.info({
      module: "admin/billing-api",
      event: "billing_overview_request_success",
      traceId,
      message: "账单总览接口请求成功",
      actorUserId: actor.userId,
      actorRoleKey: actor.roleKey,
      durationMs: Date.now() - startedAt,
      resultSummary: { groups: data.groups.length, users: data.users.length, completedTasks: data.totals.completedTaskCount }
    } as any)
    return NextResponse.json(makeApiOk(traceId, data), { status: 200 })
  } catch (error: any) {
    logger.error({
      module: "admin/billing-api",
      event: "billing_overview_request_failed",
      traceId,
      message: "账单总览接口请求失败",
      durationMs: Date.now() - startedAt,
      errorName: error?.name,
      errorMessage: error?.message ?? "unknown",
      stack: error?.stack
    } as any)
    return NextResponse.json(makeApiErr(traceId, "BILLING_OVERVIEW_FAILED", error?.message ?? "加载账单总览失败"), { status: 500 })
  }
}
