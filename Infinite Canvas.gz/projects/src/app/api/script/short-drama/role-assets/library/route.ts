import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { storyAssetLibrary } from "@/shared/schema/generation"
import { and, desc, eq, sql } from "drizzle-orm"
import { createCozeS3Storage } from "@/server/integrations/storage/s3"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  characterKey: z.string().trim().min(1).max(200),
  frontImageUrl: z.string().trim().max(4000).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    characterKey: url.searchParams.get("characterKey") ?? "",
    frontImageUrl: url.searchParams.get("frontImageUrl") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const db = await getDb({ stories, storyAssetLibrary })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (!allowed[0]?.id) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const whereParts: any[] = [
    eq(storyAssetLibrary.storyId, parsed.data.storyId),
    sql`${storyAssetLibrary.meta} ->> 'libraryType' = 'short_drama_role_asset'`,
    sql`${storyAssetLibrary.meta} ->> 'characterKey' = ${parsed.data.characterKey}`
  ]
  const front = (parsed.data.frontImageUrl ?? "").trim()
  if (front) {
    const base = front.split("?")[0]?.trim() || ""
    if (base && base !== front) {
      whereParts.push(sql`(${storyAssetLibrary.meta} ->> 'frontImageUrl' = ${front} or ${storyAssetLibrary.meta} ->> 'frontImageUrl' = ${base})`)
    } else {
      whereParts.push(sql`${storyAssetLibrary.meta} ->> 'frontImageUrl' = ${front}`)
    }
  }

  const rows = await db
    .select({
      id: storyAssetLibrary.id,
      name: storyAssetLibrary.name,
      url: storyAssetLibrary.url,
      storageKey: storyAssetLibrary.storageKey,
      meta: storyAssetLibrary.meta,
      createdAt: storyAssetLibrary.createdAt
    })
    .from(storyAssetLibrary)
    .where(and(...whereParts))
    .orderBy(desc(storyAssetLibrary.createdAt))
    .limit(300)

  const storage = createCozeS3Storage()
  const assets = await Promise.all(rows.map(async (r) => {
    let url = r.url
    const storageKey = (r.storageKey ?? "").trim()
    if (storageKey) {
      try {
        url = await resolveStorageUrl(storage, storageKey)
      } catch (e) {
        // 如果重新生成失败，回退到数据库中保存的 URL
        url = r.url
      }
    }
    return {
      id: r.id,
      name: r.name,
      url: url,
      storageKey: r.storageKey,
      meta: r.meta as any,
      createdAt: r.createdAt
    }
  }))

  return NextResponse.json(makeApiOk(traceId, { assets }), { status: 200 })
}
