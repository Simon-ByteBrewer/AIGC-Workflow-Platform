"use client"

import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { FormEvent, useCallback, useEffect, useMemo, useState } from "react"
import styles from "./QuotaRecordsPage.module.css"
import type { ApiErr, ApiOk } from "@/shared/api"
import type {
  QuotaAllocationActionType,
  QuotaAllocationRecordItem,
  QuotaAllocationRecordScope,
  QuotaAllocationRecordTargetType
} from "@/shared/contracts/quota"

type RecordActionFilter = QuotaAllocationActionType | "all"

type ListResponse = ApiOk<{
  items: QuotaAllocationRecordItem[]
  limit: number
  offset: number
  scope: QuotaAllocationRecordScope
  targetType: QuotaAllocationRecordTargetType
  targetId: string | null
  actionType: RecordActionFilter
  startDate: string | null
  endDate: string | null
  actorName: string
}> | ApiErr

type RecordFilters = {
  actionType: RecordActionFilter
  startDate: string
  endDate: string
  actorName: string
}

async function readApiJson<T>(res: Response, fallbackMessage: string): Promise<T> {
  const raw = await res.text()
  if (!raw.trim()) {
    throw new Error(`${fallbackMessage}：接口返回为空 (HTTP ${res.status})`)
  }
  try {
    return JSON.parse(raw) as T
  } catch {
    throw new Error(`${fallbackMessage}：接口返回了非预期格式 (HTTP ${res.status})`)
  }
}

function formatTime(value: string): string {
  const date = new Date(value)
  if (!Number.isFinite(date.getTime())) return value
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, "0")
  const day = String(date.getDate()).padStart(2, "0")
  return `${year}.${month}.${day}`
}

function formatQuota(value: string | null, targetType: QuotaAllocationRecordItem["targetType"]): string {
  if (value !== null) return value
  return targetType === "group" ? "未设限额" : "未设限额"
}

function getActionLabel(actionType: QuotaAllocationRecordItem["actionType"]): string {
  if (actionType === "increase") return "增加"
  return "修改"
}

function getActionClassName(actionType: QuotaAllocationRecordItem["actionType"]): string {
  if (actionType === "increase") return styles.badgeIncrease
  return styles.badgeModify
}

function readScopeParam(value: string | null): QuotaAllocationRecordScope {
  return value === "mine" ? "mine" : "all"
}

function readTargetTypeParam(value: string | null): QuotaAllocationRecordTargetType {
  if (value === "group" || value === "user") return value
  return "all"
}

function readActionTypeParam(value: string | null): RecordActionFilter {
  if (value === "increase" || value === "modify") return value
  return "all"
}

function createFiltersFromSearchParams(searchParams: URLSearchParams): RecordFilters {
  return {
    actionType: readActionTypeParam(searchParams.get("actionType")),
    startDate: searchParams.get("startDate") ?? "",
    endDate: searchParams.get("endDate") ?? "",
    actorName: searchParams.get("actorName") ?? ""
  }
}

function getTargetSummary(targetType: QuotaAllocationRecordTargetType, targetId: string | null, targetName: string | null): string {
  if (targetId) {
    const prefix = targetType === "group" ? "分组" : targetType === "user" ? "个人" : "目标对象"
    return `${prefix}：${targetName ?? targetId}`
  }
  if (targetType === "group") return "当前仅查看分组记录"
  if (targetType === "user") return "当前仅查看个人记录"
  return "当前查看全部对象"
}

function getChangeAmountText(item: QuotaAllocationRecordItem): string {
  if (item.actionType === "modify") return "-"
  return item.changeAmount ?? "-"
}

export function QuotaRecordsPage() {
  const searchParams = useSearchParams()
  const [scope, setScope] = useState<QuotaAllocationRecordScope>(() => readScopeParam(searchParams.get("scope")))
  const [targetType, setTargetType] = useState<QuotaAllocationRecordTargetType>(() => readTargetTypeParam(searchParams.get("targetType")))
  const [targetId, setTargetId] = useState<string | null>(() => searchParams.get("targetId"))
  const [targetName, setTargetName] = useState<string | null>(() => searchParams.get("targetName"))
  const [filters, setFilters] = useState<RecordFilters>(() => createFiltersFromSearchParams(searchParams))
  const [appliedFilters, setAppliedFilters] = useState<RecordFilters>(() => createFiltersFromSearchParams(searchParams))
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [items, setItems] = useState<QuotaAllocationRecordItem[]>([])

  useEffect(() => {
    setScope(readScopeParam(searchParams.get("scope")))
    setTargetType(readTargetTypeParam(searchParams.get("targetType")))
    setTargetId(searchParams.get("targetId"))
    setTargetName(searchParams.get("targetName"))
    const nextFilters = createFiltersFromSearchParams(searchParams)
    setFilters(nextFilters)
    setAppliedFilters(nextFilters)
  }, [searchParams])

  const queryString = useMemo(() => {
    const query = new URLSearchParams()
    query.set("scope", scope)
    query.set("targetType", targetType)
    if (targetId) query.set("targetId", targetId)
    if (appliedFilters.actionType !== "all") query.set("actionType", appliedFilters.actionType)
    if (appliedFilters.startDate) query.set("startDate", appliedFilters.startDate)
    if (appliedFilters.endDate) query.set("endDate", appliedFilters.endDate)
    if (appliedFilters.actorName.trim()) query.set("actorName", appliedFilters.actorName.trim())
    query.set("limit", "100")
    query.set("offset", "0")
    return query.toString()
  }, [appliedFilters, scope, targetId, targetType])

  const currentTargetSummary = useMemo(() => {
    return getTargetSummary(targetType, targetId, targetName)
  }, [targetId, targetName, targetType])

  const resetTargetFilter = useCallback(() => {
    setTargetType("all")
    setTargetId(null)
    setTargetName(null)
  }, [])

  function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setAppliedFilters(filters)
  }

  function handleResetFilters() {
    const nextFilters: RecordFilters = {
      actionType: "all",
      startDate: "",
      endDate: "",
      actorName: ""
    }
    setFilters(nextFilters)
    setAppliedFilters(nextFilters)
  }

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/quota/records?${queryString}`, { method: "GET" })
      const json = await readApiJson<ListResponse>(res, "获取额度分配记录失败")
      if (!json.ok) {
        throw new Error(json.error.message)
      }
      setItems(json.data.items ?? [])
    } catch (err: any) {
      setError(err?.message ?? "获取额度分配记录失败")
    } finally {
      setLoading(false)
    }
  }, [queryString])

  useEffect(() => {
    void load()
  }, [load])

  return (
    <main className={styles.page}>
      <div className={styles.topBar}>
        <div>
          <div className={styles.topTitle}>额度分配记录</div>
          <div className={styles.topMeta}>{loading ? "加载中..." : `共 ${items.length} 条记录`}</div>
        </div>
        <div className={styles.topActions}>
          <Link href="/admin/quota" className={styles.topBtn}>
            返回额度分配
          </Link>
        </div>
      </div>

      <form className={styles.filtersPanel} onSubmit={handleSearch}>
        <div className={styles.filtersGrid}>
          <label className={styles.filterField}>
            <span className={styles.filterLabel}>操作类型</span>
            <select
              className={styles.filterControl}
              value={filters.actionType}
              onChange={(event) => setFilters((prev) => ({ ...prev, actionType: event.target.value as RecordActionFilter }))}
            >
              <option value="all">全部</option>
              <option value="increase">增加</option>
              <option value="modify">修改</option>
            </select>
          </label>

          <label className={styles.filterField}>
            <span className={styles.filterLabel}>操作时间</span>
            <div className={styles.dateRange}>
              <input
                type="date"
                className={styles.filterControl}
                value={filters.startDate}
                onChange={(event) => setFilters((prev) => ({ ...prev, startDate: event.target.value }))}
              />
              <span className={styles.dateDivider}>-</span>
              <input
                type="date"
                className={styles.filterControl}
                value={filters.endDate}
                onChange={(event) => setFilters((prev) => ({ ...prev, endDate: event.target.value }))}
              />
            </div>
          </label>

          <label className={styles.filterField}>
            <span className={styles.filterLabel}>操作人</span>
            <input
              type="text"
              className={styles.filterControl}
              value={filters.actorName}
              onChange={(event) => setFilters((prev) => ({ ...prev, actorName: event.target.value }))}
              placeholder="请输入操作人"
            />
          </label>

          <div className={styles.filterActions}>
            <button type="submit" className={styles.topBtnPrimary} disabled={loading}>
              查询
            </button>
            <button type="button" className={styles.topBtn} onClick={handleResetFilters} disabled={loading}>
              重置
            </button>
          </div>
        </div>
      </form>

      {targetId || targetType !== "all" || scope !== "all" ? (
        <div className={styles.filterBanner}>
          <span>
            {currentTargetSummary}
            {scope === "mine" ? " · 当前仅查看我的操作记录" : ""}
          </span>
          {targetId || targetType !== "all" ? (
            <button type="button" className={styles.topBtn} onClick={resetTargetFilter}>
              查看全部对象
            </button>
          ) : null}
        </div>
      ) : null}

      {error ? <div className={styles.error}>{error}</div> : null}

      <section className={styles.panel} aria-label="额度分配记录列表">
        <div className={styles.thead}>
          <div>操作类型</div>
          <div>操作对象</div>
          <div>操作额度</div>
          <div>操作前余额</div>
          <div>操作后余额</div>
          <div>操作时间</div>
          <div>操作人</div>
        </div>
        <div className={styles.tbody}>
          {items.map((item) => (
            <div key={item.id} className={styles.row}>
              <div>
                <span className={`${styles.badge} ${getActionClassName(item.actionType)}`}>{getActionLabel(item.actionType)}</span>
              </div>
              <div className={styles.primary}>{item.targetDisplayName}</div>
              <div className={styles.primary}>{getChangeAmountText(item)}</div>
              <div className={styles.primary}>{formatQuota(item.beforeQuota, item.targetType)}</div>
              <div className={styles.primary}>{formatQuota(item.afterQuota, item.targetType)}</div>
              <div className={styles.primary}>{formatTime(item.createdAt)}</div>
              <div>
                <div className={styles.primary}>{item.actorName}</div>
                <div className={styles.secondary}>{item.actorUserId}</div>
              </div>
            </div>
          ))}
          {!loading && items.length === 0 ? <div className={styles.empty}>暂无额度分配记录</div> : null}
        </div>
      </section>
    </main>
  )
}
