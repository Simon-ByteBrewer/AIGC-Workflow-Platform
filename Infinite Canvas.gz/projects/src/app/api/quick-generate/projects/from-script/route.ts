import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { createQuickGenerateProjectFromScript } from "@/server/domains/quick-generate/usecases/createQuickGenerateProjectFromScript"

export const runtime = "nodejs"

const postSchema = z
  .object({
    sourceStoryId: z.string().trim().min(1)
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    logger.info({
      event: "quick_generate_project_from_script_start",
      module: "quick_generate",
      traceId,
      message: "开始从剧本创建快速生成项目"
    })

    const result = await createQuickGenerateProjectFromScript({
      traceId,
      userId,
      sourceStoryId: parsed.data.sourceStoryId
    })

    logger.info({
      event: "quick_generate_project_from_script_success",
      module: "quick_generate",
      traceId,
      message: "从剧本创建快速生成项目成功",
      durationMs: Date.now() - start,
      storyId: result.storyId,
      projectId: result.projectId,
      groupId: result.groupId,
      importedCount: result.importedCount
    })
    return NextResponse.json(makeApiOk(traceId, result), { status: 200 })
  } catch (error) {
    const anyErr = error as { message?: string }
    logger.error({
      event: "quick_generate_project_from_script_failed",
      module: "quick_generate",
      traceId,
      message: "从剧本创建快速生成项目失败",
      durationMs: Date.now() - start,
      errorMessage: anyErr?.message
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", anyErr?.message?.trim() || "创建快速生成项目失败"), { status: 500 })
  }
}
