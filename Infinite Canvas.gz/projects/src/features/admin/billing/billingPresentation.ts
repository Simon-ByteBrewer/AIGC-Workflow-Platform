import type { BillingDetailItem } from "@/shared/contracts/billing"
import { normalizeExternalImageModelCode } from "@/shared/image/externalImageModels"

/**
 * 账单页面展示映射。
 * 说明：统一收敛筛选选项、枚举文案与数值格式化，避免页面组件散落业务口径。
 */
export const REFERENCE_MODE_OPTIONS = [
  { value: "all", label: "全部参考视频" },
  { value: "with", label: "有参考视频" },
  { value: "without", label: "无参考视频" }
] as const

export const VIDEO_RESOLUTION_OPTIONS = [
  { value: "all", label: "全部分辨率" },
  { value: "1080p", label: "1080p" },
  { value: "480p/720p", label: "480p/720p" }
] as const

const REQUEST_TYPE_LABELS: Record<string, string> = {
  video_generate: "视频生成",
  canvas_image_generate: "画布生图",
  quick_generate_panel_image_generate: "分镜板生图",
  image_generate: "图片生成"
}

const RESOURCE_TYPE_LABELS: Record<string, string> = {
  video: "视频",
  image: "图片"
}

const MODEL_SOURCE_LABELS: Record<"internal" | "external", string> = {
  internal: "内部模型",
  external: "外部模型"
}

function formatCountLike(value: number, digits: number): string {
  const text = value.toFixed(digits)
  return text.replace(/\.?0+$/, "")
}

export function formatTaskTypeLabel(requestType: string): string {
  if (REQUEST_TYPE_LABELS[requestType]) return REQUEST_TYPE_LABELS[requestType]
  if (requestType.includes("image") && requestType.includes("generate")) return "图片生成"
  if (requestType.includes("video") && requestType.includes("generate")) return "视频生成"
  return REQUEST_TYPE_LABELS[requestType] ?? requestType
}

export function formatResourceTypeLabel(resourceType: string): string {
  return RESOURCE_TYPE_LABELS[resourceType] ?? resourceType
}

export function formatVideoResolutionLabel(resolution: string | null | undefined): string {
  if (!resolution) return "-"
  return resolution === "other" ? "480p/720p" : resolution
}

export function formatTokenMillions(tokens: number): string {
  return formatCountLike(tokens / 1_000_000, 4)
}

export function formatJobStatusLabel(status: "queued" | "running" | "done" | "error" | null | undefined): string {
  if (status === "queued") return "排队中"
  if (status === "running") return "处理中"
  if (status === "done") return "已完成"
  if (status === "error") return "任务失败"
  return "-"
}

/**
 * 统一展示账单查询区间，避免列表、详情与任务查询弹窗各自拼接日期文案。
 */
export function formatBillingDateRange(from?: string, to?: string): string {
  const start = (from ?? "").trim()
  const end = (to ?? "").trim()
  if (start && end) return `${start} - ${end}`
  if (start) return `${start} - 至今`
  if (end) return `开始时间未设 - ${end}`
  return "全部日期"
}

export function formatBillingDateTime(value?: string | null): string {
  if (!value) return "-"
  const date = new Date(value)
  if (!Number.isFinite(date.getTime())) return value
  return date.toLocaleString()
}

export function formatReferenceVideoLabel(item: Pick<BillingDetailItem, "resourceType" | "hasReference" | "hasReferenceVideo">): string {
  if (item.resourceType === "image") return item.hasReference ? "有参考图" : "无参考图"
  return item.hasReferenceVideo ? "有视频" : "无视频"
}

export function formatModelSourceLabel(item: Pick<BillingDetailItem, "resourceType" | "modelName">): string {
  if (item.resourceType === "image") {
    return normalizeExternalImageModelCode(item.modelName) ? MODEL_SOURCE_LABELS.external : MODEL_SOURCE_LABELS.internal
  }
  return "-"
}

export function formatBillingUnitPrice(item: Pick<BillingDetailItem, "unitPrice" | "unitPriceUnit">): string {
  if (item.unitPriceUnit === "yuan_per_image") return `${item.unitPrice} 元/张`
  if (item.unitPriceUnit === "yuan_per_million_tokens") return `${item.unitPrice} 元/百万Token`
  return item.unitPrice
}

export function formatBillingUsageLines(
  item: Pick<BillingDetailItem, "resourceType" | "tokens" | "quantity" | "resolution" | "durationSeconds" | "hasReference" | "hasReferenceVideo">
): string[] {
  if (item.resourceType === "image") {
    const quantity = Number.parseFloat(item.quantity || "0")
    const quantityText = Number.isFinite(quantity) ? `${formatCountLike(quantity, 4)} 张` : `${item.quantity} 张`
    return [quantityText, item.hasReference ? "有参考图" : "无参考图"]
  }

  const durationText = item.durationSeconds === null ? "-" : `${item.durationSeconds} 秒`
  return [
    `${formatTokenMillions(item.tokens)} 百万Token`,
    `${formatVideoResolutionLabel(item.resolution)} / ${durationText}`,
    item.hasReferenceVideo ? "有参考视频" : "无参考视频"
  ]
}
