import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { quickGenerateMaterials } from "@/shared/schema"
import { assertQuickGenerateMaterialTitleAvailable } from "@/server/domains/quick-generate/materialTitleUniqueness"
import { eq, inArray } from "drizzle-orm"

const patchSchema = z.object({
  id: z.string().trim().min(1),
  title: z.string().trim().min(1).max(200)
})

export async function PATCH(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  try {
    const session = await getSessionFromRequest(req)
    if (!session?.userId) {
      return NextResponse.json(makeApiErr(traceId, "UNAUTHORIZED", "未登录"), { status: 401 })
    }

    const body = await req.json().catch(() => ({}))
    const parsed = patchSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "参数错误: " + parsed.error.message), { status: 400 })
    }

    const { id, title } = parsed.data
    const db = await getDb({ quickGenerateMaterials })

    const existingRows = await db
      .select({
        id: quickGenerateMaterials.id,
        storyId: quickGenerateMaterials.storyId,
        materialType: quickGenerateMaterials.materialType
      })
      .from(quickGenerateMaterials)
      .where(eq(quickGenerateMaterials.id, id))
      .limit(1)
    const existing = existingRows[0]
    if (!existing) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到该素材"), { status: 404 })
    }

    await assertQuickGenerateMaterialTitleAvailable({
      db,
      storyId: existing.storyId,
      materialType: existing.materialType,
      title,
      excludeId: id,
      action: "修改"
    })

    const updated = await db
      .update(quickGenerateMaterials)
      .set({ title, updatedAt: new Date() })
      .where(eq(quickGenerateMaterials.id, id))
      .returning()
    return NextResponse.json(makeApiOk(traceId, updated[0]))
  } catch (error: any) {
    const status = Number.isInteger(error?.status) ? Number(error.status) : 500
    const code = String(error?.code ?? "").trim() || "INTERNAL_ERROR"
    return NextResponse.json(makeApiErr(traceId, code, error.message || "更新失败"), { status })
  }
}

const deleteSchema = z.object({
  ids: z.array(z.string().trim().min(1)).min(1)
})

/**
 * 优先从 query string 读取批量删除参数，兼容旧版 DELETE body 传参。
 */
async function resolveDeleteMaterialIds(req: NextRequest): Promise<unknown> {
  const queryIds = req.nextUrl.searchParams.get("ids")?.trim()
  if (queryIds) {
    try {
      return { ids: JSON.parse(queryIds) }
    } catch {
      return { ids: null }
    }
  }

  return await req.json().catch(() => ({}))
}

export async function DELETE(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  try {
    const session = await getSessionFromRequest(req)
    if (!session?.userId) {
      return NextResponse.json(makeApiErr(traceId, "UNAUTHORIZED", "未登录"), { status: 401 })
    }

    const body = await resolveDeleteMaterialIds(req)
    const parsed = deleteSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "参数错误: " + parsed.error.message), { status: 400 })
    }

    const { ids } = parsed.data
    const db = await getDb({ quickGenerateMaterials })

    // 执行批量删除
    await db
      .delete(quickGenerateMaterials)
      .where(inArray(quickGenerateMaterials.id, ids))

    return NextResponse.json(makeApiOk(traceId, { deletedCount: ids.length }))
  } catch (error: any) {
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", error.message || "删除失败"), { status: 500 })
  }
}
