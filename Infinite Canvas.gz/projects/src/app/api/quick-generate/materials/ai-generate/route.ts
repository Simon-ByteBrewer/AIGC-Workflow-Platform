import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { generateQuickGenerateMaterialsByAi } from "@/server/domains/quick-generate/usecases/generateQuickGenerateMaterialsByAi"

export const runtime = "nodejs"

const postSchema = z
  .object({
    storyId: z.string().trim().min(1).max(200),
    materialType: z.enum(["scene", "character", "prop"]),
    name: z.string().trim().min(1).max(200),
    prompt: z.string().trim().min(1).max(20_000),
    style: z.string().trim().max(200).optional()
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const result = await generateQuickGenerateMaterialsByAi({
      traceId,
      userId,
      storyId: parsed.data.storyId,
      materialType: parsed.data.materialType,
      name: parsed.data.name,
      prompt: parsed.data.prompt,
      style: parsed.data.style
    })
    return NextResponse.json(makeApiOk(traceId, result), { status: 200 })
  } catch (error) {
    const anyErr = error as { message?: string; name?: string; stack?: string }
    const status =
      typeof (anyErr as { status?: unknown })?.status === "number" ? Number((anyErr as { status?: unknown }).status) : 500
    const code = String((anyErr as { code?: unknown })?.code ?? "").trim() || "UNKNOWN"
    logger.error({
      event: "quick_generate_material_ai_generate_failed",
      module: "quick_generate",
      traceId,
      message: "AI 生成 quick-generate 素材失败",
      durationMs: Date.now() - start,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, code, anyErr?.message?.trim() || "AI 生成素材失败"), { status })
  }
}
