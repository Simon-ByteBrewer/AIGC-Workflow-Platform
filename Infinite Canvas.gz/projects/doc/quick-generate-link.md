# 新建剧本-快速生成文档索引

## 1. 文档说明

本文档作为“新建剧本 -> 快速生成”链路的总索引页，统一指向已经拆分后的两份子文档：

- 功能说明文档
- 接口说明文档

如果你只想快速了解链路怎么走、页面有哪些能力，优先看功能说明。

如果你要联调接口、补参数、查返回结构，优先看接口说明。

## 2. 子文档入口

### 2.1 功能说明

- 文档地址：[quick-generate-overview.md](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/doc/quick-generate-overview.md)
- 适用对象：产品、前端、业务同学
- 主要内容：
  - 入口链路
  - 页面结构
  - 当前已支持功能
  - 异步任务说明

### 2.2 接口说明

- 文档地址：[quick-generate-api.md](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/doc/quick-generate-api.md)
- 适用对象：后端、前端联调、测试同学
- 主要内容：
  - quick-generate 主接口
  - 依赖接口
  - 输入参数
  - 输出参数
  - 常见错误码

## 3. 当前链路范围

当前“新建剧本 -> 快速生成”链路已覆盖以下能力：

- 快速创建项目
- 从已有剧本派生 quick-generate 项目
- 素材上传、AI 生成、版权库导入、送审
- 剧集创建、分镜编辑、提示词生成、视频生成
- 视频定版与剪映导出

## 4. 阅读建议

- 先看 [quick-generate-overview.md](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/doc/quick-generate-overview.md) 理解业务链路
- 再看 [quick-generate-api.md](file:///Users/bytedance/Desktop/seedance2.0-sevencat/short-drama/doc/quick-generate-api.md) 对照接口联调
