import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { publicResources } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const rawParams = await ctx.params
  const parsed = paramsSchema.safeParse(rawParams)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  const db = await getDb({ publicResources })
  const rows = await db
    .select({
      id: publicResources.id,
      userId: publicResources.userId,
      voiceAudioStorageKey: publicResources.voiceAudioStorageKey
    })
    .from(publicResources)
    .where(and(eq(publicResources.id, parsed.data.id), eq(publicResources.userId, userId)))
    .limit(1)
  const row = rows[0]
  if (!row?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
  if (!row.voiceAudioStorageKey) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "音色未绑定"), { status: 404 })

  const storage = getS3Storage()
  try {
    const url = await resolveStorageUrl(storage, row.voiceAudioStorageKey)
    return NextResponse.redirect(url)
  } catch {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "资源不存在"), { status: 404 })
  }
}
