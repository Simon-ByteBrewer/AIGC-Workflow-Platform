import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { stories } from "@/shared/schema"
import { downloadBinary } from "@/server/lib/http/downloadBinary"
import { uploadPublicBuffer } from "@/shared/storage"
import { getSpeakerName } from "@/features/tts/speakers"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  characterKey: z.string().trim().min(1).max(200),
  speakerId: z.string().trim().min(1).max(200),
  speakerName: z.string().trim().max(200).optional(),
  audioUrl: z.string().trim().min(1).max(4000)
})

function safeSegment(input: string): string {
  return String(input ?? "")
    .trim()
    .replaceAll(/[^a-zA-Z0-9._:-]/gu, "_")
    .slice(0, 120)
}

function fileExtFromContentType(contentType: string): string {
  const raw = (contentType ?? "").trim().toLowerCase()
  if (raw.includes("wav")) return "wav"
  if (raw.includes("mpeg") || raw.includes("mp3")) return "mp3"
  if (raw.includes("ogg")) return "ogg"
  if (raw.includes("aac")) return "aac"
  if (raw.includes("mp4") || raw.includes("m4a")) return "m4a"
  return "bin"
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { storyId, characterKey, speakerId } = parsed.data
  const speakerName = parsed.data.speakerName?.trim() || getSpeakerName(speakerId) || speakerId

  const db = await getDb({ stories })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, storyId), eq(stories.userId, userId)))
    .limit(1)
  if (!allowed[0]?.id) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  let downloaded: { buffer: Buffer; contentType: string | null }
  try {
    downloaded = await downloadBinary(parsed.data.audioUrl, traceId, 120_000)
  } catch {
    return NextResponse.json(makeApiErr(traceId, "ASSET_DOWNLOAD_FAILED", "下载音色失败"), { status: 400 })
  }

  const contentType = downloaded.contentType ?? "audio/mpeg"
  const fileExt = fileExtFromContentType(contentType)
  const prefix = `public/short-drama/role-voices/${safeSegment(storyId)}/${safeSegment(characterKey)}`
  const uploaded = await uploadPublicBuffer({ buffer: downloaded.buffer, contentType, fileExt, prefix })

  return NextResponse.json(
    makeApiOk(traceId, {
      voiceSpeakerId: speakerId,
      voiceSpeakerName: speakerName,
      voiceAudioStorageKey: uploaded.key
    }),
    { status: 200 }
  )
}
