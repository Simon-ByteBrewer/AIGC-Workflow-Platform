import type { ApiErr, ApiOk } from "@/shared/api"
import type { BillingDetailsResponse, BillingFilter, BillingOverview, BillingTaskQueryResponse } from "@/shared/contracts/billing"
import { REFERENCE_MODE_OPTIONS, VIDEO_RESOLUTION_OPTIONS } from "./billingPresentation"

export type OverviewResponse = ApiOk<BillingOverview> | ApiErr
export type DetailsResponse = ApiOk<BillingDetailsResponse> | ApiErr
export type TaskResponse = ApiOk<BillingTaskQueryResponse> | ApiErr

export { REFERENCE_MODE_OPTIONS, VIDEO_RESOLUTION_OPTIONS }

function formatDateInputValue(date: Date): string {
  return date.toISOString().slice(0, 10)
}

/**
 * 账单统计默认聚焦最近 30 天，避免首次进入直接查询全量历史数据。
 */
export function getDefaultBillingDateRange(): Pick<BillingFilter, "from" | "to"> {
  const to = new Date()
  const from = new Date(to)
  from.setDate(from.getDate() - 29)
  return {
    from: formatDateInputValue(from),
    to: formatDateInputValue(to)
  }
}

/**
 * 统一解析账单接口返回，避免前端重复处理空响应与非 JSON 异常。
 */
export async function readApiJson<T>(res: Response, fallbackMessage: string): Promise<T> {
  const raw = await res.text()
  if (!raw.trim()) {
    throw new Error(`${fallbackMessage}：接口返回为空 (HTTP ${res.status})`)
  }
  try {
    return JSON.parse(raw) as T
  } catch {
    throw new Error(`${fallbackMessage}：接口返回了非预期格式 (HTTP ${res.status})`)
  }
}

/**
 * 将账单筛选参数统一编码到 URL 查询串，确保总览、详情与任务查询口径一致。
 */
export function buildBillingSearchParams(filter: BillingFilter): string {
  const sp = new URLSearchParams()
  if (filter.from) sp.set("from", filter.from)
  if (filter.to) sp.set("to", filter.to)
  if ((filter.groupId ?? "").trim()) sp.set("groupId", filter.groupId!.trim())
  if ((filter.userId ?? "").trim()) sp.set("userId", filter.userId!.trim())
  if ((filter.modelName ?? "").trim()) sp.set("modelName", filter.modelName!.trim())
  if ((filter.taskId ?? "").trim()) sp.set("taskId", filter.taskId!.trim())
  if ((filter.videoTaskId ?? "").trim()) sp.set("videoTaskId", filter.videoTaskId!.trim())
  if ((filter.requestType ?? "").trim()) sp.set("requestType", filter.requestType!.trim())
  if (filter.referenceMode && filter.referenceMode !== "all") sp.set("referenceMode", filter.referenceMode)
  if (filter.videoResolution) sp.set("videoResolution", filter.videoResolution)
  return sp.toString()
}

function parseAttachmentFileName(contentDisposition: string | null): string | null {
  if (!contentDisposition) return null
  const match = contentDisposition.match(/filename="([^"]+)"/i)
  return match?.[1] ?? null
}

/**
 * 下载导出接口返回的二进制内容，并尽量使用服务端指定的文件名。
 */
export async function downloadFileResponse(res: Response, fallbackFileName: string): Promise<void> {
  const fileName = parseAttachmentFileName(res.headers.get("content-disposition")) ?? fallbackFileName
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement("a")
  anchor.href = url
  anchor.download = fileName
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  URL.revokeObjectURL(url)
}
