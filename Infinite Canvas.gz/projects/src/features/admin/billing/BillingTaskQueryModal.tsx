"use client"

import { useMemo, useState } from "react"
import type { BillingFilter, BillingTaskQueryResponse } from "@/shared/contracts/billing"
import { BillingDetailTable } from "./BillingDetailTable"
import { buildBillingSearchParams, type TaskResponse, readApiJson } from "./billingApi"
import { BillingModalShell } from "./BillingModalShell"
import { formatBillingDateRange, formatBillingDateTime, formatJobStatusLabel, formatTaskTypeLabel } from "./billingPresentation"
import styles from "./BillingPage.module.css"

type BillingTaskQueryModalProps = {
  initialFilter: Pick<BillingFilter, "from" | "to">
  onClose: () => void
}

/**
 * 任务账单查询弹窗。
 * 说明：任务查询只保留日期和任务 ID 两个条件，结果仅在弹窗内展示，避免污染主页面总览状态。
 */
export function BillingTaskQueryModal({ initialFilter, onClose }: BillingTaskQueryModalProps) {
  const [from, setFrom] = useState(initialFilter.from ?? "")
  const [to, setTo] = useState(initialFilter.to ?? "")
  const [taskId, setTaskId] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [taskData, setTaskData] = useState<BillingTaskQueryResponse | null>(null)

  const dateRangeText = useMemo(() => formatBillingDateRange(from, to), [from, to])
  const hint = loading
    ? "查询中..."
    : taskData
      ? taskData.mode === "billing"
        ? `日期范围 ${dateRangeText}，账单记录 ${taskData.items.length} 条，花费 ${taskData.totalCost}`
        : `日期范围 ${dateRangeText}，${taskData.taskStatusMessage ?? taskData.taskStatusLabel ?? "已返回任务状态"}`
      : `输入任务 ID 后查询，当前日期范围 ${dateRangeText}`

  async function searchTask() {
    if (!taskId.trim()) {
      setTaskData(null)
      setError("请输入任务 ID")
      return
    }
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/billing/task?${buildBillingSearchParams({ from, to, taskId })}`)
      const json = await readApiJson<TaskResponse>(res, "查询任务账单失败")
      if (!json.ok) throw new Error(json.error.message)
      setTaskData(json.data)
    } catch (e: any) {
      setError(e?.message ?? "查询任务账单失败")
      setTaskData(null)
    } finally {
      setLoading(false)
    }
  }

  function handleReset() {
    setFrom(initialFilter.from ?? "")
    setTo(initialFilter.to ?? "")
    setTaskId("")
    setTaskData(null)
    setError(null)
  }

  return (
    <BillingModalShell title="查询任务" hint={hint} onClose={onClose}>
      <section className={styles.taskQueryFilters}>
        <input type="date" className={styles.input} value={from} onChange={(e) => setFrom(e.target.value)} />
        <input type="date" className={styles.input} value={to} onChange={(e) => setTo(e.target.value)} />
        <input className={styles.input} value={taskId} onChange={(e) => setTaskId(e.target.value)} placeholder="任务 ID" />
        <div className={styles.filterActions}>
          <button className={styles.btn} onClick={() => void searchTask()} disabled={loading}>
            查询
          </button>
          <button className={styles.btnSecondary} onClick={handleReset} disabled={loading}>
            重置条件
          </button>
        </div>
      </section>

      {error ? <div className={styles.error}>{error}</div> : null}

      {taskData ? (
        <section className={styles.taskResult}>
          <div className={styles.sectionTitle}>任务账单结果</div>
          {taskData.mode === "billing" ? (
            <>
              <div className={styles.taskMeta}>日期范围 {dateRangeText}，任务 {taskData.taskId}，账单记录 {taskData.items.length} 条，花费 {taskData.totalCost}</div>
              <BillingDetailTable items={taskData.items} />
            </>
          ) : (
            <div className={styles.taskStatusCard}>
              <div className={styles.taskStatusHeader}>
                <div>
                  <div className={styles.taskStatusTitle}>{taskData.taskStatusLabel ?? "任务状态"}</div>
                  <div className={styles.taskMeta}>任务 {taskData.taskId}</div>
                </div>
                <div className={styles.taskStatusBadge}>{formatJobStatusLabel(taskData.taskStatus)}</div>
              </div>
              <div className={styles.taskStatusGrid}>
                <div className={styles.taskStatusItem}>
                  <div className={styles.summaryLabel}>查询结论</div>
                  <div className={styles.taskStatusValue}>{taskData.taskStatusMessage ?? "-"}</div>
                </div>
                <div className={styles.taskStatusItem}>
                  <div className={styles.summaryLabel}>任务类型</div>
                  <div className={styles.taskStatusValue}>{taskData.taskType ? formatTaskTypeLabel(taskData.taskType) : "-"}</div>
                </div>
                <div className={styles.taskStatusItem}>
                  <div className={styles.summaryLabel}>创建时间</div>
                  <div className={styles.taskStatusValue}>{formatBillingDateTime(taskData.taskCreatedAt)}</div>
                </div>
                <div className={styles.taskStatusItem}>
                  <div className={styles.summaryLabel}>更新时间</div>
                  <div className={styles.taskStatusValue}>{formatBillingDateTime(taskData.taskUpdatedAt)}</div>
                </div>
                <div className={styles.taskStatusItem}>
                  <div className={styles.summaryLabel}>结束时间</div>
                  <div className={styles.taskStatusValue}>{formatBillingDateTime(taskData.taskFinishedAt)}</div>
                </div>
                <div className={styles.taskStatusItem}>
                  <div className={styles.summaryLabel}>日期范围</div>
                  <div className={styles.taskStatusValue}>{dateRangeText}</div>
                </div>
                {taskData.taskErrorMessage ? (
                  <div className={styles.taskStatusItemWide}>
                    <div className={styles.summaryLabel}>失败原因</div>
                    <div className={styles.taskStatusValue}>{taskData.taskErrorMessage}</div>
                  </div>
                ) : null}
              </div>
            </div>
          )}
        </section>
      ) : (
        <div className={styles.empty}>请输入日期和任务 ID 后查询</div>
      )}
    </BillingModalShell>
  )
}
