import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { extractTextFromEpisodeSourceFile } from "@/server/domains/quick-generate/usecases/extractTextFromEpisodeSourceFile"

/**
 * 模块说明
 *
 * 为“新增剧集”提供文件导入能力：
 * - 接收 pdf/docx/txt 文件
 * - 提取纯文本
 * - 返回给前端继续复用现有分镜大纲解析链路
 */

export const runtime = "nodejs"

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  try {
    const formData = await req.formData()
    const file = formData.get("file")
    if (!(file instanceof File)) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "文件不能为空"), { status: 400 })
    }

    logger.info({
      event: "quick_generate_episode_import_text_start",
      module: "quick_generate",
      traceId,
      message: "开始导入剧集源文件文本",
      fileName: file.name,
      fileType: file.type,
      fileSize: file.size
    })

    const buffer = Buffer.from(await file.arrayBuffer())
    const result = await extractTextFromEpisodeSourceFile({
      fileName: file.name,
      mimeType: file.type,
      buffer
    })

    logger.info({
      event: "quick_generate_episode_import_text_success",
      module: "quick_generate",
      traceId,
      message: "剧集源文件文本导入成功",
      durationMs: Date.now() - start,
      fileName: file.name,
      sourceKind: result.sourceKind,
      charCount: result.content.length
    })

    return NextResponse.json(
      makeApiOk(traceId, {
        fileName: file.name,
        sourceKind: result.sourceKind,
        content: result.content,
        charCount: result.content.length
      })
    )
  } catch (e) {
    const err = e as { code?: string; name?: string; message?: string; stack?: string }
    const code = err?.code?.trim() || "UNKNOWN"
    const status = code === "UNKNOWN" ? 500 : 400

    logger.error({
      event: "quick_generate_episode_import_text_failed",
      module: "quick_generate",
      traceId,
      message: "剧集源文件文本导入失败",
      durationMs: Date.now() - start,
      errorCode: code,
      errorName: err?.name,
      errorMessage: err?.message,
      stack: status === 500 ? err?.stack : undefined
    })

    return NextResponse.json(makeApiErr(traceId, code, err?.message?.trim() || "导入文件失败"), { status })
  }
}
