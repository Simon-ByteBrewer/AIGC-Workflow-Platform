import { NextResponse, type NextRequest } from "next/server"
import { and, eq, isNull, ne } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories, storyOutlines, videoCanvasGraphs } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  search: z.string().trim().max(100).optional(),
  mediaType: z.enum(["image", "video", "audio"]).optional()
})

type OtherEpisodeAssetItem = {
  id: string
  title: string
  mediaType: "image" | "video" | "audio"
  sourceAssetId: string
  sourceUrl: string
  previewUrl: string
  sourceStorageKey: string
  previewStorageKey: string
  mimeType: string
  sizeBytes?: number | null
  reviewAssetId: string
  reviewStatus: "Active"
  sourceType: "current_other_episode"
  sourceProjectStoryId: string
  sourceProjectTitle: string
}

type OtherEpisodeGroup = {
  outlineId: string
  sequence: number
  items: OtherEpisodeAssetItem[]
}

/**
 * 统一清洗文本字段，避免图内节点参数出现空白差异。
 */
function trimText(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

/**
 * 确保 graph_json 节点数组读取稳定。
 */
function safeArray<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : []
}

/**
 * 校验当前用户是否有权访问指定画布项目。
 */
async function assertStoryAccess(input: {
  storyId: string
  userId: string
}): Promise<boolean> {
  const db = await getDb({ stories })
  const rows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, input.storyId), eq(stories.userId, input.userId)))
    .limit(1)
  return rows.length > 0
}

/**
 * 根据资源节点类型映射版权库面板要展示的媒体类型。
 */
function toCanvasMediaType(nodeType: string): "image" | "video" | "audio" | null {
  if (nodeType === "image_resource") return "image"
  if (nodeType === "video_resource") return "video"
  if (nodeType === "audio_resource") return "audio"
  return null
}

/**
 * 从其他集的画布图中抽取已过审资源节点，供当前集快捷引入。
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({
    storyId: req.nextUrl.searchParams.get("storyId") ?? "",
    outlineId: req.nextUrl.searchParams.get("outlineId") ?? "",
    search: req.nextUrl.searchParams.get("search") ?? undefined,
    mediaType: req.nextUrl.searchParams.get("mediaType") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const allowed = await assertStoryAccess({ storyId: parsed.data.storyId, userId })
  if (!allowed) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用项目"), { status: 404 })

  const db = await getDb({ stories, storyOutlines, videoCanvasGraphs })
  const storyRows = await db
    .select({ title: stories.title })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  const projectTitle = trimText(storyRows[0]?.title) || "当前画布项目"

  const outlines = await db
    .select({ id: storyOutlines.id, sequence: storyOutlines.sequence })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.storyId, parsed.data.storyId), ne(storyOutlines.id, parsed.data.outlineId), isNull(storyOutlines.deletedAt)))
    .orderBy(storyOutlines.sequence)

  const graphs = await db
    .select({ outlineId: videoCanvasGraphs.outlineId, graphJson: videoCanvasGraphs.graphJson })
    .from(videoCanvasGraphs)
    .where(and(eq(videoCanvasGraphs.storyId, parsed.data.storyId), isNull(videoCanvasGraphs.deletedAt)))

  const graphByOutlineId = new Map(graphs.map((item) => [trimText(item.outlineId), item.graphJson]))
  const search = trimText(parsed.data.search).toLowerCase()
  const groups: OtherEpisodeGroup[] = []

  for (const outline of outlines) {
    const graphJson = graphByOutlineId.get(trimText(outline.id))
    const nodes = safeArray<any>((graphJson as any)?.nodes)
    const items: OtherEpisodeAssetItem[] = []

    for (const node of nodes) {
      const mediaType = toCanvasMediaType(trimText(node?.type))
      if (!mediaType) continue
      if (parsed.data.mediaType && mediaType !== parsed.data.mediaType) continue

      const params = (node?.params ?? {}) as Record<string, unknown>
      const reviewStatus = trimText(params.copyrightStatus)
      const reviewAssetId = trimText(params.copyrightAssetId)
      const sourceUrl = trimText(params.url)
      if (reviewStatus !== "Active" || !reviewAssetId || !sourceUrl) continue

      const title = trimText(params.displayName) || "未命名素材"
      const sourceAssetId = trimText(params.assetId)
      if (
        search &&
        !title.toLowerCase().includes(search) &&
        !sourceAssetId.toLowerCase().includes(search) &&
        !reviewAssetId.toLowerCase().includes(search)
      ) {
        continue
      }

      items.push({
        id: `${trimText(outline.id)}:${trimText(node?.id) || reviewAssetId}`,
        title,
        mediaType,
        sourceAssetId,
        sourceUrl,
        previewUrl: mediaType === "image" ? trimText(params.previewUrl) || sourceUrl : "",
        sourceStorageKey: trimText(params.sourceStorageKey),
        previewStorageKey: trimText(params.previewStorageKey),
        mimeType: trimText(params.fileMime),
        sizeBytes: typeof params.fileSizeBytes === "number" && Number.isFinite(params.fileSizeBytes) ? params.fileSizeBytes : null,
        reviewAssetId,
        reviewStatus: "Active",
        sourceType: "current_other_episode",
        sourceProjectStoryId: parsed.data.storyId,
        sourceProjectTitle: projectTitle
      })
    }

    if (items.length > 0) {
      groups.push({
        outlineId: trimText(outline.id),
        sequence: typeof outline.sequence === "number" ? outline.sequence : 0,
        items
      })
    }
  }

  return NextResponse.json(makeApiOk(traceId, { episodes: groups }), { status: 200 })
}
