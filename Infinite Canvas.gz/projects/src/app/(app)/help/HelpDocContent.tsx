import Link from "next/link"
import type { ReactElement } from "react"
import styles from "./HelpDoc.module.css"

export type DocSection = {
  id: string
  title: string
  content: ReactElement
}

function InlineCode({ children }: { children: string }): ReactElement {
  return <span className={styles.inlineCode}>{children}</span>
}

function CodeBlock({ children }: { children: string }): ReactElement {
  return (
    <pre className={styles.codeBlock}>
      <code>{children}</code>
    </pre>
  )
}

function Callout({ title, children }: { title: string; children: ReactElement }): ReactElement {
  return (
    <div className={styles.callout}>
      <div className={styles.calloutTitle}>{title}</div>
      <div className={styles.calloutText}>{children}</div>
    </div>
  )
}

export function buildHelpSections(): DocSection[] {
  return [
    {
      id: "quickstart",
      title: "快速开始",
      content: (
        <>
          <p className={styles.p}>
            帮助中心推荐按“内容库 → 剧本创作 → 视频创作”的顺序使用；其中视频创作包含分镜创作与无限画布创作两种路径。
          </p>
          <ul className={styles.list}>
            <li>
              从 <Link className={styles.link} href="/library">内容库</Link> 继续已有项目，或直接创建项目作为新的创作起点。
            </li>
            <li>
              在 <Link className={styles.link} href="/script/workspace?entry=nav">剧本创作</Link> 从剧情简介开始，先完成角色、妆造、音色、大纲、正文、口播与素材准备。
            </li>
            <li>
              在 <Link className={styles.link} href="/video?tab=list">视频创作</Link> 从剧本原文开始生成分镜文本、首帧图与分镜视频；如需更灵活的节点式制作，可进入无限画布创作。
            </li>
          </ul>
          <Callout title="推荐路径">
            <span>
              如果你是第一次使用，建议先从 <Link className={styles.link} href="/library">内容库</Link> 创建项目，再进入
              <Link className={styles.link} href="/script/workspace?entry=nav">剧本创作</Link> 完成前置内容，最后进入
              <Link className={styles.link} href="/video?tab=list">视频创作</Link> 或无限画布创作。
            </span>
          </Callout>
        </>
      )
    },
    {
      id: "auth",
      title: "账号与登录",
      content: (
        <>
          <h3 id="login" className={styles.h3}>
            登录
          </h3>
          <p className={styles.p}>
            访问需要登录的页面时，如果会话已过期会提示去登录。登录成功后，会在右上角显示账号信息，并可点击退出。
          </p>
          <ul className={styles.list}>
            <li>
              登录页：<Link className={styles.link} href="/login">/login</Link>
            </li>
            <li>
              会话 cookie：<InlineCode>ai_video_session</InlineCode>
            </li>
          </ul>
          <Callout title="开发环境提示">
            <span>
              如果服务端日志出现 <InlineCode>AUTH_SESSION_SECRET 未设置</InlineCode> 的 warn，表示会使用开发默认值；生产环境应配置该变量。
            </span>
          </Callout>
        </>
      )
    },
    {
      id: "library",
      title: "内容库（继续创作/素材管理）",
      content: (
        <>
          <p className={styles.p}>内容库是你的“起点与中转站”：既可以继续已有项目，也可以直接创建项目并进入后续创作流程。</p>
          <ul className={styles.list}>
            <li>我的项目：根据项目当前阶段，继续回到剧本创作、视频创作或无限画布创作。</li>
            <li>创建项目：适合从零开始发起新的故事或视频制作任务。</li>
            <li>素材管理：可查看、上传、导入与沉淀素材，供后续生图、生视频与分镜制作复用。</li>
          </ul>
          <Callout title="继续创作逻辑">
            <span>内容库会根据项目类型与阶段决定下一站：大纲阶段回到剧本工作台，分镜阶段进入视频创作，画布项目会直接进入无限画布创作。</span>
          </Callout>
        </>
      )
    },
    {
      id: "script-workspace",
      title: "剧本创作（从剧情简介开始）",
      content: (
        <>
          <h3 id="script-start" className={styles.h3}>
            创建剧本信息
          </h3>
          <p className={styles.p}>剧本创作建议从剧情简介开始，先把项目基础信息一次性确认完整，再继续后续生成。</p>
          <ul className={styles.list}>
            <li>先选择竖屏或横屏。</li>
            <li>再确认项目类型，例如解说剧或精品剧。</li>
            <li>同时设置视频分辨率，作为后续生成的基础参数。</li>
          </ul>
          <h3 id="script-outline" className={styles.h3}>
            前置生成与角色确认
          </h3>
          <ul className={styles.list}>
            <li>在剧本前置阶段点击生成，生成完成后先进入编辑。</li>
            <li>先生成人物基础形象，再点击妆造，修改妆造提示词并生成妆造结果。</li>
            <li>妆造确认并保存后，继续生成人物音色并完成绑定。</li>
          </ul>
          <h3 id="script-storyboard" className={styles.h3}>
            大纲、正文与素材准备
          </h3>
          <ul className={styles.list}>
            <li>当人物基础信息都确认完成后，再依次生成大纲、剧本正文、口播文案与素材。</li>
            <li>素材生成完成后，必须确认入库；否则后续无法正确匹配人物、物品与场景。</li>
            <li>素材入库完成后，再点击下一步进入视频创作，继续生成分镜文本。</li>
          </ul>
          <Callout title="关键约束">
            <span>素材生成后一定要确认入库，这是后续分镜、人物、物品与场景匹配的前置条件。</span>
          </Callout>
        </>
      )
    },
    {
      id: "video-creation",
      title: "视频创作（从剧本原文开始）",
      content: (
        <>
          <p className={styles.p}>视频创作从剧本原文开始，支持分镜创作与无限画布创作两种路径，用于衔接分镜文本、首帧图与最终视频生成。</p>
          <ul className={styles.list}>
            <li>
              分镜创作：<InlineCode>/video?tab=list</InlineCode>，适合批量查看、补齐、编辑与生成分镜内容。
            </li>
            <li>
              故事板：<InlineCode>/video?tab=board</InlineCode>，适合按顺序浏览分镜画面、提示词与生成结果。
            </li>
            <li>无限画布创作：适合更灵活的素材编排、节点式生成与人工精品化制作流程。</li>
          </ul>
          <h3 id="video-generate" className={styles.h3}>
            分镜文本与脚本生成
          </h3>
          <ul className={styles.list}>
            <li>素材入库以后，点击下一步生成分镜文本。</li>
            <li>点击生成分镜；如果结果存在缺失文本，可以一键补充缺失脚本。</li>
            <li>分镜脚本生成完成后，选择后续生成模式：从首帧图开始，或从参考图开始。</li>
          </ul>
          <h3 id="video-export" className={styles.h3}>
            首帧图与分镜视频生成
          </h3>
          <ul className={styles.list}>
            <li>点击下一步后，开始生成分镜镜头。</li>
            <li>分镜镜头就绪后，继续生成分镜首帧图。</li>
            <li>首帧图确认完成后，再生成分镜视频。</li>
          </ul>
          <Callout title="任务跟踪">
            <span>发起生成后可以在当前页面查看状态，也可以打开右上角“任务中心”持续跟踪分镜文本、首帧图与视频任务进度。</span>
          </Callout>
        </>
      )
    },
    {
      id: "task-center",
      title: "任务中心（进度跟踪/失败定位）",
      content: (
        <>
          <p className={styles.p}>任务中心用于汇总你当前故事的后台生成任务（排队/进行中/失败），并帮助你快速定位问题。</p>
          <ul className={styles.list}>
            <li>入口：右上角“任务中心”按钮。</li>
            <li>建议做法：失败时优先复制错误信息里的 traceId，用于定位服务端日志。</li>
            <li>没有任务时：去分镜列表发起生成，任务中心会自动更新。</li>
          </ul>
        </>
      )
    },
    {
      id: "image-workbench",
      title: "生图工作台（参考图/提示词/合成）",
      content: (
        <>
          <p className={styles.p}>生图工作台用于为镜头准备参考图与提示词，并生成/合成所需的图片素材，供后续视频生成使用。</p>
          <ul className={styles.list}>
            <li>常见动作：设置提示词、上传/导入参考图、生成参考图、合成图片。</li>
            <li>参考图素材会在内容库/生成记录中可复用。</li>
          </ul>
        </>
      )
    },
    {
      id: "video-workbench",
      title: "生视频工作台（参数/时间线/生成）",
      content: (
        <>
          <p className={styles.p}>生视频工作台用于配置视频生成参数、管理片段时间线（如有）、触发生成并查看进度与结果。</p>
          <ul className={styles.list}>
            <li>常见动作：设置视频提示词/时长/模式等参数，生成视频并预览。</li>
            <li>生成进度通常通过 job 事件更新（前端会轮询或订阅进度）。</li>
          </ul>
        </>
      )
    },
    {
      id: "troubleshooting",
      title: "常见问题与排障",
      content: (
        <>
          <p className={styles.p}>遇到 500/生成失败/素材不可用时，优先从浏览器 Network 与服务端日志定位 traceId。</p>
          <ul className={styles.list}>
            <li>
              Server Actions 报错：<InlineCode>x-forwarded-host</InlineCode> 与 <InlineCode>origin</InlineCode> 不匹配会导致 “Invalid Server Actions request”。
            </li>
            <li>
              S3 未配置：上传/导入素材时报 <InlineCode>S3 storage not configured</InlineCode>，需要配置 BUCKET 相关环境变量。
            </li>
            <li>
              DB 未配置：依赖 <InlineCode>PGDATABASE_URL</InlineCode>（或 DATABASE_URL/POSTGRES_URL）；缺失会导致读写失败。
            </li>
          </ul>
          <Callout title="建议做法">
            <span>优先修正网关转发头（Host/X-Forwarded-Host/X-Forwarded-Proto）与外网域名一致；必要时再配置 serverActions allowedOrigins 白名单。</span>
          </Callout>
        </>
      )
    },
    {
      id: "dev",
      title: "开发者：本地开发与配置",
      content: (
        <>
          <p className={styles.p}>本项目常用开发命令如下（依赖 Node + npm）：</p>
          <CodeBlock>
            {`npm i
npm run dev -- -p 3001

npm run lint
npm run build

npm run db:push
npm run db:studio`}
          </CodeBlock>
          <p className={styles.p}>
            环境变量以 <InlineCode>.env.local</InlineCode> 为主，常见类别：数据库连接（PGDATABASE_URL）、会话密钥（AUTH_SESSION_SECRET）、存储（BUCKET_*）以及生成相关的第三方端点（COZE_*）。
          </p>
        </>
      )
    }
  ]
}
