import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getJobById } from "@/server/framework/jobs/jobDb"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { ensureJobsTable } from "@/server/db/ensureJobsTable"
import { logger } from "@/shared/logger"
import { cancelJobWithPolicy } from "@/server/framework/jobs/usecases/cancelJobWithPolicy"

export const runtime = "nodejs"

const bodySchema = z.object({
  mode: z.enum(["auto", "soft", "hard"]).optional(),
  reason: z.string().trim().max(200).optional()
})

export async function POST(req: NextRequest, { params }: { params: Promise<{ jobId: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const { jobId: rawJobId } = await params
  const jobId = (rawJobId ?? "").trim()
  if (!jobId) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少 jobId"), { status: 400 })

  const body = await req.json().catch(() => null)
  const parsedBody = bodySchema.safeParse(body ?? {})
  if (!parsedBody.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensureJobsTable()

  const row = await getJobById(jobId)
  if (!row) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "任务不存在或已过期"), { status: 404 })
  if (row.userId !== userId) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限终止该任务"), { status: 403 })

  const mode = parsedBody.data.mode ?? "hard"
  const reason = parsedBody.data.reason
  const startedAt = Date.now()

  logger.info({
    event: "jobs_cancel_by_id_start",
    module: "jobs",
    traceId,
    message: "开始终止任务",
    jobId,
    mode
  })

  let canceled = 0
  try {
    const result = await cancelJobWithPolicy({
      traceId,
      userId,
      jobId,
      row,
      mode,
      reason
    })
    if (!result.ok) {
      return NextResponse.json(makeApiErr(traceId, result.code, result.message), { status: result.httpStatus })
    }
    canceled = result.canceled
  } catch (e) {
    logger.error({
      event: "jobs_cancel_by_id_failed",
      module: "jobs",
      traceId,
      message: "终止任务失败",
      jobId,
      mode,
      errorName: (e as any)?.name,
      errorMessage: (e as any)?.message,
      stack: (e as any)?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "CANCEL_FAILED", "终止任务失败"), { status: 500 })
  }

  // Ensure workers get a chance to observe cancel (soft) / stop claiming new jobs.
  kickAllWorkers()

  logger.info({
    event: "jobs_cancel_by_id_success",
    module: "jobs",
    traceId,
    message: "终止任务请求成功",
    jobId,
    mode,
    canceled,
    durationMs: Date.now() - startedAt
  })

  return NextResponse.json(makeApiOk(traceId, { canceled }), { status: 200 })
}
