"use client"

import { useState, useCallback, useEffect, useMemo, useRef } from "react"
import { useRouter } from "next/navigation"
import type { ReactElement } from "react"
import { createPortal } from "react-dom"
import { Users, X } from "lucide-react"
import styles from "./QuickGeneratePage.module.css"
import { QuickGenerateUploadDialog } from "./components/QuickGenerateUploadDialog"
import { QuickGenerateMaterialDetailDialog } from "./components/QuickGenerateMaterialDetailDialog"
import { QuickGenerateMaterialCard } from "./components/QuickGenerateMaterialCard"
import { QuickGenerateEpisodesPanel } from "./components/QuickGenerateEpisodesPanel"
import { ConfirmModal } from "@/shared/ui/ConfirmModal"
import {
  getQuickGenerateCollaborators,
  uploadQuickGenerateMaterial,
  batchUpdateQuickGenerateMaterials,
  deleteQuickGenerateMaterials,
  batchReviewQuickGenerateMaterials,
  deleteQuickGenerateEpisodes,
  updateQuickGenerateCollaborators
} from "./api-client"
import { readOpenEpisodeTabs, removeOpenEpisodeTab, type OpenEpisodeTab } from "./openEpisodeTabs"
import type { QuickGenerateMaterial } from "@/shared/schema/quickGenerate"
import type { QuickGenerateCollaboratorMember, QuickGenerateCollaboratorsResponse } from "@/shared/contracts/quickGenerateCollaboration"

type QuickGenerateTab = "materials" | "episodes"
type MaterialReviewFilter = "all" | "reviewed" | "unreviewed" | "processing" | "failed"

type QuickGeneratePageProps = {
  storyId: string
  storyTitle: string
  preferredActiveTab?: QuickGenerateTab | null
  enableBatchReview: boolean
  project: {
    id: string
    groupId: string | null
    status: string
    activeTab: QuickGenerateTab
  } | null
  episodes: Array<{
    id: string
    episodeNo: number
    title: string | null
    status: string
    totalShots: number
    promptCount: number
    videoTotalCount: number
    videoShotCount: number
  }>
  materials: Array<{
    id: string
    materialType: string
    title: string | null
    status: string
    sourceUrl: string | null
    assetId?: string | null
    assetStatus?: string | null
    voiceSpeakerId?: string | null
    voiceSpeakerName?: string | null
    metadata?: unknown
  }>
}

const materialReviewFilters: Array<{ id: MaterialReviewFilter; label: string }> = [
  { id: "all", label: "全部" },
  { id: "reviewed", label: "已通过" },
  { id: "unreviewed", label: "未审核" },
  { id: "processing", label: "审核中" },
  { id: "failed", label: "审核失败" }
]

/**
 * 统一素材审核态分组，保证筛选与卡片标签语义一致。
 */
function resolveMaterialReviewFilter(material: QuickGeneratePageProps["materials"][number]): Exclude<MaterialReviewFilter, "all"> {
  const assetStatus = String((material as QuickGenerateMaterial & { assetStatus?: string | null }).assetStatus ?? "").trim()
  if (assetStatus === "Active") return "reviewed"
  if (assetStatus === "Processing") return "processing"
  if (assetStatus === "Failed") return "failed"
  return "unreviewed"
}

/**
 * 快速生成工作区：与短剧前置设定分离，承载独立的素材/剧集数据结构。
 */
export function QuickGeneratePage({
  storyId,
  storyTitle,
  preferredActiveTab,
  enableBatchReview,
  project,
  episodes,
  materials
}: QuickGeneratePageProps): ReactElement {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<QuickGenerateTab>(
    preferredActiveTab === "episodes" || preferredActiveTab === "materials"
      ? preferredActiveTab
      : project?.activeTab === "episodes"
        ? "episodes"
        : "materials"
  )
  const [activeCategory, setActiveCategory] = useState<string>("all")
  const [activeReviewFilter, setActiveReviewFilter] = useState<MaterialReviewFilter>("all")
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false)
  const [detailMaterial, setDetailMaterial] = useState<QuickGenerateMaterial | null>(null)
  
  const [batchEditMode, setBatchEditMode] = useState(false)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [confirmDeleteIds, setConfirmDeleteIds] = useState<string[] | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  const [speakers, setSpeakers] = useState<Array<{ id: string; name: string; sampleUrl?: string }>>([])
  const [drafts, setDrafts] = useState<Record<string, Partial<QuickGenerateMaterial>>>({})
  const [reviewSubmitting, setReviewSubmitting] = useState(false)
  const [selectedEpisodeIds, setSelectedEpisodeIds] = useState<Set<string>>(new Set())
  const [confirmDeleteEpisodeIds, setConfirmDeleteEpisodeIds] = useState<string[] | null>(null)
  const [isDeletingEpisodes, setIsDeletingEpisodes] = useState(false)
  const [openEpisodeTabs, setOpenEpisodeTabs] = useState<OpenEpisodeTab[]>([])
  const [collaborationOpen, setCollaborationOpen] = useState(false)
  const [collaborationLoading, setCollaborationLoading] = useState(false)
  const [collaborationSaving, setCollaborationSaving] = useState(false)
  const [collaborationData, setCollaborationData] = useState<QuickGenerateCollaboratorsResponse | null>(null)
  const [selectedCollaboratorIds, setSelectedCollaboratorIds] = useState<Set<string>>(new Set())
  const [portalMounted, setPortalMounted] = useState(false)

  // 挂载时获取音色列表
  useEffect(() => {
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch("/api/tts/speakers", { cache: "no-store" })
        const json = await res.json()
        if (!cancelled && Array.isArray(json?.data?.speakers)) {
          setSpeakers(json.data.speakers)
        }
      } catch {}
    })()
    return () => { cancelled = true }
  }, [])

  useEffect(() => {
    setPortalMounted(true)
  }, [])

  const categories = [
    { id: "all", name: "全部" },
    { id: "scene", name: "场景" },
    { id: "character", name: "人物" },
    { id: "prop", name: "物品" },
    { id: "video", name: "视频" },
    { id: "audio", name: "音频" },
  ]

  const handleUpload = useCallback(async (files: File[], materialType: string) => {
    if (!storyId) return
    for (const file of files) {
      await uploadQuickGenerateMaterial(storyId, materialType, file)
    }
    // 上传成功后刷新当前路由数据
    router.refresh()
  }, [storyId, router])

  const handleImportedFromCopyrightLibrary = useCallback(async (importedCount: number) => {
    router.refresh()
    alert(`已从版权库导入 ${importedCount} 个素材`)
  }, [router])

  const handleAiGenerated = useCallback(async (createdCount: number) => {
    router.refresh()
    alert(`已生成 ${createdCount} 个素材`)
  }, [router])

  const handleSaveSingle = useCallback(async (id: string, updates: Partial<QuickGenerateMaterial>) => {
    await batchUpdateQuickGenerateMaterials([{ id, ...updates }])
    router.refresh()
  }, [router])

  const handleDraftChange = useCallback((id: string, draft: Partial<QuickGenerateMaterial>) => {
    setDrafts((prev) => ({
      ...prev,
      [id]: { ...(prev[id] || {}), ...draft }
    }))
  }, [])

  const handleFinishBatchEdit = useCallback(async () => {
    const materialMap = new Map(materials.map((material) => [material.id, material]))
    const itemsToUpdate = Object.entries(drafts).map(([id, changes]) => {
      const origin = materialMap.get(id)
      const fallbackTitle = origin?.title?.trim() || ""
      const nextTitle =
        changes.title !== undefined ? (String(changes.title ?? "").trim() || fallbackTitle) : undefined
      return {
        id,
        ...changes,
        ...(nextTitle !== undefined ? { title: nextTitle } : {})
      }
    })
    if (itemsToUpdate.length > 0) {
      await batchUpdateQuickGenerateMaterials(itemsToUpdate)
      setDrafts({})
      router.refresh()
    }
    setBatchEditMode(false)
  }, [drafts, materials, router])

  const requestDelete = useCallback((ids: string[]) => {
    if (!ids.length) return
    setConfirmDeleteIds(ids)
  }, [])

  const executeDelete = useCallback(async () => {
    if (!confirmDeleteIds?.length) return
    setIsDeleting(true)
    try {
      await deleteQuickGenerateMaterials(confirmDeleteIds)
      setSelectedIds(new Set())
      setConfirmDeleteIds(null)
      router.refresh()
    } catch (err) {
      alert("删除失败")
    } finally {
      setIsDeleting(false)
    }
  }, [confirmDeleteIds, router])

  const toggleSelect = useCallback((id: string, checked: boolean) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (checked) next.add(id)
      else next.delete(id)
      return next
    })
  }, [])

  const toggleEpisodeSelect = useCallback((id: string, checked: boolean) => {
    setSelectedEpisodeIds((prev) => {
      const next = new Set(prev)
      if (checked) next.add(id)
      else next.delete(id)
      return next
    })
  }, [])

  const requestDeleteEpisodes = useCallback((ids: string[]) => {
    if (!ids.length) return
    setConfirmDeleteEpisodeIds(ids)
  }, [])

  const executeDeleteEpisodes = useCallback(async () => {
    if (!confirmDeleteEpisodeIds?.length) return
    setIsDeletingEpisodes(true)
    try {
      await deleteQuickGenerateEpisodes(confirmDeleteEpisodeIds)
      setSelectedEpisodeIds(new Set())
      setConfirmDeleteEpisodeIds(null)
      router.refresh()
    } catch (error) {
      alert(error instanceof Error ? error.message : "删除剧集失败")
    } finally {
      setIsDeletingEpisodes(false)
    }
  }, [confirmDeleteEpisodeIds, router])

  useEffect(() => {
    setSelectedIds(new Set())
  }, [activeCategory, activeReviewFilter])

  useEffect(() => {
    if (activeTab !== "episodes") return
    setSelectedEpisodeIds((prev) => {
      const availableIds = new Set(episodes.map((episode) => episode.id))
      const next = new Set<string>()
      prev.forEach((id) => {
        if (availableIds.has(id)) next.add(id)
      })
      return next
    })
  }, [activeTab, episodes])

  // When visiting the episodes tab, read opened episode tabs from localStorage so the tabs stay visible after returning from result pages.
  useEffect(() => {
    if (activeTab !== "episodes") return
    setOpenEpisodeTabs(readOpenEpisodeTabs(storyId))
  }, [activeTab, storyId])

  const openedEpisodes = useMemo(() => {
    const map = new Map(episodes.map((e) => [e.id, e]))
    return openEpisodeTabs
      .map((t) => map.get(t.id))
      .filter(Boolean) as Array<{ id: string; episodeNo: number; title: string | null; status: string }>
  }, [episodes, openEpisodeTabs])

  const closeOpenedEpisodeTab = useCallback((episodeId: string) => {
    const next = removeOpenEpisodeTab(storyId, episodeId)
    setOpenEpisodeTabs(next)
  }, [storyId])

  const displayMaterials = useMemo(() => {
    return materials.filter((material) => {
      const matchesCategory = activeCategory === "all" || material.materialType === activeCategory
      if (!matchesCategory) return false
      if (activeReviewFilter === "all") return true
      return resolveMaterialReviewFilter(material) === activeReviewFilter
    })
  }, [activeCategory, activeReviewFilter, materials])

  const [visibleCount, setVisibleCount] = useState(40)
  const loadMoreRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    const target = loadMoreRef.current
    if (!target) return

    const observer = new IntersectionObserver((entries) => {
      if (entries[0] && entries[0].isIntersecting) {
        setVisibleCount((prev) => prev + 40)
      }
    }, { rootMargin: "200px 0px" })

    observer.observe(target)

    return () => {
      observer.disconnect()
    }
  }, [displayMaterials.length, visibleCount])

  // Reset visible count when category or filter changes
  useEffect(() => {
    setVisibleCount(40)
  }, [activeCategory, activeReviewFilter])

  const visibleMaterials = useMemo(() => displayMaterials.slice(0, visibleCount), [displayMaterials, visibleCount])

  const audioMaterials = useMemo(() => {
    return materials
      .filter((m) => m.materialType === "audio" && String((m as any).assetStatus ?? "").trim() === "Active")
      .map((m) => ({
        id: m.id,
        title: String(m.title ?? "").trim() || "未命名音频",
        assetId: String((m as any).assetId ?? "").trim(),
        assetStatus: String((m as any).assetStatus ?? "").trim(),
        sourceUrl: String(m.sourceUrl ?? "").trim()
      }))
  }, [materials])

  const isDetailOpen = detailMaterial !== null
  const isPortalDialogOpen = isDetailOpen || uploadDialogOpen || collaborationOpen
  const selectedCount = selectedIds.size
  const selectedEpisodeCount = selectedEpisodeIds.size
  const isAllFilteredSelected = displayMaterials.length > 0 && displayMaterials.every((item) => selectedIds.has(item.id))
  const collaborationMembers = useMemo(() => {
    const map = new Map<string, QuickGenerateCollaboratorMember>()
    for (const member of collaborationData?.candidates ?? []) map.set(member.userId, member)
    for (const member of collaborationData?.collaborators ?? []) map.set(member.userId, member)
    return Array.from(map.values()).sort((a, b) => a.name.localeCompare(b.name, "zh-CN"))
  }, [collaborationData])
  const collaborationCount = collaborationData?.collaborators.length ?? 0
  const collaborationDialog =
    collaborationOpen && portalMounted
      ? createPortal(
          <div className={styles.collaborationOverlay}>
            <div className={styles.collaborationDialog}>
              <div className={styles.collaborationHeader}>
                <div>
                  <div className={styles.collaborationTitle}>协同成员配置</div>
                  <div className={styles.collaborationHint}>仅支持勾选当前项目创建者所在组的成员</div>
                </div>
                <button
                  type="button"
                  className={styles.collaborationClose}
                  onClick={() => {
                    if (collaborationSaving) return
                    setCollaborationOpen(false)
                  }}
                >
                  <X size={16} />
                </button>
              </div>

              {collaborationLoading ? (
                <div className={styles.collaborationEmpty}>加载中...</div>
              ) : collaborationMembers.length === 0 ? (
                <div className={styles.collaborationEmpty}>当前组下暂无可选协同成员</div>
              ) : (
                <div className={styles.collaborationList}>
                  {collaborationMembers.map((member) => {
                    const checked = selectedCollaboratorIds.has(member.userId)
                    return (
                      <label key={member.userId} className={styles.collaborationItem}>
                        <input
                          type="checkbox"
                          checked={checked}
                          disabled={!collaborationData?.canManage || collaborationSaving}
                          onChange={(event) => toggleCollaborator(member.userId, event.target.checked)}
                        />
                        <div className={styles.collaborationMeta}>
                          <div className={styles.collaborationName}>{member.name}</div>
                          <div className={styles.collaborationRole}>
                            {member.roleKey === "group_admin" ? "组管理员" : member.roleKey === "admin" ? "管理员" : "成员"}
                          </div>
                        </div>
                      </label>
                    )
                  })}
                </div>
              )}

              <div className={styles.collaborationFooter}>
                <div className={styles.collaborationHint}>已选择 {selectedCollaboratorIds.size} 人</div>
                <div className={styles.collaborationActions}>
                  <button
                    type="button"
                    className={styles.collaborationSecondaryBtn}
                    disabled={collaborationSaving}
                    onClick={() => setCollaborationOpen(false)}
                  >
                    取消
                  </button>
                  <button
                    type="button"
                    className={styles.collaborationPrimaryBtn}
                    disabled={!collaborationData?.canManage || collaborationSaving}
                    onClick={() => void handleSaveCollaborators()}
                  >
                    {collaborationSaving ? "保存中..." : collaborationData?.canManage ? "保存协同成员" : "无权配置"}
                  </button>
                </div>
              </div>
            </div>
          </div>,
          document.body
        )
      : null

  const processingMaterialIds = useMemo(() => {
    return materials
      .filter((m: any) => String((m as any).assetStatus ?? "").trim() === "Processing" && String((m as any).assetId ?? "").trim())
      .map((m) => m.id)
  }, [materials])

  const toggleSelectAllFiltered = useCallback(() => {
    if (displayMaterials.length === 0) return
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (isAllFilteredSelected) {
        displayMaterials.forEach((item) => next.delete(item.id))
      } else {
        displayMaterials.forEach((item) => next.add(item.id))
      }
      return next
    })
  }, [displayMaterials, isAllFilteredSelected])

  // 自动刷新 UI：每 5s 刷新一次页面数据（真正的状态轮询在服务端 job 中执行，离开页面也会继续）
  useEffect(() => {
    if (processingMaterialIds.length === 0) return
    const timer = setInterval(() => router.refresh(), 5000)
    router.refresh()
    return () => clearInterval(timer)
  }, [processingMaterialIds, router])

  const openCollaborationDialog = useCallback(async () => {
    if (!project?.id) return
    setCollaborationOpen(true)
    setCollaborationLoading(true)
    try {
      const data = await getQuickGenerateCollaborators(project.id)
      setCollaborationData(data)
      setSelectedCollaboratorIds(new Set(data.collaborators.map((item) => item.userId)))
    } catch (error: any) {
      alert(error?.message ?? "获取协同成员失败")
      setCollaborationOpen(false)
    } finally {
      setCollaborationLoading(false)
    }
  }, [project?.id])

  const toggleCollaborator = useCallback((userId: string, checked: boolean) => {
    setSelectedCollaboratorIds((prev) => {
      const next = new Set(prev)
      if (checked) next.add(userId)
      else next.delete(userId)
      return next
    })
  }, [])

  const handleSaveCollaborators = useCallback(async () => {
    if (!project?.id || !collaborationData?.canManage) return
    setCollaborationSaving(true)
    try {
      const data = await updateQuickGenerateCollaborators(project.id, {
        collaboratorUserIds: Array.from(selectedCollaboratorIds)
      })
      setCollaborationData(data)
      setSelectedCollaboratorIds(new Set(data.collaborators.map((item) => item.userId)))
      setCollaborationOpen(false)
      alert("协同成员已更新")
    } catch (error: any) {
      alert(error?.message ?? "保存协同成员失败")
    } finally {
      setCollaborationSaving(false)
    }
  }, [collaborationData?.canManage, project?.id, selectedCollaboratorIds])

  return (
    <main className={`${styles.page} ${isPortalDialogOpen ? styles.pageBlurred : ""}`}>
      <section className={styles.headerCard}>
        <div className={styles.headerLeft}>
          <div className={styles.headerTag}>快速生成</div>
          <div className={styles.title}>{storyTitle.trim() || "未命名快速生成项目"}</div>
          {project?.id ? (
            <button type="button" className={styles.collaborationBtn} onClick={() => void openCollaborationDialog()}>
              <Users size={14} />
              <span>{collaborationCount > 0 ? `协同设置 (${collaborationCount})` : "开启协同"}</span>
            </button>
          ) : null}
        </div>
      </section>

      <section className={styles.panel} aria-label="快速生成内容">
        <div className={styles.tabsHeader}>
          <div className={styles.tabsLeft}>
            <div className={styles.tabs}>
              <button
                type="button"
                className={`${styles.tab} ${activeTab === "materials" ? styles.tabActive : ""}`}
                onClick={() => setActiveTab("materials")}
              >
                素材
              </button>
              <button
                type="button"
                className={`${styles.tab} ${activeTab === "episodes" ? styles.tabActive : ""}`}
                onClick={() => setActiveTab("episodes")}
              >
                剧集
              </button>
            </div>
            {activeTab === "materials" && (
              <div className={styles.reviewFilters}>
                {materialReviewFilters.map((filter) => (
                  <button
                    key={filter.id}
                    type="button"
                    className={`${styles.reviewFilterBtn} ${activeReviewFilter === filter.id ? styles.reviewFilterBtnActive : ""}`}
                    onClick={() => setActiveReviewFilter(filter.id)}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
            )}
            {activeTab === "episodes" && openedEpisodes.length > 0 && (
              <div
                className={`${styles.episodeTabs} ${openedEpisodes.length > 10 ? styles.episodeTabsScrollable : ""}`}
                aria-label="已打开剧集标签"
              >
                {openedEpisodes.map((e) => (
                  <button
                    key={e.id}
                    type="button"
                    className={styles.episodeTab}
                    onClick={() => {
                      const qs = new URLSearchParams()
                      qs.set("storyId", storyId)
                      router.push(`/script/quick-generate/${encodeURIComponent(storyId)}/episodes/${encodeURIComponent(e.id)}?${qs.toString()}`)
                    }}
                  >
                    <span className={styles.episodeTabText}>{`第 ${e.episodeNo} 集`}</span>
                    <span
                      className={styles.episodeTabClose}
                      role="button"
                      aria-label="关闭标签"
                      onClick={(event) => {
                        event.preventDefault()
                        event.stopPropagation()
                        closeOpenedEpisodeTab(e.id)
                      }}
                    >
                      <X size={14} />
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
          {activeTab === "materials" && (
            <div className={styles.tabActions}>
              <button
                type="button"
                className={styles.selectAllBtn}
                disabled={displayMaterials.length === 0}
                onClick={toggleSelectAllFiltered}
              >
                {isAllFilteredSelected ? "取消全选" : "全选"}
                {displayMaterials.length > 0 ? ` (${displayMaterials.length})` : ""}
              </button>
              {selectedCount > 0 && enableBatchReview && Boolean(project?.groupId?.trim()) ? (
                <button
                  type="button"
                  className={styles.batchReviewBtn}
                  disabled={reviewSubmitting}
                  onClick={async () => {
                    if (reviewSubmitting) return
                    const ids = Array.from(selectedIds)
                    if (ids.length === 0) return
                    setReviewSubmitting(true)
                    try {
                      await batchReviewQuickGenerateMaterials(ids)
                      setSelectedIds(new Set())
                      alert(`已提交 ${ids.length} 个素材审核`)
                      router.refresh()
                    } catch (e: any) {
                      alert(e?.message || "批量提交审核失败")
                    } finally {
                      setReviewSubmitting(false)
                    }
                  }}
                >
                  {reviewSubmitting ? `提交中... (${selectedCount})` : `批量审核 (${selectedCount})`}
                </button>
              ) : null}
              {selectedCount > 0 && (
                <button
                  type="button"
                  className={styles.batchDeleteBtn}
                  onClick={() => void requestDelete(Array.from(selectedIds))}
                >
                  批量删除 ({selectedCount})
                </button>
              )}
              <button
                type="button"
                className={styles.batchEditBtn}
                onClick={() => {
                  if (batchEditMode) {
                    void handleFinishBatchEdit()
                  } else {
                    setBatchEditMode(true)
                  }
                }}
              >
                {batchEditMode ? "完成编辑" : "批量编辑"}
              </button>
            </div>
          )}
          {activeTab === "episodes" && selectedEpisodeCount > 0 && (
            <div className={styles.tabActions}>
              <div className={styles.selectionSummary}>已选中 {selectedEpisodeCount} 个剧集</div>
              <button
                type="button"
                className={styles.batchDeleteBtn}
                onClick={() => void requestDeleteEpisodes(Array.from(selectedEpisodeIds))}
              >
                批量删除 ({selectedEpisodeCount})
              </button>
            </div>
          )}
        </div>

        <div className={styles.content}>
          {activeTab === "materials" ? (
            <>
              <aside className={styles.sidebar}>
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    type="button"
                    className={`${styles.categoryItem} ${activeCategory === cat.id ? styles.categoryActive : ""}`}
                    onClick={() => setActiveCategory(cat.id)}
                  >
                    {cat.name}
                  </button>
                ))}
              </aside>
              <div className={styles.mainArea}>
                <div className={styles.materialsGrid}>
                  {/* 常驻的上传按钮卡片 */}
                  <button type="button" className={styles.uploadCard} onClick={() => setUploadDialogOpen(true)}>
                    <div className={styles.uploadIcon}>+</div>
                    <div className={styles.uploadText}>上传素材</div>
                  </button>

                  {/* 素材列表 */}
                  {visibleMaterials.map((item) => {
                    const isSelected = selectedIds.has(item.id)
                    const currentDraft = drafts[item.id] || {}
                    // Create an optimistic item based on draft
                    const displayItem = {
                      ...item,
                      ...currentDraft,
                    } as QuickGenerateMaterial

                    return (
                      <QuickGenerateMaterialCard
                        key={item.id}
                        item={displayItem}
                        batchEditMode={batchEditMode}
                        audioMaterials={audioMaterials}
                        isSelected={isSelected}
                        toggleSelect={toggleSelect}
                        requestDelete={requestDelete}
                        onClickDetail={(material) => setDetailMaterial(material)}
                        onSave={handleSaveSingle}
                        onDraftChange={handleDraftChange}
                        speakers={speakers}
                      />
                    )
                  })}
                  
                  {visibleCount < displayMaterials.length && (
                    <div 
                      ref={loadMoreRef} 
                      style={{ 
                        height: '20px', 
                        gridColumn: '1 / -1',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        color: 'rgba(255, 255, 255, 0.5)',
                        margin: '20px 0'
                      }}
                    >
                      加载更多...
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : episodes.length === 0 ? (
            <QuickGenerateEpisodesPanel
              storyId={storyId}
              episodes={episodes}
              selectedIds={selectedEpisodeIds}
              toggleSelect={toggleEpisodeSelect}
              requestDelete={requestDeleteEpisodes}
            />
          ) : (
            <QuickGenerateEpisodesPanel
              storyId={storyId}
              episodes={episodes}
              selectedIds={selectedEpisodeIds}
              toggleSelect={toggleEpisodeSelect}
              requestDelete={requestDeleteEpisodes}
            />
          )}
        </div>
      </section>

      <QuickGenerateUploadDialog
        open={uploadDialogOpen}
        storyId={storyId}
        onOpenChange={setUploadDialogOpen}
        onUpload={handleUpload}
        onImported={handleImportedFromCopyrightLibrary}
        onAiGenerated={handleAiGenerated}
      />

      <QuickGenerateMaterialDetailDialog
        material={detailMaterial as any}
        audioMaterials={audioMaterials}
        onClose={() => setDetailMaterial(null)}
      />

      {collaborationDialog}

      <ConfirmModal
        open={confirmDeleteIds !== null}
        title={confirmDeleteIds?.length === 1 ? "删除素材" : "批量删除素材"}
        message={`确定要删除选定的 ${confirmDeleteIds?.length || 0} 个素材吗？此操作不可恢复。`}
        confirmText="确认删除"
        cancelText="取消"
        confirming={isDeleting}
        onCancel={() => {
          if (isDeleting) return
          setConfirmDeleteIds(null)
        }}
        onConfirm={() => void executeDelete()}
      />

      <ConfirmModal
        open={confirmDeleteEpisodeIds !== null}
        title={confirmDeleteEpisodeIds?.length === 1 ? "删除剧集" : "批量删除剧集"}
        message={`确定要删除选定的 ${confirmDeleteEpisodeIds?.length || 0} 个剧集吗？此操作不可恢复。`}
        confirmText="确认删除"
        cancelText="取消"
        confirming={isDeletingEpisodes}
        onCancel={() => {
          if (isDeletingEpisodes) return
          setConfirmDeleteEpisodeIds(null)
        }}
        onConfirm={() => void executeDeleteEpisodes()}
      />
    </main>
  )
}
