"use client"

import { useEffect, type ReactElement } from "react"
import { Film, Image as ImageIcon, Music2, X } from "lucide-react"
import type { CopyrightLibraryItem } from "@/shared/contracts/library/copyrightLibrary"
import styles from "./CopyrightLibrary.module.css"

interface CopyrightLibraryPreviewModalProps {
  open: boolean
  item: CopyrightLibraryItem | null
  onClose: () => void
}

function getReviewText(item: CopyrightLibraryItem): string {
  const status = String(item.assetStatus ?? "").trim()
  const assetId = String(item.assetId ?? "").trim()
  const errorMessage = String(item.assetErrorMessage ?? "").trim()
  if (status === "Active") return assetId ? `已通过 · ${assetId}` : "已通过"
  if (status === "Processing") return assetId ? `审核中 · ${assetId}` : "审核中"
  if (status === "Failed") return errorMessage || "审核失败"
  return "未审核"
}

export function CopyrightLibraryPreviewModal({ open, item, onClose }: CopyrightLibraryPreviewModalProps): ReactElement | null {
  useEffect(() => {
    if (!open) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [onClose, open])

  if (!open || !item) return null

  const mediaType = item.materialType === "video" ? "video" : item.materialType === "audio" ? "audio" : "image"

  return (
    <>
      <div className={styles.previewOverlay} onClick={onClose} role="presentation" />
      <div className={styles.previewModal} role="dialog" aria-modal="true" aria-label="版权素材预览">
        <div className={styles.modalHeader}>
          <div>
            <div className={styles.modalTitle}>{item.title}</div>
            <div className={styles.modalMeta}>
              {item.projectTitle} · {getReviewText(item)}
            </div>
          </div>
          <button type="button" className={styles.closeBtn} onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>
        <div className={styles.previewBody}>
          {mediaType === "image" && item.sourceUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={item.sourceUrl} alt={item.title} className={styles.previewImage} />
          ) : mediaType === "video" && item.sourceUrl ? (
            <video className={styles.previewVideo} src={item.sourceUrl} controls autoPlay />
          ) : mediaType === "audio" && item.sourceUrl ? (
            <audio className={styles.previewAudio} src={item.sourceUrl} controls autoPlay />
          ) : (
            <div className={styles.previewPlaceholder}>
              {mediaType === "video" ? <Film size={36} /> : mediaType === "audio" ? <Music2 size={36} /> : <ImageIcon size={36} />}
              <span>暂无可预览内容</span>
            </div>
          )}
        </div>
      </div>
    </>
  )
}
