import { NextResponse, type NextRequest } from "next/server"
import { and, eq, inArray, isNull } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { generatedImages, stories, storyOutlines, storyboards, videoCanvasGraphs } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

const paramsSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200)
})

const querySchema = z.object({
  kind: z.enum(["image", "video"]).optional()
})

type AssetItem = {
  kind: "image" | "video"
  assetId: string
  url: string
  title: string | null
  thumbnail: string | null
}

function safeArray<T>(v: unknown): T[] {
  return Array.isArray(v) ? (v as T[]) : []
}

function isValidUrl(v: unknown): v is string {
  if (typeof v !== "string") return false
  const s = v.trim()
  if (!s) return false
  return s.startsWith("http") || s.startsWith("/api/")
}

function dedupe(items: AssetItem[]): AssetItem[] {
  const map = new Map<string, AssetItem>()
  for (const it of items) {
    const k = `${it.kind}:${it.assetId}:${it.url}`
    if (map.has(k)) continue
    map.set(k, it)
  }
  return Array.from(map.values())
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ storyId: string; outlineId: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const url = new URL(req.url)
  const parsedQuery = querySchema.safeParse({ kind: url.searchParams.get("kind") ?? undefined })
  if (!parsedQuery.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, storyOutlines, videoCanvasGraphs, storyboards, generatedImages })

  const storyRows = await db
    .select({ id: stories.id, storyType: stories.storyType })
    .from(stories)
    .where(and(eq(stories.id, parsedParams.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的项目"), { status: 404 })

  const outlineRows = await db
    .select({ id: storyOutlines.id, sequence: storyOutlines.sequence })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.id, parsedParams.data.outlineId), eq(storyOutlines.storyId, parsedParams.data.storyId), isNull(storyOutlines.deletedAt)))
    .limit(1)
  if (outlineRows.length === 0) return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "未找到可用的剧集"), { status: 404 })

  const kindFilter = parsedQuery.data.kind
  const storyType = (storyRows[0]?.storyType ?? "").trim()
  let items: AssetItem[] = []

  if (storyType === "canvas") {
    const graphRows = await db
      .select({ graphJson: videoCanvasGraphs.graphJson })
      .from(videoCanvasGraphs)
      .where(and(eq(videoCanvasGraphs.storyId, parsedParams.data.storyId), eq(videoCanvasGraphs.outlineId, parsedParams.data.outlineId), isNull(videoCanvasGraphs.deletedAt)))
      .limit(1)

    const rawGraph = (graphRows[0]?.graphJson ?? null) as any
    const nodes = safeArray<any>(rawGraph?.nodes)
    const pickedRaw = nodes
      .filter((n) => typeof n?.type === "string" && (n.type === "image_resource" || n.type === "video_resource"))
      .map((n): AssetItem | null => {
        const params = (n?.params ?? {}) as Record<string, unknown>
        const url = params.url
        const assetId = params.assetId
        const title = params.displayName
        if (!isValidUrl(url) || typeof assetId !== "string" || !assetId.trim()) return null
        const kind: AssetItem["kind"] = n.type === "image_resource" ? "image" : "video"
        if (kindFilter && kind !== kindFilter) return null
        return {
          kind,
          assetId: assetId.trim(),
          url: url.trim(),
          title: typeof title === "string" ? title : null,
          thumbnail: null
        }
      })

    const picked = pickedRaw.filter((v): v is AssetItem => v !== null)

    items = dedupe(picked)
  } else {
    const sbRows = await db
      .select({ id: storyboards.id, frames: storyboards.frames, videoInfo: storyboards.videoInfo, updatedAt: storyboards.updatedAt, createdAt: storyboards.createdAt })
      .from(storyboards)
      .where(eq(storyboards.outlineId, parsedParams.data.outlineId))

    const storyboardIds = sbRows.map((r) => r.id).filter(Boolean)

    if (!kindFilter || kindFilter === "image") {
      if (storyboardIds.length > 0) {
        const imgRows = await db
          .select({ id: generatedImages.id, name: generatedImages.name })
          .from(generatedImages)
          .where(and(eq(generatedImages.storyId, parsedParams.data.storyId), inArray(generatedImages.storyboardId, storyboardIds), isNull(generatedImages.deletedAt)))

        items.push(
          ...imgRows.map((r) => ({
            kind: "image" as const,
            assetId: `generated:image_db:${r.id}`,
            url: `/api/video-creation/images/file/${encodeURIComponent(r.id)}`,
            title: r.name ?? null,
            thumbnail: null
          }))
        )
      }

      for (const sb of sbRows) {
        const frames = (sb.frames ?? {}) as any
        const first = frames?.first ?? null
        const last = frames?.last ?? null
        const candidates: Array<{ url?: unknown; thumbnailUrl?: unknown; title?: unknown }> = []
        if (first) {
          if (Array.isArray(first?.images)) {
            for (let i = 0; i < first.images.length; i += 1) {
              const im = first.images[i]
              candidates.push({ url: im?.url, thumbnailUrl: im?.thumbnailUrl, title: first?.prompt })
            }
          }
          candidates.push({ url: first?.url, thumbnailUrl: first?.thumbnailUrl, title: first?.prompt })
        }
        if (last) candidates.push({ url: last?.url, thumbnailUrl: last?.thumbnailUrl, title: last?.prompt })

        for (let i = 0; i < candidates.length; i += 1) {
          const c = candidates[i]
          if (!isValidUrl(c.url)) continue
          items.push({
            kind: "image",
            assetId: `storyboard:image:${sb.id}:${i + 1}`,
            url: c.url.trim(),
            title: typeof c.title === "string" ? c.title : null,
            thumbnail: isValidUrl(c.thumbnailUrl) ? c.thumbnailUrl.trim() : null
          })
        }
      }
    }

    if (!kindFilter || kindFilter === "video") {
      for (const sb of sbRows) {
        const info = (sb.videoInfo ?? {}) as any
        const urls: Array<{ url: unknown; title?: unknown }> = []
        urls.push({ url: info?.url, title: info?.prompt })
        if (Array.isArray(info?.videos)) {
          for (const v of info.videos) urls.push({ url: v?.url, title: v?.prompt })
        }
        for (let i = 0; i < urls.length; i += 1) {
          const u = urls[i]
          if (!isValidUrl(u.url)) continue
          items.push({
            kind: "video",
            assetId: `storyboard:video:${sb.id}:${i + 1}`,
            url: u.url.trim(),
            title: typeof u.title === "string" ? u.title : null,
            thumbnail: null
          })
        }
      }
    }

    items = dedupe(items)
  }

  return NextResponse.json(
    makeApiOk(traceId, {
      storyId: parsedParams.data.storyId,
      outlineId: parsedParams.data.outlineId,
      sequence: outlineRows[0]?.sequence ?? null,
      kind: kindFilter ?? null,
      items
    }),
    { status: 200 }
  )
}
