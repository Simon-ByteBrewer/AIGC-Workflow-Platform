import { NextResponse, type NextRequest } from "next/server"
import { and, desc, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { quickGenerateMaterials, quickGenerateProjects, stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  search: z.string().trim().max(100).optional(),
  mediaType: z.enum(["image", "video", "audio"]).optional()
})

type QuickGenerateReviewedAssetItem = {
  id: string
  title: string
  mediaType: "image" | "video" | "audio"
  sourceUrl: string
  previewUrl: string
  sourceStorageKey: string
  reviewAssetId: string
  reviewStatus: "Active"
  sourceType: "quick_generate"
  sourceProjectStoryId: string
  sourceProjectTitle: string
}

type QuickGenerateReviewedAssetProject = {
  storyId: string
  title: string
  updatedAt: string | null
  items: QuickGenerateReviewedAssetItem[]
}

/**
 * 统一清洗文本字段，避免后续分组和搜索出现空白差异。
 */
function trimText(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

/**
 * 将 Quick Generate 素材类型归一为版权库面板可识别的媒体类型。
 */
function normalizeQuickGenerateMediaType(materialType: unknown): "image" | "video" | "audio" {
  const raw = trimText(materialType).toLowerCase()
  if (raw === "video") return "video"
  if (raw === "audio") return "audio"
  return "image"
}

/**
 * 校验当前用户是否有权访问指定画布项目。
 */
async function assertStoryAccess(input: {
  storyId: string
  userId: string
}): Promise<boolean> {
  const db = await getDb({ stories })
  const rows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, input.storyId), eq(stories.userId, input.userId)))
    .limit(1)
  return rows.length > 0
}

/**
 * 根据搜索词判断 Quick Generate 已过审素材是否应显示在版权库中。
 */
function matchQuickGenerateReviewedAssetSearch(
  projectTitle: string,
  item: QuickGenerateReviewedAssetItem,
  search: string
): boolean {
  if (!search) return true
  return (
    projectTitle.toLowerCase().includes(search) ||
    item.title.toLowerCase().includes(search) ||
    item.reviewAssetId.toLowerCase().includes(search)
  )
}

/**
 * 加载其他 Quick Generate 项目中已过审的素材，并按项目分组返回给版权库面板。
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({
    storyId: req.nextUrl.searchParams.get("storyId") ?? "",
    search: req.nextUrl.searchParams.get("search") ?? undefined,
    mediaType: req.nextUrl.searchParams.get("mediaType") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const allowed = await assertStoryAccess({ storyId: parsed.data.storyId, userId })
  if (!allowed) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用项目"), { status: 404 })

  const db = await getDb({ stories, quickGenerateProjects, quickGenerateMaterials })
  const rows = await db
    .select({
      projectStoryId: stories.id,
      projectTitle: stories.title,
      projectUpdatedAt: stories.updatedAt,
      materialId: quickGenerateMaterials.id,
      materialTitle: quickGenerateMaterials.title,
      materialType: quickGenerateMaterials.materialType,
      sourceUrl: quickGenerateMaterials.sourceUrl,
      sourceStorageKey: quickGenerateMaterials.storageKey,
      reviewAssetId: quickGenerateMaterials.assetId
    })
    .from(quickGenerateMaterials)
    .innerJoin(quickGenerateProjects, eq(quickGenerateMaterials.projectId, quickGenerateProjects.id))
    .innerJoin(stories, eq(quickGenerateProjects.storyId, stories.id))
    .where(
      and(
        eq(stories.userId, userId),
        eq(stories.storyType, "quick_generate"),
        eq(quickGenerateMaterials.assetStatus, "Active")
      )
    )
    .orderBy(desc(stories.updatedAt), desc(quickGenerateMaterials.updatedAt), desc(quickGenerateMaterials.createdAt))

  const mediaTypeFilter = parsed.data.mediaType
  const search = trimText(parsed.data.search).toLowerCase()
  const grouped = new Map<string, QuickGenerateReviewedAssetProject>()

  for (const row of rows) {
    const sourceUrl = trimText(row.sourceUrl)
    const reviewAssetId = trimText(row.reviewAssetId)
    const projectStoryId = trimText(row.projectStoryId)
    if (!sourceUrl || !reviewAssetId || !projectStoryId) continue

    const mediaType = normalizeQuickGenerateMediaType(row.materialType)
    if (mediaTypeFilter && mediaType !== mediaTypeFilter) continue

    const item: QuickGenerateReviewedAssetItem = {
      id: trimText(row.materialId),
      title: trimText(row.materialTitle) || "未命名素材",
      mediaType,
      sourceUrl,
      previewUrl: mediaType === "image" ? sourceUrl : "",
      sourceStorageKey: trimText(row.sourceStorageKey),
      reviewAssetId,
      reviewStatus: "Active",
      sourceType: "quick_generate",
      sourceProjectStoryId: projectStoryId,
      sourceProjectTitle: trimText(row.projectTitle) || "未命名 Quick Generate 项目"
    }
    if (!matchQuickGenerateReviewedAssetSearch(item.sourceProjectTitle, item, search)) continue

    const existing =
      grouped.get(projectStoryId) ??
      {
        storyId: projectStoryId,
        title: item.sourceProjectTitle,
        updatedAt: row.projectUpdatedAt ? row.projectUpdatedAt.toISOString() : null,
        items: []
      }
    existing.items.push(item)
    grouped.set(projectStoryId, existing)
  }

  return NextResponse.json(makeApiOk(traceId, { projects: Array.from(grouped.values()) }), { status: 200 })
}
