import { NextResponse, type NextRequest } from "next/server"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { deleteFailedCanvasCopyrightAsset } from "@/server/domains/video/canvas/copyright/canvasCopyrightAssetStore"

export const runtime = "nodejs"

const paramsSchema = z
  .object({
    id: z.string().trim().min(1).max(200)
  })
  .strict()

const querySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200)
  })
  .strict()

/**
 * 校验当前用户是否有权访问指定画布项目。
 */
async function assertStoryAccess(input: {
  storyId: string
  userId: string
}): Promise<boolean> {
  const db = await getDb({ stories })
  const rows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, input.storyId), eq(stories.userId, input.userId)))
    .limit(1)
  return rows.length > 0
}

/**
 * 删除一条送审未通过的版权素材记录。
 */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const parsedQuery = querySchema.safeParse({
    storyId: req.nextUrl.searchParams.get("storyId") ?? ""
  })
  if (!parsedQuery.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const allowed = await assertStoryAccess({ storyId: parsedQuery.data.storyId, userId })
    if (!allowed) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用项目"), { status: 404 })

    const deleted = await deleteFailedCanvasCopyrightAsset({
      id: parsedParams.data.id,
      storyId: parsedQuery.data.storyId
    })
    if (!deleted) return NextResponse.json(makeApiErr(traceId, "COPYRIGHT_ASSET_NOT_FOUND", "版权素材不存在"), { status: 404 })
    return NextResponse.json(makeApiOk(traceId, { item: deleted }), { status: 200 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "删除版权素材失败"
    if (message === "仅支持删除送审未通过的素材") {
      return NextResponse.json(makeApiErr(traceId, "COPYRIGHT_ASSET_DELETE_FORBIDDEN", message), { status: 400 })
    }
    logger.error({
      event: "canvas_copyright_asset_delete_failed",
      module: "video/canvas",
      traceId,
      message: "删除画布版权素材失败",
      errorMessage: message,
      storyId: parsedQuery.data.storyId,
      copyrightAssetId: parsedParams.data.id
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", message || "删除版权素材失败"), { status: 500 })
  }
}
