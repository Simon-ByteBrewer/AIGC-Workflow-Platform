import { NextResponse } from "next/server"
import { z } from "zod"
import { getCozeAsyncTaskStatus } from "@/features/coze/asyncTaskClient"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { getSessionFromRequest } from "@/shared/session"
import type { NextRequest } from "next/server"

const paramsSchema = z.object({
  taskId: z.string().trim().min(1)
})

export const runtime = "nodejs"

export async function GET(
  req: Request,
  { params }: { params: Promise<{ taskId: string }> }
): Promise<Response> {
  const traceId = getTraceId(req.headers)

  // Next.js 16: params 是 Promise，需要 await
  const rawParams = await params

  // 验证任务 ID
  const parsed = paramsSchema.safeParse(rawParams)
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "INVALID_TASK_ID", "任务 ID 格式不正确"), {
      status: 400
    })
  }

  const { taskId } = parsed.data

  try {
    const session = await getSessionFromRequest(req as unknown as NextRequest)
    const userId = session?.userId
    if (!userId) {
      return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), {
        status: 401
      })
    }

    const task = await getCozeAsyncTaskStatus(taskId)

    logger.info({
      event: "storyboard_script_body_task_status",
      module: "coze",
      traceId,
      taskId,
      status: task.status,
      message: "查询任务状态成功"
    })

    return NextResponse.json(
      makeApiOk(traceId, {
        taskId: task.taskId,
        status: task.status,
        createdAt: task.createdAt,
        startedAt: task.startedAt,
        completedAt: task.completedAt,
        result: task.status === "completed" ? task.result : undefined,
        error: task.status === "failed" ? task.error : undefined
      }),
      { status: 200 }
    )
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error)

    logger.error({
      event: "storyboard_script_body_task_status_error",
      module: "coze",
      traceId,
      taskId,
      message: "查询任务状态失败",
      error: msg
    })

    if (msg.includes("不存在")) {
      return NextResponse.json(makeApiErr(traceId, "TASK_NOT_FOUND", "任务不存在"), { status: 404 })
    }

    return NextResponse.json(makeApiErr(traceId, "TASK_STATUS_ERROR", "查询任务状态失败"), {
      status: 500
    })
  }
}
