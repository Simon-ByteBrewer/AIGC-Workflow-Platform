import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { stories, storyOutlines, videoCanvasSessions } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

export const runtime = "nodejs"

const CANVAS_SESSION_TTL_MS = 30_000

const acquireSchema = z.object({
  action: z.literal("acquire"),
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  clientId: z.string().trim().min(1).max(200)
})

const heartbeatSchema = z.object({
  action: z.literal("heartbeat"),
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  clientId: z.string().trim().min(1).max(200)
})

const releaseSchema = z.object({
  action: z.literal("release"),
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  clientId: z.string().trim().min(1).max(200)
})

const bodySchema = z.discriminatedUnion("action", [acquireSchema, heartbeatSchema, releaseSchema])

/**
 * 计算画布编辑租约的过期时间，避免异常关闭的页面永久占用编辑权。
 */
function getLeaseExpiresAt(now = new Date()): Date {
  return new Date(now.getTime() + CANVAS_SESSION_TTL_MS)
}

/**
 * 校验当前用户是否拥有目标画布，并确保 outline 仍属于该项目。
 */
async function assertCanvasAccess(input: {
  db: Awaited<ReturnType<typeof getDb>>
  userId: string
  storyId: string
  outlineId: string
}): Promise<{ code: string; message: string; status: number } | null> {
  const storyRows = await input.db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, input.storyId), eq(stories.userId, input.userId)))
    .limit(1)
  if (storyRows.length === 0) return { code: "STORY_NOT_FOUND", message: "未找到可用的项目", status: 404 }

  const outlineRows = await input.db
    .select({ id: storyOutlines.id })
    .from(storyOutlines)
    .where(and(eq(storyOutlines.id, input.outlineId), eq(storyOutlines.storyId, input.storyId), isNull(storyOutlines.deletedAt)))
    .limit(1)
  if (outlineRows.length === 0) return { code: "OUTLINE_NOT_FOUND", message: "剧集不存在", status: 404 }

  return null
}

/**
 * 创建或接管目标画布的编辑租约，后打开页面会覆盖旧页面。
 */
async function acquireCanvasSession(input: {
  db: Awaited<ReturnType<typeof getDb>>
  userId: string
  storyId: string
  outlineId: string
  clientId: string
  userAgent: string
}): Promise<{ expiresAt: Date; displacedClientId: string | null }> {
  const now = new Date()
  const expiresAt = getLeaseExpiresAt(now)
  const existingRows = await input.db
    .select({ clientId: videoCanvasSessions.clientId })
    .from(videoCanvasSessions)
    .where(
      and(
        eq(videoCanvasSessions.userId, input.userId),
        eq(videoCanvasSessions.storyId, input.storyId),
        eq(videoCanvasSessions.outlineId, input.outlineId)
      )
    )
    .limit(1)
  const displacedClientId = existingRows[0]?.clientId && existingRows[0].clientId !== input.clientId ? existingRows[0].clientId : null

  await input.db
    .insert(videoCanvasSessions)
    .values({
      userId: input.userId,
      storyId: input.storyId,
      outlineId: input.outlineId,
      clientId: input.clientId,
      userAgent: input.userAgent,
      openedAt: now,
      lastSeenAt: now,
      expiresAt,
      updatedAt: now
    })
    .onConflictDoUpdate({
      target: [videoCanvasSessions.userId, videoCanvasSessions.storyId, videoCanvasSessions.outlineId],
      set: {
        clientId: input.clientId,
        userAgent: input.userAgent,
        openedAt: now,
        lastSeenAt: now,
        expiresAt,
        updatedAt: now
      }
    })

  return { expiresAt, displacedClientId }
}

/**
 * 续期当前页面的编辑租约；如果已被新页面接管，则返回失效结果。
 */
async function heartbeatCanvasSession(input: {
  db: Awaited<ReturnType<typeof getDb>>
  userId: string
  storyId: string
  outlineId: string
  clientId: string
}): Promise<{ ok: true; expiresAt: Date } | { ok: false; code: string; message: string; status: number }> {
  const rows = await input.db
    .select({ clientId: videoCanvasSessions.clientId })
    .from(videoCanvasSessions)
    .where(
      and(
        eq(videoCanvasSessions.userId, input.userId),
        eq(videoCanvasSessions.storyId, input.storyId),
        eq(videoCanvasSessions.outlineId, input.outlineId)
      )
    )
    .limit(1)

  const row = rows[0]
  if (!row) return { ok: false, code: "CANVAS_SESSION_LOST", message: "画布编辑会话已失效", status: 409 }
  if (row.clientId !== input.clientId) return { ok: false, code: "CANVAS_SESSION_DISPLACED", message: "当前画布已在其他窗口打开", status: 409 }

  const now = new Date()
  const expiresAt = getLeaseExpiresAt(now)
  await input.db
    .update(videoCanvasSessions)
    .set({ lastSeenAt: now, expiresAt, updatedAt: now })
    .where(
      and(
        eq(videoCanvasSessions.userId, input.userId),
        eq(videoCanvasSessions.storyId, input.storyId),
        eq(videoCanvasSessions.outlineId, input.outlineId),
        eq(videoCanvasSessions.clientId, input.clientId)
      )
    )

  return { ok: true, expiresAt }
}

/**
 * 释放当前页面持有的编辑租约，避免正常关闭页面后等待超时。
 */
async function releaseCanvasSession(input: {
  db: Awaited<ReturnType<typeof getDb>>
  userId: string
  storyId: string
  outlineId: string
  clientId: string
}): Promise<void> {
  await input.db
    .delete(videoCanvasSessions)
    .where(
      and(
        eq(videoCanvasSessions.userId, input.userId),
        eq(videoCanvasSessions.storyId, input.storyId),
        eq(videoCanvasSessions.outlineId, input.outlineId),
        eq(videoCanvasSessions.clientId, input.clientId)
      )
    )
}

/**
 * 处理画布编辑租约的获取、续期和释放。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, storyOutlines, videoCanvasSessions })
  const accessError = await assertCanvasAccess({ db, userId, storyId: parsed.data.storyId, outlineId: parsed.data.outlineId })
  if (accessError) {
    return NextResponse.json(makeApiErr(traceId, accessError.code, accessError.message), { status: accessError.status })
  }

  if (parsed.data.action === "acquire") {
    const acquired = await acquireCanvasSession({
      db,
      userId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      clientId: parsed.data.clientId,
      userAgent: req.headers.get("user-agent") ?? ""
    })
    return NextResponse.json(
      makeApiOk(traceId, {
        clientId: parsed.data.clientId,
        expiresAt: acquired.expiresAt.toISOString(),
        displacedClientId: acquired.displacedClientId
      }),
      { status: 200 }
    )
  }

  if (parsed.data.action === "heartbeat") {
    const heartbeat = await heartbeatCanvasSession({
      db,
      userId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      clientId: parsed.data.clientId
    })
    if (!heartbeat.ok) return NextResponse.json(makeApiErr(traceId, heartbeat.code, heartbeat.message), { status: heartbeat.status })
    return NextResponse.json(makeApiOk(traceId, { clientId: parsed.data.clientId, expiresAt: heartbeat.expiresAt.toISOString() }), { status: 200 })
  }

  await releaseCanvasSession({
    db,
    userId,
    storyId: parsed.data.storyId,
    outlineId: parsed.data.outlineId,
    clientId: parsed.data.clientId
  })
  return NextResponse.json(makeApiOk(traceId, { released: true }), { status: 200 })
}
