import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { eq, inArray, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getExternalImageModelLabel, normalizeExternalImageModelCode } from "@/shared/image/externalImageModels"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { auditLogs, groupExternalImageModels, userGroups } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"

export const runtime = "nodejs"

function isExternalImageModelEnabled(): boolean {
  const raw = (process.env.EXTERNAL_IMAGE_MODEL_ENABLED ?? process.env.NEXT_PUBLIC_EXTERNAL_IMAGE_MODEL_ENABLED ?? "").toLowerCase().trim()
  return raw === "1" || raw === "true"
}

function maskApiKey(value: string): string {
  if (!value) return ""
  if (value.length <= 8) return `${value.slice(0, 2)}***${value.slice(-2)}`
  return `${value.slice(0, 4)}***${value.slice(-4)}`
}

const upsertSchema = z.object({
  modelName: z.string().trim().min(1).max(100),
  apiKey: z.string().trim().min(1).max(500),
  enabled: z.boolean().optional()
})

const toggleSchema = z.object({
  modelName: z.string().trim().min(1).max(100),
  enabled: z.boolean()
})

const deleteSchema = z.object({
  modelName: z.string().trim().min(1).max(100)
})

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  // 默认关闭：未配置环境变量时不会报错，只是不提供该能力
  if (!isExternalImageModelEnabled()) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部模型接入"), { status: 404 })
  }

  const { id } = await ctx.params
  if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ userGroups, groupExternalImageModels })
  const group = await db.select({ id: userGroups.id }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
  if (!group[0]?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

  const rows = await db
    .select({
      modelName: groupExternalImageModels.modelName,
      isEnabled: groupExternalImageModels.isEnabled,
      apiKey: groupExternalImageModels.apiKey,
      updatedAt: groupExternalImageModels.updatedAt
    })
    .from(groupExternalImageModels)
    .where(eq(groupExternalImageModels.groupId, id))

  const items = Array.from(
    new Map(
      rows
        .sort((a, b) => {
          const at = a.updatedAt instanceof Date ? a.updatedAt.getTime() : 0
          const bt = b.updatedAt instanceof Date ? b.updatedAt.getTime() : 0
          return bt - at
        })
        .map((row) => {
          const canonicalModelName = normalizeExternalImageModelCode(row.modelName)
          if (!canonicalModelName) return null
          return [
            canonicalModelName,
            {
              modelName: canonicalModelName,
              label: getExternalImageModelLabel(canonicalModelName),
              enabled: row.isEnabled,
              apiKeyConfigured: Boolean(row.apiKey),
              apiKeyMasked: row.apiKey ? maskApiKey(row.apiKey) : null
            }
          ] as const
        })
        .filter(Boolean) as Array<readonly [string, { modelName: string; label: string; enabled: boolean; apiKeyConfigured: boolean; apiKeyMasked: string | null }]>
    ).values()
  ).sort((a, b) => a.modelName.localeCompare(b.modelName))

  return NextResponse.json(
    makeApiOk(traceId, {
      items
    }),
    { status: 200 }
  )
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }
  if (!isExternalImageModelEnabled()) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部模型接入"), { status: 404 })
  }

  const { id } = await ctx.params
  if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
  const parsed = upsertSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ userGroups, auditLogs, groupExternalImageModels })
  const group = await db.select({ id: userGroups.id }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
  if (!group[0]?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

  const now = new Date()
  const modelName = normalizeExternalImageModelCode(parsed.data.modelName)
  if (!modelName) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "不支持的外部图片模型"), { status: 400 })
  }
  const apiKey = parsed.data.apiKey.trim()
  const enabled = parsed.data.enabled ?? true

  await db
    .insert(groupExternalImageModels)
    .values({
      groupId: id,
      modelName,
      apiKey,
      isEnabled: enabled,
      createdAt: now,
      updatedAt: now,
      createdBy: actor.userId,
      updatedBy: actor.userId
    })
    .onConflictDoUpdate({
      // conflict target uses unique index (group_id, model_name)
      target: [groupExternalImageModels.groupId, groupExternalImageModels.modelName],
      set: {
        apiKey,
        isEnabled: enabled,
        updatedAt: now,
        updatedBy: actor.userId
      }
    })

  // audit: do not log apiKey
  await db.execute(sql`
    insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
    values (
      ${actor.userId},
      'user_group.external_image_model.upsert',
      'user_group',
      ${id},
      null,
      '{}'::jsonb,
      ${JSON.stringify({ groupId: id, modelName, enabled, apiKeyConfigured: true })}::jsonb,
      ${actor.ip},
      ${actor.userAgent},
      ${traceId}
    )
  `)

  return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }
  if (!isExternalImageModelEnabled()) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部模型接入"), { status: 404 })
  }

  const { id } = await ctx.params
  if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
  const parsed = toggleSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ groupExternalImageModels, auditLogs })
  const modelName = normalizeExternalImageModelCode(parsed.data.modelName)
  if (!modelName) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "不支持的外部图片模型"), { status: 400 })
  }
  const enabled = parsed.data.enabled
  const now = new Date()

  const rows = await db
    .select({ id: groupExternalImageModels.id, modelName: groupExternalImageModels.modelName })
    .from(groupExternalImageModels)
    .where(eq(groupExternalImageModels.groupId, id))
  const targetIds = rows.filter((item) => normalizeExternalImageModelCode(item.modelName) === modelName).map((item) => item.id)
  if (targetIds.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部模型不存在"), { status: 404 })
  }
  const updated = await db
    .update(groupExternalImageModels)
    .set({ isEnabled: enabled, updatedAt: now, updatedBy: actor.userId })
    .where(inArray(groupExternalImageModels.id, targetIds))
    .returning({ modelName: groupExternalImageModels.modelName })

  if (!updated[0]?.modelName) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部模型不存在"), { status: 404 })
  }

  await db.execute(sql`
    insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
    values (
      ${actor.userId},
      'user_group.external_image_model.toggle',
      'user_group',
      ${id},
      null,
      ${JSON.stringify({ groupId: id, modelName })}::jsonb,
      ${JSON.stringify({ groupId: id, modelName, enabled })}::jsonb,
      ${actor.ip},
      ${actor.userAgent},
      ${traceId}
    )
  `)

  return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }
  if (!isExternalImageModelEnabled()) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部模型接入"), { status: 404 })
  }

  const { id } = await ctx.params
  if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
  const parsed = deleteSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ groupExternalImageModels, auditLogs })
  const modelName = normalizeExternalImageModelCode(parsed.data.modelName)
  if (!modelName) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "不支持的外部图片模型"), { status: 400 })
  }

  const rows = await db
    .select({ id: groupExternalImageModels.id, modelName: groupExternalImageModels.modelName })
    .from(groupExternalImageModels)
    .where(eq(groupExternalImageModels.groupId, id))
  const targetIds = rows.filter((item) => normalizeExternalImageModelCode(item.modelName) === modelName).map((item) => item.id)
  if (targetIds.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部模型不存在"), { status: 404 })
  }
  const deleted = await db
    .delete(groupExternalImageModels)
    .where(inArray(groupExternalImageModels.id, targetIds))
    .returning({ modelName: groupExternalImageModels.modelName })

  if (!deleted[0]?.modelName) {
    return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部模型不存在"), { status: 404 })
  }

  await db.execute(sql`
    insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
    values (
      ${actor.userId},
      'user_group.external_image_model.delete',
      'user_group',
      ${id},
      null,
      ${JSON.stringify({ groupId: id, modelName })}::jsonb,
      '{}'::jsonb,
      ${actor.ip},
      ${actor.userAgent},
      ${traceId}
    )
  `)

  return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
}
