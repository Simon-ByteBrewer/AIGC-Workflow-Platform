import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { episodeMaterialAssets, episodeMaterialImages } from "@/shared/schema/generation"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

export const runtime = "nodejs"

export async function GET(req: NextRequest, ctx: { params: Promise<{ materialId: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const params = await ctx.params
  const materialId = (params?.materialId ?? "").trim()
  if (!materialId) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ storyId: url.searchParams.get("storyId") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialImages, episodeMaterialAssets })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const batch = await db
    .select({
      id: episodeMaterialImages.id,
      outlineId: episodeMaterialImages.outlineId,
      name: episodeMaterialImages.name,
      url: episodeMaterialImages.url,
      meta: episodeMaterialImages.meta,
      createdAt: episodeMaterialImages.createdAt
    })
    .from(episodeMaterialImages)
    .where(and(eq(episodeMaterialImages.id, materialId), eq(episodeMaterialImages.storyId, parsed.data.storyId)))
    .limit(1)

  const item = batch[0] ?? null
  if (!item) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到图片素材批次"), { status: 404 })

  const assets = await db
    .select({
      id: episodeMaterialAssets.id,
      kind: episodeMaterialAssets.kind,
      name: episodeMaterialAssets.name,
      roleName: episodeMaterialAssets.roleName,
      makeupName: episodeMaterialAssets.makeupName,
      costumeName: episodeMaterialAssets.costumeName,
      prompt: episodeMaterialAssets.prompt,
      url: episodeMaterialAssets.url,
      meta: episodeMaterialAssets.meta,
      createdAt: episodeMaterialAssets.createdAt
    })
    .from(episodeMaterialAssets)
    .where(and(eq(episodeMaterialAssets.storyId, parsed.data.storyId), eq(episodeMaterialAssets.materialId, materialId)))
    .orderBy(desc(episodeMaterialAssets.createdAt))

  return NextResponse.json(makeApiOk(traceId, { batch: item, assets }), { status: 200 })
}
