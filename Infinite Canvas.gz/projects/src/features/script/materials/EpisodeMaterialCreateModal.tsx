"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import { readAcceptedJobIdFromStream } from "@/shared/readAcceptedJobIdFromStream"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"
import styles from "./EpisodeMaterialGalleryPage.module.css"

type Props = {
  storyId: string
  kind: "scene" | "role" | "item"
  roleNameOptions: string[]
  onClose: () => void
  onSubmitted: () => void
}

function kindLabel(kind: string): string {
  if (kind === "scene") return "场景"
  if (kind === "role") return "人物"
  if (kind === "item") return "物品"
  return kind
}

export function EpisodeMaterialCreateModal({ storyId, kind, roleNameOptions, onClose, onSubmitted }: Props): ReactElement {
  const sid = (storyId ?? "").trim()
  const [name, setName] = useState("")
  const [prompt, setPrompt] = useState("")
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [uploadSingle, setUploadSingle] = useState<File | null>(null)
  const [uploadFront, setUploadFront] = useState<File | null>(null)
  const [uploadBack, setUploadBack] = useState<File | null>(null)
  const [fileInputSeed, setFileInputSeed] = useState(0)

  const [roleName, setRoleName] = useState("")
  const [characterKey, setCharacterKey] = useState("")
  const [characterId, setCharacterId] = useState("")
  const [makeupName, setMakeupName] = useState("")
  const [costumeName, setCostumeName] = useState("")
  const [roleOptions, setRoleOptions] = useState<{ makeup: string[]; costume: string[] }>({ makeup: [], costume: [] })
  const [promptTouched, setPromptTouched] = useState(false)
  const [cameraOne, setCameraOne] = useState("")
  const [cameraTwo, setCameraTwo] = useState("")
  const [characterCandidates, setCharacterCandidates] = useState<Array<{ characterKey: string; displayName: string; characterId: string }>>([])

  useEffect(() => {
    setName("")
    setPrompt("")
    setError(null)
    setSubmitting(false)
    setRoleName("")
    setCharacterKey("")
    setCharacterId("")
    setMakeupName("")
    setCostumeName("")
    setRoleOptions({ makeup: [], costume: [] })
    setPromptTouched(false)
    setCameraOne("")
    setCameraTwo("")
    setCharacterCandidates([])
    setUploadSingle(null)
    setUploadFront(null)
    setUploadBack(null)
    setFileInputSeed((s) => s + 1)
  }, [kind])

  useEffect(() => {
    if (!sid) return
    if (kind !== "role") return
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch(`/api/library/stories/${encodeURIComponent(sid)}/detail`, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { story?: any }; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        if (cancelled) return
        const story = (json.data as any)?.story ?? null
        const meta = story && typeof story === "object" ? (story as any).metadata : null
        const shortDrama = meta && typeof meta === "object" ? (meta as any).shortDrama : null
        const roleImageDraws = shortDrama && typeof shortDrama === "object" ? (shortDrama as any).roleImageDraws : null
        const characterSettingRaw = shortDrama && typeof shortDrama === "object" ? (shortDrama as any).characterSetting : null
        const unwrap = (v: any) => {
          if (v && typeof v === "object" && v.character_settings && typeof v.character_settings === "object") return v.character_settings
          return v && typeof v === "object" ? v : {}
        }
        const inner = unwrap(characterSettingRaw as any)
        const characters = Array.isArray((inner as any).characters) ? ((inner as any).characters as any[]) : []
        const toText = (x: any) => (typeof x === "string" ? x : x == null ? "" : String(x))
        const pickDraw = (key: string, displayName: string) => {
          const a = roleImageDraws && typeof roleImageDraws === "object" ? (roleImageDraws as any)[key] : null
          const b = roleImageDraws && typeof roleImageDraws === "object" ? (roleImageDraws as any)[displayName] : null
          return (a && typeof a === "object" ? a : null) ?? (b && typeof b === "object" ? b : null) ?? null
        }
        const list: Array<{ characterKey: string; displayName: string; characterId: string }> = []
        for (let i = 0; i < characters.length; i += 1) {
          const c = characters[i]
          if (!c || typeof c !== "object") continue
          const key = toText((c as any).character_id).trim()
          const displayName = toText((c as any).character_name).trim() || (key ? key : `角色${i + 1}`)
          if (!key) continue
          const draw = pickDraw(key, displayName)
          const selectedUrl = (draw && typeof draw.selectedUrl === "string" ? draw.selectedUrl.trim() : "") || ""
          const byUrl = selectedUrl && draw && typeof draw === "object" ? (draw as any).assetSelectionByFrontImageUrl?.[selectedUrl] : null
          const sel = (byUrl && typeof byUrl === "object" ? byUrl : null) ?? (draw && typeof draw === "object" ? (draw as any).assetSelection : null)
          const cid = sel && typeof sel === "object" ? toText((sel as any).characterId).trim() : ""
          list.push({ characterKey: key, displayName, characterId: cid })
        }
        setCharacterCandidates(list)
        if (!roleName.trim()) {
          const first = list[0]
          const fallbackName = roleNameOptions[0] ?? ""
          setRoleName(first?.displayName ?? fallbackName)
          setCharacterKey(first?.characterKey ?? "")
          setCharacterId(first?.characterId ?? "")
        }
      } catch (e) {
        const anyErr = e as { message?: string }
        if (!cancelled) setError(anyErr?.message ?? "加载人物列表失败")
        if (!cancelled && !roleName.trim() && roleNameOptions.length) setRoleName(roleNameOptions[0] ?? "")
      }
    })()
    return () => {
      cancelled = true
    }
  }, [kind, roleName, roleNameOptions, sid])

  useEffect(() => {
    if (!sid) return
    if (kind !== "role") return
    const rn = roleName.trim()
    if (!rn) return
    let cancelled = false
    void (async () => {
      try {
        const query = characterId.trim()
          ? `/api/script/episode-material-assets/options?storyId=${encodeURIComponent(sid)}&characterId=${encodeURIComponent(characterId.trim())}`
          : `/api/script/episode-material-assets/options?storyId=${encodeURIComponent(sid)}&roleName=${encodeURIComponent(rn)}`
        const res = await fetch(query, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { makeup?: string[]; costume?: string[] }; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        if (cancelled) return
        const makeup = Array.isArray(json.data?.makeup) ? json.data?.makeup : []
        const costume = Array.isArray(json.data?.costume) ? json.data?.costume : []
        setRoleOptions({ makeup, costume })
        setMakeupName((prev) => prev || makeup[0] || "")
        setCostumeName((prev) => prev || costume[0] || "")
      } catch (e) {
        const anyErr = e as { message?: string }
        if (!cancelled) setError(anyErr?.message ?? "加载妆造/服装选项失败")
      }
    })()
    return () => {
      cancelled = true
    }
  }, [characterId, kind, roleName, sid])

  useEffect(() => {
    if (kind !== "role") return
    if (promptTouched) return
    const rn = roleName.trim()
    const mk = makeupName.trim()
    const cs = costumeName.trim()
    if (!rn && !mk && !cs) return
    const next = [rn ? `人物：${rn}` : "", mk ? `妆造：${mk}` : "", cs ? `服装：${cs}` : ""].filter(Boolean).join("\n")
    setPrompt(next)
  }, [costumeName, kind, makeupName, promptTouched, roleName])

  useEffect(() => {
    if (kind !== "scene") return
    if (promptTouched) return
    const c1 = cameraOne.trim()
    const c2 = cameraTwo.trim()
    if (!c1 && !c2) return
    setPrompt([c1, c2].filter(Boolean).join("\n"))
  }, [cameraOne, cameraTwo, kind, promptTouched])

  const title = useMemo(() => `新增${kindLabel(kind)}`, [kind])

  const uploadEnabled = useMemo(() => {
    if (kind === "scene") return Boolean(uploadFront)
    return Boolean(uploadSingle)
  }, [kind, uploadFront, uploadSingle])

  const canSubmit = useMemo(() => {
    if (!sid) return false
    if (submitting) return false
    if (uploadEnabled) {
      if (kind === "scene") return Boolean(name.trim() && uploadFront)
      if (kind === "role") return Boolean(roleName.trim() && uploadSingle)
      return Boolean(name.trim() && uploadSingle)
    }
    if (kind === "role") return Boolean(roleName.trim() && makeupName.trim() && costumeName.trim() && prompt.trim())
    if (kind === "scene") return Boolean(name.trim() && cameraOne.trim() && cameraTwo.trim() && prompt.trim())
    return Boolean(name.trim() && prompt.trim())
  }, [cameraOne, cameraTwo, costumeName, kind, makeupName, name, prompt, roleName, sid, submitting, uploadEnabled, uploadFront, uploadSingle])

  const submit = useCallback(async () => {
    if (!canSubmit) return
    setSubmitting(true)
    setError(null)
    try {
      if (uploadEnabled) {
        const formData = new FormData()
        formData.set("storyId", sid)
        formData.set("kind", kind)
        if (kind === "role") formData.set("name", roleName.trim())
        else formData.set("name", name.trim())
        if (prompt.trim()) formData.set("prompt", prompt.trim())
        if (kind === "scene") {
          if (cameraOne.trim()) formData.set("cameraOne", cameraOne.trim())
          if (cameraTwo.trim()) formData.set("cameraTwo", cameraTwo.trim())
        }
        if (kind === "role") {
          if (roleName.trim()) formData.set("roleName", roleName.trim())
          if (characterId.trim()) formData.set("characterId", characterId.trim())
          if (makeupName.trim()) formData.set("makeupName", makeupName.trim())
          if (costumeName.trim()) formData.set("costumeName", costumeName.trim())
        }

        if (kind === "scene") {
          if (!uploadFront) throw new Error("请先选择场景正视图")
          formData.set("front", uploadFront)
          if (uploadBack) formData.set("back", uploadBack)
        } else {
          if (!uploadSingle) throw new Error("请先选择图片")
          formData.set("file", uploadSingle)
        }

        const res = await fetch("/api/script/episode-material-assets/upload", { method: "POST", body: formData })
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { assetId?: string }; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        onSubmitted()
        return
      }

      const body =
        kind === "role"
          ? {
              storyId: sid,
              kind,
              name: roleName.trim(),
              roleName: roleName.trim(),
              characterId: characterId.trim() || undefined,
              makeupName: makeupName.trim(),
              costumeName: costumeName.trim(),
              prompt: prompt.trim()
            }
          : kind === "scene"
            ? {
                storyId: sid,
                kind,
                name: name.trim(),
                prompt: prompt.trim(),
                cameraOne: cameraOne.trim(),
                cameraTwo: cameraTwo.trim()
              }
          : {
              storyId: sid,
              kind,
              name: name.trim(),
              prompt: prompt.trim()
            }
      const res = await fetch("/api/script/episode-material-assets/create-and-generate/stream", {
        method: "POST",
        headers: { "content-type": "application/json", accept: "text/event-stream" },
        body: JSON.stringify(body)
      })
      if (!res.ok) {
        const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: { message?: string } } | null
        throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      }
      await readAcceptedJobIdFromStream({ res })
      onSubmitted()
      window.dispatchEvent(new Event("open_task_center"))
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "提交失败")
    } finally {
      setSubmitting(false)
    }
  }, [
    cameraOne,
    cameraTwo,
    canSubmit,
    characterId,
    costumeName,
    kind,
    makeupName,
    name,
    onSubmitted,
    prompt,
    roleName,
    sid,
    uploadBack,
    uploadEnabled,
    uploadFront,
    uploadSingle
  ])

  return (
    <div
      className={styles.modalOverlay}
      role="dialog"
      aria-modal="true"
      aria-label={title}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>{title}</div>
          <div className={styles.actions}>
            <button type="button" className={styles.btn} onClick={onClose} disabled={submitting}>
              关闭
            </button>
          </div>
        </div>

        {error ? <div className={styles.hint}>{error}</div> : null}

        {kind === "role" ? (
          <>
            <div className={styles.row}>
              <ListboxSelect
                className={styles.btn}
                value={characterKey || (characterCandidates[0]?.characterKey ?? "")}
                ariaLabel="选择人物"
                options={characterCandidates.map((c) => ({ value: c.characterKey, label: c.characterId ? c.displayName : `${c.displayName}（未入库）` }))}
                onChange={(v) => {
                  const next = characterCandidates.find((c) => c.characterKey === v) ?? null
                  setCharacterKey(v)
                  setRoleName(next?.displayName ?? "")
                  setCharacterId(next?.characterId ?? "")
                  setRoleOptions({ makeup: [], costume: [] })
                  setMakeupName("")
                  setCostumeName("")
                }}
                disabled={characterCandidates.length === 0}
              />
              <input
                className={styles.textarea}
                style={{ minHeight: 0, height: 36, resize: "none" as any }}
                value={roleName}
                onChange={(e) => {
                  setRoleName(e.target.value)
                  setCharacterKey("")
                  setCharacterId("")
                }}
                placeholder="人物名（可手动输入）"
              />
            </div>
            <div className={styles.field}>
              <div className={styles.fieldLabel}>本地人物图</div>
              <div className={styles.row}>
                <input
                  key={`role-file-${fileInputSeed}`}
                  className={styles.fileInput}
                  type="file"
                  accept="image/*"
                  onChange={(e) => setUploadSingle(e.currentTarget.files?.[0] ?? null)}
                />
                <button
                  type="button"
                  className={styles.btn}
                  onClick={() => {
                    setUploadSingle(null)
                    setFileInputSeed((s) => s + 1)
                  }}
                  disabled={!uploadSingle || submitting}
                >
                  清除图片
                </button>
              </div>
              <div className={styles.hint}>选择图片后将走“上传添加”，不进入任务中心。</div>
            </div>
            <div className={styles.row}>
              <ListboxSelect
                className={styles.btn}
                value={makeupName || roleOptions.makeup[0] || ""}
                ariaLabel="选择妆造"
                options={roleOptions.makeup.map((v) => ({ value: v, label: v }))}
                onChange={(v) => setMakeupName(v)}
                disabled={roleOptions.makeup.length === 0}
              />
              <input
                className={styles.textarea}
                style={{ minHeight: 0, height: 36, resize: "none" as any }}
                value={makeupName}
                onChange={(e) => setMakeupName(e.target.value)}
                placeholder="妆造名（可手动输入）"
              />
            </div>
            <div className={styles.row}>
              <ListboxSelect
                className={styles.btn}
                value={costumeName || roleOptions.costume[0] || ""}
                ariaLabel="选择服装"
                options={roleOptions.costume.map((v) => ({ value: v, label: v }))}
                onChange={(v) => setCostumeName(v)}
                disabled={roleOptions.costume.length === 0}
              />
              <input
                className={styles.textarea}
                style={{ minHeight: 0, height: 36, resize: "none" as any }}
                value={costumeName}
                onChange={(e) => setCostumeName(e.target.value)}
                placeholder="服装名（可手动输入）"
              />
            </div>
          </>
        ) : kind === "scene" ? (
          <>
            <input
              className={styles.textarea}
              style={{ minHeight: 0, height: 36, resize: "none" as any }}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="场景名称"
            />
            <div className={styles.row}>
              <textarea
                className={styles.textarea}
                style={{ minHeight: 80 }}
                value={cameraOne}
                onChange={(e) => setCameraOne(e.target.value)}
                placeholder="场景正视图描述"
              />
              <textarea
                className={styles.textarea}
                style={{ minHeight: 80 }}
                value={cameraTwo}
                onChange={(e) => setCameraTwo(e.target.value)}
                placeholder="场景背视图描述"
              />
            </div>
            <div className={styles.field}>
              <div className={styles.fieldLabel}>本地场景图</div>
              <div className={styles.row}>
                <div className={styles.field}>
                  <div className={styles.fieldLabel}>正视图</div>
                  <input
                    key={`scene-front-${fileInputSeed}`}
                    className={styles.fileInput}
                    type="file"
                    accept="image/*"
                    onChange={(e) => setUploadFront(e.currentTarget.files?.[0] ?? null)}
                  />
                </div>
                <div className={styles.field}>
                  <div className={styles.fieldLabel}>背视图（可选）</div>
                  <input
                    key={`scene-back-${fileInputSeed}`}
                    className={styles.fileInput}
                    type="file"
                    accept="image/*"
                    onChange={(e) => setUploadBack(e.currentTarget.files?.[0] ?? null)}
                  />
                </div>
              </div>
              <div className={styles.actions}>
                <button
                  type="button"
                  className={styles.btn}
                  onClick={() => {
                    setUploadFront(null)
                    setUploadBack(null)
                    setFileInputSeed((s) => s + 1)
                  }}
                  disabled={(!uploadFront && !uploadBack) || submitting}
                >
                  清除图片
                </button>
              </div>
              <div className={styles.hint}>只上传一张时，会自动用同一张图作为正视/背视。</div>
            </div>
          </>
        ) : (
          <>
            <input
              className={styles.textarea}
              style={{ minHeight: 0, height: 36, resize: "none" as any }}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={`${kindLabel(kind)}名称`}
            />
            <div className={styles.field}>
              <div className={styles.fieldLabel}>本地物品图</div>
              <div className={styles.row}>
                <input
                  key={`item-file-${fileInputSeed}`}
                  className={styles.fileInput}
                  type="file"
                  accept="image/*"
                  onChange={(e) => setUploadSingle(e.currentTarget.files?.[0] ?? null)}
                />
                <button
                  type="button"
                  className={styles.btn}
                  onClick={() => {
                    setUploadSingle(null)
                    setFileInputSeed((s) => s + 1)
                  }}
                  disabled={!uploadSingle || submitting}
                >
                  清除图片
                </button>
              </div>
              <div className={styles.hint}>选择图片后将走“上传添加”，不进入任务中心。</div>
            </div>
          </>
        )}

        <textarea
          className={styles.textarea}
          value={prompt}
          onChange={(e) => {
            setPromptTouched(true)
            setPrompt(e.target.value)
          }}
          placeholder={kind === "scene" ? "提示词（默认使用上面的正视/背视描述拼接）" : "输入提示词"}
        />
        <div className={styles.actions}>
          <button type="button" className={`${styles.btn} ${styles.btnPrimary}`} onClick={() => void submit()} disabled={!canSubmit}>
            {submitting ? "提交中…" : uploadEnabled ? "上传" : "生成"}
          </button>
        </div>
        <div className={styles.hint}>{uploadEnabled ? "上传成功后刷新即可看到新结果。" : "提交后会进入任务中心队列，完成后刷新即可看到新结果。"}</div>
      </div>
    </div>
  )
}
