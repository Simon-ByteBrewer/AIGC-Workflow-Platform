import { NextResponse, type NextRequest } from "next/server"
import { and, desc, eq, like, sql } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

const querySchema = z.object({
  query: z.string().trim().max(200).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ query: url.searchParams.get("query") ?? undefined })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories })

  const conditions = [eq(stories.userId, userId)]
  const q = parsed.data.query?.trim() ?? ""
  if (q) conditions.push(like(stories.title, `%${q}%`))

  const rows = await db
    .select({
      id: stories.id,
      title: stories.title,
      storyType: stories.storyType,
      progressStage: stories.progressStage,
      videoCategory: stories.videoCategory,
      updatedAt: stories.updatedAt,
      createdAt: stories.createdAt
    })
    .from(stories)
    .where(and(...conditions))
    .orderBy(desc(sql`coalesce(${stories.updatedAt}, ${stories.createdAt})`), desc(stories.createdAt))
    .limit(500)

  const items = rows.map((r) => {
    const time = r.updatedAt ?? r.createdAt
    const label = time
      ? new Date(time)
          .toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false })
          .replace(/\//g, "-")
      : null
    return {
      id: r.id,
      title: r.title || "未命名",
      storyType: r.storyType ?? null,
      progressStage: r.progressStage ?? null,
      videoCategory: r.videoCategory ?? null,
      updatedAt: label
    }
  })

  return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
}

