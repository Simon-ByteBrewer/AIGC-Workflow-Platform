import { NextResponse, type NextRequest } from "next/server"
import { and, desc, eq, isNull, like } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { virtualAvatars } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const querySchema = z.object({
  search: z.string().trim().max(200).optional()
})

const createSchema = z.object({
  name: z.string().trim().min(1).max(200),
  assetId: z.string().trim().min(1).max(2000),
  refImageKey: z.string().trim().min(1).max(5000),
  refImagePreviewKey: z.string().trim().min(1).max(5000).optional()
})

function normalizeAssetId(raw: string): string {
  let a = String(raw ?? "").trim()
  if (!a) return ""
  if ((a.startsWith("`") && a.endsWith("`")) || (a.startsWith("\"") && a.endsWith("\"")) || (a.startsWith("'") && a.endsWith("'"))) {
    a = a.slice(1, -1).trim()
  }
  while (a.startsWith("asset://")) a = a.slice("asset://".length).trim()
  return a
}

/**
 * 将一条虚拟人像记录归一化成前端可消费的数据结构，并补齐参考图 URL（预签名）。
 */
async function normalizeAvatarRow(row: {
  id: string
  name: string
  uri: string
  refImageKey: string
  refImagePreviewKey: string | null
  createdAt: Date
  updatedAt: Date
}): Promise<Record<string, unknown>> {
  const storage = getS3Storage()
  const key = (row.refImagePreviewKey || row.refImageKey || "").trim()
  const refImageUrl = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
  return {
    id: row.id,
    name: row.name,
    assetId: row.uri,
    refImageKey: row.refImageKey,
    refImagePreviewKey: row.refImagePreviewKey,
    refImageUrl,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  }
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({ search: url.searchParams.get("search") ?? undefined })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ virtualAvatars })

  const conditions = [eq(virtualAvatars.userId, userId), isNull(virtualAvatars.deletedAt)]
  const s = parsed.data.search?.trim() ?? ""
  if (s) conditions.push(like(virtualAvatars.name, `%${s}%`))

  const rows = await db
    .select({
      id: virtualAvatars.id,
      name: virtualAvatars.name,
      uri: virtualAvatars.uri,
      refImageKey: virtualAvatars.refImageKey,
      refImagePreviewKey: virtualAvatars.refImagePreviewKey,
      createdAt: virtualAvatars.createdAt,
      updatedAt: virtualAvatars.updatedAt
    })
    .from(virtualAvatars)
    .where(and(...conditions))
    .orderBy(desc(virtualAvatars.createdAt))
    .limit(500)

  const items = await Promise.all(rows.map((r) => normalizeAvatarRow(r as any)))
  return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = createSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ virtualAvatars })

  try {
    const normalizedAssetId = normalizeAssetId(parsed.data.assetId)
    if (!normalizedAssetId) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "assetID 不正确"), { status: 400 })
    }
    const dup = await db
      .select({ id: virtualAvatars.id })
      .from(virtualAvatars)
      .where(and(eq(virtualAvatars.userId, userId), eq(virtualAvatars.uri, normalizedAssetId), isNull(virtualAvatars.deletedAt)))
      .limit(1)
    if (dup[0]?.id) {
      return NextResponse.json(makeApiErr(traceId, "DUPLICATE_ASSET_ID", "assetID 已存在，请换一个"), { status: 409 })
    }

    const inserted = await db
      .insert(virtualAvatars)
      .values({
        userId,
        name: parsed.data.name,
        uri: normalizedAssetId,
        refImageKey: parsed.data.refImageKey,
        refImagePreviewKey: parsed.data.refImagePreviewKey ?? null,
        updatedAt: new Date()
      } as any)
      .returning({
        id: virtualAvatars.id,
        name: virtualAvatars.name,
        uri: virtualAvatars.uri,
        refImageKey: virtualAvatars.refImageKey,
        refImagePreviewKey: virtualAvatars.refImagePreviewKey,
        createdAt: virtualAvatars.createdAt,
        updatedAt: virtualAvatars.updatedAt
      })

    const rec = inserted[0]
    if (!rec?.id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
    const item = await normalizeAvatarRow(rec as any)
    return NextResponse.json(makeApiOk(traceId, { item }), { status: 200 })
  } catch (e: any) {
    const msg = String(e?.message ?? "")
    if (e?.code === "23505" || msg.toLowerCase().includes("unique") || msg.toLowerCase().includes("duplicate")) {
      return NextResponse.json(makeApiErr(traceId, "DUPLICATE_ASSET_ID", "assetID 已存在，请换一个"), { status: 409 })
    }
    return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建失败"), { status: 500 })
  }
}
