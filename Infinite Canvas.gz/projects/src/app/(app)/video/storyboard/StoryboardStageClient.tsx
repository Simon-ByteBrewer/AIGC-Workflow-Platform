"use client"

import { useMemo, type ReactElement } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import styles from "../page.module.css"
import { ProgressNav } from "@/shared/ui/ProgressNav"
import progressNavStyles from "@/shared/ui/ProgressNav.module.css"
import { StoryboardList } from "@/features/video/components/StoryboardList"

type Stage = "description" | "frames" | "videos"

export function StoryboardStageClient({
  stage,
  initialStoryId,
  initialOutlineId
}: {
  stage: Stage
  initialStoryId?: string
  initialOutlineId?: string
}): ReactElement {
  const router = useRouter()
  const searchParams = useSearchParams()

  const urlStoryId = useMemo(() => searchParams.get("storyId") ?? initialStoryId ?? "", [initialStoryId, searchParams])
  const urlOutlineId = useMemo(
    () => searchParams.get("outlineId") ?? initialOutlineId ?? "",
    [initialOutlineId, searchParams]
  )
  const autoGenerateRaw = searchParams.get("autoGenerate")
  const autoGenerateMode = autoGenerateRaw === "script" ? "script" : autoGenerateRaw === "true" ? "all" : undefined
  const forceStoryboardText = searchParams.get("forceStoryboardText") === "true"

  const activeKey = stage === "frames" ? "storyboard_frames" : stage === "videos" ? "storyboard_videos" : "storyboard_desc"

  const buildQs = (extra?: Record<string, string>) => {
    const qs = new URLSearchParams()
    if (urlStoryId) qs.set("storyId", urlStoryId)
    if (urlOutlineId) qs.set("outlineId", urlOutlineId)
    if (autoGenerateRaw) qs.set("autoGenerate", autoGenerateRaw)
    const videoCount = searchParams.get("videoCount")
    if (videoCount) qs.set("videoCount", videoCount)
    const runId = searchParams.get("autoGenerateRunId")
    if (runId) qs.set("autoGenerateRunId", runId)
    const forceStoryboardText = searchParams.get("forceStoryboardText")
    if (forceStoryboardText) qs.set("forceStoryboardText", forceStoryboardText)
    for (const [k, v] of Object.entries(extra ?? {})) qs.set(k, v)
    return qs.toString()
  }

  return (
    <main className={styles.container}>
      <ProgressNav
        activeKey={activeKey}
        rightSlot={
          <button
            type="button"
            className={`${progressNavStyles.step} ${progressNavStyles.actionButton}`}
            onClick={() => {
              router.push(`/video/storyboard/shot?${buildQs()}`)
            }}
          >
            单独生成镜头
          </button>
        }
        steps={[
          {
            key: "script_setup",
            label: "剧本设置",
            href: urlStoryId ? `/script/short-drama/${encodeURIComponent(urlStoryId)}` : "/script"
          },
          {
            key: "script_body",
            label: "剧本正文",
            href: urlStoryId ? `/script/workspace/${encodeURIComponent(urlStoryId)}?mode=brief` : "/script"
          },
          { key: "storyboard_desc", label: "分镜描述", href: `/video/storyboard/description?${buildQs()}` },
          { key: "storyboard_frames", label: "分镜镜头", href: `/video/storyboard/frames?${buildQs()}` },
          { key: "storyboard_videos", label: "分镜视频", href: `/video/storyboard/videos?${buildQs()}` },
        ]}
      />

      <div className={`${styles.headerCard} ${styles.headerCardCompact}`}>
        <div className={`${styles.headerLeft} ${styles.headerLeftCompact}`}>
          <div className={`${styles.headerTag} ${styles.headerTagCompact}`}>视频创作</div>
          <div className={styles.headerSubtitle}>
            {autoGenerateMode
              ? "正在从剧本自动生成分镜，你可以随时查看生成详情与任务进度。"
              : "先在分镜表整理镜头与素材，再进入生图/生视频工作台。"}
          </div>
        </div>
        <div className={`${styles.tabs} ${styles.tabsCompact}`}>
          <button
            type="button"
            className={`${styles.tab} ${styles.tabCompact} ${styles.activeTab}`}
            onClick={() => {
              router.push(`/video/storyboard/description?${buildQs()}`)
            }}
          >
            分镜表
          </button>
          <button
            type="button"
            className={`${styles.tab} ${styles.tabCompact}`}
            onClick={() => {
              const qs = new URLSearchParams({ tab: "board" })
              if (urlStoryId) qs.set("storyId", urlStoryId)
              if (urlOutlineId) qs.set("outlineId", urlOutlineId)
              router.push(`/video?${qs.toString()}`)
            }}
          >
            分镜故事板
          </button>
        </div>
      </div>

      <div className={`${styles.contentCard} ${styles.contentCardCompact}`}>
        <StoryboardList
          storyId={urlStoryId || undefined}
          outlineId={urlOutlineId || undefined}
          autoGenerate={autoGenerateMode}
          forceStoryboardText={forceStoryboardText}
          stage={stage}
        />
      </div>
    </main>
  )
}
