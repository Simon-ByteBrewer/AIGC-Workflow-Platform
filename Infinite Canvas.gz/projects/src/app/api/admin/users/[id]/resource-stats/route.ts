import { NextResponse, type NextRequest } from "next/server"
import { eq, and, sql, inArray } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { jobs, storyAssetLibrary, episodeMaterialAssets, storyboards, storyOutlines, stories } from "@/shared/schema"
import { requireAdmin } from "@/server/domains/admin/services/adminGuard"
import { 
  FIRST_FRAME_JOB_TYPE, 
  VIDEO_GENERATE_JOB_TYPE, 
  EPISODE_MATERIAL_GENERATE_JOB_TYPE, 
  VOICEOVER_AUDIO_GENERATE_JOB_TYPE, 
  JIAN_YING_EXPORT_JOB_TYPE, 
  CANVAS_VIDEO_GENERATE_JOB_TYPE,
  SHORT_DRAMA_ROLE_IMAGE_DRAW_JOB_TYPE,
  SHORT_DRAMA_ROLE_ASSET_DRAW_JOB_TYPE
} from "@/shared/jobs/jobTypes"

export const runtime = "nodejs"

const REFERENCE_IMAGE_JOB_TYPE = "reference_image_generate"

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const admin = await requireAdmin(req, traceId)
    if (admin instanceof Response) return admin

    const { id } = await ctx.params
    const userId = id?.trim()
    if (!userId) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户 ID"), { status: 400 })

    await ensurePublicSchema()
    // NOTE: 引入的 schema 必须完全包含表定义，以防 drizzle query builder 出错
    const db = await getDb({ jobs, storyAssetLibrary, episodeMaterialAssets, storyboards, storyOutlines, stories })

    // 1. 获取该用户的所有任务（不论最终状态，因为失败的任务可能也成功生成了部分图片/音视频）
    // 注意：为了避免下载过大的全量 JSONB 导致 statement_timeout，这里仅投影我们统计需要的关键字段
    const userJobs = await db
      .select({
        type: jobs.type,
        status: jobs.status,
        payload: sql<any>`jsonb_build_object(
          'first_image', ${jobs.payload}->'first_image',
          'drawCount', ${jobs.payload}->'drawCount'
        )`,
        snapshot: sql<any>`jsonb_build_object(
          'summary', ${jobs.snapshot}->'summary',
          'done', ${jobs.snapshot}->'done',
          'progress', ${jobs.snapshot}->'progress',
          'results', ${jobs.snapshot}->'results',
          'storyId', ${jobs.snapshot}->'storyId',
          'items', ${jobs.snapshot}->'items',
          'video', ${jobs.snapshot}->'video'
        )`
      })
      .from(jobs)
      .where(eq(jobs.userId, userId))

    let imageGenerateCount = 0
    let imageGenerateFirstFrameCount = 0
    let imageGenerateMaterialCount = 0
    let imageGenerateRoleFrontCount = 0
    let imageGenerateRoleAssetCount = 0
    let videoGenerateCount = 0
    let audioGenerateCount = 0
    let firstFrameVideoCount = 0
    let episodeMaterialGenerateCount = 0
    let jianyingExportVideoCount = 0
    let jianyingExportAudioCount = 0

    const exportedStoryIds = new Set<string>()

    // 遍历 jobs 计算各维度数据
    for (const job of userJobs) {
      const snap = (job.snapshot || {}) as any
      const payload = (job.payload || {}) as any

      switch (job.type) {
        case REFERENCE_IMAGE_JOB_TYPE:
          imageGenerateCount += Number(snap?.summary?.ok || 0)
          break
        case FIRST_FRAME_JOB_TYPE:
          // 首帧图也是图片生成，按照成功张数计算
          const ffCount = Number(snap?.done || 0)
          imageGenerateCount += ffCount
          imageGenerateFirstFrameCount += ffCount
          break
        case VIDEO_GENERATE_JOB_TYPE:
          if (job.status === "done") {
            videoGenerateCount += 1
            if (payload?.first_image?.url) {
              firstFrameVideoCount += 1
            }
          }
          break
        case CANVAS_VIDEO_GENERATE_JOB_TYPE:
          if (Array.isArray(snap?.results)) {
            videoGenerateCount += snap.results.filter((r: any) => r?.ok).length
          }
          break
        case VOICEOVER_AUDIO_GENERATE_JOB_TYPE:
          audioGenerateCount += Number(snap?.progress?.done || 0)
          break
        case EPISODE_MATERIAL_GENERATE_JOB_TYPE:
          // 素材生成包含物品、场景、人物合成，都是图片生成
          // 注意：每个 done 代表一个渲染项。对于场景，通常会同时生成正背视图（两张图片）
          // 但是这里 snap.done 只表示项数，为了简单/或按原有逻辑处理，我们可以直接加 done。
          // 可是业务之前是怎么算的呢？如果之前算的也小，那可能确实因为缺少 error 状态下的 done 或者两张图的逻辑
          // 为了精确还原，我们可以考虑直接取 done
          const epsMatCount = Number(snap?.done || 0)
          episodeMaterialGenerateCount += epsMatCount
          imageGenerateCount += epsMatCount
          imageGenerateMaterialCount += epsMatCount
          break
        case SHORT_DRAMA_ROLE_IMAGE_DRAW_JOB_TYPE:
          // 角色素材抽卡，也是图片生成
          const drawCount = Number(payload?.drawCount || 1)
          const drawsDone = Number(snap?.progress?.done || 0) * drawCount
          episodeMaterialGenerateCount += drawsDone
          imageGenerateCount += drawsDone
          imageGenerateRoleFrontCount += drawsDone
          break
        case SHORT_DRAMA_ROLE_ASSET_DRAW_JOB_TYPE:
          // 角色装造、服装抽卡
          // 根据业务规则，每个成功的 key 代表一张正反拼接的宽图（即2张图的工作量/产出）
          const items = Array.isArray(snap?.items) ? snap.items : []
          let assetsDone = 0
          for (const item of items) {
             const storageKeys = Array.isArray(item?.storageKeys) ? item.storageKeys : []
             assetsDone += (storageKeys.length * 2)
          }
          episodeMaterialGenerateCount += assetsDone
          imageGenerateCount += assetsDone
          imageGenerateRoleAssetCount += assetsDone
          break
        case JIAN_YING_EXPORT_JOB_TYPE:
          if (job.status === "done" && snap?.storyId) {
            exportedStoryIds.add(snap.storyId)
          }
          break
      }
    }

    // 2. 对于剪映导出的 story，精确还原音视频数量
    if (exportedStoryIds.size > 0) {
      const storyboardsList = await db
        .select({ 
          storyId: storyOutlines.storyId, 
          isVideoGenerated: storyboards.isVideoGenerated, 
          scriptContent: sql<any>`jsonb_build_object('audio_lines', ${storyboards.scriptContent}->'audio_lines')`
        })
        .from(storyboards)
        .innerJoin(storyOutlines, eq(storyboards.outlineId, storyOutlines.id))
        .where(inArray(storyOutlines.storyId, Array.from(exportedStoryIds)))

      // 按 storyId 统计其视频和音频数量
      const storyMediaCounts: Record<string, { v: number; a: number }> = {}
      for (const sb of storyboardsList) {
        if (!sb.storyId) continue
        if (!storyMediaCounts[sb.storyId]) {
          storyMediaCounts[sb.storyId] = { v: 0, a: 0 }
        }
        if (sb.isVideoGenerated) {
          storyMediaCounts[sb.storyId].v += 1
        }
        
        const scriptContent = (sb.scriptContent || {}) as any
        const audioLines = Array.isArray(scriptContent?.audio_lines) ? scriptContent.audio_lines : []
        if (audioLines.length > 0) {
          storyMediaCounts[sb.storyId].a += audioLines.length
        }
      }

      // 累加剪映导出任务对应的媒体数量
      for (const job of userJobs) {
        if (job.type === JIAN_YING_EXPORT_JOB_TYPE) {
          const sid = (job.snapshot as any)?.storyId
          if (sid && storyMediaCounts[sid]) {
            jianyingExportVideoCount += storyMediaCounts[sid].v
            jianyingExportAudioCount += storyMediaCounts[sid].a
          }
        }
      }
    }

    // 3. 统计存入资源库的数量
    // 常规图片存入库数
    const libraryRows = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(storyAssetLibrary)
      .innerJoin(stories, eq(storyAssetLibrary.storyId, stories.id))
      .where(eq(stories.userId, userId))
    
    const libraryCount = libraryRows[0]?.count || 0

    // 人物合成图片存入库数
    const materialRows = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(episodeMaterialAssets)
      .innerJoin(stories, eq(episodeMaterialAssets.storyId, stories.id))
      .where(eq(stories.userId, userId))
      
    const materialCount = materialRows[0]?.count || 0

    // 4. 获取用户创建的剧本列表
    const userStories = await db
      .select({
        id: stories.id,
        title: stories.title,
        createdAt: stories.createdAt
      })
      .from(stories)
      .where(eq(stories.userId, userId))
      .orderBy(sql`${stories.createdAt} desc`)

    const storiesData = {
      count: userStories.length,
      list: userStories.map(s => ({
        id: s.id,
        title: s.title || "未命名剧本",
        createdAt: s.createdAt.toISOString()
      }))
    }

    const responseData = {
      generate: {
        images: imageGenerateCount,
        imageDetails: {
          firstFrame: imageGenerateFirstFrameCount,
          material: imageGenerateMaterialCount,
          roleFront: imageGenerateRoleFrontCount,
          roleAsset: imageGenerateRoleAssetCount
        },
        videos: videoGenerateCount,
        audios: audioGenerateCount
      },
      store: {
        images: libraryCount,
        episodeMaterials: materialCount
      },
      stories: storiesData,
      other: {
        firstFrameVideos: firstFrameVideoCount,
        jianyingExportVideos: jianyingExportVideoCount,
        jianyingExportAudios: jianyingExportAudioCount
      }
    }

    return NextResponse.json(makeApiOk(traceId, responseData), { status: 200 })
  } catch (error) {
    const anyErr = error as any
    const causeMsg = anyErr?.cause?.message || anyErr?.cause || ""
    const code = anyErr?.code || anyErr?.cause?.code || ""
    const fullMsg = `${anyErr?.message} | Cause: ${causeMsg} | Code: ${code}`
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", fullMsg), { status: 500 })
  }
}
