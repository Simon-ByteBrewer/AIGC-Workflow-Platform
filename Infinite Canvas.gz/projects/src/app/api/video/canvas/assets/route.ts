import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq, like, or } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { stories, videoCanvasAssets } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

const listQuerySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  kind: z.enum(["image", "video", "audio"]).optional(),
  search: z.string().trim().max(200).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(50),
  offset: z.coerce.number().int().min(0).max(10_000).default(0)
})

const createBodySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  kind: z.enum(["image", "video", "audio"]),
  storageKey: z.string().trim().min(1).max(1000),
  previewStorageKey: z.string().trim().max(1000).optional(),
  mimeType: z.string().trim().max(200).optional(),
  sizeBytes: z.number().int().min(0).max(2_000_000_000).optional(),
  sha256: z.string().trim().max(200).optional(),
  width: z.number().int().min(0).max(100_000).optional(),
  height: z.number().int().min(0).max(100_000).optional(),
  durationMs: z.number().int().min(0).max(10_000_000).optional(),
  source: z.enum(["upload", "generated"]).default("upload"),
  sourceRef: z.record(z.string(), z.any()).default({})
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = listQuerySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    kind: url.searchParams.get("kind") ?? undefined,
    search: url.searchParams.get("search") ?? undefined,
    limit: url.searchParams.get("limit") ?? undefined,
    offset: url.searchParams.get("offset") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, videoCanvasAssets })

  const storyRows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

  const conds = [eq(videoCanvasAssets.storyId, parsed.data.storyId)]
  if (parsed.data.kind) conds.push(eq(videoCanvasAssets.kind, parsed.data.kind))
  if (parsed.data.search) {
    const q = `%${parsed.data.search}%`
    const searchCond = or(like(videoCanvasAssets.storageKey, q), like(videoCanvasAssets.previewStorageKey, q), like(videoCanvasAssets.mimeType, q))
    if (searchCond) conds.push(searchCond)
  }

  const items = await db
    .select({
      id: videoCanvasAssets.id,
      storyId: videoCanvasAssets.storyId,
      kind: videoCanvasAssets.kind,
      storageKey: videoCanvasAssets.storageKey,
      previewStorageKey: videoCanvasAssets.previewStorageKey,
      mimeType: videoCanvasAssets.mimeType,
      sizeBytes: videoCanvasAssets.sizeBytes,
      sha256: videoCanvasAssets.sha256,
      width: videoCanvasAssets.width,
      height: videoCanvasAssets.height,
      durationMs: videoCanvasAssets.durationMs,
      source: videoCanvasAssets.source,
      sourceRef: videoCanvasAssets.sourceRef,
      createdAt: videoCanvasAssets.createdAt,
      updatedAt: videoCanvasAssets.updatedAt
    })
    .from(videoCanvasAssets)
    .where(and(...conds))
    .orderBy(desc(videoCanvasAssets.createdAt))
    .limit(parsed.data.limit)
    .offset(parsed.data.offset)

  return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = createBodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, videoCanvasAssets })

  const storyRows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

  const inserted = await db
    .insert(videoCanvasAssets)
    .values({
      storyId: parsed.data.storyId,
      kind: parsed.data.kind,
      storageKey: parsed.data.storageKey,
      previewStorageKey: parsed.data.previewStorageKey,
      mimeType: parsed.data.mimeType,
      sizeBytes: parsed.data.sizeBytes,
      sha256: parsed.data.sha256,
      width: parsed.data.width,
      height: parsed.data.height,
      durationMs: parsed.data.durationMs,
      source: parsed.data.source,
      sourceRef: parsed.data.sourceRef,
      updatedAt: new Date()
    })
    .returning({ id: videoCanvasAssets.id })

  return NextResponse.json(makeApiOk(traceId, { id: inserted[0]?.id }), { status: 200 })
}
