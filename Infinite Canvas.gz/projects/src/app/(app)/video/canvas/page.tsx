import type { ReactElement } from "react"
import { eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import styles from "../page.module.css"
import { CanvasCreationClient } from "@/features/video/canvas/CanvasCreationClient"
import { stories } from "@/shared/schema"

type VideoCanvasPageProps = Readonly<{
  searchParams: Promise<Readonly<{ storyId?: string | string[]; outlineId?: string | string[] }>>
}>

export const dynamic = "force-dynamic"

export default async function VideoCanvasPage({ searchParams }: VideoCanvasPageProps): Promise<ReactElement> {
  const params = await searchParams
  const storyIdValue = params.storyId
  const storyId = Array.isArray(storyIdValue) ? storyIdValue[0] : storyIdValue
  const outlineIdValue = params.outlineId
  const outlineId = Array.isArray(outlineIdValue) ? outlineIdValue[0] : outlineIdValue
  const storyTitle = await (async (): Promise<string> => {
    const id = (storyId ?? "").trim()
    if (!id) return ""
    const db = await getDb({ stories })
    const [row] = await db.select({ title: stories.title }).from(stories).where(eq(stories.id, id)).limit(1)
    const title = typeof row?.title === "string" ? row.title.trim() : ""
    return title
  })()

  return (
    <main className={styles.container}>
      <div className={`${styles.contentCard} ${styles.contentCardCanvas}`}>
        <CanvasCreationClient storyId={storyId ?? ""} outlineId={outlineId ?? ""} storyTitle={storyTitle || "未命名项目"} />
      </div>
    </main>
  )
}
