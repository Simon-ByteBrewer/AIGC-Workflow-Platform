import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { episodeMaterialAssets, episodeMaterialImages } from "@/shared/schema/generation"
import { createCozeS3Storage } from "@/server/integrations/storage/s3"
import { resolveStorageUrl } from "@/shared/storageUrl"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  limit: z.preprocess((v) => (v === "" || v === null ? undefined : v), z.coerce.number().int().min(50).max(2000).default(800)),
  latestOnly: z.preprocess((v) => (v === "" || v === null ? undefined : v), z.coerce.boolean().optional().default(false))
})

export const runtime = "nodejs"

function dedupeKey(row: { kind: string; name: string; roleName?: string | null; makeupName?: string | null; costumeName?: string | null }): string {
  const kind = (row.kind ?? "").trim().toLowerCase()
  const name = (row.name ?? "").trim()
  if (kind === "role" || kind === "character") {
    const meta = (row as any)?.meta
    const metaObj = meta && typeof meta === "object" && !Array.isArray(meta) ? (meta as any) : null
    const requestedLook = typeof metaObj?.requestedLookName === "string" ? metaObj.requestedLookName.trim() : ""
    const requestedCostume = typeof metaObj?.requestedCostumeName === "string" ? metaObj.requestedCostumeName.trim() : ""
    const look = requestedLook || (row.makeupName ?? "")
    const costume = requestedCostume || (row.costumeName ?? "")
    return ["role", row.roleName ?? name, look, costume].join("|")
  }
  return [kind, name].join("|")
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    limit: url.searchParams.get("limit") ?? undefined,
    latestOnly: url.searchParams.get("latestOnly") ?? undefined
  })
  if (!parsed.success) {
    const reason = parsed.error.issues
      .map((it) => `${it.path.join(".") || "root"}: ${it.message}`)
      .join("; ")
      .trim()
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", reason ? `参数格式不正确（${reason}）` : "参数格式不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialAssets, episodeMaterialImages })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  let materialId: string | null = null
  if (parsed.data.latestOnly) {
    const latest = await db
      .select({ id: episodeMaterialImages.id })
      .from(episodeMaterialImages)
      .where(eq(episodeMaterialImages.storyId, parsed.data.storyId))
      .orderBy(desc(episodeMaterialImages.createdAt))
      .limit(1)
    materialId = latest[0]?.id ?? null
    if (!materialId) return NextResponse.json(makeApiOk(traceId, { scene: [], role: [], item: [] }), { status: 200 })
  }

  const rows = await db
    .select({
      id: episodeMaterialAssets.id,
      materialId: episodeMaterialAssets.materialId,
      kind: episodeMaterialAssets.kind,
      name: episodeMaterialAssets.name,
      roleName: episodeMaterialAssets.roleName,
      makeupName: episodeMaterialAssets.makeupName,
      costumeName: episodeMaterialAssets.costumeName,
      prompt: episodeMaterialAssets.prompt,
      url: episodeMaterialAssets.url,
      storageKey: episodeMaterialAssets.storageKey,
      meta: episodeMaterialAssets.meta,
      createdAt: episodeMaterialAssets.createdAt
    })
    .from(episodeMaterialAssets)
    .where(
      materialId
        ? and(eq(episodeMaterialAssets.storyId, parsed.data.storyId), eq(episodeMaterialAssets.materialId, materialId))
        : eq(episodeMaterialAssets.storyId, parsed.data.storyId)
    )
    .orderBy(desc(episodeMaterialAssets.createdAt))
    .limit(parsed.data.limit)

  const map = new Map<string, (typeof rows)[number]>()
  for (const r of rows) {
    const key = dedupeKey(r)
    if (!key) continue
    if (!map.has(key)) map.set(key, r)
  }

  const storage = createCozeS3Storage()
  const items = await Promise.all(
    Array.from(map.values()).map(async (it) => {
      const key = String((it as any).storageKey ?? "")
      if (!key) return it
      try {
        const url = await resolveStorageUrl(storage, key)
        const meta = (it as any).meta
        const metaObj = meta && typeof meta === "object" && !Array.isArray(meta) ? (meta as any) : null
        const generatedImageIdsRaw = metaObj?.generatedImageIds
        const generatedImageIds = Array.isArray(generatedImageIdsRaw) ? generatedImageIdsRaw.filter((v) => typeof v === "string") : []
        const primaryGeneratedImageId =
          typeof metaObj?.library?.generatedImageId === "string" ? metaObj.library.generatedImageId : generatedImageIds[0] ?? ""
        let thumbnailUrl = primaryGeneratedImageId ? `/api/video-creation/images/file/${primaryGeneratedImageId}?kind=thumbnail` : null
        const thumbnailStorageKey = typeof metaObj?.thumbnailStorageKey === "string" ? metaObj.thumbnailStorageKey.trim() : ""
        if (!thumbnailUrl && thumbnailStorageKey) {
          try {
            thumbnailUrl = await resolveStorageUrl(storage, thumbnailStorageKey)
          } catch {}
        }
        const viewsRaw = metaObj?.views
        const views = Array.isArray(viewsRaw)
          ? await Promise.all(
              viewsRaw.map(async (v: any, index: number) => {
                const vk = typeof v?.storageKey === "string" ? v.storageKey.trim() : ""
                if (!vk) return v
                try {
                  const vu = await resolveStorageUrl(storage, vk)
                  const viewThumbKey = typeof v?.thumbnailStorageKey === "string" ? v.thumbnailStorageKey.trim() : ""
                  let viewThumb = viewThumbKey ? await resolveStorageUrl(storage, viewThumbKey) : null
                  if (!viewThumb) {
                    const gid = generatedImageIds[index] ?? ""
                    viewThumb = gid ? `/api/video-creation/images/file/${gid}?kind=thumbnail` : null
                  }
                  return { ...v, url: vu, ...(viewThumb ? { thumbnailUrl: viewThumb } : {}) }
                } catch {
                  return v
                }
              })
            )
          : null
        const nextMeta = views ? { ...metaObj, views } : meta
        return { ...it, url, ...(thumbnailUrl ? { thumbnailUrl } : {}), ...(nextMeta !== undefined ? { meta: nextMeta } : {}) }
      } catch {
        return it
      }
    })
  )
  const scene = items.filter((x) => String(x.kind ?? "").trim().toLowerCase() === "scene")
  const role = items.filter((x) => {
    const k = String(x.kind ?? "").trim().toLowerCase()
    return k === "role" || k === "character"
  })
  const thing = items.filter((x) => {
    const k = String(x.kind ?? "").trim().toLowerCase()
    return k === "item" || (k !== "scene" && k !== "role" && k !== "character")
  })

  return NextResponse.json(makeApiOk(traceId, { scene, role, item: thing }), { status: 200 })
}
