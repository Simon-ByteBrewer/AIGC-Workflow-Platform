"use client"

import type { ReactElement } from "react"
import type { CopyrightLibraryReviewFilter } from "@/shared/contracts/library/copyrightLibrary"
import styles from "./CopyrightLibrary.module.css"

const REVIEW_FILTERS: Array<{ id: CopyrightLibraryReviewFilter; label: string }> = [
  { id: "all", label: "全部" },
  { id: "reviewed", label: "已通过" },
  { id: "unreviewed", label: "未审核" },
  { id: "processing", label: "审核中" },
  { id: "failed", label: "审核失败" }
]

interface CopyrightReviewFiltersProps {
  value: CopyrightLibraryReviewFilter
  onChange: (value: CopyrightLibraryReviewFilter) => void
}

export function CopyrightReviewFilters({ value, onChange }: CopyrightReviewFiltersProps): ReactElement {
  return (
    <div className={styles.reviewFilters} aria-label="版权库审核筛选">
      {REVIEW_FILTERS.map((filter) => (
        <button
          key={filter.id}
          type="button"
          className={`${styles.reviewFilterBtn} ${value === filter.id ? styles.reviewFilterBtnActive : ""}`}
          onClick={() => onChange(filter.id)}
        >
          {filter.label}
        </button>
      ))}
    </div>
  )
}
