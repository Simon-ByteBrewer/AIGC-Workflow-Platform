import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr } from "@/shared/api"
import { getTraceId } from "@/shared/trace"

export const runtime = "nodejs"

/**
 * 独立分镜初始化接口当前未接入实现，先返回稳定的未实现错误，避免空 route 文件阻塞构建。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  return NextResponse.json(makeApiErr(traceId, "NOT_IMPLEMENTED", "独立分镜初始化接口暂未实现"), { status: 501 })
}
