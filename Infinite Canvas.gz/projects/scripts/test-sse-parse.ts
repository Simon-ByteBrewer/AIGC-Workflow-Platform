import { readFileSync } from "node:fs"

function tryParseJsonValue(raw: string): unknown {
  try {
    return JSON.parse(raw)
  } catch {
    return null
  }
}

function hasOptimizationResult(value: unknown): boolean {
  return (
    !!value &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    Array.isArray((value as Record<string, unknown>).optimization_result)
  )
}

function parseMaybeJsonString(value: unknown): unknown {
  let current = value
  for (let depth = 0; depth < 3; depth += 1) {
    if (typeof current !== "string") return current
    const trimmed = current.trim()
    if (!trimmed) return trimmed
    const parsed = tryParseJsonValue(trimmed)
    if (parsed !== null) {
      current = parsed
      continue
    }
    return current
  }
  return current
}

function unwrapWorkflowPayload(value: unknown): unknown {
  let current = parseMaybeJsonString(value)
  for (let depth = 0; depth < 4; depth += 1) {
    current = parseMaybeJsonString(current)
    if (hasOptimizationResult(current)) return current
    if (!current || typeof current !== "object" || Array.isArray(current)) return current

    const obj = current as Record<string, unknown>
    const wrappedKey = ["data", "output", "response", "res", "result", "shot_optimization", "router", "load_system_prompt"].find((key) => obj[key] !== undefined)
    if (!wrappedKey) return current
    const next = parseMaybeJsonString(obj[wrappedKey])
    if (next === obj[wrappedKey] && typeof next !== "object") return current
    current = next
  }
  return current
}

function parseSseWorkflowEndOutput(rawText: string): unknown {
  const chunks = rawText.trim().split(/\n\s*\n/g)
  for (let index = chunks.length - 1; index >= 0; index -= 1) {
    const dataLine = chunks[index]
      .split("\n")
      .map((line) => line.trim())
      .find((line) => line.startsWith("data:"))
    if (!dataLine) continue
    const rawData = dataLine.slice("data:".length).trim()
    if (!rawData) continue
    const parsed = tryParseJsonValue(rawData)
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) continue
    
    // Check if any part of the unwrapped payload has optimization_result
    const unwrapped = unwrapWorkflowPayload(parsed)
    if (hasOptimizationResult(unwrapped)) return unwrapped
  }
  return null
}

const sseText = `event: message
data: {"router": {"shots": ["shot_no=1 roles=['机器人'] items=[] scenes=[] shot_text='出租屋·夜·内景\\\\n【镜头时长】6秒\\\\n【画面风格】冷蓝灰调，低照度，写实压抑\\\\n【镜头1｜极近特写】手机屏幕震动，裂痕明显。来电备注：杨慧珊\\\\n【音效】震动声低频压迫\\\\n【动作】高言手指悬停——按下。' duration=None"], "use_volcano_ark": true, "optimization_type": "outline", "personal_prompt": null, "fenjingban_prompt": null}}

event: message
data: {"shot_optimization": {"optimization_result": ["shot_no=1 roles=['机器人'] items=[] scenes=[] shot_text='出租屋·夜·内景\\\\n【镜头时长】6秒\\\\n【画面风格】冷蓝灰调，低照度，写实压抑\\\\n【镜头1｜极近特写】手机屏幕震动，裂痕明显。来电备注：杨慧珊\\\\n【音效】震动声低频压迫\\\\n【动作】高言手指悬停——按下。' optimized_text='【整体描述】冷蓝灰调，低照度，写实压抑风格，6秒，紧张压抑的悬疑氛围\\\\n【分镜描述】\\\\n0-2秒：极近特写镜头，聚焦手机屏幕，屏幕持续震动，裂痕清晰可见，来电备注显示「杨慧珊」，冷蓝色微光从屏幕透出\\\\n2-4秒：镜头微微上移，展现高言的手指悬停在接听键上方，指尖微颤，紧绷感拉满\\\\n4-6秒：特写镜头，高言手指按下接听键的瞬间，屏幕亮度微微升高，微光扫过高言紧绷的面部轮廓\\\\n【声音说明】低频压迫的手机震动声，随着手指按下逐渐减弱\\\\n【光影效果】全程冷蓝灰调，低照度，仅手机屏幕为唯一光源，阴影浓重，强化压抑的悬疑感' speak_list=[] duration=6"]}}`

console.log("Parsed:", JSON.stringify(parseSseWorkflowEndOutput(sseText), null, 2))

