"use client"

import { type ReactElement } from "react"
import type { AdminModelType } from "@/shared/contracts/adminUserModelAccess"
import styles from "./UserDetailPage.module.css"
import type { ApiKeyAction, UserModelDraftGroups, UserModelDraftRow } from "./userModelAccessForm"

const sections: Array<{ type: AdminModelType; title: string; description: string }> = [
  { type: "video", title: "视频模型", description: "用于后续视频生成工作流的模型名到 EP 映射" },
  { type: "language", title: "文本模型", description: "用于后续文本生成工作流的模型名到 EP 映射" },
  { type: "image", title: "图片模型", description: "用于后续图片生成工作流的模型名到 EP 映射" }
]

type Props = {
  actorRoleKey?: string
  apiKeyConfigured?: boolean
  apiKeyMasked?: string | null
  apiKeyDraft?: string
  apiKeyAction?: ApiKeyAction
  modelRows: UserModelDraftGroups
  disabled?: boolean
  onApiKeyDraftChange?: (value: string) => void
  onClearApiKey?: () => void
  onUndoClearApiKey?: () => void
  onAddRow?: (type: AdminModelType) => void
  onRemoveRow?: (type: AdminModelType, rowId: string) => void
  onUpdateRow: (type: AdminModelType, rowId: string, patch: Partial<UserModelDraftRow>) => void
}

export function UserModelAccessPanel(props: Props): ReactElement {
  return (
    <section className={`${styles.panel} ${styles.panelWide}`} aria-label="模型接入配置">
      <div className={styles.panelTitle}>模型启用控制</div>
      <div className={styles.tip}>
        这里展示的是该账号从所属用户组继承到的模型清单。管理员只能控制当前账号的启用状态，不能在账号页修改 API Key、模型名称或 EP。
      </div>

      <div className={styles.modelSectionList}>
        {sections.map((section) => (
          <div key={section.type} className={styles.modelAccessCard}>
            <div className={styles.modelAccessHeader}>
              <div>
                <div className={styles.modelAccessTitle}>{section.title}</div>
                <div className={styles.modelAccessDesc}>仅允许调整启用状态</div>
              </div>
            </div>

            <div className={styles.modelTable}>
              <div className={`${styles.modelRow} ${styles.modelRowCompact} ${styles.modelRowHead}`}>
                <div>模型名称(展示名)</div>
                <div>真实名称</div>
                <div>EP 接入点</div>
                <div>启用</div>
              </div>

              {props.modelRows[section.type].length === 0 ? (
                <div className={styles.empty}>暂无配置</div>
              ) : (
                props.modelRows[section.type].map((row) => (
                  <div key={row.id} className={`${styles.modelRow} ${styles.modelRowCompact}`}>
                    <div className={styles.readonlyValue}>{row.modelName}</div>
                    <div className={styles.readonlyValue}>{row.realName || "-"}</div>
                    <div className={styles.readonlyValue}>{row.ep}</div>
                    <label className={styles.switchLabel}>
                      <input
                        type="checkbox"
                        checked={row.enabled}
                        onChange={(event) => props.onUpdateRow(section.type, row.id, { enabled: event.target.checked })}
                        disabled={props.disabled}
                      />
                      <span>{row.enabled ? "启用" : "禁用"}</span>
                    </label>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
