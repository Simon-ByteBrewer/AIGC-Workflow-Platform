import path from "node:path"
import { fileURLToPath } from "node:url"
import { getDb } from "coze-coding-dev-sdk"
import { text, jsonb, pgTable, timestamp } from "drizzle-orm/pg-core"
import { eq, desc } from "drizzle-orm"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

function stripQuotes(v) {
  const s = String(v ?? "")
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1)
  return s
}

async function loadEnvFile(filePath) {
  try {
    const fs = await import("node:fs/promises")
    const text = await fs.readFile(filePath, "utf8")
    for (const line of text.split(/\r?\n/)) {
      const s = line.trim()
      if (!s || s.startsWith("#")) continue
      const idx = s.indexOf("=")
      if (idx <= 0) continue
      const k = s.slice(0, idx).trim()
      const v = stripQuotes(s.slice(idx + 1).trim())
      if (!k) continue
      if (process.env[k] == null) process.env[k] = v
    }
  } catch {
  }
}

function normalizePgEnv() {
  const keys = ["PGDATABASE_URL", "DATABASE_URL", "POSTGRES_URL"]
  for (const key of keys) {
    const raw = process.env[key]
    if (!raw) continue
    const trimmed = raw.trim()
    if (!trimmed) continue
    try {
      const url = new URL(trimmed)
      const sslmode = (url.searchParams.get("sslmode") ?? "").toLowerCase()
      if (sslmode === "prefer" || sslmode === "require" || sslmode === "verify-ca") {
        url.searchParams.set("sslmode", "verify-full")
        process.env[key] = url.toString()
      }
      if ((process.env.NODE_ENV ?? "").toLowerCase() !== "production") {
        const connectTimeout = (url.searchParams.get("connect_timeout") ?? "").trim()
        if (!connectTimeout) url.searchParams.set("connect_timeout", "3")
        const options = (url.searchParams.get("options") ?? "").trim()
        if (!options) url.searchParams.set("options", "-c statement_timeout=15000 -c lock_timeout=15000")
        process.env[key] = url.toString()
      }
    } catch {
    }
  }
}

async function main() {
  await loadEnvFile(path.join(process.cwd(), ".env.local"))
  await loadEnvFile(path.join(process.cwd(), ".env"))
  normalizePgEnv()

  const args = process.argv.slice(2)
  const jobId = args[0]
  
  if (!jobId) {
    console.error("Usage: node query-job.mjs <job-id>")
    process.exit(1)
  }

  const jobs = pgTable("jobs", {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    type: text("type").notNull(),
    status: text("status").notNull(),
    payload: jsonb("payload").notNull(),
    snapshot: jsonb("snapshot").notNull(),
    errorMessage: text("error_message")
  })

  const episodeMaterialImages = pgTable("episode_material_images", {
    id: text("id").primaryKey(),
    storyId: text("story_id").notNull(),
    outlineId: text("outline_id"),
    meta: jsonb("meta").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull()
  })

  const db = await getDb({ jobs, episodeMaterialImages })
  
  const rows = await db
    .select({
      id: jobs.id,
      type: jobs.type,
      status: jobs.status,
      payload: jobs.payload,
      snapshot: jobs.snapshot,
      errorMessage: jobs.errorMessage
    })
    .from(jobs)
    .where(eq(jobs.id, jobId))
    .limit(1)

  if (rows.length === 0) {
    console.log(`Job ${jobId} not found`)
    process.exit(0)
  }

  const job = rows[0]
  console.log("=" . repeat(80))
  console.log(`Job ID: ${job.id}`)
  console.log(`Type: ${job.type}`)
  console.log(`Status: ${job.status}`)
  if (job.errorMessage) {
    console.log(`Error: ${job.errorMessage}`)
  }
  console.log("=" . repeat(80))
  
  const snapshot = job.snapshot
  console.log("Total done:", snapshot.done)
  console.log("Total planned:", snapshot.total)
  console.log("=" . repeat(80))
  
  if (snapshot.roleApiOutput) {
    console.log("roleApiOutput (current batch only):")
    console.log("  backgroundsCount:", snapshot.roleApiOutput.backgroundsCount)
    console.log("  itemsCount:", snapshot.roleApiOutput.itemsCount)
    console.log("  rolesCount:", snapshot.roleApiOutput.rolesCount)
    console.log("  Total (current batch only):", 
      (snapshot.roleApiOutput.backgroundsCount || 0) + 
      (snapshot.roleApiOutput.itemsCount || 0) + 
      (snapshot.roleApiOutput.rolesCount || 0))
    console.log()
  }
  
  const imgRows = await db
    .select({ 
      id: episodeMaterialImages.id, 
      meta: episodeMaterialImages.meta,
      createdAt: episodeMaterialImages.createdAt
    })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.storyId, job.payload.storyId))
    .orderBy(desc(episodeMaterialImages.createdAt))
    .limit(5)
  
  console.log("episode_material_images records (latest 5):")
  console.log("=" . repeat(80))
  
  for (let i = 0; i < imgRows.length; i++) {
    const imgRow = imgRows[i]
    console.log(`\n--- Batch ${i + 1} (created at: ${imgRow.createdAt}) ---`)
    
    if (imgRow.meta && imgRow.meta.parseResult) {
      const pr = imgRow.meta.parseResult
      const bgCount = pr.backgrounds?.length || 0
      const itemCount = pr.items?.length || 0
      const roleCount = pr.roles?.length || 0
      const total = bgCount + itemCount + roleCount
      
      console.log(`  Backgrounds: ${bgCount}`)
      if (bgCount > 0) {
        console.log(`    List: ${pr.backgrounds.map(b => b.name).join(", ")}`)
      }
      console.log(`  Items: ${itemCount}`)
      if (itemCount > 0) {
        console.log(`    List: ${pr.items.map(i => i.name).join(", ")}`)
      }
      console.log(`  Roles: ${roleCount}`)
      if (roleCount > 0) {
        console.log(`    List: ${pr.roles.map(r => `${r.name}(${r.head}/${r.cloth})`).join(", ")}`)
      }
      console.log(`  Total: ${total}`)
    }
  }
  
  console.log("\n" + "=".repeat(80))
  console.log("EXPLANATION:")
  console.log("- The '57' total comes from MERGING current batch + previous batches (mergedBackgrounds + mergedItems + mergedRoles)")
  console.log("- The code uses 'pickPrevParseResult()' to get earlier batches and merge them with current results")
  console.log("- This ensures all materials from all episodes are collected together")
  console.log("=".repeat(80))
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
