import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { listEnabledImageModelsForUser } from "@/server/domains/image/imageModelResolver"

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const items = await listEnabledImageModelsForUser(userId)
  return NextResponse.json(
    makeApiOk(traceId, {
      items: items.map((item) => ({
        modelName: item.modelName,
        label: item.label
      }))
    }),
    { status: 200 }
  )
}
