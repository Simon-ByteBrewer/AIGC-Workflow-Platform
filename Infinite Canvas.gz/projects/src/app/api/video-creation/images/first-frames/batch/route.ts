import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq } from "drizzle-orm"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"
import { enqueueFirstFrameJob } from "@/server/domains/video-creation/jobs/firstFrameWorker"
import { kickFirstFrameWorker } from "@/server/domains/video-creation/jobs/firstFrameWorker"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  count: z.coerce.number().int().min(1).max(3).optional().default(3),
  items: z.array(
    z.object({
      storyboardId: z.string().trim().min(1).max(200),
      referenceImages: z
        .array(
          z.object({
            name: z.string().trim().min(1).max(200),
            url: z.string().trim().min(1).max(4000)
          })
        )
        .max(10)
        .default([])
    })
  )
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { storyId, outlineId, count } = parsed.data

  const db = await getDb({ stories, storyOutlines, storyboards })
  const allowed = await db
    .select({ id: storyOutlines.id, episodeNo: storyOutlines.sequence })
    .from(storyOutlines)
    .innerJoin(stories, eq(storyOutlines.storyId, stories.id))
    .where(and(eq(storyOutlines.id, outlineId), eq(stories.id, storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧集"), { status: 403 })
  const episodeNo = Number((allowed[0] as any)?.episodeNo ?? 0) || null

  const byId = new Map<string, { referenceImages: Array<{ name: string; url: string }> }>()
  for (const it of parsed.data.items) byId.set(it.storyboardId, { referenceImages: it.referenceImages })

  const existing = await db
    .select({ id: storyboards.id, sceneNo: storyboards.sequence })
    .from(storyboards)
    .where(eq(storyboards.outlineId, outlineId))

  const jobIds: string[] = []
  for (const r of existing) {
    const storyboardId = r.id
    const config = byId.get(storyboardId)
    const referenceImages = config?.referenceImages ?? []
    const sceneNo = Number((r as any)?.sceneNo ?? 0) || null
    const { jobId } = await enqueueFirstFrameJob({
      userId,
      traceId,
      storyId,
      outlineId,
      storyboardId,
      referenceImages,
      ...(episodeNo ? { episodeNo } : {}),
      ...(sceneNo ? { sceneNo } : {}),
      ...((episodeNo && sceneNo) ? { label: `第 ${episodeNo} 集 · 镜 ${sceneNo}` } : sceneNo ? { label: `镜 ${sceneNo}` } : {}),
      count
    })
    jobIds.push(jobId)
  }
  // #region debug-point FF:batch-enqueued
  fetch("http://127.0.0.1:7777/event", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      sessionId: "firstframe-batch",
      runId: "pre-fix",
      hypothesisId: "H1",
      location: "first-frames/batch/route.ts:POST",
      msg: "[DEBUG] first frame batch enqueued",
      data: {
        traceId,
        userId,
        storyId,
        outlineId,
        storyboardCount: existing.length,
        jobCount: jobIds.length
      }
    })
  }).catch(() => {})
  // #endregion


  kickFirstFrameWorker()
  return NextResponse.json(makeApiOk(traceId, { jobIds }), { status: 200 })
}
