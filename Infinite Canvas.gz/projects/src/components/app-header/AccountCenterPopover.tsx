"use client"

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import type { ReactElement } from "react"
import { createPortal } from "react-dom"
import { usePathname } from "next/navigation"
import { KeyRound, LogOut, UserRound, X } from "lucide-react"
import type { ApiErr, ApiOk } from "@/shared/api"
import type { CurrentUserProfile } from "@/shared/contracts/authProfile"
import { AccountCenterPasswordDialog } from "./AccountCenterPasswordDialog"
import styles from "./AccountCenterPopover.module.css"

type CurrentUserProfileResult = ApiOk<{ profile: CurrentUserProfile }> | ApiErr

function getRoleLabel(role: string): string {
  if (role === "admin") return "超级管理员"
  if (role === "group_admin") return "组管理员"
  return "普通用户"
}

function getRoleTone(role: string): "danger" | "warning" | "neutral" {
  if (role === "admin") return "danger"
  if (role === "group_admin") return "warning"
  return "neutral"
}

type AccountCenterPopoverProps = {
  accountTitle: string
  loggingOut: boolean
  onLogout: () => Promise<void>
}

/**
 * 账号按钮贴边弹出的个人中心面板。
 * 只负责展示与交互，真实资料通过独立接口懒加载，避免 Header 初始负担继续扩大。
 */
export function AccountCenterPopover({ accountTitle, loggingOut, onLogout }: AccountCenterPopoverProps): ReactElement {
  const pathname = usePathname()
  const buttonRef = useRef<HTMLButtonElement | null>(null)
  const panelRef = useRef<HTMLDivElement | null>(null)
  const [open, setOpen] = useState(false)
  const [passwordDialogOpen, setPasswordDialogOpen] = useState(false)
  const [position, setPosition] = useState({ top: 12, left: 84 })
  const [profileResult, setProfileResult] = useState<CurrentUserProfileResult | null>(null)
  const [loading, setLoading] = useState(false)

  const canPortal = typeof document !== "undefined"

  const syncPosition = useCallback(() => {
    const button = buttonRef.current
    if (!button) return
    const panel = panelRef.current
    const rect = button.getBoundingClientRect()
    const gap = 12
    const viewportPadding = 12
    const panelWidth = panel?.offsetWidth ?? 388
    const panelHeight = panel?.offsetHeight ?? 320
    const preferredLeft = rect.right + gap
    const fallbackLeft = rect.left - panelWidth - gap
    const unclampedLeft =
      preferredLeft + panelWidth + viewportPadding <= window.innerWidth
        ? preferredLeft
        : fallbackLeft
    const maxLeft = Math.max(viewportPadding, window.innerWidth - panelWidth - viewportPadding)
    const left = Math.min(Math.max(viewportPadding, unclampedLeft), maxLeft)

    const preferredTop = rect.top
    const maxTop = Math.max(viewportPadding, window.innerHeight - panelHeight - viewportPadding)
    const top = Math.min(Math.max(viewportPadding, preferredTop), maxTop)
    setPosition({ top, left })
  }, [])

  const loadProfile = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/auth/profile", { method: "GET", cache: "no-store" })
      const json = (await res.json().catch(() => null)) as CurrentUserProfileResult | null
      if (!json) {
        setProfileResult({
          ok: false,
          error: { code: "AUTH_PROFILE_INVALID", message: "接口返回格式异常" },
          traceId: "n/a"
        })
        return
      }
      setProfileResult(json)
    } catch {
      setProfileResult({
        ok: false,
        error: { code: "NETWORK_ERROR", message: "网络异常，请稍后重试" },
        traceId: "n/a"
      })
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    setOpen(false)
    setPasswordDialogOpen(false)
  }, [pathname])

  useEffect(() => {
    if (!passwordDialogOpen) return
    setOpen(false)
  }, [passwordDialogOpen])

  useEffect(() => {
    if (!open) return
    syncPosition()
    if (!profileResult && !loading) {
      void loadProfile()
    }

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false)
    }

    window.addEventListener("resize", syncPosition)
    window.addEventListener("scroll", syncPosition, true)
    window.addEventListener("keydown", handleKeyDown)
    return () => {
      window.removeEventListener("resize", syncPosition)
      window.removeEventListener("scroll", syncPosition, true)
      window.removeEventListener("keydown", handleKeyDown)
    }
  }, [loadProfile, loading, open, profileResult, syncPosition])

  const profile = useMemo(() => {
    if (!profileResult || !profileResult.ok) return null
    return profileResult.data.profile
  }, [profileResult])

  const errorMessage = useMemo(() => {
    if (!profileResult || profileResult.ok) return ""
    return profileResult.error.message || "获取个人中心资料失败"
  }, [profileResult])

  const roleLabel = useMemo(() => getRoleLabel(profile?.role ?? "user"), [profile?.role])
  const roleTone = useMemo(() => getRoleTone(profile?.role ?? "user"), [profile?.role])
  const remainingQuota = useMemo(() => {
    const display = profile?.remainingQuotaDisplay?.trim()
    if (display) return display
    if (profile?.remainingQuota !== null && typeof profile?.remainingQuota !== "undefined") return profile.remainingQuota
    return "无限制"
  }, [profile?.remainingQuota, profile?.remainingQuotaDisplay])
  const personalRemainingQuota = useMemo(() => profile?.personalRemainingQuotaDisplay?.trim() || "无限制", [profile?.personalRemainingQuotaDisplay])
  const groupRemainingQuota = useMemo(() => profile?.groupRemainingQuotaDisplay?.trim() || "无限制", [profile?.groupRemainingQuotaDisplay])

  const panelNode =
    open && canPortal
      ? createPortal(
          <div
            className={styles.layer}
            onMouseDown={(event) => {
              if (event.target === event.currentTarget) setOpen(false)
            }}
          >
            <div
              ref={panelRef}
              className={styles.panel}
              style={{ top: `${position.top}px`, left: `${position.left}px` }}
              role="dialog"
              aria-modal="false"
              aria-label="个人中心"
              onMouseDown={(event) => event.stopPropagation()}
            >
              <div className={styles.header}>
                <div>
                  <div className={styles.title}>个人中心</div>
                  <div className={styles.subtitle}>查看当前账号资料</div>
                </div>
                <button type="button" className={styles.closeButton} onClick={() => setOpen(false)} aria-label="关闭个人中心" title="关闭个人中心">
                  <X size={16} strokeWidth={2.2} />
                </button>
              </div>

              {loading && !profile ? <div className={styles.stateText}>加载中...</div> : null}

              {!loading && errorMessage ? (
                <div className={styles.errorBlock}>
                  <div>{errorMessage}</div>
                  <button
                    type="button"
                    className={styles.retryButton}
                    onClick={() => {
                      void loadProfile()
                    }}
                  >
                    重新加载
                  </button>
                </div>
              ) : null}

              {!loading && profile ? (
                <div className={styles.content}>
                  <div className={styles.heroCard}>
                    <div className={styles.heroIcon}>
                      <UserRound size={20} strokeWidth={2.2} />
                    </div>
                    <div className={styles.heroBody}>
                      <div className={styles.heroTopRow}>
                        <div className={styles.heroAccount} title={profile.account}>
                          {profile.account}
                        </div>
                        <span className={`${styles.roleBadge} ${styles[`roleBadge${roleTone[0].toUpperCase()}${roleTone.slice(1)}`]}`}>{roleLabel}</span>
                      </div>
                      <div className={styles.heroGroup} title={profile.groupName ?? "-"}>
                        所在分组：{profile.groupName ?? "-"}
                      </div>
                    </div>
                  </div>

                  <div className={styles.infoGrid}>
                    <div className={styles.item}>
                      <div className={styles.label}>用户账号</div>
                      <div className={styles.valueMono}>{profile.account}</div>
                    </div>
                    <div className={styles.item}>
                      <div className={styles.label}>用户权限</div>
                      <div className={styles.value}>{roleLabel}</div>
                    </div>
                    <div className={`${styles.item} ${styles.itemWide} ${styles.quotaCard}`}>
                      <div className={styles.quotaHead}>
                        <div className={styles.quotaLabelRow}>
                          <div className={styles.label}>可用额度</div>
                        </div>
                        <div className={styles.quotaTooltipHost}>
                          <button
                            type="button"
                            className={styles.quotaValueButton}
                            aria-label="查看可用额度说明"
                            title="查看可用额度说明"
                          >
                            <span className={styles.quotaValue}>{remainingQuota}</span>
                          </button>
                          <div className={styles.quotaTooltip} role="tooltip">
                            <div className={styles.quotaTooltipTitle}>说明：这里展示真实余额，为 min(个人余额，分组余额)，不包含锁定占用</div>
                            <div className={styles.quotaTooltipRow}>
                              <span>个人余额：</span>
                              <span>{personalRemainingQuota}</span>
                            </div>
                            <div className={styles.quotaTooltipRow}>
                              <span>分组余额：</span>
                              <span>{groupRemainingQuota}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className={`${styles.item} ${styles.itemWide}`}>
                      <div className={styles.label}>操作</div>
                      <div className={styles.actionRow}>
                        <button
                          type="button"
                          className={styles.secondaryActionButton}
                          onClick={() => {
                            setOpen(false)
                            setPasswordDialogOpen(true)
                          }}
                        >
                          <KeyRound size={15} strokeWidth={2.2} />
                          <span>修改密码</span>
                        </button>
                        <button type="button" className={styles.dangerActionButton} onClick={() => void onLogout()} disabled={loggingOut}>
                          <LogOut size={15} strokeWidth={2.2} />
                          <span>{loggingOut ? "退出中..." : "退出账号"}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>
          </div>,
          document.body
        )
      : null

  return (
    <>
      <button
        ref={buttonRef}
        type="button"
        className={`${styles.accountButton} ${open ? styles.accountButtonActive : ""}`}
        aria-label="当前账号"
        title={accountTitle}
        onClick={() => setOpen((prev) => !prev)}
      >
        <UserRound size={20} strokeWidth={2.2} />
      </button>
      {panelNode}
      <AccountCenterPasswordDialog open={passwordDialogOpen} onOpenChange={setPasswordDialogOpen} onPasswordChanged={onLogout} />
    </>
  )
}
