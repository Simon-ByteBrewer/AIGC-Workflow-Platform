"use client"

import Link from "next/link"
import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import type { AdminModelType, AdminUserModelAccess } from "@/shared/contracts/adminUserModelAccess"
import styles from "./UserDetailPage.module.css"
import { UserModelAccessPanel } from "./UserModelAccessPanel"
import { createEmptyModelDraftGroups, modelMapToRows, rowsToModelMap, type UserModelDraftGroups, type UserModelDraftRow } from "./userModelAccessForm"

type ApiOk<T> = { ok: true; data: T; traceId: string }
type ApiErr = { ok: false; error: { code: string; message: string }; traceId: string }

type UserDetail = {
  id: string
  account: string
  email: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string | null
  groupId: string | null
  groupName: string | null
  security: {
    roleKey: string
    tokenVersion: number
    lastLoginAt: string | null
    passwordUpdatedAt: string | null
    failedLoginCount: number
    lockedUntil: string | null
    disabledAt: string | null
    disabledReason: string | null
  }
  modelAccess: AdminUserModelAccess
}

type GetResult = ApiOk<{ actor?: { roleKey: string }; user: UserDetail }> | ApiErr
type PatchResult = ApiOk<{ user: { id: string; account: string; email: string | null; roleKey: string; groupId?: string | null } }> | ApiErr
type ActionResult = ApiOk<{ ok: true }> | ApiErr
type GroupsResult = ApiOk<{ items: Array<{ id: string; name: string; code: string | null; isActive: boolean }> }> | ApiErr

async function parseJsonBody<T>(res: Response): Promise<T | null> {
  const text = await res.text()
  if (!text.trim()) return null
  try {
    return JSON.parse(text) as T
  } catch {
    throw new Error(`请求失败，服务器返回了非预期的格式 (HTTP ${res.status})`)
  }
}

function fmtTime(v: string | null): string {
  if (!v) return "-"
  const d = new Date(v)
  if (!Number.isFinite(d.getTime())) return v
  return d.toLocaleString()
}

type ModalKind = null | "disable" | "enable" | "resetPassword" | "forceLogout" | "resourceStats"

type ResourceStatsResult = ApiOk<{
  generate: { 
    images: number; 
    imageDetails: {
      firstFrame: number;
      material: number;
      roleFront: number;
      roleAsset: number;
    };
    videos: number; 
    audios: number;
  }
  store: { images: number; episodeMaterials: number }
  stories: { count: number; list: Array<{ id: string; title: string; createdAt: string }> }
  other: { firstFrameVideos: number; jianyingExportVideos: number; jianyingExportAudios: number }
}> | ApiErr

export function UserDetailPage({ userId }: { userId: string }): ReactElement {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [user, setUser] = useState<UserDetail | null>(null)

  const [emailDraft, setEmailDraft] = useState("")
  const [roleDraft, setRoleDraft] = useState("")
  const [groupIdDraft, setGroupIdDraft] = useState("")
  const [modelRows, setModelRows] = useState<UserModelDraftGroups>(createEmptyModelDraftGroups())
  const [actorRole, setActorRole] = useState("user")
  const [groupItems, setGroupItems] = useState<Array<{ id: string; name: string; code: string | null; isActive: boolean }>>([])

  const [modal, setModal] = useState<ModalKind>(null)
  const [confirmAccount, setConfirmAccount] = useState("")
  const [reason, setReason] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [acting, setActing] = useState(false)

  const [resourceStatsLoading, setResourceStatsLoading] = useState(false)
  const [resourceStatsData, setResourceStatsData] = useState<Exclude<ResourceStatsResult, ApiErr>["data"] | null>(null)

  const title = useMemo(() => (user ? `账号：${user.account}` : "账号详情"), [user])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/users/${encodeURIComponent(userId)}`, { method: "GET" })
      const json = await parseJsonBody<GetResult>(res)
      if (!json) throw new Error(`加载失败（HTTP ${res.status}）`)
      if (!json.ok) throw new Error(json.error.message)
      setUser(json.data.user)
      setEmailDraft(json.data.user.email ?? "")
      setRoleDraft(json.data.user.security.roleKey ?? "user")
      setGroupIdDraft(json.data.user.groupId ?? "")
      setActorRole(json.data.actor?.roleKey ?? "user")
      setModelRows({
        video: modelMapToRows(json.data.user.modelAccess.videoModels),
        language: modelMapToRows(json.data.user.modelAccess.languageModels),
        image: modelMapToRows(json.data.user.modelAccess.imageModels)
      })
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载失败")
    } finally {
      setLoading(false)
    }
  }, [userId])

  const loadGroups = useCallback(async () => {
    try {
      const res = await fetch("/api/admin/groups", { method: "GET" })
      const json = (await res.json()) as GroupsResult
      if (!json.ok) return
      setGroupItems((json.data.items ?? []).filter((item) => item.isActive))
    } catch {}
  }, [])

  const updateModelRow = useCallback((type: AdminModelType, rowId: string, patch: Partial<UserModelDraftRow>) => {
    setModelRows((current) => ({
      ...current,
      [type]: current[type].map((row) => (row.id === rowId ? { ...row, ...patch } : row))
    }))
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const onSave = useCallback(async () => {
    if (!user || saving) return
    setSaving(true)
    setError(null)
    try {
      const canEditRole = actorRole === "admin"
      const canEditGroup = actorRole === "admin"
      const nextRoleKey = roleDraft.trim() || "user"
      const nextGroupId = groupIdDraft.trim() || ""
      const didRoleChange = canEditRole && nextRoleKey !== (user.security.roleKey ?? "user")
      const didGroupChange = canEditGroup && nextGroupId !== (user.groupId ?? "")
      const shouldSendModelAccess = !didRoleChange && !didGroupChange
      const modelAccessPayload: {
        videoModels: AdminUserModelAccess["videoModels"]
        languageModels: AdminUserModelAccess["languageModels"]
        imageModels: AdminUserModelAccess["imageModels"]
      } = {
        videoModels: rowsToModelMap(modelRows.video),
        languageModels: rowsToModelMap(modelRows.language),
        imageModels: rowsToModelMap(modelRows.image)
      }

      const res = await fetch(`/api/admin/users/${encodeURIComponent(user.id)}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          email: emailDraft.trim(),
          roleKey: canEditRole ? nextRoleKey : undefined,
          groupId: canEditGroup ? (nextGroupId || null) : undefined,
          modelAccess: shouldSendModelAccess ? modelAccessPayload : undefined
        })
      })
      const json = await parseJsonBody<PatchResult>(res)
      if (!json) throw new Error(`保存失败（HTTP ${res.status}）`)
      if (!json.ok) throw new Error(json.error.message)
      await load()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "保存失败")
    } finally {
      setSaving(false)
    }
  }, [actorRole, emailDraft, groupIdDraft, load, modelRows.image, modelRows.language, modelRows.video, roleDraft, saving, user])

  useEffect(() => {
    if (actorRole === "admin") {
      void loadGroups()
    }
  }, [actorRole, loadGroups])

  const openModal = useCallback((k: ModalKind) => {
    setModal(k)
    setConfirmAccount("")
    setReason("")
    setNewPassword("")
    if (k === "resourceStats") {
      void (async () => {
        setResourceStatsLoading(true)
        setResourceStatsData(null)
        try {
          const res = await fetch(`/api/admin/users/${encodeURIComponent(userId)}/resource-stats`)
          const json = (await res.json()) as ResourceStatsResult
          if (!json.ok) throw new Error(json.error.message)
          setResourceStatsData(json.data)
        } catch (e) {
          const anyErr = e as { message?: string }
          alert(anyErr?.message ?? "获取资源消耗失败")
          setModal(null)
        } finally {
          setResourceStatsLoading(false)
        }
      })()
    }
  }, [userId])

  const closeModal = useCallback(() => {
    setModal(null)
    setConfirmAccount("")
    setReason("")
    setNewPassword("")
  }, [])

  const runAction = useCallback(async () => {
    if (!user || !modal || acting) return
    setActing(true)
    setError(null)
    try {
      const base = `/api/admin/users/${encodeURIComponent(user.id)}`
      const url =
        modal === "disable"
          ? `${base}/disable`
          : modal === "enable"
            ? `${base}/enable`
            : modal === "resetPassword"
              ? `${base}/reset-password`
              : `${base}/force-logout`

      const body =
        modal === "disable"
          ? { confirmAccount: confirmAccount.trim(), reason: reason.trim() || undefined }
          : modal === "resetPassword"
            ? { confirmAccount: confirmAccount.trim(), newPassword }
            : { confirmAccount: confirmAccount.trim() }

      const res = await fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) })
      const json = (await res.json()) as ActionResult
      if (!json.ok) throw new Error(json.error.message)
      closeModal()
      await load()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "操作失败")
    } finally {
      setActing(false)
    }
  }, [acting, closeModal, confirmAccount, load, modal, newPassword, reason, user])

  return (
    <main className={styles.page}>
      <div className={styles.topBar}>
        <div className={styles.topLeft}>
          <div className={styles.breadcrumb}>
            <Link className={styles.link} href="/admin/users">
              账号管理
            </Link>
            <span className={styles.sep}>/</span>
            <span>{user?.account ?? userId}</span>
          </div>
          <div className={styles.topTitle}>{title}</div>
          <div className={styles.topMeta}>{loading ? "加载中…" : user ? `ID: ${user.id}` : ""}</div>
        </div>
        <div className={styles.topActions}>
          <button type="button" className={styles.topBtn} onClick={() => void load()} disabled={loading || saving || acting}>
            刷新
          </button>
          <button type="button" className={styles.topBtnPrimary} onClick={() => void onSave()} disabled={loading || saving || acting || !user}>
            {saving ? "保存中…" : "保存"}
          </button>
        </div>
      </div>

      {error ? <div className={styles.error}>{error}</div> : null}

      {!user && !loading ? <div className={styles.empty}>账号不存在或无权限</div> : null}

      {user ? (
        <div className={styles.grid}>
          <section className={styles.panel} aria-label="基本信息">
            <div className={styles.panelTitle}>基本信息</div>
            <div className={styles.kv}>
              <div className={styles.k}>账号</div>
              <div className={styles.v}>{user.account}</div>
              <div className={styles.k}>邮箱</div>
              <div className={styles.v}>
                <input className={styles.input} value={emailDraft} onChange={(e) => setEmailDraft(e.target.value)} placeholder="可为空" />
              </div>
              <div className={styles.k}>状态</div>
              <div className={styles.v}>{user.isActive ? <span className={styles.ok}>启用</span> : <span className={styles.bad}>禁用</span>}</div>
              <div className={styles.k}>角色</div>
              <div className={styles.v}>
                {actorRole === "admin" ? (
                  <select className={styles.input} value={roleDraft} onChange={(e) => setRoleDraft(e.target.value)}>
                    <option value="user">user</option>
                    <option value="admin">admin</option>
                    <option value="group_admin">group_admin</option>
                  </select>
                ) : (
                  <div className={styles.readonlyValue}>{user.security.roleKey}</div>
                )}
              </div>
              <div className={styles.k}>所属组</div>
              <div className={styles.v}>
                {actorRole === "admin" ? (
                  <select className={styles.input} value={groupIdDraft} onChange={(e) => setGroupIdDraft(e.target.value)}>
                    <option value="">未绑定</option>
                    {groupItems.map((group) => (
                      <option key={group.id} value={group.id}>
                        {group.name}
                        {group.code ? ` (${group.code})` : ""}
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className={styles.readonlyValue}>{user.groupName ?? (user.groupId ? user.groupId : "-")}</div>
                )}
              </div>
              <div className={styles.k}>创建时间</div>
              <div className={styles.v}>{fmtTime(user.createdAt)}</div>
              <div className={styles.k}>更新时间</div>
              <div className={styles.v}>{fmtTime(user.updatedAt)}</div>
            </div>
          </section>

          <section className={styles.panel} aria-label="安全信息">
            <div className={styles.panelTitle}>安全信息</div>
            <div className={styles.kv}>
              <div className={styles.k}>最近登录</div>
              <div className={styles.v}>{fmtTime(user.security.lastLoginAt)}</div>
              <div className={styles.k}>密码更新时间</div>
              <div className={styles.v}>{fmtTime(user.security.passwordUpdatedAt)}</div>
              <div className={styles.k}>失败次数</div>
              <div className={styles.v}>{String(user.security.failedLoginCount ?? 0)}</div>
              <div className={styles.k}>锁定至</div>
              <div className={styles.v}>{fmtTime(user.security.lockedUntil)}</div>
              <div className={styles.k}>Token 版本</div>
              <div className={styles.v}>{String(user.security.tokenVersion ?? 1)}</div>
              <div className={styles.k}>禁用时间</div>
              <div className={styles.v}>{fmtTime(user.security.disabledAt)}</div>
              <div className={styles.k}>禁用原因</div>
              <div className={styles.v}>{user.security.disabledReason ?? "-"}</div>
            </div>
          </section>

          <section className={styles.panel} aria-label="操作">
            <div className={styles.panelTitle}>操作</div>
            <div className={styles.actions}>
              {user.isActive ? (
                <button type="button" className={styles.dangerBtn} onClick={() => openModal("disable")} disabled={acting}>
                  禁用账号
                </button>
              ) : (
                <button type="button" className={styles.topBtnPrimary} onClick={() => openModal("enable")} disabled={acting}>
                  启用账号
                </button>
              )}
              <button type="button" className={styles.dangerBtn} onClick={() => openModal("resetPassword")} disabled={acting}>
                重置密码
              </button>
              <button type="button" className={styles.dangerBtn} onClick={() => openModal("forceLogout")} disabled={acting}>
                强制下线
              </button>
              <button type="button" className={styles.topBtnPrimary} onClick={() => openModal("resourceStats")} disabled={acting}>
                查看资源消耗
              </button>
              <Link className={styles.topBtn} href={`/admin/audit?targetId=${encodeURIComponent(user.id)}`}>
                查看审计
              </Link>
            </div>
          </section>

          <UserModelAccessPanel
            modelRows={modelRows}
            disabled={loading || saving || acting}
            onUpdateRow={updateModelRow}
          />
        </div>
      ) : null}

      {modal ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="确认操作" onMouseDown={closeModal}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>
                {modal === "disable"
                  ? "禁用账号"
                  : modal === "enable"
                    ? "启用账号"
                    : modal === "resetPassword"
                      ? "重置密码"
                      : modal === "resourceStats"
                        ? "资源消耗统计"
                        : "强制下线"}
              </div>
              <button type="button" className={styles.modalClose} onClick={closeModal} aria-label="关闭">
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              {modal === "resourceStats" ? (
                resourceStatsLoading ? (
                  <div className={styles.tip}>加载中…</div>
                ) : resourceStatsData ? (
                  <div className={styles.kv}>
                    <div className={styles.panelTitle} style={{ gridColumn: "1 / -1", marginTop: 8 }}>生成总量（仅计成功）</div>
                    <div className={styles.k}>生成图片总数</div>
                    <div className={styles.v}>{resourceStatsData.generate.images}</div>
                    <div className={styles.k} style={{ paddingLeft: 16, color: "var(--c-text-muted)" }}>- 首帧图</div>
                    <div className={styles.v} style={{ color: "var(--c-text-muted)" }}>{resourceStatsData.generate.imageDetails.firstFrame}</div>
                    <div className={styles.k} style={{ paddingLeft: 16, color: "var(--c-text-muted)" }}>- 角色形象图抽卡</div>
                    <div className={styles.v} style={{ color: "var(--c-text-muted)" }}>{resourceStatsData.generate.imageDetails.roleFront}</div>
                    <div className={styles.k} style={{ paddingLeft: 16, color: "var(--c-text-muted)" }}>- 角色装造/服装抽卡</div>
                    <div className={styles.v} style={{ color: "var(--c-text-muted)" }}>{resourceStatsData.generate.imageDetails.roleAsset}</div>
                    <div className={styles.k} style={{ paddingLeft: 16, color: "var(--c-text-muted)" }}>- 素材(物品/场景/合成)</div>
                    <div className={styles.v} style={{ color: "var(--c-text-muted)" }}>{resourceStatsData.generate.imageDetails.material}</div>
                    
                    <div className={styles.k}>生成视频总数</div>
                    <div className={styles.v}>{resourceStatsData.generate.videos}</div>
                    <div className={styles.k}>生成音频总数</div>
                    <div className={styles.v}>{resourceStatsData.generate.audios}</div>

                    <div className={styles.panelTitle} style={{ gridColumn: "1 / -1", marginTop: 8 }}>存入资源库量</div>
                    <div className={styles.k}>常规图片入库数</div>
                    <div className={styles.v}>{resourceStatsData.store.images}</div>
                    <div className={styles.k}>人物合成图片入库</div>
                    <div className={styles.v}>{resourceStatsData.store.episodeMaterials}</div>

                    <div className={styles.panelTitle} style={{ gridColumn: "1 / -1", marginTop: 8 }}>产出转化情况</div>
                    <div className={styles.k}>首帧图生成分镜数</div>
                    <div className={styles.v}>{resourceStatsData.other.firstFrameVideos}</div>
                    <div className={styles.k}>剪映导出视频数</div>
                    <div className={styles.v}>{resourceStatsData.other.jianyingExportVideos}</div>
                    <div className={styles.k}>剪映导出音频数</div>
                    <div className={styles.v}>{resourceStatsData.other.jianyingExportAudios}</div>

                    <div className={styles.panelTitle} style={{ gridColumn: "1 / -1", marginTop: 8 }}>创作剧本数量</div>
                    <div className={styles.k}>生成剧本总数</div>
                    <div className={styles.v}>{resourceStatsData.stories?.count ?? 0}</div>
                    
                    {resourceStatsData.stories?.count > 0 && (
                      <div style={{ gridColumn: "1 / -1", maxHeight: 150, overflowY: "auto", border: "1px solid var(--c-border)", borderRadius: 4, padding: 8, background: "var(--c-bg-subtle)" }}>
                        <ul style={{ margin: 0, paddingLeft: 20, fontSize: 13, color: "var(--c-text-muted)" }}>
                          {(resourceStatsData.stories?.list ?? []).map(s => (
                            <li key={s.id} style={{ marginBottom: 4 }}>
                              {s.title} <span style={{ opacity: 0.6, fontSize: 12 }}>({fmtTime(s.createdAt)})</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ) : null
              ) : (
                <>
                  <div className={styles.tip}>
                    输入目标账号 <span className={styles.mono}>{user?.account}</span> 以确认
                  </div>
                  <input className={styles.input} value={confirmAccount} onChange={(e) => setConfirmAccount(e.target.value)} placeholder="确认账号" />
                  {modal === "disable" ? (
                    <input className={styles.input} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="禁用原因（可选）" />
                  ) : null}
                  {modal === "resetPassword" ? (
                    <input className={styles.input} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="新密码" type="password" />
                  ) : null}
                  <div className={styles.modalActions}>
                    <button type="button" className={styles.topBtn} onClick={closeModal} disabled={acting}>
                      取消
                    </button>
                    <button type="button" className={styles.dangerBtn} onClick={() => void runAction()} disabled={acting || !confirmAccount.trim()}>
                      {acting ? "处理中…" : "确认执行"}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      ) : null}
    </main>
  )
}
