"use client"

import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter, useSearchParams } from "next/navigation"
import { useCallback, useEffect, useMemo, useState } from "react"
import type { ReactElement } from "react"
import { createPortal } from "react-dom"
import { CircleHelp, Home, Library, ListChecks, LogIn, NotebookPen, RotateCw, Shield, Video, X } from "lucide-react"
import { appNavItems } from "@/shared/navigation"
import { useActiveJobs } from "@/features/video/hooks/useActiveJobs"
import { EmptyState } from "@/components/empty-state/EmptyState"
import { AccountCenterPopover } from "@/components/app-header/AccountCenterPopover"
import logoImage from "../../../assets/logo.jpg"
import styles from "./AppHeader.module.css"

// 任务类型友好名称映射
const JOB_TYPE_LABELS: Record<string, string> = {
  first_frame_generate: "首帧图生成",
  video_generate: "视频生成",
  episode_material_generate: "素材生成",
  episode_material_asset_regenerate: "素材重制",
  SHORT_DRAMA_ROLE_ASSET_DRAW: "角色绘制",
  short_drama_role_image_draw: "角色图生成",
  voiceover_audio_generate: "旁白音频",
  jianying_export: "剪映工程导出",
  coze_generate_script: "分镜脚本",
  coze_generate_outline: "大纲生成",
  coze_generate_storyboard_text: "分镜文本",
  coze_generate_script_body: "剧本正文",
  short_drama_parsing: "剧本解析",
  short_drama_role_parsing: "角色解析",
  quick_generate_episode_create: "剧集创作",
  quick_generate_video_prompt: "视频提示词",
  quick_generate_jianying_export: "剪映工程导出",
  quick_generate_panel_prompt: "分镜板提示词",
  quick_generate_panel_image: "分镜板图片",
  quick_generate_storyboard_panel_review_poll: "分镜板送审"
}

// 任务阶段友好名称映射
const JOB_STAGE_LABELS: Record<string, string> = {
  queued: "排队中",
  running: "执行中",
  cancelling: "取消中",
  coze: "Coze处理",
  persist: "上传入库",
  write_metadata: "写入剧本",
  skip: "跳过已生成",
  load_materials: "收集素材",
  call_workflow: "拆分镜头",
  persist_result: "写入结果",
  enqueue_video_prompt: "发起生成提示词",
  polling: "审核中",
  done: "已完成",
  error: "失败",
  canceled: "已取消",
  worker_crash: "执行异常",
  prompt: "生成提示词"
}

function getJobTypeLabel(type: string): string {
  return JOB_TYPE_LABELS[type] || type
}

function getJobStageLabel(stage: string): string {
  return JOB_STAGE_LABELS[stage] || stage
}

function getJobTargetLabel(snapshot: unknown): string {
  const s = snapshot && typeof snapshot === "object" ? (snapshot as any) : null
  const label = typeof s?.label === "string" ? s.label.trim() : ""
  if (label) return label
  const episodeNo = Number(s?.episodeNo ?? 0) || 0
  const sceneNo = Number(s?.sceneNo ?? 0) || 0
  if (episodeNo > 0 && sceneNo > 0) return `第 ${episodeNo} 集 · 镜 ${sceneNo}`
  if (sceneNo > 0) return `镜 ${sceneNo}`
  const currentName = typeof s?.currentName === "string" ? s.currentName.trim() : ""
  if (currentName) return currentName
  const characterName = typeof s?.characterName === "string" ? s.characterName.trim() : ""
  if (characterName) return characterName
  return ""
}

function formatJobCreatedAt(value: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return "-"
  const pad = (num: number) => String(num).padStart(2, "0")
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`
}

type MeResult =
  | { ok: true; data: { user: { id: string; account: string; role: string } }; traceId: string }
  | { ok: false; error: { code: string; message: string }; traceId: string }

type AppHeaderVariant = "app" | "auth"

type AppHeaderProps = {
  variant?: AppHeaderVariant
}

/**
 * 应用侧边导航栏
 * @returns {ReactElement} Header 组件
 */
export function AppHeader({ variant = "app" }: AppHeaderProps): ReactElement {
  const pathname = usePathname() ?? "/"
  const router = useRouter()
  const searchParams = useSearchParams()
  const [me, setMe] = useState<MeResult | null>(null)
  const [loggingOut, setLoggingOut] = useState(false)
  const [taskOpen, setTaskOpen] = useState(false)
  const [activeStoryId, setActiveStoryId] = useState("")
  const [cancelingJobs, setCancelingJobs] = useState<Record<string, true>>({})

  const isActive = (href: string): boolean => {
    if (href === "/") return pathname === "/"
    return pathname.startsWith(href)
  }

  useEffect(() => {
    if (variant === "auth") return

    let cancelled = false

    ;(async (): Promise<void> => {
      try {
        const res = await fetch("/api/auth/me?refresh=1", { method: "GET" })
        const json = (await res.json()) as MeResult
        if (!cancelled) setMe(json)
      } catch {
        if (!cancelled)
          setMe({
            ok: false,
            error: { code: "NETWORK_ERROR", message: "网络错误" },
            traceId: "n/a"
          })
      }
    })()

    return () => {
      cancelled = true
    }
  }, [variant])

  const derivedStoryId = useMemo(() => {
    const fromQuery = (searchParams?.get("storyId") ?? "").trim()
    if (fromQuery) return fromQuery
    const m =
      pathname.match(/^\/script\/workspace\/([^/]+)/) ??
      pathname.match(/^\/script\/short-drama\/([^/]+)/) ??
      pathname.match(/^\/script\/quick-generate\/([^/]+)/)
    return (m?.[1] ?? "").trim()
  }, [pathname, searchParams])

  useEffect(() => {
    if (variant !== "app") return
    const next = derivedStoryId.trim()
    if (next) {
      setActiveStoryId(next)
      try {
        window.localStorage.setItem("last_story_id", next)
      } catch {}
      return
    }
    try {
      const cached = (window.localStorage.getItem("last_story_id") ?? "").trim()
      if (cached) setActiveStoryId(cached)
    } catch {}
  }, [derivedStoryId, variant])

  useEffect(() => {
    if (variant !== "app") return
    const onOpen = () => setTaskOpen(true)
    window.addEventListener("open_task_center", onOpen)
    return () => window.removeEventListener("open_task_center", onOpen)
  }, [variant])

  const { jobs, summary: jobSummary, loading: jobsLoading, error: jobsError, refresh: refreshJobs } = useActiveJobs({
    storyId: activeStoryId,
    enabled: variant === "app" && Boolean(activeStoryId)
  })

  const jobBadgeCount = useMemo(() => jobSummary.queued + jobSummary.running, [jobSummary.queued, jobSummary.running])

  const displayAccount = useMemo(() => {
    if (!me || !me.ok) return null
    return me.data.user.account
  }, [me])

  const userRole = useMemo(() => {
    if (!me || !me.ok) return null
    return me.data.user.role
  }, [me])

  // 根据角色判断是否为管理员（admin / group_admin 都可访问 /admin）
  const isAdmin = useMemo(() => userRole === "admin" || userRole === "group_admin", [userRole])

  /**
   * 退出登录并跳转到登录页
   * @returns {Promise<void>} 无返回值
   */
  const onLogout = useCallback(async (): Promise<void> => {
    if (loggingOut) return
    setLoggingOut(true)

    try {
      await fetch("/api/auth/logout", { method: "POST" })
    } finally {
      setLoggingOut(false)
      router.replace("/login")
      router.refresh()
    }
  }, [loggingOut, router])

  const canPortal = typeof document !== "undefined"

  const taskOverlayNode =
    variant === "app" && taskOpen && canPortal
      ? createPortal(
          <div
            className={styles.taskOverlay}
            role="dialog"
            aria-modal="true"
            aria-label="任务中心"
            onMouseDown={(e) => {
              if (e.target === e.currentTarget) setTaskOpen(false)
            }}
          >
            <div className={styles.taskPanel}>
              <div className={styles.taskHeader}>
                <div className={styles.taskTitleRow}>
                  <div className={styles.taskTitle}>任务中心</div>
                  <button
                    type="button"
                    className={styles.taskTerminateButton}
                    onClick={async () => {
                      if (!activeStoryId) return
                      try {
                        const res = await fetch("/api/jobs/cancel-by-story", {
                          method: "POST",
                          headers: { "content-type": "application/json" },
                          body: JSON.stringify({ storyId: activeStoryId })
                        })
                        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { canceled: number }; error?: { message?: string } } | null
                        if (!res.ok || !json?.ok) {
                          alert(json?.error?.message || "终止任务失败")
                          return
                        }
                        alert(`已终止 ${json.data?.canceled || 0} 个任务`)
                      } catch (e) {
                        alert(`终止任务失败：${(e as any)?.message || "未知错误"}`)
                      } finally {
                        void refreshJobs()
                      }
                    }}
                    disabled={!activeStoryId || jobsLoading || jobBadgeCount === 0}
                    aria-label="终止所有任务"
                    title="终止所有任务"
                  >
                    终止所有任务
                  </button>
                </div>
                <div className={styles.taskHeaderActions}>
                  <button
                    type="button"
                    className={styles.taskIconButton}
                    onClick={() => void refreshJobs()}
                    disabled={!activeStoryId || jobsLoading}
                    aria-label="刷新任务"
                    title="刷新任务"
                  >
                    <RotateCw size={16} strokeWidth={2.2} />
                  </button>
                  <button type="button" className={styles.taskIconButton} onClick={() => setTaskOpen(false)} aria-label="关闭" title="关闭">
                    <X size={16} strokeWidth={2.2} />
                  </button>
                </div>
              </div>

              {!activeStoryId ? (
                <EmptyState
                  size="inline"
                  title="暂时还没有可展示的任务"
                  description="先打开一个故事（项目），生成素材后这里会展示进度与失败原因。"
                  primaryAction={{ label: "去内容库", href: "/library" }}
                  secondaryAction={{ label: "去创作剧本", href: "/script/workspace?mode=brief" }}
                  learnHref="/help?topic=task-center"
                />
              ) : (
                <>
                  <div className={styles.taskMeta}>
                    <Link className={styles.taskMetaLink} href={`/video?tab=list&storyId=${encodeURIComponent(activeStoryId)}`}>
                      打开分镜表
                    </Link>
                    <span className={styles.taskMetaText}>
                      总任务：{jobSummary.total} / 已完成：{jobSummary.done} / 进行中：{jobSummary.running} / 排队中：{jobSummary.queued}
                    </span>
                  </div>

                  {jobsError ? <div className={styles.taskError}>{jobsError}</div> : null}

                  <div className={styles.taskList}>
                    {jobs.length === 0 ? (
                      <EmptyState
                        size="inline"
                        title="当前没有进行中的任务"
                        description="你可以在分镜表里发起生成，这里会自动跟踪进度。"
                        primaryAction={{ label: "打开分镜表", href: `/video?tab=list&storyId=${encodeURIComponent(activeStoryId)}` }}
                        learnHref="/help?topic=task-center"
                      />
                    ) : (
                      jobs.map((j) => {
                        const stage = typeof (j.snapshot as any)?.stage === "string" ? String((j.snapshot as any).stage) : ""
                        const isCancelled = stage === "canceled"
                        const isCancelling = stage === "cancelling"
                        const canCancel = (j.status === "queued" || j.status === "running") && !isCancelled
                        const canceling = Boolean(cancelingJobs[j.jobId]) || isCancelling
                        const typeLabel = getJobTypeLabel(j.type)
                        const targetLabel = getJobTargetLabel(j.snapshot)
                        const stageLabel = getJobStageLabel(stage)
                        const createdAtLabel = formatJobCreatedAt(j.createdAt)
                        const downloadUrl = typeof (j.snapshot as any)?.downloadUrl === "string" ? String((j.snapshot as any).downloadUrl).trim() : ""
                        const canDownload = j.status === "done" && Boolean(downloadUrl)
                        const displayStatus = isCancelled ? "已取消" : isCancelling ? "取消中" : j.status
                        return (
                          <div key={j.jobId} className={styles.taskItem}>
                            <div className={styles.taskItemTop}>
                              <div className={styles.taskItemType}>{targetLabel ? `${typeLabel}（${targetLabel}）` : typeLabel}</div>
                              <div className={`${styles.taskItemStatus} ${j.status === "error" && !isCancelled ? styles.taskItemStatusError : ""}`}>
                                {displayStatus}
                              </div>
                            </div>
                            <div className={styles.taskItemBottom}>
                              <div className={styles.taskItemStage}>{stageLabel || "-"}</div>
                              <div className={styles.taskItemMeta}>
                                <div className={styles.taskItemTime}>{createdAtLabel}</div>
                                <div className={styles.taskItemId}>{j.jobId}</div>
                              </div>
                            </div>
                            {canDownload || canCancel ? (
                              <div className={styles.taskItemActions}>
                                {canCancel ? (
                                  <button
                                    type="button"
                                    className={styles.taskCancelButton}
                                    onClick={async () => {
                                      if (canceling) return
                                      const ok = window.confirm("确定要终止这个任务吗？这不会影响其它任务。")
                                      if (!ok) return
                                      setCancelingJobs((prev) => ({ ...prev, [j.jobId]: true }))
                                      try {
                                        const res = await fetch(`/api/jobs/${encodeURIComponent(j.jobId)}/cancel`, {
                                          method: "POST",
                                          headers: { "content-type": "application/json" },
                                          body: JSON.stringify({ mode: "auto" })
                                        })
                                        const json = (await res.json().catch(() => null)) as
                                          | { ok: boolean; data?: { canceled: number }; error?: { message?: string } }
                                          | null
                                        if (!res.ok || !json?.ok) {
                                          alert(json?.error?.message || "终止任务失败")
                                          return
                                        }
                                      } catch (e) {
                                        alert(`终止任务失败：${(e as any)?.message || "未知错误"}`)
                                      } finally {
                                        setCancelingJobs((prev) => {
                                          const next = { ...prev }
                                          delete next[j.jobId]
                                          return next
                                        })
                                        void refreshJobs()
                                      }
                                    }}
                                    disabled={!activeStoryId || jobsLoading || canceling}
                                    aria-label="终止任务"
                                    title="终止任务"
                                  >
                                    {canceling ? "取消中" : "终止"}
                                  </button>
                                ) : null}
                                {canDownload ? (
                                  <a className={styles.taskDownloadButton} href={downloadUrl} target="_blank" rel="noreferrer">
                                    下载
                                  </a>
                                ) : null}
                              </div>
                            ) : null}
                          </div>
                        )
                      })
                    )}
                  </div>
                </>
              )}
            </div>
          </div>,
          document.body
        )
      : null

  const headerNode = (
    <header className={styles.header}>
      <div className={`${styles.inner} ${variant === "auth" ? styles.innerNoNav : ""}`}>
        <Link href="/" className={styles.brand} aria-label="MagiCo" title="MagiCo">
          <span className={styles.brandIcon} aria-hidden="true">
            <Image className={styles.brandLogo} src={logoImage} alt="" sizes="34px" />
          </span>
        </Link>

        {variant === "app" ? (
          <nav className={styles.nav} aria-label="主导航">
            {appNavItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`${styles.navItem} ${isActive(item.href) ? styles.navItemActive : ""}`}
                aria-label={item.label}
                title={item.label}
              >
                {item.href === "/" ? (
                  <Home size={20} strokeWidth={2.2} />
                ) : item.href.startsWith("/script") ? (
                  <NotebookPen size={20} strokeWidth={2.2} />
                ) : item.href.startsWith("/video") ? (
                  <Video size={20} strokeWidth={2.2} />
                ) : (
                  <Library size={20} strokeWidth={2.2} />
                )}
              </Link>
            ))}
          </nav>
        ) : null}

        <div className={styles.actions}>
          {variant === "app" ? (
            <button
              type="button"
              className={styles.taskButton}
              onClick={() => setTaskOpen(true)}
              aria-label="任务中心"
              title={activeStoryId ? "任务中心" : "任务中心（打开一个故事后可查看）"}
            >
              <ListChecks size={20} strokeWidth={2.2} />
              {jobBadgeCount > 0 ? <span className={styles.taskBadge}>{jobBadgeCount}</span> : null}
            </button>
          ) : null}
          <Link href="/help" className={styles.actionLink} aria-label="帮助中心" title="帮助中心">
            <CircleHelp size={20} strokeWidth={2.2} />
          </Link>
          {variant === "app" ? (
            <>
              {displayAccount ? (
                <>
                  {isAdmin ? (
                    <Link href="/admin" className={styles.actionLink} aria-label="管理员后台" title="管理员后台">
                      <Shield size={20} strokeWidth={2.2} />
                    </Link>
                  ) : null}
                  <AccountCenterPopover accountTitle={displayAccount} loggingOut={loggingOut} onLogout={onLogout} />
                </>
              ) : (
                <Link href="/login" className={styles.actionLink} aria-label="去登录" title="去登录">
                  <LogIn size={20} strokeWidth={2.2} />
                </Link>
              )}
            </>
          ) : null}
        </div>
      </div>
    </header>
  )

  return (
    <>
      {headerNode}
      {taskOverlayNode}
    </>
  )
}
