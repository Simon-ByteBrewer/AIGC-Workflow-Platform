import { NextResponse, type NextRequest } from "next/server"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import {
  getCanvasCopyrightStoryReviewConfig,
  listCanvasCopyrightAssetsForStory,
  normalizeCanvasCopyrightMediaType,
  updateCanvasCopyrightAssetReview,
  upsertCanvasCopyrightAsset
} from "@/server/domains/video/canvas/copyright/canvasCopyrightAssetStore"
import { isCanvasSeedance20AudEnabled } from "@/server/domains/video/canvas/copyright/canvasCopyrightCapability"
import { enqueueCanvasCopyrightReviewJob } from "@/server/domains/video/canvas/jobs/canvasCopyrightReviewWorker"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  search: z.string().trim().max(100).optional(),
  mediaType: z.enum(["image", "video", "audio"]).optional()
})

const bodySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200),
    title: z.string().trim().min(1).max(200),
    mediaType: z.enum(["image", "video", "audio"]),
    sourceAssetId: z.string().trim().max(300).optional(),
    sourceUrl: z.string().trim().max(5000).optional(),
    previewUrl: z.string().trim().max(5000).optional(),
    sourceStorageKey: z.string().trim().max(1000).optional(),
    previewStorageKey: z.string().trim().max(1000).optional(),
    mimeType: z.string().trim().max(200).optional(),
    sizeBytes: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER).optional(),
    metadata: z.record(z.string(), z.unknown()).optional()
  })
  .strict()

/**
 * 校验当前用户是否有权访问指定画布项目。
 */
async function assertStoryAccess(input: {
  storyId: string
  userId: string
}): Promise<boolean> {
  const db = await getDb({ stories })
  const rows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, input.storyId), eq(stories.userId, input.userId)))
    .limit(1)
  return rows.length > 0
}

/**
 * 获取项目级版权库列表。
 */
export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const parsed = querySchema.safeParse({
    storyId: req.nextUrl.searchParams.get("storyId") ?? "",
    search: req.nextUrl.searchParams.get("search") ?? undefined,
    mediaType: req.nextUrl.searchParams.get("mediaType") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const allowed = await assertStoryAccess({ storyId: parsed.data.storyId, userId })
    if (!allowed) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用项目"), { status: 404 })

    const items = await listCanvasCopyrightAssetsForStory(parsed.data.storyId)
    const search = (parsed.data.search ?? "").trim().toLowerCase()
    const filtered = items.filter((item) => {
      if (parsed.data.mediaType && item.mediaType !== parsed.data.mediaType) return false
      if (!search) return true
      return (
        item.title.toLowerCase().includes(search) ||
        item.sourceAssetId.toLowerCase().includes(search) ||
        item.reviewAssetId.toLowerCase().includes(search)
      )
    })
    return NextResponse.json(makeApiOk(traceId, { items: filtered }), { status: 200 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "加载版权库失败"
    logger.error({
      event: "canvas_copyright_assets_list_failed",
      module: "video/canvas",
      traceId,
      message: "加载画布版权库失败",
      errorMessage: message
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "加载版权库失败"), { status: 500 })
  }
}

/**
 * 为当前项目提交一条版权审核任务，并返回可供前端恢复的 jobId。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const allowed = await assertStoryAccess({ storyId: parsed.data.storyId, userId })
    if (!allowed) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用项目"), { status: 404 })
    if (!isCanvasSeedance20AudEnabled()) {
      return NextResponse.json(makeApiErr(traceId, "FEATURE_DISABLED", "当前环境未开启画布送审能力"), { status: 400 })
    }

    const reviewConfig = await getCanvasCopyrightStoryReviewConfig({ storyId: parsed.data.storyId, userId })
    if (!reviewConfig?.groupId) {
      return NextResponse.json(makeApiErr(traceId, "GROUP_ID_MISSING", "当前画布项目缺少 group_id，请重新创建项目"), { status: 400 })
    }

    const mediaType = normalizeCanvasCopyrightMediaType(parsed.data.mediaType)
    if (!mediaType) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "版权素材类型不支持"), { status: 400 })

    const item = await upsertCanvasCopyrightAsset({
      storyId: parsed.data.storyId,
      title: parsed.data.title,
      mediaType,
      sourceAssetId: parsed.data.sourceAssetId,
      sourceUrl: parsed.data.sourceUrl,
      previewUrl: parsed.data.previewUrl,
      sourceStorageKey: parsed.data.sourceStorageKey,
      previewStorageKey: parsed.data.previewStorageKey,
      mimeType: parsed.data.mimeType,
      sizeBytes: parsed.data.sizeBytes,
      metadata: parsed.data.metadata
    })

    const { jobId, snapshot } = await enqueueCanvasCopyrightReviewJob({
      userId,
      traceId,
      storyId: parsed.data.storyId,
      copyrightAssetId: item.id
    })

    const updated = await updateCanvasCopyrightAssetReview({
      id: item.id,
      reviewStatus: "queued",
      reviewErrorMessage: null,
      submitJobId: jobId,
      submittedAt: new Date(),
      finishedAt: null
    })

    kickAllWorkers()
    return NextResponse.json(makeApiOk(traceId, { item: updated, jobId, snapshot }), { status: 202 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "版权送审失败"
    logger.error({
      event: "canvas_copyright_assets_submit_failed",
      module: "video/canvas",
      traceId,
      message: "提交画布版权审核失败",
      errorMessage: message
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "版权送审失败，请稍后重试"), { status: 500 })
  }
}
