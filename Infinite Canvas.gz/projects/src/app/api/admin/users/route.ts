import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, asc, desc, eq, inArray, or, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { groupModelBindings, groupModelCredentials, userGroups, userModelToggles, userSecurity, users } from "@/shared/schema"
import { assignManagedPromptsToUserByGroup } from "@/server/domains/admin/promptManagement"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { ensureAdminPersonalGroup } from "@/server/domains/admin/services/adminPersonalGroup"
import { hashPassword } from "@/features/auth/password"

export const runtime = "nodejs"

type ModelAccessSummary = {
  apiKeyConfigured: boolean
  video: { enabledModels: string[]; disabledModels: string[] }
  language: { enabledModels: string[]; disabledModels: string[] }
  image: { enabledModels: string[]; disabledModels: string[] }
}

function emptySummary(): ModelAccessSummary {
  return {
    apiKeyConfigured: false,
    video: { enabledModels: [], disabledModels: [] },
    language: { enabledModels: [], disabledModels: [] },
    image: { enabledModels: [], disabledModels: [] }
  }
}

const listQuerySchema = z.object({
  q: z.string().trim().optional(),
  status: z.enum(["active", "inactive"]).optional(),
  role: z.string().trim().min(1).max(50).optional(),
  sort: z.enum(["createdAt", "lastLoginAt"]).optional(),
  order: z.enum(["asc", "desc"]).optional(),
  limit: z.string().trim().optional(),
  offset: z.string().trim().optional()
})

const createBodySchema = z.object({
  account: z.string().trim().min(1).max(100),
  email: z.string().trim().min(1).max(200).optional(),
  password: z.string().min(1).max(200),
  roleKey: z.enum(["user", "admin", "group_admin"]).optional(),
  groupId: z.string().trim().max(200).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor

  const url = new URL(req.url)
  const parsed = listQuerySchema.safeParse(Object.fromEntries(url.searchParams.entries()))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  const limit = Math.max(1, Math.min(100, Number(parsed.data.limit ?? "20") || 20))
  const offset = Math.max(0, Number(parsed.data.offset ?? "0") || 0)
  const q = (parsed.data.q ?? "").trim().toLowerCase()
  const sort = parsed.data.sort ?? "createdAt"
  const order = parsed.data.order ?? "desc"

  await ensurePublicSchema()
  const db = await getDb({ users, userSecurity, groupModelCredentials, groupModelBindings, userModelToggles, userGroups })

  const whereParts: any[] = []
  if (parsed.data.status === "active") whereParts.push(eq(users.isActive, true))
  if (parsed.data.status === "inactive") whereParts.push(eq(users.isActive, false))
  if (parsed.data.role) whereParts.push(eq(userSecurity.roleKey, parsed.data.role))

  // group_admin 只能看到自己组内账号；并且不可跨组
  if (actor.roleKey === "group_admin") {
    whereParts.push(eq(userSecurity.groupId, actor.groupId!))
    whereParts.push(eq(userSecurity.roleKey, "user"))
  }

  if (q) {
    const like = `%${q}%`
    whereParts.push(
      or(
        sql`lower(${users.name}) like ${like}`,
        sql`lower(coalesce(${users.email}, '')) like ${like}`,
        sql`${users.id} = ${q}`
      )
    )
  }

  const where = whereParts.length > 0 ? and(...whereParts) : undefined

  const orderExpr =
    sort === "lastLoginAt"
      ? sql`coalesce(${userSecurity.lastLoginAt}, '1970-01-01'::timestamptz)`
      : users.createdAt

  const rows = await db
    .select({
      id: users.id,
      account: users.name,
      email: users.email,
      isActive: users.isActive,
      createdAt: users.createdAt,
      updatedAt: users.updatedAt,
      roleKey: userSecurity.roleKey,
      lastLoginAt: userSecurity.lastLoginAt,
      groupId: userSecurity.groupId,
      groupName: userGroups.name
    })
    .from(users)
    .leftJoin(userSecurity, eq(userSecurity.userId, users.id))
    .leftJoin(userGroups, eq(userGroups.id, userSecurity.groupId))
    .where(where)
    .orderBy(order === "asc" ? asc(orderExpr) : desc(orderExpr))
    .limit(limit)
    .offset(offset)

  const userIds = rows.map((r) => r.id)
  const groupIds = Array.from(new Set(rows.map((r) => r.groupId).filter(Boolean))) as string[]
  const summaryByUserId = new Map<string, ModelAccessSummary>()
  for (const userId of userIds) summaryByUserId.set(userId, emptySummary())

  if (userIds.length > 0) {
    const summaryByGroupId = new Map<string, ModelAccessSummary>()
    for (const groupId of groupIds) summaryByGroupId.set(groupId, emptySummary())

    if (groupIds.length > 0) {
      const credentialRows = await db
        .select({
          groupId: groupModelCredentials.groupId
        })
        .from(groupModelCredentials)
        .where(inArray(groupModelCredentials.groupId, groupIds))

      for (const r of credentialRows) {
        const s = summaryByGroupId.get(r.groupId)
        if (s) s.apiKeyConfigured = true
      }

      const bindingRows = await db
        .select({
          groupId: groupModelBindings.groupId,
          modelType: groupModelBindings.modelType,
          modelName: groupModelBindings.modelName,
          isEnabled: groupModelBindings.isEnabled
        })
        .from(groupModelBindings)
        .where(inArray(groupModelBindings.groupId, groupIds))

      for (const r of bindingRows) {
        const s = summaryByGroupId.get(r.groupId)
        if (!s) continue
        const group =
          r.modelType === "video" ? s.video : r.modelType === "language" ? s.language : r.modelType === "image" ? s.image : null
        if (!group) continue
        if (r.isEnabled) group.enabledModels.push(r.modelName)
        else group.disabledModels.push(r.modelName)
      }

      const toggleRows = await db
        .select({
          userId: userModelToggles.userId,
          modelType: userModelToggles.modelType,
          modelName: userModelToggles.modelName,
          isEnabled: userModelToggles.isEnabled
        })
        .from(userModelToggles)
        .where(inArray(userModelToggles.userId, userIds))

      for (const row of rows) {
        const userSummary = summaryByUserId.get(row.id) ?? emptySummary()
        const groupSummary = row.groupId ? summaryByGroupId.get(row.groupId) : null
        if (groupSummary) {
          userSummary.apiKeyConfigured = groupSummary.apiKeyConfigured
          userSummary.video.enabledModels = [...groupSummary.video.enabledModels]
          userSummary.video.disabledModels = [...groupSummary.video.disabledModels]
          userSummary.language.enabledModels = [...groupSummary.language.enabledModels]
          userSummary.language.disabledModels = [...groupSummary.language.disabledModels]
          userSummary.image.enabledModels = [...groupSummary.image.enabledModels]
          userSummary.image.disabledModels = [...groupSummary.image.disabledModels]
        }
        summaryByUserId.set(row.id, userSummary)
      }

      for (const t of toggleRows) {
        const s = summaryByUserId.get(t.userId)
        if (!s) continue
        const group =
          t.modelType === "video" ? s.video : t.modelType === "language" ? s.language : t.modelType === "image" ? s.image : null
        if (!group) continue
        group.enabledModels = group.enabledModels.filter((name) => name !== t.modelName)
        group.disabledModels = group.disabledModels.filter((name) => name !== t.modelName)
        if (t.isEnabled) group.enabledModels.push(t.modelName)
        else group.disabledModels.push(t.modelName)
      }

      for (const s of summaryByUserId.values()) {
        s.video.enabledModels.sort()
        s.video.disabledModels.sort()
        s.language.enabledModels.sort()
        s.language.disabledModels.sort()
        s.image.enabledModels.sort()
        s.image.disabledModels.sort()
      }
    }
  }

  const items = rows.map((r) => ({
    id: r.id,
    account: r.account,
    email: r.email,
    isActive: r.isActive,
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
    roleKey: r.roleKey ?? "user",
    lastLoginAt: r.lastLoginAt ?? null,
    groupId: r.groupId ?? null,
    groupName: r.groupName ?? null,
    modelAccessSummary: summaryByUserId.get(r.id) ?? emptySummary()
  }))

  return NextResponse.json(makeApiOk(traceId, { items, limit, offset, actor: { roleKey: actor.roleKey, groupId: actor.groupId } }), { status: 200 })
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor

  const parsed = createBodySchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  const account = parsed.data.account.trim()
  const email = (parsed.data.email ?? "").trim()
  const roleKey = (parsed.data.roleKey ?? "user").trim() as "user" | "admin" | "group_admin"
  const requestedGroupId = (parsed.data.groupId ?? "").trim()

  if (actor.roleKey === "group_admin" && roleKey !== "user") {
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "组管理员只能创建普通员工"), { status: 403 })
  }
  if (actor.roleKey === "group_admin" && !actor.groupId) {
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "组管理员未绑定用户组"), { status: 403 })
  }

  await ensurePublicSchema()
  const db = await getDb({ users, userSecurity, userGroups })

  const groupId =
    actor.roleKey === "group_admin"
      ? actor.groupId!
      : roleKey === "admin"
        ? (requestedGroupId || null)
        : (requestedGroupId || null)

  if (roleKey !== "admin" && !groupId) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "创建组管理员/员工必须选择用户组"), { status: 400 })
  }
  if (roleKey === "admin" && groupId) {
    // admin 可以不绑定组；绑定也允许，但需要组存在
    const g = await db.select({ id: userGroups.id, isActive: userGroups.isActive }).from(userGroups).where(eq(userGroups.id, groupId)).limit(1)
    if (!g[0]?.id) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "用户组不存在"), { status: 400 })
    if (!g[0].isActive) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "用户组已禁用"), { status: 400 })
  }
  if (groupId) {
    const g = await db.select({ id: userGroups.id, isActive: userGroups.isActive }).from(userGroups).where(eq(userGroups.id, groupId)).limit(1)
    if (!g[0]?.id) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "用户组不存在"), { status: 400 })
    if (!g[0].isActive) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "用户组已禁用"), { status: 400 })
  }

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.name, account))
    .limit(1)
  if (existing[0]?.id) {
    return NextResponse.json(makeApiErr(traceId, "ALREADY_EXISTS", "账号已存在"), { status: 409 })
  }

  const passwordHash = await hashPassword(parsed.data.password)
  const now = new Date()
  const [created] = await db
    .insert(users)
    .values({
      name: account,
      email: email ? email : null,
      password: passwordHash,
      isActive: true,
      updatedAt: now
    })
    .returning()

  if (!created?.id) {
    return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "创建账号失败"), { status: 500 })
  }

  await db
    .insert(userSecurity)
    .values({
      userId: created.id,
      roleKey,
      groupId: groupId ?? null,
      tokenVersion: 1,
      passwordUpdatedAt: now,
      createdAt: now,
      updatedAt: now
    })
    .onConflictDoNothing()

  const finalGroupId = roleKey === "admin" ? await ensureAdminPersonalGroup(db, created.id) : (groupId ?? null)
  if (roleKey !== "admin" && finalGroupId) {
    await assignManagedPromptsToUserByGroup({
      db,
      userId: created.id,
      groupId: finalGroupId,
      actorUserId: actor.userId
    })
  }

  await db.execute(sql`
    insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
    values (
      ${actor.userId},
      'user.create',
      'user',
      ${created.id},
      ${created.id},
      '{}'::jsonb,
      ${JSON.stringify({ id: created.id, account, email: created.email, roleKey, groupId: finalGroupId, isActive: true })}::jsonb,
      ${actor.ip},
      ${actor.userAgent},
      ${traceId}
    )
  `)

  return NextResponse.json(
    makeApiOk(traceId, {
      user: {
        id: created.id,
        account: created.name,
        email: created.email,
        isActive: created.isActive,
        createdAt: created.createdAt,
        groupId: finalGroupId
      }
    }),
    { status: 201 }
  )
}
