import { NextResponse, type NextRequest } from "next/server"
import { inArray } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ttsSpeakerSamples } from "@/shared/schema"
import { DEFAULT_TTS_TEST_TEXT, TTS_SPEAKERS } from "@/features/tts/speakers"

export const runtime = "nodejs"

type SpeakerSample = {
  url: string
  sampleText: string
}

function buildSpeakersResponse(sampleBySpeakerId?: Map<string, SpeakerSample>) {
  return TTS_SPEAKERS.map((s) => ({
    id: s.id,
    name: s.name,
    sampleText: sampleBySpeakerId?.get(s.id)?.sampleText ?? DEFAULT_TTS_TEST_TEXT,
    sampleUrl: sampleBySpeakerId?.get(s.id)?.url ?? null
  }))
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req).catch(() => null)
  const userId = session?.userId
  if (!userId) {
    logger.warn({
      event: "tts_speakers_auth_missing",
      module: "tts",
      traceId,
      message: "音色列表请求缺少登录态，返回静态音色清单",
    })
    return NextResponse.json(makeApiOk(traceId, { speakers: buildSpeakersResponse() }), { status: 200 })
  }

  try {
    const speakerIds = TTS_SPEAKERS.map((s) => s.id)
    const db = await getDb({ ttsSpeakerSamples })
    const list =
      speakerIds.length > 0
        ? await db
            .select({
              id: ttsSpeakerSamples.id,
              speakerId: ttsSpeakerSamples.speakerId,
              speakerName: ttsSpeakerSamples.speakerName,
              sampleText: ttsSpeakerSamples.sampleText,
              url: ttsSpeakerSamples.url,
              storageKey: ttsSpeakerSamples.storageKey
            })
            .from(ttsSpeakerSamples)
            .where(inArray(ttsSpeakerSamples.speakerId, speakerIds as any))
            .limit(Math.max(speakerIds.length, 1))
        : []

    const sampleBySpeakerId = new Map<string, SpeakerSample>()
    for (const r of list) {
      const sampleId = String(r.id ?? "").trim()
      const id = String(r.speakerId ?? "").trim()
      const storageKey = String(r.storageKey ?? "").trim()
      const rawUrl = String(r.url ?? "").trim()
      const sampleText = String(r.sampleText ?? "").trim()
      if (!id) continue
      const stableUrl = sampleId ? `/api/tts/speakers/file/${sampleId}` : rawUrl
      const finalUrl = stableUrl || rawUrl || (storageKey ? `/api/tts/speakers/file/${sampleId}` : "")
      if (!finalUrl) continue
      if (!sampleBySpeakerId.has(id)) sampleBySpeakerId.set(id, { url: finalUrl, sampleText })
    }

    return NextResponse.json(makeApiOk(traceId, { speakers: buildSpeakersResponse(sampleBySpeakerId) }), { status: 200 })
  } catch (err) {
    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "tts_speakers_query_failed",
      module: "tts",
      traceId,
      message: "读取音色样音失败，回退静态音色清单",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })

    return NextResponse.json(makeApiOk(traceId, { speakers: buildSpeakersResponse() }), { status: 200 })
  }
}
