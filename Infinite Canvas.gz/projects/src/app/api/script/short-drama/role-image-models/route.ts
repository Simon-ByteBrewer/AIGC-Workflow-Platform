import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { listEnabledImageModelsForUser } from "@/server/domains/image/imageModelResolver"

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) {
    return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })
  }

  const items = await listEnabledImageModelsForUser(userId)
  const hasInternal = items.some((item) => item.kind === "internal")
  const hasExternal = items.some((item) => item.kind === "external")

  return NextResponse.json(
    makeApiOk(traceId, {
      kinds: [
        ...(hasInternal ? [{ value: "internal" as const, label: "内部模型" }] : []),
        ...(hasExternal ? [{ value: "external" as const, label: "外部模型" }] : [])
      ],
      items
    }),
    { status: 200 }
  )
}
