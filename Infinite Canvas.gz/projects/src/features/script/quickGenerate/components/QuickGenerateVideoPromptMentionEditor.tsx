"use client"

import { createPortal } from "react-dom"
import { memo, useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import styles from "./QuickGenerateVideoPromptMentionEditor.module.css"
import { normalizeQuickGenerateEditorText } from "./quickGenerateEditorText"
import {
  buildMentionItems,
  formatMentionDisplayLabel,
  normalizePlainMentionsToTokens,
  parseToken,
  parseValueTokens,
  toDisplayText,
  type QuickGenerateAllowedMention,
  type QuickGenerateMentionItem,
  type QuickGenerateMentionKind
} from "./quickGenerateMentions"
import { syncQuickGenerateVideoPromptFooter, syncQuickGenerateVoiceTail } from "@/shared/quickGenerate/voicePromptTail"

export type { QuickGenerateAllowedMention } from "./quickGenerateMentions"

type QuickGenerateMentionEditorMode = "videoPrompt" | "storyboardPanel"

type MentionCapture = {
  active: boolean
  query: string
  range: Range | null
  replaceRange: Range | null
}

const INTERNAL_MENTION_CLIPBOARD_MIME = "application/x-short-drama-mentions"

type MentionClipboardPart =
  | { kind: "text"; value: string }
  | { kind: "token"; token: string; orderNo?: number }

type MentionClipboardPayload = {
  parts: MentionClipboardPart[]
  text: string
}

function normalizeFuzzyInput(s: string): string {
  return String(s ?? "")
    .toLowerCase()
    .replace(/\s+/g, "")
}

function fuzzyMatch(query: string, text: string): boolean {
  const q = normalizeFuzzyInput(query)
  if (!q) return true
  const t = normalizeFuzzyInput(text)
  if (!t) return false
  let i = 0
  for (let j = 0; j < t.length && i < q.length; j += 1) {
    if (t[j] === q[i]) i += 1
  }
  return i >= q.length
}

function countDisplayChars(text: string): number {
  return Array.from(String(text ?? "")).length
}

function isTokenEl(el: HTMLElement): boolean {
  return el.nodeType === Node.ELEMENT_NODE && el.getAttribute?.("data-mention") === "1"
}

function getSelectionRange(): Range | null {
  const sel = window.getSelection?.()
  if (!sel || sel.rangeCount <= 0) return null
  return sel.getRangeAt(0)
}

function rangeWithinHost(range: Range | null, host: HTMLElement): boolean {
  return Boolean(range && host.contains(range.startContainer) && host.contains(range.endContainer))
}

function moveCaretAfter(node: Node): void {
  const selection = window.getSelection?.()
  if (!selection) return
  const range = document.createRange()
  range.setStartAfter(node)
  range.collapse(true)
  selection.removeAllRanges()
  selection.addRange(range)
}

function moveCaretToEnd(el: HTMLElement): void {
  const selection = window.getSelection?.()
  if (!selection) return
  const range = document.createRange()
  range.selectNodeContents(el)
  range.collapse(false)
  selection.removeAllRanges()
  selection.addRange(range)
}

function computeCaretRect(range: Range): DOMRect | null {
  const rect = range.getBoundingClientRect()
  if (rect.width || rect.height) return rect
  const marker = document.createElement("span")
  marker.textContent = "\u200b"
  const clone = range.cloneRange()
  clone.collapse(true)
  clone.insertNode(marker)
  const markerRect = marker.getBoundingClientRect()
  marker.remove()
  return markerRect.width || markerRect.height ? markerRect : null
}

function createTokenElement(item: QuickGenerateMentionItem, orderNo?: number): HTMLElement {
  const span = document.createElement("span")
  span.setAttribute("data-mention", "1")
  span.setAttribute("contenteditable", "false")
  span.setAttribute("draggable", "false")
  span.setAttribute("data-token", item.token)
  span.setAttribute("data-kind", item.kind)
  if (item.previewUrl) span.setAttribute("data-preview-url", item.previewUrl)
  span.className = styles.token

  if (Number.isFinite(orderNo) && Number(orderNo) > 0) {
    span.setAttribute("data-order-no", String(Math.trunc(Number(orderNo))))
    const index = document.createElement("span")
    index.className = styles.tokenIndex
    index.textContent = String(Math.trunc(Number(orderNo)))
    span.appendChild(index)
  } else {
    span.removeAttribute("data-order-no")
  }

  const label = document.createElement("span")
  label.className = styles.tokenLabel
  label.textContent = item.label
  span.appendChild(label)
  return span
}

function findMentionTokenElement(target: EventTarget | null): HTMLElement | null {
  if (!(target instanceof HTMLElement)) return null
  return target.closest?.("[data-mention='1']") as HTMLElement | null
}

function insertPlainTextAtSelection(text: string): void {
  const selection = window.getSelection?.()
  if (!selection || selection.rangeCount <= 0) return

  const range = selection.getRangeAt(0)
  range.deleteContents()

  const fragment = document.createDocumentFragment()
  const lines = normalizeQuickGenerateEditorText(text).split("\n")
  for (let i = 0; i < lines.length; i += 1) {
    if (i > 0) fragment.appendChild(document.createElement("br"))
    if (lines[i]) fragment.appendChild(document.createTextNode(lines[i]))
  }

  const lastNode = fragment.lastChild
  range.insertNode(fragment)
  if (lastNode) moveCaretAfter(lastNode)
}

function serializeEditorToText(root: HTMLElement): string {
  const walk = (node: Node): string => {
    if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? ""
    if (node.nodeType !== Node.ELEMENT_NODE) return ""
    const el = node as HTMLElement
    if (el.tagName === "BR") return "\n"
    if (isTokenEl(el)) return toDisplayText(el.getAttribute("data-token") ?? "")
    let out = ""
    for (const child of Array.from(el.childNodes)) out += walk(child)
    return out
  }
  return Array.from(root.childNodes).map(walk).join("")
}

function appendClipboardPartsFromNode(node: Node, out: MentionClipboardPart[]): void {
  if (node.nodeType === Node.TEXT_NODE) {
    const value = node.textContent ?? ""
    if (value) out.push({ kind: "text", value })
    return
  }
  if (node.nodeType !== Node.ELEMENT_NODE) return

  const el = node as HTMLElement
  if (el.tagName === "BR") {
    out.push({ kind: "text", value: "\n" })
    return
  }
  if (isTokenEl(el)) {
    const token = String(el.getAttribute("data-token") ?? "").trim()
    if (!token) return
    const rawOrderNo = String(el.getAttribute("data-order-no") ?? "").trim()
    const orderNo = Number(rawOrderNo)
    out.push({
      kind: "token",
      token,
      ...(Number.isFinite(orderNo) && orderNo > 0 ? { orderNo: Math.trunc(orderNo) } : {})
    })
    return
  }
  for (const child of Array.from(el.childNodes)) appendClipboardPartsFromNode(child, out)
}

function serializeSelectionForClipboard(host: HTMLElement): MentionClipboardPayload | null {
  const selection = window.getSelection?.()
  if (!selection || selection.rangeCount <= 0 || selection.isCollapsed) return null
  const range = selection.getRangeAt(0)
  if (!rangeWithinHost(range, host)) return null

  const fragment = range.cloneContents()
  const parts: MentionClipboardPart[] = []
  for (const child of Array.from(fragment.childNodes)) appendClipboardPartsFromNode(child, parts)
  if (parts.length === 0) return null

  const text = parts.map((part) => (part.kind === "text" ? part.value : toDisplayText(part.token))).join("")
  return { parts, text }
}

function parseInternalClipboardPayload(raw: string): MentionClipboardPayload | null {
  if (!raw) return null
  try {
    const parsed = JSON.parse(raw) as MentionClipboardPayload
    if (!Array.isArray(parsed?.parts)) return null
    const parts: MentionClipboardPart[] = []
    for (const part of parsed.parts) {
      if (!part || typeof part !== "object") continue
      if (part.kind === "text") {
        parts.push({ kind: "text", value: String(part.value ?? "") })
        continue
      }
      if (part.kind === "token") {
        const token = String(part.token ?? "").trim()
        if (!token) continue
        const orderNo = Number((part as { orderNo?: number }).orderNo)
        parts.push({
          kind: "token",
          token,
          ...(Number.isFinite(orderNo) && orderNo > 0 ? { orderNo: Math.trunc(orderNo) } : {})
        })
      }
    }
    if (parts.length === 0) return null
    return {
      parts,
      text: String(parsed.text ?? parts.map((part) => (part.kind === "text" ? part.value : toDisplayText(part.token))).join(""))
    }
  } catch {
    return null
  }
}

function insertClipboardPayloadAtSelection(
  payload: MentionClipboardPayload,
  resolveItem: (token: string) => QuickGenerateMentionItem | null
): void {
  const selection = window.getSelection?.()
  if (!selection || selection.rangeCount <= 0) return

  const range = selection.getRangeAt(0)
  range.deleteContents()

  const fragment = document.createDocumentFragment()
  const appendText = (value: string) => {
    const lines = normalizeQuickGenerateEditorText(value).split("\n")
    for (let i = 0; i < lines.length; i += 1) {
      if (i > 0) fragment.appendChild(document.createElement("br"))
      if (lines[i]) fragment.appendChild(document.createTextNode(lines[i]))
    }
  }

  for (const part of payload.parts) {
    if (part.kind === "text") {
      appendText(part.value)
      continue
    }

    const resolved = resolveItem(part.token)
    if (resolved) {
      fragment.appendChild(createTokenElement(resolved, part.orderNo))
      continue
    }

    appendText(toDisplayText(part.token))
  }

  const lastNode = fragment.lastChild
  range.insertNode(fragment)
  if (lastNode) moveCaretAfter(lastNode)
}

/**
 * quick-generate 视频提示词中的自动音色说明不再插入正文内部，
 * 而是统一追加到提示词尾部，例如：
 * `@姜凡音色是@米在`
 */
function syncRoleVoiceMentionsToTail(input: {
  value: string
  mentionItems: QuickGenerateMentionItem[]
  roleVoiceMap: Record<string, string>
  mutedAutoAudioNames: string[]
  autoVoiceRoleNames: string[]
}): string {
  const muted = new Set(input.mutedAutoAudioNames.map((v) => String(v ?? "").trim()).filter(Boolean))
  const audioNameSet = new Set(input.mentionItems.filter((it) => it.kind === "audio").map((it) => it.name))
  const retainedRoleSet = new Set(input.autoVoiceRoleNames.map((v) => String(v ?? "").trim()).filter(Boolean))

  const normalized = normalizePlainMentionsToTokens(input.value, input.mentionItems)
  const parts = parseValueTokens(normalized)

  const pairs = parts
    .filter((part): part is { kind: "token"; token: string } => part.kind === "token")
    .map((part) => parseToken(part.token))
    .filter((parsed): parsed is NonNullable<ReturnType<typeof parseToken>> => Boolean(parsed && parsed.kind === "role"))
    .map((parsed) => {
      // 只要当前 prompt 里仍然 @ 着这个人物，就应该继续保留它绑定的自动音色；
      // speakerList 仅作为兼容旧数据的附加来源，不能把用户刚 @ 出来的音色再“同步丢掉”。
      retainedRoleSet.add(parsed.name)
      return {
        roleName: parsed.name,
        voiceName: String(input.roleVoiceMap[parsed.name] ?? "").trim()
      }
    })
    .filter((pair) => retainedRoleSet.has(pair.roleName) && pair.voiceName && !muted.has(pair.voiceName) && audioNameSet.has(pair.voiceName))

  return syncQuickGenerateVoiceTail({
    value: input.value,
    pairs
  })
}

function tryDeletePreviousToken(host: HTMLElement): boolean {
  const selection = window.getSelection?.()
  if (!selection || selection.rangeCount <= 0) return false
  const range = selection.getRangeAt(0)
  if (!range.collapsed) return false

  let node: Node | null = range.startContainer
  let offset = range.startOffset
  if (node.nodeType === Node.TEXT_NODE && offset > 0) return false

  if (node.nodeType === Node.TEXT_NODE) node = node.parentNode
  if (!node || !host.contains(node)) return false

  let prev: Node | null = null
  if (node === host) {
    prev = host.childNodes[offset - 1] ?? null
  } else {
    prev = node.previousSibling
    let current: Node | null = node
    while (!prev && current && current !== host) {
      prev = current.previousSibling
      current = current.parentNode
    }
  }

  if (!prev) return false
  if (prev.nodeType === Node.TEXT_NODE && (prev.textContent ?? "").trim() === "") {
    const beforePrev = prev.previousSibling
    prev.parentNode?.removeChild(prev)
    prev = beforePrev
  }
  if (!(prev instanceof HTMLElement) || !isTokenEl(prev)) return false
  prev.remove()
  return true
}

const KIND_ORDER: QuickGenerateMentionKind[] = ["role", "scene", "item", "audio", "video"]

export const QuickGenerateVideoPromptMentionEditor = memo(function QuickGenerateVideoPromptMentionEditor(props: {
  value: string
  onChange: (next: string) => void
  placeholder?: string
  allowedMentions: QuickGenerateAllowedMention[]
  maxLength?: number
  roleVoiceMap: Record<string, string>
  autoVoiceRoleNames?: string[]
  mutedAutoAudioNames?: string[]
  mentionOrderMap?: Record<string, number>
  loading?: boolean
  mode?: QuickGenerateMentionEditorMode
}): ReactElement {
  const editorRef = useRef<HTMLDivElement | null>(null)
  const popoverRef = useRef<HTMLDivElement | null>(null)
  const captureAnchorRef = useRef<HTMLElement | null>(null)
  const searchRef = useRef<HTMLInputElement | null>(null)
  const [focused, setFocused] = useState(false)
  const [composing, setComposing] = useState(false)
  const [capture, setCapture] = useState<MentionCapture>({ active: false, query: "", range: null, replaceRange: null })
  const [open, setOpen] = useState(false)
  const [activeIdx, setActiveIdx] = useState(0)
  const [pos, setPos] = useState({ top: 0, left: 0 })
  const [activeTab, setActiveTab] = useState<"all" | QuickGenerateMentionKind>("all")
  const {
    onChange,
    value,
    allowedMentions,
    maxLength,
    roleVoiceMap,
    autoVoiceRoleNames,
    mutedAutoAudioNames,
    mentionOrderMap,
    mode = "videoPrompt"
  } = props

  const mentionItems = useMemo(() => buildMentionItems(allowedMentions), [allowedMentions])
  const itemsByToken = useMemo(() => new Map(mentionItems.map((item) => [item.token, item])), [mentionItems])
  const normalizedValue = useMemo(
    () => normalizePlainMentionsToTokens(normalizeQuickGenerateEditorText(value), mentionItems),
    [mentionItems, value]
  )
  const filteredMentionItems = useMemo(() => {
    if (activeTab === "all") return mentionItems
    return mentionItems.filter((it) => it.kind === activeTab)
  }, [activeTab, mentionItems])

  const suggestions = useMemo(() => {
    const query = capture.active ? capture.query.trim() : ""
    const source = filteredMentionItems
    if (!query) return source.slice(0, 30)
    return source.filter((item) => fuzzyMatch(query, `${item.label} ${item.kind}`)).slice(0, 30)
  }, [capture.active, capture.query, filteredMentionItems])

  const groupedSuggestions = useMemo(() => {
    return KIND_ORDER.map((kind) => ({
      kind,
      items: suggestions
        .map((item, idx) => ({ item, idx }))
        .filter((entry) => entry.item.kind === kind)
    })).filter((group) => group.items.length > 0)
  }, [suggestions])

  const hasPlaceholder = useMemo(() => toDisplayText(normalizedValue).trim().length === 0, [normalizedValue])

  const promptLen = useMemo(() => {
    const raw = String(normalizedValue ?? "")
    if (!raw) return 0
    return parseValueTokens(raw).reduce((sum, part) => {
      if (part.kind === "text") return sum + countDisplayChars(part.value)
      const parsed = parseToken(part.token)
      return sum + countDisplayChars(parsed ? formatMentionDisplayLabel(parsed.name, parsed.kind) : part.token)
    }, 0)
  }, [normalizedValue])

  const overMaxLen = typeof maxLength === "number" && promptLen > maxLength
  const shouldSyncVoiceTail = mode === "videoPrompt"
  const shouldSyncFooter = mode === "videoPrompt"

  const removeCaptureAnchor = useCallback(() => {
    const anchor = captureAnchorRef.current
    if (!anchor) return
    try {
      anchor.remove()
    } catch {}
    captureAnchorRef.current = null
  }, [])

  const closeCapture = useCallback(() => {
    setOpen(false)
    setActiveIdx(0)
    setCapture({ active: false, query: "", range: null, replaceRange: null })
    removeCaptureAnchor()
  }, [removeCaptureAnchor])

  const recomputePopoverPosition = useCallback(() => {
    const anchor = captureAnchorRef.current
    if (anchor) {
      const rect = anchor.getBoundingClientRect()
      if (rect.width || rect.height) {
        setPos({ top: rect.bottom + 8, left: rect.left })
        return
      }
    }
    const range = capture.active && capture.range ? capture.range : getSelectionRange()
    if (!range) return
    const rect = computeCaretRect(range)
    if (!rect) return
    setPos({ top: rect.bottom + 8, left: rect.left })
  }, [capture.active, capture.range])

  const lastEmittedValueRef = useRef<string | null>(null)

  const applyChangeFromDom = useCallback(() => {
    const el = editorRef.current
    if (!el) return
    const raw = normalizeQuickGenerateEditorText(serializeEditorToText(el))
    const next = shouldSyncVoiceTail
      ? syncRoleVoiceMentionsToTail({
          value: raw,
          mentionItems,
          roleVoiceMap,
          mutedAutoAudioNames: mutedAutoAudioNames ?? [],
          autoVoiceRoleNames: autoVoiceRoleNames ?? []
        })
      : raw
    const emittedValue = shouldSyncFooter ? syncQuickGenerateVideoPromptFooter(next) : next

    const normalizedNext = normalizePlainMentionsToTokens(emittedValue, mentionItems)
    
    // 如果实际内容完全没变，就不要往外抛，避免触发无意义的 React state 更新周期
    // 这也是解决死循环和输入框诡异行为的关键一步
    if (normalizedNext === lastEmittedValueRef.current) {
      return
    }

    lastEmittedValueRef.current = normalizedNext
    onChange(emittedValue)
  }, [autoVoiceRoleNames, mentionItems, mutedAutoAudioNames, onChange, roleVoiceMap, shouldSyncFooter, shouldSyncVoiceTail])

  const renderFromValue = useCallback(
    (value: string) => {
      const el = editorRef.current
      if (!el) return
      el.innerHTML = ""

      const parts = parseValueTokens(value)
      for (const part of parts) {
        if (part.kind === "text") {
          const chunks = part.value.split("\n")
          for (let i = 0; i < chunks.length; i += 1) {
            if (i > 0) el.appendChild(document.createElement("br"))
            if (chunks[i]) el.appendChild(document.createTextNode(chunks[i]))
          }
          continue
        }

        const item = itemsByToken.get(part.token)
        const parsed = parseToken(part.token)
        const fallback: QuickGenerateMentionItem | null = parsed
          ? {
              kind: parsed.kind,
              name: parsed.name,
              token: part.token,
              label: formatMentionDisplayLabel(parsed.name, parsed.kind)
            }
          : null
        if (item ?? fallback) {
          const resolved = (item ?? fallback) as QuickGenerateMentionItem
          el.appendChild(createTokenElement(resolved, mentionOrderMap?.[resolved.token]))
        }
      }
    },
    [itemsByToken, mentionOrderMap]
  )

  const resolveMentionItem = useCallback((token: string): QuickGenerateMentionItem | null => {
    const item = itemsByToken.get(token)
    if (item) return item
    const parsed = parseToken(token)
    if (!parsed) return null
    return {
      kind: parsed.kind,
      name: parsed.name,
      token,
      label: formatMentionDisplayLabel(parsed.name, parsed.kind)
    }
  }, [itemsByToken])

  const selectItem = useCallback(
    (item: QuickGenerateMentionItem) => {
      const el = editorRef.current
      if (!el) return
      try {
        el.focus()
      } catch {}
      setFocused(true)

      const replaceRange = rangeWithinHost(capture.replaceRange, el) ? capture.replaceRange!.cloneRange() : null
      const baseRange = capture.range || getSelectionRange()
      const caretRange = rangeWithinHost(baseRange, el) ? baseRange : null
      const anchor = captureAnchorRef.current
      const resolvedRange = document.createRange()
      if (replaceRange) {
        resolvedRange.setStart(replaceRange.startContainer, replaceRange.startOffset)
        resolvedRange.setEnd(replaceRange.endContainer, replaceRange.endOffset)
      } else if (anchor && el.contains(anchor)) {
        resolvedRange.setStartBefore(anchor)
        resolvedRange.collapse(true)
      } else if (caretRange) {
        resolvedRange.setStart(caretRange.startContainer, caretRange.startOffset)
        resolvedRange.collapse(true)
      } else {
        moveCaretToEnd(el)
        const end = getSelectionRange()
        if (end && el.contains(end.startContainer)) {
          resolvedRange.setStart(end.startContainer, end.startOffset)
          resolvedRange.collapse(true)
        } else {
          resolvedRange.selectNodeContents(el)
          resolvedRange.collapse(false)
        }
      }

      const tokenEl = createTokenElement(item, mentionOrderMap?.[item.token])
      const finalSpace = document.createTextNode(" ")

      try {
        resolvedRange.deleteContents()
        // Insert in reverse order because insertNode() inserts before the range.
        resolvedRange.insertNode(finalSpace)
        resolvedRange.insertNode(tokenEl)
      } catch {
        el.appendChild(tokenEl)
        el.appendChild(finalSpace)
      }

      if (anchor) {
        try {
          anchor.remove()
        } catch {}
        captureAnchorRef.current = null
      }

      moveCaretAfter(finalSpace)
      closeCapture()
      if (item.kind === "role" && shouldSyncVoiceTail) {
        const raw = serializeEditorToText(el)
        const voiceName = String(roleVoiceMap[item.name] ?? "").trim()
        const audioNameSet = new Set(mentionItems.filter((it) => it.kind === "audio").map((it) => it.name))
        const muted = new Set((mutedAutoAudioNames ?? []).map((v) => String(v ?? "").trim()).filter(Boolean))
        if (voiceName && audioNameSet.has(voiceName) && !muted.has(voiceName)) {
          const next = syncQuickGenerateVoiceTail({
            value: raw,
            pairs: [{ roleName: item.name, voiceName }]
          })
          const emittedValue = shouldSyncFooter ? syncQuickGenerateVideoPromptFooter(next) : next
          const normalizedNext = normalizePlainMentionsToTokens(emittedValue, mentionItems)
          lastEmittedValueRef.current = normalizedNext
          onChange(emittedValue)
          return
        }
      }
      applyChangeFromDom()
    },
    [applyChangeFromDom, capture.range, capture.replaceRange, closeCapture, mentionItems, mentionOrderMap, mutedAutoAudioNames, onChange, roleVoiceMap, shouldSyncFooter, shouldSyncVoiceTail]
  )

  const startCapture = useCallback(() => {
    const el = editorRef.current
    if (el) {
      try {
        el.focus()
      } catch {}
      if (!getSelectionRange()) moveCaretToEnd(el)
    }

    removeCaptureAnchor()
    const base = getSelectionRange()?.cloneRange() ?? null
    const hasReplaceSelection = Boolean(base && el && rangeWithinHost(base, el) && !base.collapsed)
    if (base && el && rangeWithinHost(base, el) && base.collapsed) {
      const anchor = document.createElement("span")
      anchor.setAttribute("data-mention-anchor", "1")
      anchor.textContent = "\u200b"
      try {
        base.insertNode(anchor)
        captureAnchorRef.current = anchor
        moveCaretAfter(anchor)
      } catch {
        try {
          anchor.remove()
        } catch {}
      }
    }

    const range = getSelectionRange()?.cloneRange() ?? base
    setCapture({
      active: true,
      query: "",
      range,
      replaceRange: hasReplaceSelection ? base : null
    })
    setOpen(true)
    setActiveIdx(0)
    setActiveTab("all")
    requestAnimationFrame(recomputePopoverPosition)
    window.setTimeout(() => {
      searchRef.current?.focus()
      searchRef.current?.select()
    }, 0)
  }, [recomputePopoverPosition, removeCaptureAnchor])

  // ============================================================================
  // Re-render editor on value change
  // ============================================================================
  // We re-render the DOM from the `value` prop whenever the user stops typing
  // (not focused) or when the value changes externally.
  // Important: initialize to empty so the first non-empty `value` on mount also triggers render.
  // Otherwise, when `prevValueRef` starts with `normalizedValue`, the effect bails out and the
  // contentEditable remains empty until the next value change (exactly the user's bug).
  const prevValueRef = useRef<string>("")
  
  useEffect(() => {
    if (!editorRef.current) return
    if (capture.active) return
    
    // 如果外部传入的值和我们上一次记录的值一样，说明不用更新DOM
    if (prevValueRef.current === normalizedValue) return
    prevValueRef.current = normalizedValue

    // 如果当前正在输入且值确实是由我们抛出的，我们就不刷新 DOM 防止光标跳动。
    // 但是！只要是外部注入的新值（即和上次发出的不同），我们必须强制刷新！
    // 即使目前焦点在这个输入框里，也要强刷。
    if (focused && lastEmittedValueRef.current === normalizedValue) {
      return
    }

    // AI 刚刚生成完提示词等任何真正来自外部的数据变更，走到这里进行 DOM 更新
    renderFromValue(normalizedValue)
    
    // 更新后，将内部记录的发出值也同步对齐，防止下一次手打时发生冲突
    lastEmittedValueRef.current = normalizedValue
  }, [capture.active, focused, hasPlaceholder, itemsByToken, normalizedValue, props.loading, props.value, renderFromValue])

  useEffect(() => {
    if (!open) return
    recomputePopoverPosition()
    const onScroll = () => recomputePopoverPosition()
    window.addEventListener("scroll", onScroll, true)
    window.addEventListener("resize", onScroll)
    return () => {
      window.removeEventListener("scroll", onScroll, true)
      window.removeEventListener("resize", onScroll)
    }
  }, [open, recomputePopoverPosition])

  return (
    <div className={styles.wrap}>
      <div
        ref={editorRef}
        className={styles.editor}
        contentEditable
        role="textbox"
        aria-multiline="true"
        data-focused={focused ? "true" : "false"}
        data-loading={props.loading ? "true" : "false"}
        data-placeholder={hasPlaceholder && !props.loading ? "true" : "false"}
        data-placeholder-text={props.placeholder ?? "输入提示词，输入 @ 可插入人物/场景/物品/视频参考"}
        onFocus={() => {
          setFocused(true)
        }}
        onMouseDown={(e) => {
          const el = editorRef.current
          if (!el) return
          const tokenEl = findMentionTokenElement(e.target)
          if (tokenEl && el.contains(tokenEl)) {
            e.preventDefault()
            try {
              el.focus()
            } catch {}
            setFocused(true)
            moveCaretAfter(tokenEl)
            return
          }

          window.setTimeout(() => {
            const selection = getSelectionRange()
            if (selection && rangeWithinHost(selection, el)) return
            try {
              el.focus()
            } catch {}
            moveCaretToEnd(el)
          }, 0)
        }}
        onBlur={() => {
          setFocused(false)
          window.setTimeout(() => {
            const active = document.activeElement
            if (popoverRef.current && active && popoverRef.current.contains(active)) return
            closeCapture()
            
            applyChangeFromDom()
          }, 0)
        }}
        onCompositionStart={() => {
          setComposing(true)
          if (capture.active) closeCapture()
        }}
        onCompositionEnd={() => setComposing(false)}
        onBeforeInput={(e) => {
          const nativeEvent = (e as unknown as { nativeEvent: InputEvent }).nativeEvent
          if (!nativeEvent) return
          if (composing) return

          if (!capture.active) {
            if (nativeEvent.inputType === "insertText" && nativeEvent.data === "@") {
              nativeEvent.preventDefault()
              startCapture()
            }
            return
          }

          if (nativeEvent.inputType === "insertText") {
            nativeEvent.preventDefault()
            const next = nativeEvent.data || ""
            if (next.length === 1 && !/\s/u.test(next) && next !== "@") {
              setCapture((state) => ({ ...state, query: state.query + next }))
            }
            return
          }

          if (nativeEvent.inputType === "deleteContentBackward") {
            nativeEvent.preventDefault()
            setCapture((state) => {
              if (!state.query) {
                closeCapture()
                return state
              }
              return { ...state, query: state.query.slice(0, -1) }
            })
          }
        }}
        onKeyDown={(e) => {
          if ((e.metaKey || e.ctrlKey) && !e.altKey && !e.shiftKey && (e.key === "a" || e.key === "A")) {
            e.preventDefault()
            const el = editorRef.current
            if (!el) return
            try {
              el.focus()
              const selection = window.getSelection()
              if (!selection) return
              const range = document.createRange()
              range.selectNodeContents(el)
              selection.removeAllRanges()
              selection.addRange(range)
            } catch {}
            return
          }

          if (!capture.active && e.key === "@") {
            e.preventDefault()
            startCapture()
            return
          }

          if (capture.active) {
            if (e.key === "Escape") {
              e.preventDefault()
              closeCapture()
              return
            }
            if (e.key === "ArrowDown") {
              e.preventDefault()
              setActiveIdx((index) => (index + 1) % Math.max(1, suggestions.length))
              return
            }
            if (e.key === "ArrowUp") {
              e.preventDefault()
              setActiveIdx((index) => (index - 1 + Math.max(1, suggestions.length)) % Math.max(1, suggestions.length))
              return
            }
            if (e.key === "Enter") {
              e.preventDefault()
              const item = suggestions[activeIdx]
              if (item) selectItem(item)
              return
            }
            return
          }

          if (e.key === "Backspace") {
            const el = editorRef.current
            if (!el) return
            if (tryDeletePreviousToken(el)) {
              e.preventDefault()
              applyChangeFromDom()
            }
          }
        }}
        onInput={() => {
          if (capture.active) return
          applyChangeFromDom()
        }}
        onCopy={(e) => {
          const el = editorRef.current
          if (!el) return
          const payload = serializeSelectionForClipboard(el)
          if (!payload) return
          e.preventDefault()
          e.clipboardData.setData("text/plain", payload.text)
          e.clipboardData.setData(INTERNAL_MENTION_CLIPBOARD_MIME, JSON.stringify(payload))
        }}
        onPaste={(e) => {
          e.preventDefault()
          closeCapture()
          const internalPayload = parseInternalClipboardPayload(
            e.clipboardData.getData(INTERNAL_MENTION_CLIPBOARD_MIME)
          )
          if (internalPayload) {
            insertClipboardPayloadAtSelection(internalPayload, resolveMentionItem)
            applyChangeFromDom()
            return
          }
          insertPlainTextAtSelection(e.clipboardData.getData("text/plain"))
          applyChangeFromDom()
        }}
        onDragStart={(e) => {
          e.preventDefault()
        }}
      />
      {props.loading && (
        <div className={styles.spinnerOverlay}>
          <div className={styles.spinner} />
          <div className={styles.spinnerText}>生成中...</div>
        </div>
      )}
      {typeof props.maxLength === "number" ? (
        <div className={styles.counter} data-over={overMaxLen ? "true" : "false"}>
          {promptLen}/{props.maxLength}
        </div>
      ) : null}

      {open
        ? createPortal(
            <div
              ref={popoverRef}
              className={styles.popover}
              style={{ top: pos.top, left: pos.left }}
              onPointerDown={(e) => e.stopPropagation()}
              onMouseDown={(e) => e.stopPropagation()}
            >
              <div className={styles.popoverHeader}>选择要插入的引用素材</div>
              <div className={styles.popoverControls}>
                <div className={styles.tabs} role="tablist" aria-label="素材分类">
                  <button
                    type="button"
                    className={styles.tab}
                    data-active={activeTab === "all" ? "true" : "false"}
                    onClick={() => {
                      setActiveTab("all")
                      setActiveIdx(0)
                    }}
                  >
                    全部
                  </button>
                  <button
                    type="button"
                    className={styles.tab}
                    data-active={activeTab === "role" ? "true" : "false"}
                    onClick={() => {
                      setActiveTab("role")
                      setActiveIdx(0)
                    }}
                  >
                    人物
                  </button>
                  <button
                    type="button"
                    className={styles.tab}
                    data-active={activeTab === "scene" ? "true" : "false"}
                    onClick={() => {
                      setActiveTab("scene")
                      setActiveIdx(0)
                    }}
                  >
                    背景
                  </button>
                  <button
                    type="button"
                    className={styles.tab}
                    data-active={activeTab === "item" ? "true" : "false"}
                    onClick={() => {
                      setActiveTab("item")
                      setActiveIdx(0)
                    }}
                  >
                    物品
                  </button>
                  <button
                    type="button"
                    className={styles.tab}
                    data-active={activeTab === "audio" ? "true" : "false"}
                    onClick={() => {
                      setActiveTab("audio")
                      setActiveIdx(0)
                    }}
                  >
                    音频
                  </button>
                  <button
                    type="button"
                    className={styles.tab}
                    data-active={activeTab === "video" ? "true" : "false"}
                    onClick={() => {
                      setActiveTab("video")
                      setActiveIdx(0)
                    }}
                  >
                    视频
                  </button>
                </div>
                <input
                  ref={searchRef}
                  className={styles.search}
                  placeholder="搜索素材..."
                  value={capture.query}
                  onChange={(e) => setCapture((s) => ({ ...s, query: e.target.value }))}
                  onFocus={(e) => e.stopPropagation()}
                  onMouseDown={(e) => e.stopPropagation()}
                  onKeyDown={(e) => {
                    e.stopPropagation()
                    if (e.key === "Escape") {
                      e.preventDefault()
                      closeCapture()
                      return
                    }
                    if (e.key === "ArrowDown") {
                      e.preventDefault()
                      setActiveIdx((index) => (index + 1) % Math.max(1, suggestions.length))
                      return
                    }
                    if (e.key === "ArrowUp") {
                      e.preventDefault()
                      setActiveIdx((index) => (index - 1 + Math.max(1, suggestions.length)) % Math.max(1, suggestions.length))
                      return
                    }
                    if (e.key === "Enter") {
                      e.preventDefault()
                      const item = suggestions[activeIdx]
                      if (item) selectItem(item)
                    }
                  }}
                />
              </div>
              <div className={styles.list}>
                {groupedSuggestions.length > 0 ? (
                  activeTab === "all" ? (
                    groupedSuggestions.map((group) => (
                      <div key={group.kind}>
                        <div className={styles.groupHeader} data-kind={group.kind}>
                          {group.kind === "role"
                            ? "人物"
                            : group.kind === "scene"
                              ? "背景"
                              : group.kind === "item"
                                ? "物品"
                                : group.kind === "audio"
                                  ? "音频"
                                  : "视频"}
                        </div>
                        {group.items.map(({ item, idx }) => (
                          <div
                            key={item.token}
                            className={styles.item}
                            data-active={idx === activeIdx ? "true" : "false"}
                            onMouseEnter={() => setActiveIdx(idx)}
                            onPointerDown={(event) => {
                              event.preventDefault()
                              selectItem(item)
                            }}
                            onClick={(event) => {
                              event.preventDefault()
                              selectItem(item)
                            }}
                          >
                            <div className={styles.itemBody}>
                              {item.previewUrl ? <img className={styles.thumb} src={item.previewUrl} alt={item.label} /> : null}
                              <div className={styles.itemText}>
                                <div className={styles.itemTitle}>{item.label}</div>
                                <div className={styles.itemSub}>
                                  {group.kind === "role"
                                    ? "人物"
                                    : group.kind === "scene"
                                      ? "背景"
                                      : group.kind === "item"
                                        ? "物品"
                                        : group.kind === "audio"
                                          ? "音频"
                                          : "视频"}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ))
                  ) : (
                    suggestions.map((item, idx) => (
                      <div
                        key={item.token}
                        className={styles.item}
                        data-active={idx === activeIdx ? "true" : "false"}
                        onMouseEnter={() => setActiveIdx(idx)}
                        onPointerDown={(event) => {
                          event.preventDefault()
                          selectItem(item)
                        }}
                        onClick={(event) => {
                          event.preventDefault()
                          selectItem(item)
                        }}
                      >
                        <div className={styles.itemBody}>
                          {item.previewUrl ? <img className={styles.thumb} src={item.previewUrl} alt={item.label} /> : null}
                          <div className={styles.itemText}>
                            <div className={styles.itemTitle}>{item.label}</div>
                            <div className={styles.itemSub}>
                              {item.kind === "role"
                                ? "人物"
                                : item.kind === "scene"
                                  ? "背景"
                                  : item.kind === "item"
                                    ? "物品"
                                    : item.kind === "audio"
                                      ? "音频"
                                      : "视频"}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )
                ) : (
                  <div className={styles.empty}>
                    {capture.query ? `未找到与“${capture.query}”匹配的素材` : "未找到可插入的素材"}
                  </div>
                )}
              </div>
            </div>,
            document.body
          )
        : null}
    </div>
  )
})

export default QuickGenerateVideoPromptMentionEditor
