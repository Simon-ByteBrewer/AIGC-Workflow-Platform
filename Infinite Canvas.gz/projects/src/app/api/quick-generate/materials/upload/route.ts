import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { uploadPublicFile } from "@/shared/storage"
import { quickGenerateProjects, quickGenerateMaterials } from "@/shared/schema"
import { assertQuickGenerateMaterialTitleAvailable } from "@/server/domains/quick-generate/materialTitleUniqueness"
import { eq } from "drizzle-orm"

const uploadSchema = z.object({
  storyId: z.string().trim().min(1),
  materialType: z.enum(["all", "scene", "character", "prop", "video", "audio"]),
})

/**
 * 统一 quick-generate 上传素材的默认标题：
 * 去掉最后一个扩展名，但保留诸如 `.env` 这类点开头文件名。
 */
function getMaterialTitleFromFileName(fileName: string): string {
  const normalized = fileName.trim()
  if (!normalized) return "未命名素材"
  if (normalized.startsWith(".") && normalized.indexOf(".", 1) === -1) return normalized

  const nextTitle = normalized.replace(/\.[^/.]+$/, "").trim()
  return nextTitle || normalized
}

export async function POST(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  try {
    const session = await getSessionFromRequest(req)
    if (!session?.userId) {
      return NextResponse.json(makeApiErr(traceId, "UNAUTHORIZED", "未登录"), { status: 401 })
    }

    const formData = await req.formData()
    const file = formData.get("file") as File | null
    if (!file) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "文件为空"), { status: 400 })
    }

    const body = {
      storyId: formData.get("storyId") as string,
      materialType: formData.get("materialType") as string,
    }

    const parsed = uploadSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "INVALID_PARAMS", "参数错误: " + parsed.error.message), { status: 400 })
    }

    const { storyId, materialType } = parsed.data
    const db = await getDb({ quickGenerateProjects, quickGenerateMaterials })

    // 找到对应的 project 记录
    const projects = await db
      .select({ id: quickGenerateProjects.id })
      .from(quickGenerateProjects)
      .where(eq(quickGenerateProjects.storyId, storyId))
      .limit(1)

    const project = projects[0]
    if (!project) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到对应的快速生成项目"), { status: 404 })
    }

    const title = getMaterialTitleFromFileName(file.name)
    await assertQuickGenerateMaterialTitleAvailable({
      db,
      storyId,
      materialType,
      title,
      action: "新增"
    })

    // 上传到对象存储，永久有效
    const { url, key } = await uploadPublicFile(file, `quick-generate/${storyId}/${materialType}`)

    // 插入记录，默认标题使用去掉扩展名后的文件名。
    const newMaterial = {
      projectId: project.id,
      storyId,
      materialType,
      title,
      sourceUrl: url,
      storageKey: key,
      status: "ready",
    }

    const inserted = await db.insert(quickGenerateMaterials).values(newMaterial).returning()

    return NextResponse.json(makeApiOk(traceId, inserted[0]))
  } catch (error: any) {
    const status = Number.isInteger(error?.status) ? Number(error.status) : 500
    const code = String(error?.code ?? "").trim() || "INTERNAL_ERROR"
    return NextResponse.json(makeApiErr(traceId, code, error.message || "上传失败"), { status })
  }
}
