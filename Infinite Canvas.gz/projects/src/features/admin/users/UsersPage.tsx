"use client"

import Link from "next/link"
import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactElement } from "react"
import styles from "./UsersPage.module.css"

type ApiOk<T> = { ok: true; data: T; traceId: string }
type ApiErr = { ok: false; error: { code: string; message: string }; traceId: string }

type ModelAccessSummary = {
  apiKeyConfigured: boolean
  video: { enabledModels: string[]; disabledModels: string[] }
  language: { enabledModels: string[]; disabledModels: string[] }
  image: { enabledModels: string[]; disabledModels: string[] }
}

type UserListItem = {
  id: string
  account: string
  email: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string | null
  roleKey: string
  lastLoginAt: string | null
  groupId: string | null
  groupName: string | null
  modelAccessSummary: ModelAccessSummary
}

type GroupedUserList = {
  key: string
  groupId: string | null
  groupName: string
  isActiveGroup: boolean
  total: number
  activeCount: number
  items: UserListItem[]
}

type ListResult = ApiOk<{ groups: GroupedUserList[]; totalUsers: number; actor?: { roleKey: string; groupId: string | null } }> | ApiErr
type CreateResult = ApiOk<{ user: { id: string; account: string } }> | ApiErr
type GroupsResult = ApiOk<{ items: Array<{ id: string; name: string; code: string | null; isActive: boolean }> }> | ApiErr

function fmtTime(v: string | null): string {
  if (!v) return "-"
  const d = new Date(v)
  if (!Number.isFinite(d.getTime())) return v
  return d.toLocaleString()
}

function summarizeModels(v: { enabledModels: string[]; disabledModels: string[] }): string {
  const enabled = v.enabledModels.length
  const disabled = v.disabledModels.length
  if (enabled === 0 && disabled === 0) return "0"
  if (disabled === 0) return String(enabled)
  return `${enabled}/${disabled}`
}

function buildTooltip(summary: ModelAccessSummary): string {
  const lines: string[] = []
  lines.push(summary.apiKeyConfigured ? "API Key: 已配置" : "API Key: 未配置")

  const pushModels = (label: string, v: { enabledModels: string[]; disabledModels: string[] }) => {
    const enabled = v.enabledModels.length ? `启用: ${v.enabledModels.join(", ")}` : "启用: -"
    const disabled = v.disabledModels.length ? `禁用: ${v.disabledModels.join(", ")}` : "禁用: -"
    lines.push(`${label} ${enabled}`)
    lines.push(`${label} ${disabled}`)
  }

  pushModels("视频:", summary.video)
  pushModels("文本:", summary.language)
  pushModels("图片:", summary.image)
  return lines.join("\n")
}

export function UsersPage(): ReactElement {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [groups, setGroups] = useState<GroupedUserList[]>([])
  const [totalUsers, setTotalUsers] = useState(0)
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({})

  const [q, setQ] = useState("")
  const [status, setStatus] = useState<"" | "active" | "inactive">("")
  const [role, setRole] = useState("")
  const [sort, setSort] = useState<"createdAt" | "lastLoginAt">("createdAt")

  const [createOpen, setCreateOpen] = useState(false)
  const [creating, setCreating] = useState(false)
  const [createAccount, setCreateAccount] = useState("")
  const [createEmail, setCreateEmail] = useState("")
  const [createPassword, setCreatePassword] = useState("")
  const [createRoleKey, setCreateRoleKey] = useState<"user" | "admin" | "group_admin">("user")
  const [createGroupId, setCreateGroupId] = useState("")
  const [meRole, setMeRole] = useState<string>("user")
  const [groupItems, setGroupItems] = useState<Array<{ id: string; name: string; code: string | null; isActive: boolean }>>([])
  const [loadingGroups, setLoadingGroups] = useState(false)
  const hasActiveFilters = useMemo(() => Boolean(q.trim() || status || role.trim()), [q, role, status])
  const prevHasActiveFiltersRef = useRef(hasActiveFilters)

  const queryString = useMemo(() => {
    const sp = new URLSearchParams()
    if (q.trim()) sp.set("q", q.trim())
    if (status) sp.set("status", status)
    if (role.trim()) sp.set("role", role.trim())
    sp.set("sort", sort)
    sp.set("order", "desc")
    return sp.toString()
  }, [q, role, sort, status])

  const visibleItems = useMemo(() => groups.flatMap((group) => group.items), [groups])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/users/grouped?${queryString}`, { method: "GET" })
      const json = (await res.json()) as ListResult
      if (!json.ok) throw new Error(json.error.message)
      setGroups(json.data.groups ?? [])
      setTotalUsers(json.data.totalUsers ?? 0)
      if (json.data.actor?.roleKey) setMeRole(json.data.actor.roleKey)
      setSelected((prev) => {
        const next = new Set<string>()
        for (const id of prev) {
          if ((json.data.groups ?? []).some((group) => group.items.some((u) => u.id === id))) next.add(id)
        }
        return next
      })
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载失败")
    } finally {
      setLoading(false)
    }
  }, [queryString])

  useEffect(() => {
    void (async () => {
      try {
        const res = await fetch("/api/auth/me?refresh=0")
        const json = (await res.json()) as ApiOk<{ user: { role: string } }> | ApiErr
        if (json.ok) setMeRole(json.data.user.role ?? "user")
      } catch {}
    })()
  }, [])

  const loadGroups = useCallback(async () => {
    setLoadingGroups(true)
    try {
      const res = await fetch("/api/admin/groups", { method: "GET" })
      const json = (await res.json()) as GroupsResult
      if (!json.ok) return
      setGroupItems((json.data.items ?? []).filter((g) => g.isActive))
    } catch {
    } finally {
      setLoadingGroups(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  useEffect(() => {
    if (!createOpen) return
    if (meRole !== "admin") return
    if (createRoleKey !== "user" && createRoleKey !== "group_admin") return
    if (groupItems.length > 0) return
    void loadGroups()
  }, [createOpen, createRoleKey, groupItems.length, loadGroups, meRole])

  useEffect(() => {
    setCollapsedGroups((prev) => {
      const modeChanged = prevHasActiveFiltersRef.current !== hasActiveFilters
      const next: Record<string, boolean> = {}
      for (const group of groups) {
        const key = group.key
        if (key in next) continue
        if (hasActiveFilters) {
          next[key] = modeChanged ? false : (prev[key] ?? false)
        } else {
          next[key] = modeChanged ? true : (prev[key] ?? true)
        }
      }
      return next
    })
    prevHasActiveFiltersRef.current = hasActiveFilters
  }, [groups, hasActiveFilters])

  const allVisibleSelected = useMemo(() => visibleItems.length > 0 && visibleItems.every((u) => selected.has(u.id)), [selected, visibleItems])

  const toggleAllVisible = useCallback(() => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (visibleItems.length === 0) return next
      if (visibleItems.every((u) => next.has(u.id))) {
        for (const u of visibleItems) next.delete(u.id)
      } else {
        for (const u of visibleItems) next.add(u.id)
      }
      return next
    })
  }, [visibleItems])

  const toggleOne = useCallback((id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  const toggleGroup = useCallback((key: string) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [key]: !(prev[key] ?? true)
    }))
  }, [])

  const onCreate = useCallback(
    async (e: FormEvent) => {
      e.preventDefault()
      if (creating) return
      setCreating(true)
      setError(null)
      try {
        if (meRole === "admin" && (createRoleKey === "user" || createRoleKey === "group_admin") && !createGroupId.trim()) {
          throw new Error("创建组管理员/员工必须选择用户组")
        }
        const res = await fetch("/api/admin/users", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            account: createAccount.trim(),
            email: createEmail.trim() || undefined,
            password: createPassword,
            roleKey: createRoleKey,
            groupId: meRole === "admin" ? (createGroupId.trim() || undefined) : undefined
          })
        })
        const json = (await res.json()) as CreateResult
        if (!json.ok) throw new Error(json.error.message)
        setCreateOpen(false)
        setCreateAccount("")
        setCreateEmail("")
        setCreatePassword("")
        setCreateRoleKey("user")
        setCreateGroupId("")
        await load()
      } catch (e2) {
        const anyErr = e2 as { message?: string }
        setError(anyErr?.message ?? "创建失败")
      } finally {
        setCreating(false)
      }
    },
    [createAccount, createEmail, createGroupId, createPassword, createRoleKey, creating, load, meRole]
  )

  const openCreateModal = useCallback(() => {
    setCreateAccount("")
    setCreateEmail("")
    setCreatePassword("")
    setCreateRoleKey("user")
    setCreateGroupId("")
    setCreateOpen(true)
  }, [])

  const closeCreateModal = useCallback(() => {
    setCreateOpen(false)
  }, [])

  return (
    <main className={styles.page}>
      <div className={styles.topBar}>
        <div className={styles.topLeft}>
          <div className={styles.topTitle}>账号管理</div>
          <div className={styles.topMeta}>{loading ? "加载中…" : `${groups.length} 个组，${totalUsers} 个账号`}</div>
        </div>
        <div className={styles.topActions}>
          <button type="button" className={styles.topBtn} onClick={() => void load()} disabled={loading || creating}>
            刷新
          </button>
          <button type="button" className={styles.topBtnPrimary} onClick={openCreateModal} disabled={loading || creating}>
            新建账号
          </button>
        </div>
      </div>

      {error ? <div className={styles.error}>{error}</div> : null}

      <section className={styles.panel} aria-label="筛选">
        <div className={styles.filters}>
          <input className={styles.input} value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索账号 / 邮箱 / ID" />
          <select className={styles.select} value={status} onChange={(e) => setStatus(e.target.value as any)} aria-label="状态筛选">
            <option value="">全部状态</option>
            <option value="active">启用</option>
            <option value="inactive">禁用</option>
          </select>
          <input className={styles.input} value={role} onChange={(e) => setRole(e.target.value)} placeholder="角色（roleKey）" />
          <select className={styles.select} value={sort} onChange={(e) => setSort(e.target.value as any)} aria-label="排序">
            <option value="createdAt">按创建时间</option>
            <option value="lastLoginAt">按最近登录</option>
          </select>
          <button type="button" className={styles.topBtn} onClick={() => void load()} disabled={loading}>
            查询
          </button>
        </div>
      </section>

      <section className={styles.panel} aria-label="账号列表">
        <div className={styles.table}>
          <div className={`${styles.tr} ${styles.th}`}>
            <div className={styles.checkCell}>
              <input type="checkbox" checked={allVisibleSelected} onChange={toggleAllVisible} aria-label="全选当前页" />
            </div>
            <div>账号</div>
            <div>邮箱</div>
            <div>状态</div>
            <div>角色</div>
            <div>所属组</div>
            <div>模型配置</div>
            <div>最近登录</div>
            <div>创建时间</div>
          </div>
          {groups.map((group) => {
            const collapsed = collapsedGroups[group.key] ?? true

            return (
              <div key={group.key} className={styles.groupSection}>
                <button
                  type="button"
                  className={styles.groupHeader}
                  onClick={() => toggleGroup(group.key)}
                  aria-expanded={!collapsed}
                  aria-controls={`group-panel-${group.key}`}
                >
                  <div className={styles.groupHeaderLeft}>
                    <span className={styles.groupChevron}>{collapsed ? "▸" : "▾"}</span>
                    <span className={styles.groupName}>{group.groupName}</span>
                    {!group.isActiveGroup ? <span className={styles.groupStateTag}>已停用</span> : null}
                  </div>
                  <div className={styles.groupMeta}>
                    <span>{group.total} 个账号</span>
                    <span>启用 {group.activeCount}</span>
                  </div>
                </button>
                {!collapsed ? (
                  <div id={`group-panel-${group.key}`} className={styles.groupBody}>
                    {group.items.map((u) => (
                      <Link key={u.id} className={`${styles.tr} ${styles.row}`} href={`/admin/users/${encodeURIComponent(u.id)}`}>
                        <div className={styles.checkCell} onClick={(e) => e.preventDefault()} onMouseDown={(e) => e.preventDefault()}>
                          <input
                            type="checkbox"
                            checked={selected.has(u.id)}
                            onClick={(e) => {
                              e.preventDefault()
                              e.stopPropagation()
                            }}
                            onChange={() => toggleOne(u.id)}
                            aria-label={`选择账号 ${u.account}`}
                          />
                        </div>
                        <div className={styles.mono}>{u.account}</div>
                        <div className={styles.muted}>{u.email ?? "-"}</div>
                        <div className={u.isActive ? styles.ok : styles.bad}>{u.isActive ? "启用" : "禁用"}</div>
                        <div className={styles.mono}>{u.roleKey}</div>
                        <div className={styles.muted}>{u.groupName ?? (u.groupId ? u.groupId : "-")}</div>
                        <div className={styles.tag} title={buildTooltip(u.modelAccessSummary)}>
                          {u.modelAccessSummary.apiKeyConfigured ? "Key✓" : "Key-"} · V:{summarizeModels(u.modelAccessSummary.video)} · T:{summarizeModels(u.modelAccessSummary.language)} · I:
                          {summarizeModels(u.modelAccessSummary.image)}
                        </div>
                        <div className={styles.muted}>{fmtTime(u.lastLoginAt)}</div>
                        <div className={styles.muted}>{fmtTime(u.createdAt)}</div>
                      </Link>
                    ))}
                  </div>
                ) : null}
              </div>
            )
          })}
          {groups.length === 0 && !loading ? <div className={styles.empty}>暂无可见用户组</div> : null}
        </div>
      </section>

      {createOpen ? (
        <div
          className={styles.overlay}
          role="dialog"
          aria-modal="true"
          aria-label="新建账号"
          onMouseDown={closeCreateModal}
        >
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>新建账号</div>
              <button type="button" className={styles.modalClose} onClick={closeCreateModal} aria-label="关闭">
                ×
              </button>
            </div>
            <form className={styles.modalBody} onSubmit={onCreate}>
              <label className={styles.field}>
                <div className={styles.label}>账号</div>
                <input className={styles.input} value={createAccount} onChange={(e) => setCreateAccount(e.target.value)} required />
              </label>
              <label className={styles.field}>
                <div className={styles.label}>邮箱（可选）</div>
                <input className={styles.input} value={createEmail} onChange={(e) => setCreateEmail(e.target.value)} />
              </label>
              <label className={styles.field}>
                <div className={styles.label}>初始密码</div>
                <input className={styles.input} value={createPassword} onChange={(e) => setCreatePassword(e.target.value)} type="password" required />
              </label>
              <label className={styles.field}>
                <div className={styles.label}>角色（roleKey）</div>
                <select className={styles.select} value={createRoleKey} onChange={(e) => setCreateRoleKey(e.target.value as any)}>
                  {meRole === "admin" ? (
                    <>
                      <option value="user">user（组员）</option>
                      <option value="group_admin">group_admin（组管理员）</option>
                      <option value="admin">admin（超级管理员）</option>
                    </>
                  ) : (
                    <option value="user">user（组员）</option>
                  )}
                </select>
              </label>

              {meRole === "admin" && (createRoleKey === "user" || createRoleKey === "group_admin") ? (
                <label className={styles.field}>
                  <div className={styles.label}>用户组</div>
                  <select className={styles.select} value={createGroupId} onChange={(e) => setCreateGroupId(e.target.value)} disabled={loadingGroups}>
                    <option value="">{loadingGroups ? "加载中..." : "请选择用户组"}</option>
                    {groupItems.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.name}
                        {g.code ? ` (${g.code})` : ""}
                      </option>
                    ))}
                  </select>
                </label>
              ) : null}
              <div className={styles.modalActions}>
                <button type="button" className={styles.topBtn} onClick={closeCreateModal} disabled={creating}>
                  取消
                </button>
                <button type="submit" className={styles.topBtnPrimary} disabled={creating}>
                  {creating ? "创建中…" : "创建"}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </main>
  )
}
