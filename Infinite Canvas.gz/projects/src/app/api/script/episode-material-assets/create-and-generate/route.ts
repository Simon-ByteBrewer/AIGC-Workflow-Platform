import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { episodeMaterialAssets, episodeMaterialImages } from "@/shared/schema/generation"
import { stories } from "@/shared/schema/story"
import { enqueueEpisodeMaterialAssetRegenerateJob, kickEpisodeMaterialWorker } from "@/server/domains/storyboard/jobs/episodeMaterialWorker"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  kind: z.enum(["scene", "role", "item"]),
  name: z.string().trim().min(1).max(200),
  prompt: z.string().trim().min(1).max(20_000),
  cameraOne: z.string().trim().max(2000).optional(),
  cameraTwo: z.string().trim().max(2000).optional(),
  roleName: z.string().trim().max(200).optional(),
  characterId: z.string().trim().max(200).optional(),
  makeupName: z.string().trim().max(200).optional(),
  costumeName: z.string().trim().max(200).optional()
})

export const runtime = "nodejs"

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialImages, episodeMaterialAssets })

  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const latest = await db
    .select({ id: episodeMaterialImages.id })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.storyId, parsed.data.storyId))
    .orderBy(desc(episodeMaterialImages.createdAt))
    .limit(1)

  const materialId = latest[0]?.id ?? ""
  if (!materialId) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "暂无图片素材批次，请先生成一次图片素材"), { status: 404 })

  const kind = parsed.data.kind
  const isRole = kind === "role"
  const roleName = isRole ? (parsed.data.roleName ?? parsed.data.name).trim() : null
  const characterId = isRole ? (parsed.data.characterId ?? "").trim() || null : null
  const makeupName = isRole ? (parsed.data.makeupName ?? "").trim() || null : null
  const costumeName = isRole ? (parsed.data.costumeName ?? "").trim() || null : null
  const cameraOne = kind === "scene" ? (parsed.data.cameraOne ?? "").trim() : ""
  const cameraTwo = kind === "scene" ? (parsed.data.cameraTwo ?? "").trim() : ""
  if (kind === "scene" && (!cameraOne || !cameraTwo)) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "场景需要填写正视图描述与背视图描述"), { status: 400 })
  }

  const createdAt = new Date()
  const inserted = await db
    .insert(episodeMaterialAssets)
    .values({
      storyId: parsed.data.storyId,
      materialId,
      kind,
      name: parsed.data.name,
      roleName,
      makeupName,
      costumeName,
      prompt: parsed.data.prompt,
      url: "",
      storageKey: "",
      meta: {
        generationStatus: "pending",
        createdBy: "manual",
        errorName: null,
        errorMessage: null,
        errorRaw: null,
        ...(kind === "scene" ? { cameraOne, cameraTwo } : {}),
        ...(kind === "role" && characterId ? { characterId } : {})
      } as any,
      createdAt
    } as any)
    .returning({ id: episodeMaterialAssets.id })

  const assetId = inserted[0]?.id ?? ""
  if (!assetId) return NextResponse.json(makeApiErr(traceId, "UNKNOWN", "创建素材失败"), { status: 500 })

  const { jobId } = await enqueueEpisodeMaterialAssetRegenerateJob({
    userId,
    traceId,
    storyId: parsed.data.storyId,
    assetId,
    prompt: parsed.data.prompt,
    makeupName,
    costumeName
  })
  kickEpisodeMaterialWorker()

  return NextResponse.json(makeApiOk(traceId, { jobId, assetId }), { status: 200 })
}
