import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, inArray, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { readEnv, readEnvInt } from "@/shared/env"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { readCozeStreamRunOutput } from "@/server/integrations/coze/cozeStreamRunClient"
import { generatedImages, publicResources, sharedResources, stories } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { CANVAS_PROMPT_MAX_LENGTH } from "@/shared/contracts/video/canvas"

export const runtime = "nodejs"

function truncateText(input: string, maxLen: number): string {
  const s = (input ?? "").toString()
  if (maxLen <= 0) return ""
  if (s.length <= maxLen) return s
  return `${s.slice(0, Math.max(0, maxLen - 30))}...<truncated:${s.length}>`
}

function parseInternalFileId(rawUrl: string, prefixPath: string): string {
  const trimmed = rawUrl.trim()
  if (!trimmed) return ""
  const pathname = (() => {
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
      try {
        return new URL(trimmed).pathname
      } catch {
        return ""
      }
    }
    return trimmed.split("?")[0]?.split("#")[0] ?? ""
  })()
  if (!pathname.startsWith(prefixPath)) return ""
  const rest = pathname.slice(prefixPath.length)
  if (!rest) return ""
  try {
    return decodeURIComponent(rest)
  } catch {
    return rest
  }
}

const requestSchema = z.object({
  model: z.enum(["doubao-seed-2-0-pro", "doubao-seed-2-0-lite"]),
  prompt: z.string().trim().min(1).max(CANVAS_PROMPT_MAX_LENGTH),
  files: z
    .array(
      z.object({
        url: z.string().trim().min(1).max(4000),
        file_type: z.enum(["image", "video"])
      })
    )
    .max(12)
    .optional()
    .default([])
})

const responseSchema = z.object({
  result: z.string().trim().min(1).max(50_000)
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = requestSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const token = readEnv("TEXT_GENERATE_API_TOKEN")
  const url = readEnv("TEXT_GENERATE_API_URL") ?? "https://kqx97ntfry.coze.site/stream_run"
  if (!token) return NextResponse.json(makeApiErr(traceId, "TEXT_GEN_NOT_CONFIGURED", "未配置 TEXT_GENERATE_API_TOKEN"), { status: 500 })

  const normalizeFileUrl = (raw: string): string => {
    const u = typeof raw === "string" ? raw.trim() : ""
    if (!u) return ""
    if (u.startsWith("http://") || u.startsWith("https://")) return u
    if (u.startsWith("api/")) return new URL(`/${u}`, req.nextUrl.origin).toString()
    if (u.startsWith("/")) return new URL(u, req.nextUrl.origin).toString()
    return ""
  }

  const resolveSignedFileUrls = async (input: {
    userId: string
    files: Array<{ url: string; file_type: "image" | "video" }>
  }): Promise<{
    inputFiles: Array<{ url: string; file_type: "image" | "video" }>
    resolvedFiles: Array<{ url: string; file_type: "image" | "video" }>
  }> => {
    const normalized = input.files
      .map((f) => ({
        url: normalizeFileUrl(f.url),
        file_type: f.file_type
      }))
      .filter((f) => Boolean(f.url))
      .slice(0, 12)
    if (normalized.length === 0) return { inputFiles: [], resolvedFiles: [] }

    const imgIds = normalized
      .filter((f) => f.file_type === "image")
      .map((f) => parseInternalFileId(f.url, "/api/video-creation/images/file/"))
      .filter(Boolean)
      .slice(0, 12)
    const publicIds = normalized
      .filter((f) => f.file_type === "image")
      .map((f) => parseInternalFileId(f.url, "/api/library/public-resources/file/"))
      .filter(Boolean)
      .slice(0, 12)
    const sharedIds = normalized
      .filter((f) => f.file_type === "image")
      .map((f) => parseInternalFileId(f.url, "/api/library/shared-resources/file/"))
      .filter(Boolean)
      .slice(0, 12)

    if (imgIds.length === 0 && publicIds.length === 0 && sharedIds.length === 0) {
      return { inputFiles: normalized, resolvedFiles: normalized }
    }

    const db = await getDb({ generatedImages, publicResources, sharedResources, stories })
    const storage = getS3Storage()

    const imageRows =
      imgIds.length > 0
        ? await db
            .select({ id: generatedImages.id, storageKey: generatedImages.storageKey, url: generatedImages.url })
            .from(generatedImages)
            .innerJoin(stories, eq(generatedImages.storyId, stories.id))
            .where(and(inArray(generatedImages.id, imgIds), eq(stories.userId, input.userId), isNull(generatedImages.deletedAt)))
        : []

    const publicRows =
      publicIds.length > 0
        ? await db
            .select({
              id: publicResources.id,
              userId: publicResources.userId,
              previewUrl: publicResources.previewUrl,
              originalUrl: publicResources.originalUrl,
              previewStorageKey: publicResources.previewStorageKey,
              originalStorageKey: publicResources.originalStorageKey
            })
            .from(publicResources)
            .where(inArray(publicResources.id, publicIds))
        : []

    const sharedRows =
      sharedIds.length > 0
        ? await db
            .select({
              id: sharedResources.id,
              previewUrl: sharedResources.previewUrl,
              originalUrl: sharedResources.originalUrl,
              previewStorageKey: sharedResources.previewStorageKey,
              originalStorageKey: sharedResources.originalStorageKey
            })
            .from(sharedResources)
            .where(inArray(sharedResources.id, sharedIds))
        : []

    const resolvedByUrl = new Map<string, string>()

    for (const r of imageRows) {
      const key = typeof r.storageKey === "string" ? r.storageKey.trim() : ""
      const fallback = typeof r.url === "string" ? r.url.trim() : ""
      const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
      const internalBase = new URL(`/api/video-creation/images/file/${encodeURIComponent(r.id)}`, req.nextUrl.origin).toString()
      const resolved = signed || fallback || internalBase
      resolvedByUrl.set(internalBase, resolved)
      resolvedByUrl.set(`${internalBase}?kind=original`, resolved)
      resolvedByUrl.set(`${internalBase}?kind=thumbnail`, resolved)
    }

    for (const r of publicRows) {
      if (r.userId !== input.userId) continue
      const key = (r.originalStorageKey || r.previewStorageKey || "").trim()
      const fallback = (r.originalUrl || r.previewUrl || "").trim()
      const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
      const internalBase = new URL(`/api/library/public-resources/file/${encodeURIComponent(r.id)}`, req.nextUrl.origin).toString()
      const resolved = signed || fallback || internalBase
      resolvedByUrl.set(internalBase, resolved)
      resolvedByUrl.set(`${internalBase}?kind=original`, resolved)
      resolvedByUrl.set(`${internalBase}?kind=preview`, resolved)
    }

    for (const r of sharedRows) {
      const key = (r.originalStorageKey || r.previewStorageKey || "").trim()
      const fallback = (r.originalUrl || r.previewUrl || "").trim()
      const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
      const internalBase = new URL(`/api/library/shared-resources/file/${encodeURIComponent(r.id)}`, req.nextUrl.origin).toString()
      const resolved = signed || fallback || internalBase
      resolvedByUrl.set(internalBase, resolved)
      resolvedByUrl.set(`${internalBase}?kind=original`, resolved)
      resolvedByUrl.set(`${internalBase}?kind=preview`, resolved)
    }

    const resolvedFiles = normalized.map((f) => ({ ...f, url: resolvedByUrl.get(f.url) ?? f.url }))
    return { inputFiles: normalized, resolvedFiles }
  }

  const timeoutMs = readEnvInt("TEXT_GENERATE_REQUEST_TIMEOUT_MS") ?? readEnvInt("REQUEST_TIMEOUT_MS") ?? 60_000
  const fileResolution = await resolveSignedFileUrls({ userId, files: parsed.data.files })
  const payload = { model: parsed.data.model, prompt: parsed.data.prompt, files: fileResolution.resolvedFiles }
  const logPayloadEnabled = (readEnv("CANVAS_TEXT_GEN_LOG_PAYLOAD") ?? "").trim() === "1"
  const payloadMeta = {
    model: parsed.data.model,
    promptSize: parsed.data.prompt.length,
    prompt: logPayloadEnabled ? parsed.data.prompt : undefined,
    promptPreview: truncateText(parsed.data.prompt, 600),
    filesCount: fileResolution.resolvedFiles.length,
    filesInput: logPayloadEnabled
      ? fileResolution.inputFiles
      : fileResolution.inputFiles.map((f) => ({ ...f, url: truncateText(f.url, 160) })),
    filesResolved: logPayloadEnabled
      ? fileResolution.resolvedFiles
      : fileResolution.resolvedFiles.map((f) => ({ ...f, url: truncateText(f.url, 160) }))
  }

  try {
    const startedAt = Date.now()
    logger.info({
      event: "canvas_text_generate_request",
      module: "video/canvas",
      traceId,
      message: "文生文接口请求",
      ...payloadMeta
    })
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), Math.max(1000, Math.floor(timeoutMs)))
    let out: unknown = null
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: controller.signal
      })

      if (!res.ok) {
        logger.error({
          event: "canvas_text_generate_error",
          module: "video/canvas",
          traceId,
          message: "文生文接口调用失败",
          ...payloadMeta,
          status: res.status
        })
        return NextResponse.json(makeApiErr(traceId, "TEXT_GEN_FAILED", "文生文接口调用失败"), { status: 502 })
      }

      const ctype = (res.headers.get("content-type") ?? "").toLowerCase()
      if (ctype.includes("text/event-stream")) {
        const stream = await readCozeStreamRunOutput({ traceId, module: "video/canvas", apiUrl: url, res })
        if (!stream.ok) {
          logger.error({
            event: "canvas_text_generate_error",
            module: "video/canvas",
            traceId,
            message: "文生文接口调用失败",
            ...payloadMeta,
            errorMessage: stream.message
          })
          return NextResponse.json(makeApiErr(traceId, "TEXT_GEN_FAILED", "文生文接口调用失败"), { status: 502 })
        }
        out = stream.output
      } else {
        const json = (await res.json().catch(() => null)) as any
        out = json
      }
    } finally {
      clearTimeout(timer)
    }

    const parsedRes = responseSchema.safeParse(out)
    if (!parsedRes.success) return NextResponse.json(makeApiErr(traceId, "TEXT_GEN_INVALID_RESPONSE", "返回格式不正确"), { status: 502 })

    logger.info({
      event: "canvas_text_generate_response",
      module: "video/canvas",
      traceId,
      message: "文生文接口返回成功",
      model: parsed.data.model,
      resultSize: parsedRes.data.result.length,
      elapsedMs: Date.now() - startedAt
    })

    return NextResponse.json(makeApiOk(traceId, { result: parsedRes.data.result }), { status: 200 })
  } catch (err) {
    logger.error({ event: "canvas_text_generate_error", module: "video/canvas", traceId, message: "文生文接口异常", error: err })
    return NextResponse.json(makeApiErr(traceId, "TEXT_GEN_FAILED", "文生文接口异常"), { status: 500 })
  }
}
