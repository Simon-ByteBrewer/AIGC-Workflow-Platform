import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq, inArray } from "drizzle-orm"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"
import { generatedImages } from "@/shared/schema/generation"
import { enqueueFirstFrameJob, kickFirstFrameWorker } from "@/server/domains/video-creation/jobs/firstFrameWorker"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  count: z.coerce.number().int().min(1).max(3).optional().default(3)
})

function uniqByUrl(list: Array<{ name: string; url: string }>): Array<{ name: string; url: string }> {
  const seen = new Set<string>()
  const out: Array<{ name: string; url: string }> = []
  for (const it of list) {
    const url = (it?.url ?? "").trim()
    if (!url) continue
    if (seen.has(url)) continue
    seen.add(url)
    out.push({ name: (it?.name ?? "").trim() || "reference", url })
  }
  return out
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { storyId, count } = parsed.data
  const db = await getDb({ stories, storyOutlines, storyboards, generatedImages })

  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到故事"), { status: 403 })

  const outlineRows = await db
    .select({ id: storyOutlines.id, episodeNo: storyOutlines.sequence })
    .from(storyOutlines)
    .where(eq(storyOutlines.storyId, storyId))

  const outlineIds = outlineRows.map((r) => r.id).filter(Boolean)
  const outlineNoById = new Map<string, number>()
  for (const r of outlineRows) {
    const id = (r.id ?? "").trim()
    const no = Number((r as any)?.episodeNo ?? 0) || 0
    if (id && no > 0) outlineNoById.set(id, no)
  }
  if (outlineIds.length === 0) return NextResponse.json(makeApiOk(traceId, { jobIds: [], outlineCount: 0, storyboardCount: 0 }), { status: 200 })

  const storyboardRows = await db
    .select({ id: storyboards.id, outlineId: storyboards.outlineId, sceneNo: storyboards.sequence })
    .from(storyboards)
    .where(inArray(storyboards.outlineId, outlineIds))

  const storyboardIds = storyboardRows.map((r) => r.id).filter(Boolean)
  if (storyboardIds.length === 0) return NextResponse.json(makeApiOk(traceId, { jobIds: [], outlineCount: outlineIds.length, storyboardCount: 0 }), { status: 200 })

  const imagesByStoryboardId = new Map<string, Array<{ name: string; url: string }>>()
  const categories = ["role", "background", "item"] as const
  const chunkSize = 200
  for (let i = 0; i < storyboardIds.length; i += chunkSize) {
    const chunk = storyboardIds.slice(i, i + chunkSize)
    const rows = await db
      .select({ storyboardId: generatedImages.storyboardId, name: generatedImages.name, url: generatedImages.url })
      .from(generatedImages)
      .where(and(inArray(generatedImages.storyboardId, chunk), inArray(generatedImages.category, categories as any)))
    for (const r of rows) {
      const sid = (r.storyboardId ?? "").trim()
      if (!sid) continue
      const list = imagesByStoryboardId.get(sid) ?? []
      list.push({ name: (r.name ?? "").trim() || "reference", url: (r.url ?? "").trim() })
      imagesByStoryboardId.set(sid, list)
    }
  }

  const jobIds: string[] = []
  for (const r of storyboardRows) {
    const storyboardId = r.id
    const outlineId = (r.outlineId ?? "").trim()
    if (!storyboardId || !outlineId) continue
    const episodeNo = outlineNoById.get(outlineId) ?? null
    const sceneNo = Number((r as any)?.sceneNo ?? 0) || null
    const referenceImages = uniqByUrl(imagesByStoryboardId.get(storyboardId) ?? []).slice(0, 10)
    const { jobId } = await enqueueFirstFrameJob({
      userId,
      traceId,
      storyId,
      outlineId,
      storyboardId,
      referenceImages,
      ...(episodeNo ? { episodeNo } : {}),
      ...(sceneNo ? { sceneNo } : {}),
      ...((episodeNo && sceneNo) ? { label: `第 ${episodeNo} 集 · 镜 ${sceneNo}` } : sceneNo ? { label: `镜 ${sceneNo}` } : {}),
      count
    })
    jobIds.push(jobId)
  }

  kickFirstFrameWorker()
  return NextResponse.json(makeApiOk(traceId, { jobIds, outlineCount: outlineIds.length, storyboardCount: storyboardIds.length }), { status: 200 })
}
