import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { eq, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { groupModelBindings, groupModelCredentials, userModelToggles, userSecurity, users } from "@/shared/schema"
import { userGroups } from "@/shared/schema/userGroups"
import { canManageTargetUser, requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { ensureAdminPersonalGroup } from "@/server/domains/admin/services/adminPersonalGroup"
import { getEffectiveUserModelAccess, updateUserModelToggles, userModelToggleUpdateSchema } from "@/server/domains/admin/groupModelAccess"

export const runtime = "nodejs"

const patchBodySchema = z.object({
  email: z.string().trim().max(200).optional(),
  roleKey: z.enum(["user", "admin", "group_admin"]).optional(),
  groupId: z.string().trim().max(200).nullable().optional(),
  modelAccess: userModelToggleUpdateSchema.optional()
})

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户 ID"), { status: 400 })

    await ensurePublicSchema()
    const db = await getDb({ users, userGroups, userSecurity, groupModelCredentials, groupModelBindings, userModelToggles })

    const rows = await db
      .select({
        id: users.id,
        account: users.name,
        email: users.email,
        isActive: users.isActive,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        roleKey: userSecurity.roleKey,
        groupId: userSecurity.groupId,
        groupName: userGroups.name,
        tokenVersion: userSecurity.tokenVersion,
        lastLoginAt: userSecurity.lastLoginAt,
        passwordUpdatedAt: userSecurity.passwordUpdatedAt,
        failedLoginCount: userSecurity.failedLoginCount,
        lockedUntil: userSecurity.lockedUntil,
        disabledAt: userSecurity.disabledAt,
        disabledReason: userSecurity.disabledReason
      })
      .from(users)
      .leftJoin(userSecurity, eq(userSecurity.userId, users.id))
      .leftJoin(userGroups, eq(userGroups.id, userSecurity.groupId))
      .where(eq(users.id, id))
      .limit(1)

    const row = rows[0]
    if (!row?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "账号不存在"), { status: 404 })

    const effectiveGroupId =
      (row.roleKey ?? "user") === "admin" && !(row.groupId ?? "").trim()
        ? await ensureAdminPersonalGroup(db, row.id)
        : (row.groupId ?? null)

    if (!canManageTargetUser(actor, { groupId: effectiveGroupId })) {
      return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限访问该账号"), { status: 403 })
    }
    if (actor.roleKey === "group_admin" && (row.roleKey ?? "user") !== "user") {
      return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "组管理员只能管理组员账号"), { status: 403 })
    }

    const modelAccess = await getEffectiveUserModelAccess(db, {
      userId: id,
      groupId: effectiveGroupId,
      revealApiKey: false
    })

    const effectiveGroupName =
      effectiveGroupId && effectiveGroupId === (row.groupId ?? null)
        ? (row.groupName ?? null)
        : effectiveGroupId
          ? (
              await db
                .select({ name: userGroups.name })
                .from(userGroups)
                .where(eq(userGroups.id, effectiveGroupId))
                .limit(1)
            )[0]?.name ?? null
          : null

    return NextResponse.json(
      makeApiOk(traceId, {
        actor: {
          roleKey: actor.roleKey
        },
        user: {
          id: row.id,
          account: row.account,
          email: row.email,
          isActive: row.isActive,
          createdAt: row.createdAt,
          updatedAt: row.updatedAt,
          security: {
            roleKey: row.roleKey ?? "user",
            tokenVersion: row.tokenVersion ?? 1,
            lastLoginAt: row.lastLoginAt ?? null,
            passwordUpdatedAt: row.passwordUpdatedAt ?? null,
            failedLoginCount: row.failedLoginCount ?? 0,
            lockedUntil: row.lockedUntil ?? null,
            disabledAt: row.disabledAt ?? null,
            disabledReason: row.disabledReason ?? null
          },
          groupId: effectiveGroupId,
          groupName: effectiveGroupName,
          modelAccess
        }
      }),
      { status: 200 }
    )
  } catch (err) {
    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "admin_user_get_failed",
      module: "admin-users",
      traceId,
      message: "获取账号信息失败",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", anyErr?.message || "加载失败，请稍后重试"), { status: 500 })
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户 ID"), { status: 400 })

    const parsed = patchBodySchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ users, userGroups, userSecurity, groupModelCredentials, groupModelBindings, userModelToggles })

    const existing = await db
      .select({
        id: users.id,
        account: users.name,
        email: users.email,
        roleKey: userSecurity.roleKey,
        groupId: userSecurity.groupId,
        groupName: userGroups.name
      })
      .from(users)
      .leftJoin(userSecurity, eq(userSecurity.userId, users.id))
      .leftJoin(userGroups, eq(userGroups.id, userSecurity.groupId))
      .where(eq(users.id, id))
      .limit(1)

    const before = existing[0]
    if (!before?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "账号不存在"), { status: 404 })

    let effectiveGroupId =
      (before.roleKey ?? "user") === "admin" && !(before.groupId ?? "").trim()
        ? await ensureAdminPersonalGroup(db, before.id)
        : (before.groupId ?? null)

    if (!canManageTargetUser(actor, { groupId: effectiveGroupId })) {
      return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限操作该账号"), { status: 403 })
    }
    if (actor.roleKey === "group_admin" && (before.roleKey ?? "user") !== "user") {
      return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "组管理员只能管理组员账号"), { status: 403 })
    }

    const nextEmail = parsed.data.email !== undefined ? parsed.data.email.trim() : undefined
    const nextRoleKey = parsed.data.roleKey
    const nextGroupIdInput = parsed.data.groupId
    let nextModelAccessAudit: Record<string, unknown> | null = null
    let previousModelAccessAudit: Record<string, unknown> | null = null

    if (nextEmail !== undefined) {
      await db.update(users).set({ email: nextEmail || null, updatedAt: new Date() }).where(eq(users.id, id))
    }

    if (nextRoleKey !== undefined) {
      if (actor.roleKey !== "admin") {
        return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "仅超级管理员可修改角色"), { status: 403 })
      }
      const nextGroupIdPreview =
        parsed.data.groupId !== undefined
          ? (typeof parsed.data.groupId === "string" ? parsed.data.groupId.trim() : "") || null
          : (before.groupId ?? null)
      if (nextRoleKey === "group_admin" && !nextGroupIdPreview) {
        return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "该账号未绑定用户组，暂不支持升级为组管理员"), { status: 400 })
      }
      if (nextRoleKey === "admin") {
        effectiveGroupId = await ensureAdminPersonalGroup(db, id)
      }
    }

    const finalRoleKey = nextRoleKey !== undefined ? nextRoleKey : (before.roleKey ?? "user")
    let finalGroupId = effectiveGroupId

    if (nextGroupIdInput !== undefined) {
      if (actor.roleKey !== "admin") {
        return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "仅超级管理员可修改用户组"), { status: 403 })
      }

      const normalizedGroupId = typeof nextGroupIdInput === "string" ? nextGroupIdInput.trim() : ""
      finalGroupId = normalizedGroupId || null

      if (finalGroupId) {
        const targetGroup = await db
          .select({ id: userGroups.id, isActive: userGroups.isActive })
          .from(userGroups)
          .where(eq(userGroups.id, finalGroupId))
          .limit(1)
        if (!targetGroup[0]?.id) {
          return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "用户组不存在"), { status: 400 })
        }
        if (!targetGroup[0].isActive) {
          return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "用户组已禁用"), { status: 400 })
        }
      }
    }

    if (finalRoleKey !== "admin" && !finalGroupId) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "组管理员和员工必须绑定用户组"), { status: 400 })
    }

    if (finalRoleKey === "admin" && !finalGroupId) {
      finalGroupId = await ensureAdminPersonalGroup(db, id)
    }

    if (nextGroupIdInput !== undefined || nextRoleKey !== undefined) {
      await db
        .insert(userSecurity)
        .values({ userId: id, roleKey: finalRoleKey, groupId: finalGroupId, updatedAt: new Date() })
        .onConflictDoUpdate({
          target: userSecurity.userId,
          set: { roleKey: finalRoleKey, groupId: finalGroupId, updatedAt: new Date() }
        })
    }

    const didGroupScopeChange = finalGroupId !== effectiveGroupId

    if (parsed.data.modelAccess && !didGroupScopeChange) {
      const modelAccessResult = await updateUserModelToggles({
        db,
        userId: id,
        groupId: finalGroupId,
        actorUserId: actor.userId,
        traceId,
        data: parsed.data.modelAccess
      })
      previousModelAccessAudit = modelAccessResult.before
      nextModelAccessAudit = modelAccessResult.after
    } else if (parsed.data.modelAccess && didGroupScopeChange) {
      logger.info({
        event: "admin_user_update_skip_model_access",
        module: "admin-users",
        traceId,
        message: "用户组已变化，跳过过期模型开关保存",
        resultSummary: {
          userId: id,
          previousGroupId: effectiveGroupId,
          nextGroupId: finalGroupId
        }
      })
    }

    const after = {
      id,
      account: before.account,
      email: nextEmail !== undefined ? (nextEmail || null) : before.email,
      roleKey: finalRoleKey,
      groupId: finalGroupId,
      ...(nextModelAccessAudit ? { modelAccess: nextModelAccessAudit } : {})
    }

    const beforeAudit = {
      id,
      account: before.account,
      email: before.email,
      roleKey: before.roleKey ?? "user",
      groupId: before.groupId ?? null,
      ...(previousModelAccessAudit ? { modelAccess: previousModelAccessAudit } : {})
    }

    await db.execute(sql`
      insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
      values (
        ${actor.userId},
        'user.update',
        'user',
        ${id},
        ${id},
        ${JSON.stringify(beforeAudit)}::jsonb,
        ${JSON.stringify(after)}::jsonb,
        ${actor.ip},
        ${actor.userAgent},
        ${traceId}
      )
    `)

    return NextResponse.json(makeApiOk(traceId, { user: after }), { status: 200 })
  } catch (err) {
    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "admin_user_update_failed",
      module: "admin-users",
      traceId,
      message: "更新账号失败",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "INTERNAL_ERROR", anyErr?.message || "保存失败，请稍后重试"), { status: 500 })
  }
}
