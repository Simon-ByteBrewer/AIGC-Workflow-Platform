"use client"

export type QuickGenerateVideoModel = string

export const DEFAULT_QUICK_GENERATE_VIDEO_MODEL: QuickGenerateVideoModel = ""

function getEpisodeModelStorageKey(episodeId: string): string {
  return `quick-generate:episode-default-video-model:${episodeId}`
}

function getShotModelStorageKey(episodeId: string): string {
  return `quick-generate:shot-video-models:${episodeId}`
}

function normalizeQuickGenerateVideoModel(input: unknown): QuickGenerateVideoModel {
  return typeof input === "string" ? input.trim() : ""
}

/**
 * 读取当前剧集默认视频模型；无缓存时回退到默认模型。
 */
export function getEpisodeDefaultVideoModel(episodeId: string, fallback: QuickGenerateVideoModel = DEFAULT_QUICK_GENERATE_VIDEO_MODEL): QuickGenerateVideoModel {
  if (typeof window === "undefined") return fallback
  const raw = window.localStorage.getItem(getEpisodeModelStorageKey(episodeId))
  return normalizeQuickGenerateVideoModel(raw) || fallback
}

/**
 * 保存当前剧集默认视频模型，供新开详情页或刷新后恢复默认值。
 */
export function setEpisodeDefaultVideoModel(episodeId: string, model: QuickGenerateVideoModel): void {
  if (typeof window === "undefined") return
  const next = normalizeQuickGenerateVideoModel(model)
  if (!next) return
  window.localStorage.setItem(getEpisodeModelStorageKey(episodeId), next)
}

/**
 * 读取分镜级视频模型覆盖值；未命中的分镜由上层回退到剧集默认模型。
 */
export function getEpisodeShotVideoModels(episodeId: string): Record<number, QuickGenerateVideoModel> {
  if (typeof window === "undefined") return {}
  try {
    const raw = window.localStorage.getItem(getShotModelStorageKey(episodeId))
    const parsed = raw ? (JSON.parse(raw) as Record<string, unknown>) : {}
    const out: Record<number, QuickGenerateVideoModel> = {}
    for (const [key, value] of Object.entries(parsed)) {
      const shotNo = Number(key)
      if (!Number.isFinite(shotNo) || shotNo <= 0) continue
      const next = normalizeQuickGenerateVideoModel(value)
      if (!next) continue
      out[Math.trunc(shotNo)] = next
    }
    return out
  } catch {
    return {}
  }
}

/**
 * 保存当前剧集所有分镜的前端模型选择；仅用于前端阶段占位，不参与后端提交。
 */
export function setEpisodeShotVideoModels(
  episodeId: string,
  items: Array<{ shotNo: number; videoModel: QuickGenerateVideoModel }>
): void {
  if (typeof window === "undefined") return
  const payload: Record<string, QuickGenerateVideoModel> = {}
  for (const item of items) {
    const shotNo = Number(item.shotNo)
    if (!Number.isFinite(shotNo) || shotNo <= 0) continue
    const next = normalizeQuickGenerateVideoModel(item.videoModel)
    if (!next) continue
    payload[String(Math.trunc(shotNo))] = next
  }
  window.localStorage.setItem(getShotModelStorageKey(episodeId), JSON.stringify(payload))
}
