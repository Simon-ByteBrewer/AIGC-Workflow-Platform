Go to English Version

使用 Seedance 2.0 / Seedance 2.0 fast 模型生成的视频可能包含字幕，本文为您介绍如何通过 API 对视频进行字幕擦除。

字幕擦除为方舟平台提供的免费功能，暂不收费。

如有问题优先看下方常见问题自查。

# 使用流程

暂时无法在飞书文档外展示此内容

## 流程简介

字幕擦除任务接口是异步接口，流程如下：

1. 发起字幕擦除任务
2. 定时使用查询接口查询视频生成任务状态
   1. 任务 running，过段时间再查询任务状态
   2. 任务 completed，返回视频URL，在24小时内下载生成的视频文件

## 调用示例

1. 发起字幕擦除任务

video\_url 即待擦除字幕的视频 URL，从方舟[查询 Seedance 2.0 视频生成任务 API](https://www.volcengine.com/docs/82379/1521309?lang=zh)返回的`content.``video_url` 字段获取。

注意：**仅支持使用 方舟Seedance 2.0 生成的原始 URL，转存后无效**。原始 URL 存在 24h 有效期，请及时处理。

```
curl https://mediakit.cn-beijing.volces.com/api/v1/ark-tools/ark-erase-video-subtitle-pro \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ARK_API_KEY"
  -d '{
    "video_url":"https://ark-acg-cn-beijing.tos-cn-beijing.volces.com/doubao-seedance-2-0/02177599245546000000000000000000000ffffac15f56e704723.mp4?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260412%2Fcn-beijing%2Ftos%2Frequest&X-Tos-Date=20260412T112031Z&X-Tos-Expires=86400&X-Tos-Signature=2851b7efebb1a284536914c4f261a26a10e774af9d0bfde64c2f02e595e425a4&X-Tos-SignedHeaders=host"
}'
```

成功后返回以下信息，复制 task\_id 备用。

```
{
"success":true,
"task_id":"amk-tool-ark-erase-video-subtitle-pro-65295360258",
"request_id":"20260413115555A9B605F29A01D0ADE980"
}
```

1. 使用您的 task\_id 查询字幕擦除任务结果

```
curl -X GET https://mediakit.cn-beijing.volces.com/api/v1/ark-tasks/amk-tool-ark-erase-video-subtitle-pro-65295360258 \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $ARK_API_KEY"
```

任务执行成功后，可通过`result.video_url` 获取擦除字幕后的视频链接。

```
{
"success":true,
"task_id":"amk-tool-ark-erase-video-subtitle-pro-65295360258",
"task_type":"ark-erase-video-subtitle-pro",
"status":"completed",
"result": {
        "video_url": "https://example.volcvideo.com/enhanced_output.mp4?auth_key=1775271661-..."
    },
"expires_at": 1775119556,
"created_at": 1774946747,
"finished_at": 1774946756,
"request_id":"202604131419582011F31E0C3DCBB48AA5"
}
```

***

# API参考

# 发起字幕擦除任务

POST https\://mediakit.cn-beijing.volces.com/api/v1/ark-tools/ark-erase-video-subtitle-pro

本接口用于提交一个异步的精细化字幕擦除任务。它利用 AI 算法针对视频字幕提供精细化检测与擦除功能，实现高质量无痕擦除效果，最大程度还原视频画面。

任务提交成功后，您需要保存返回的 task\_id，并通过轮询查询任务信息接口获取最终结果。

## 使用说明

- 在首次使用擦除能力时系统需要一定时间进行初始化，预计需要5min左右，此时接口message会返回“system is initialing. please wait a moment to retry”，可稍后重新发起请求
- 为确保在网络波动或客户端重试等不确定场景下，同一个处理请求不被重复执行，所有任务提交接口均采用幂等性设计。
  - **为什么需要幂等性：**防止因客户端重试、网络抖动等原因导致同一个任务被多次执行，从而避免不必要的资源消耗和重复计费。
  - **默认幂等行为**：当您调用一个任务提交接口时，AI MediaKit 会根据您的**账户信息**和**核心请求参数**组合生成一个唯一标识。如果在**该任务成功提交的两天内**，系统收到一个具有相同标识的请求，将不会创建新任务，而是会返回与首次请求相同的结果（例如，返回同一个 task\_id）。



## 请求参数

### Header 参数

参数

类型

是否必选

示例值

描述

Authorization

String

是

Bearer {Your\_API\_Key}

格式为 Bearer {Your\_API\_Key}。方舟API Key

### Body 参数

参数

类型

是否必选

示例值

描述

video\_url

String

是

"https\://example.com/source.mp4"

待擦除字幕的视频 URL。

- **视频来源**：仅支持方舟生成的视频 URL。

## 响应参数

参数

类型

描述

success

Boolean

任务是否提交成功。

- true：成功。
- false：失败。更多信息请查看错误处理。

task\_id

String

任务的唯一标识，用于后续查询任务进度和结果。

request\_id

String

本次请求的唯一标识，可用于问题排查。

示例：

```
{
    "success": true,
    "task_id": "amk-tool-ark-erase-video-subtitle-pro-1703200",
    "request_id": "20260415150000******24A6A0D94B7FF1"
}
```



## 错误处理

当请求的参数或鉴权信息不正确时，任务将不会被创建，接口会返回一个同步的错误响应。详见[错误码](https://www.volcengine.com/docs/6448/2300662?lang=zh)。示例如下：

```
{
  "success": false,
  "task_id": "",
  "request_id": "20240521170000AABBCCDD112233",
  "error": {
    "code": "InvalidParameter",
    "message": "validating root: required: missing properties: [\"video_url\"]",
    "type": "BadRequest"
  }
}
```

# 查询字幕擦除任务结果

GET https\://mediakit.cn-beijing.volces.com/api/v1/ark-tasks/{task\_id}

## 请求参数

### Path 参数

参数

类型

是否必选

示例值

描述

task\_id

String

是

amk-tool-ark-erase-video-subtitle-pro-14\*\*\*24

任务的唯一标识。在提交异步任务时，从响应体中获取。

### Header 参数

参数

类型

是否必选

示例值

描述

Authorization

String

是

Bearer {Your\_API\_Key}

格式为 Bearer {Your\_API\_Key}。请参考基础概念及准备工作获取 API Key。

## 响应参数

接口的响应体为一个 JSON 对象，包含了任务的详细信息。

参数

类型

描述

success

Boolean

标识本次 API 请求是否被成功处理。

- true：服务端成功处理了查询请求。
- false：请求失败，具体原因请查看 error 字段。

说明

此字段仅代表查询操作本身是否成功，不代表任务的执行状态。

task\_id

String

所查询任务的唯一标识。

task\_type

String

任务类型。例如 ark-erase-video-subtitle-pro（精细化字幕擦除）等。

status

String

任务当前的状态。枚举值：

- running：任务正在处理中。
- completed：任务已成功完成。
- failed：任务处理失败。

result

Object

**任务成功时**返回的结果对象。仅当 status 为 completed 时出现。其内容结构请参见下文Result 对象。

error

Object

**任务失败时**返回的错误详情对象，或在任务成功时为 null。其内容结构请参见下文 Error 对象。

expires\_at

String

任务结果的过期时间戳（Unix Time，单位：秒）。仅当任务成功且有结果时返回。

created\_at

String

任务创建时间戳（Unix Time，单位：秒）。

finished\_at

String

任务完成（成功或失败）的时间戳（Unix Time，单位：秒）。仅当 status 为 completed 或 failed 时出现。

request\_id

String

本次 API 请求的唯一标识符，可用于问题排查。

### Result 对象

当 status 为 completed 时，响应会包含 result 对象。

**参数**

**类型**

**示例**

**描述**

video\_url

String

"https\://example.volcvideo.com/output.mp4?auth\_key=..."

输出视频的 URL。有效期为 24 小时。

### Error 对象

当 success 为 false 或 status 为 failed 时，会返回 error 对象，包含错误详情。

参数

类型

描述

code

String

错误码。详见[错误码](https://www.volcengine.com/docs/6448/2300662?lang=zh)。

message

String

错误描述信息，用于展示或记录日志。

param

String

(可选) 指示导致错误的具体参数名。

type

String

错误类型，如 TaskError 表示任务执行出错，ApiError 表示 API 调用出错。

## 响应示例

### 示例 1：任务正在运行

```
{
  "success": true,
  "task_id": "amk-tool-ark-erase-video-subtitle-pro-14***24",
  "task_type": "ark-erase-video-subtitle",
  "status": "running",
  "created_at": 1700484518,
  "request_id": "202603252052226AE61BF072A5A596F761"
}
```

### 示例 2：任务运行成功

```
Response：
{
    "success": true,
    "task_id": "amk-tool-ark-erase-video-subtitle-pro-1703200",
    "task_type": "ark-erase-video-subtitle",
    "status": "completed",
    "result": {
        "video_url": "https://example.volcvideo.com/enhanced_output.mp4?auth_key=1775271661-..."
    },
    "expires_at": 1775119556,
    "created_at": 1774946747,
    "finished_at": 1774946756,
    "request_id": "20260415150000******24A6A0D94B7FF1"
}
```

### 示例 3：任务执行失败

```
{
  "success": true,
  "task_id": " amk-tool-ark-erase-video-subtitle-pro-14***24",
  "task_type": "ark-erase-video-subtitle",
  "status": "failed",
  "error": {
    "code": "DownloadFailed",
    "message": "Failed to download file from the provided URL: https://example.com/nonexistent.mp4. Please check if the URL is correct and publicly accessible.",
    "param": "video_url",
    "type": "TaskError"
  },
  "created_at": 1700484518,
  "finished_at": 1700484522,
  "request_id": "202603252052226AE61BF072A5A596F761"
}
```



# 常见问题

## 问题1：擦除速度较慢？

- 不排队的情况下任务一般可以在20～30分钟以内可处理完成
- 若短时间内提交大量擦除任务会进入排队队列（受到整体资源池限制，同时提交的客户过多也会造成排队），**建议业务侧平滑提交擦除任务，**排队后一般可以在2～3小时内处理完成。



## 问题2：字幕擦除的不干净

> 请通过下方case进行自查

### 支持擦除的字幕范围

条件

边界

示例

字幕竖向位置

在视频画面下方50%以内的横向字幕会被擦除

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=YmQ4ODQwMmMyMGRiYTQxZGE3NzgwZGU2NDE4ZTlkMDNfc1JQU1dZT2pzOWNzVDhPU21XVnMyWGtuMnRpajVrT2hfVG9rZW46U0xBSGI2WTgyb1BWSDN4VU9xTmNaM3JHblpmXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

字幕横向位置

默认擦除全部视频画面下方50%以内的横向字幕

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=Y2VhNGI2NTY3YmNhN2FkYTZmNzhjODAwODg4MWYwODVfRUdQNkZoclVZekc4T1FwUGVJd012TDFRSXI3dWF5bTFfVG9rZW46VzZzWWJqZWlhb3UyT1l4VXV6M2NIVThFbm9kXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

字幕大小

文字竖向高度在视频高度的1%～10%会被擦除

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=ZjBlNDg2NWVkNDQzNjY2YTQyZTI5NjIxZTAwNzc4MTJfcWdWMzBiYVNUYlhsSHlId1dYVjRSa1FFRExaa21weGRfVG9rZW46QkJNTWJuTVFYb1ZqSzh4S0czZmNIbzBHbjRjXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=ODgxNjcyYjExNjE2MWJlNzU0YTg2N2UwMGE0MTIwNWFfT2JFNEdlUGZiUDhsS3Zjb1VVSE1rTlZXMWRKR1FvaWNfVG9rZW46UnU4NWJQVm1ib3JIOFN4cUZ3SWM0d0U2bkJmXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

字幕语言

<br />

- 中文
- 英文



### 不支持擦除的字幕范围

条件

边界

示例

字幕竖向位置

在视频画面上方50%以内的字幕不会被擦除

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=OWExZGViMjU1M2Q2OWIwZWI1YzBiYzkyY2ExMDk2NTNfOGZFWE1ISTdTVzNlTHhaSERlOGtNeU5KaXNUS2Y1QnBfVG9rZW46Q0VCQWJJbld6b1ZkUVN4RHFFR2NCQ1l1bk5mXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

字幕大小

单个文字竖向宽度在视频高度的小于1%和大于10%不会被擦除

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=OWZkMzY3MmE4MmU3MWU1OTZhM2I1ZmQ0YTNmZjVkNTVfT3NUUXZXWE41d3BqbGZKbU96Rjg4MFp0blhVbndSTTZfVG9rZW46U2lQWGI5Y0czb21EUjd4REUwc2NiNnkzblNmXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=Yzc1MmY2YjBlN2RjZjA2M2JmNmI3MmQ2MTA1MDQxN2ZfVTBRTG9ybklGeHpEb1M2dlZmdzRKbWpYUWk4MlJSSjNfVG9rZW46R1dCcmJuR3dLb1luUVl4UXVWVmNXdk93blZkXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

字幕语言

除中文和英文以外的语言字幕无法正常擦除

无法识别语种的字幕无法正常擦除



![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=MTk1NWJkZmY5OTQwMTc0M2RmMjA0NzlkMWIyZjA0OWJfMndEbFJIMFdiWlZlZk9tREp4NzBHa1pTZ3RNcmx0VnhfVG9rZW46Q3Q4R2JBdGM4bzFwQTh4YU5CMmNGc0QxblBoXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

### 可能不符合预期的场景

场景

描述

示例

场景文本误擦

对于符合支持擦除范围的场景文本会发生误擦除。

如示例，被误擦的条幅文本的位置、大小、颜色都符合擦除范围，所以被误擦。

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=ZjhkMjg1ZWJjMDBkZmU2Nzk3MWFjY2YxNjBiMjkyOTdfV1lyUUlKYW40NWJ5MDgyZElEbXBLQlE0MEdjdlJxR0lfVG9rZW46QVlsOGI1dUxEb29hTnp4M1VadWM2dEpKbnNlXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

***

\>> English version

# \[Please fill in the client name when applying] Dreamina Seedance 2.0 video subtitle erasure tutorial

Videos generated using the Dreamina Seedance 2.0 / Dreamina Seedance 2.0 Fast model may contain subtitles. This topic explains how to erase subtitles from videos via API.

Important

This feature is for invited users only. The account ID must be added to our whitelist before users can use this feature.

Note

Subtitle erasure is a free feature provided by ModelArk, and there is no charge for it at present. If you encounter any problems, please check the FAQs below first.

# Procedure

暂时无法在飞书文档外展示此内容

## Steps

The subtitle erasure API is asynchronous and the procedure is as follows:

1. Initiate a subtitle erasure task
2. Use the query API to regularly query the status of the video generation task
   1. If the task is running, query the task status again later.
   2. If the task is completed, the video URL will be returned. Make sure you download the generated video file within 24 hours.

## Call example

1. Initiate a subtitle erasure task
   1.   `video_url` is the URL of the video from which subtitles are to be erased, which is obtained from the `content.video_url` parameter returned by the [Retrieve a video generation task API](https://docs.byteplus.com/en/docs/ModelArk/1521309).
   2. Warning
   3. **Only original URLs generated by Seedance 2.0 are supported.** URLs after transfer are invalid. The original URL is valid for 24 hours. Please process it in time.
   ```
   curl https://mediakit.ap-southeast-1.bytepluses.com/api/v1/ark-tools/ark-erase-video-subtitle-pro \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer $ARK_API_KEY"
     -d '{
       "video_url": "https://ark-acg-ap-southeast-1.tos-ap-southeast-1.volces.com/dreamina-seedance-2-0/02177866142703300000000000000000000ffffc0a8845b91e6cd.mp4?X-Tos-Algorithm=TOS4-HMAC-SHA256&X-Tos-Credential=AKLTYWJkZTExNjA1ZDUyNDc3YzhjNTM5OGIyNjBhNDcyOTQ%2F20260513%2Fap-southeast-1%2Ftos%2Frequest&X-Tos-Date=20260513T084557Z&X-Tos-Expires=86400&X-Tos-Signature=f12e2ad05c4fa232456e79a327dd78b35454b62a01999970504113bfef4b109e&X-Tos-SignedHeaders=host"
   }'
   ```
     Copy the `task_id` from the response for future use.
   ```
   {
   "success":true,
   "task_id":"amk-tool-ark-erase-video-subtitle-pro-65295360258",
   "request_id":"20260413115555A9B605F29A01D0ADE980"
   }
   ```
2. Query the subtitle erasure task result using your `task_id`.
   1. <br />
   ```
   curl -X GET https://mediakit.ap-southeast-1.bytepluses.com/api/v1/ark-tasks/amk-tool-ark-erase-video-subtitle-pro-65295360258 \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer $ARK_API_KEY"
   ```
     After the task is executed successfully, you can obtain the video link after subtitle erasure through `result.video_url`.
   ```
   {
   "success":true,
   "task_id":"amk-tool-ark-erase-video-subtitle-pro-65295360258",
   "task_type":"ark-erase-video-subtitle-pro",
   "status":"completed",
   "result": {
           "video_url": "https://example.volcvideo.com/enhanced_output.mp4?auth_key=1775271661-..."
       },
   "expires_at": 1775119556,
   "created_at": 1774946747,
   "finished_at": 1774946756,
   "request_id":"202604131419582011F31E0C3DCBB48AA5"
   }
   ```

***

# API reference

## Initiate a subtitle erasure task

`POST https://mediakit.ap-southeast-1.bytepluses.com/api/v1/ark-tools/ark-erase-video-subtitle-pro`

This API is used to submit an asynchronous refined subtitle erasure task. It uses AI algorithms to provide refined detection and erasure functions for video subtitles, achieving high-quality traceless erasure effects and restoring video frames to the greatest extent possible.

Note

After the task is submitted successfully, you need to save the returned `task_id` and obtain the final result by polling the task information query API.

## Instructions

- It takes about 5 minutes for the erasure capability to initialize. During this period, the API returns "System is initializing. Please wait a moment to retry". You can re-initiate the request later.
- To ensure that the same processing request is not executed repeatedly in unstable scenarios such as network fluctuations or client retries, all task submission APIs are designed with idempotency.
  - **Why idempotency is needed**: To prevent the same task from being executed multiple times due to client retries, network jitter, etc., thereby avoiding unnecessary resource consumption and duplicate billing.
  - **Default idempotent behavior**: When you call a task submission API, AI MediaKit generates a unique identifier based on the combination of your **account information** and your **core request parameters**. If the system receives a request with the same identifier **within two days after the task is successfully submitted**, it will not create a new task, but will return the same result as the first request (for example, return the same `task_id`).



## Request Parameters

### Header parameter

**Parameter**

**Type**

**Required?**

**Example value**

**Description**

Authorization

String

Yes

Bearer {Your\_API\_Key}

The format is `Bearer {Your_API_Key}`. Use the ModelArk API key.

### Body parameters

**Parameter**

**Type**

**Required?**

**Example value**

**Description**

video\_url

String

Yes

"https\://example.com/source.mp4"

URL of the video from which subtitles are to be erased.

**Video source**: Only video URLs generated by ModelArk are supported.

## Response parameters

**Parameter**

**Type**

**Description**

success

Boolean

Indicates whether the task is submitted successfully.

- true: Success.
- false: Failure. See Error handling for more information.

task\_id

String

Unique identifier of the task, used for subsequent query of task progress and results.

request\_id

String

Unique identifier of this request, which can be used for troubleshooting.

Example:

```
{
    "success": true,
    "task_id": "amk-tool-ark-erase-video-subtitle-pro-1703200",
    "request_id": "20260415150000******24A6A0D94B7FF1"
}
```



## Error handling

If the requested parameters or authentication information are incorrect, the task will not be created, and the API will return an error response. See [Error codes](https://www.volcengine.com/docs/6448/2300662?lang=zh) for details. See the example below:

```
{
  "success": false,
  "task_id": "",
  "request_id": "20240521170000AABBCCDD112233",
  "error": {
    "code": "InvalidParameter",
    "message": "validating root: required: missing properties: [\"video_url\"]",
    "type": "BadRequest"
  }
}
```

# Query subtitle erasure task result

`GET https://mediakit.ap-southeast-1.bytepluses.com/api/v1/ark-tasks/{task_id}`

## Request parameters

### Path parameter

**Parameter**

**Type**

**Required?**

**Example value**

**Description**

task\_id

String

is

amk-tool-ark-erase-video-subtitle-pro-14\*\*\*24

Unique identifier of the task. Obtained from the response body when submitting an asynchronous task.

### Header parameter

**Parameter**

**Type**

**Required?**

**Example value**

**Description**

Authorization

String

is

Bearer {Your\_API\_Key}

The format is `Bearer {Your_API_Key}`. See Basic concepts and preparations to obtain the API key.

## Response parameters

The response body of the API is a JSON object containing detailed information about the task.

**Parameter**

**Type**

**Description**

success

Boolean

Indicates whether this API request was processed successfully.

- true: The server processed the query request successfully.
- false: Request failed. See the `error` parameter for the detailed reason.

This parameter only indicates whether the query operation itself is successful, not the execution status of the task.

task\_id

String

Unique identifier of the queried task.

task\_type

String

Task type. For example, `ark-erase-video-subtitle-pro` (refined subtitle erasure), etc.

status

String

Current status of the task. Valid values:

- running: Task is running.
- completed: Task completed successfully.
- failed: Task failed.

result

Object

Result object returned when the **task succeeds**. Returned only when `status` is `completed`. See the Result object below for its content structure.

error

Object

Error details object returned when the **task fails**. The value will be null when the task succeeds. See the Error object below for its content structure.

expires\_at

String

Expiration timestamp of the task result (Unix timestamp in seconds). Returned only when the task is successful and has a result.

created\_at

String

Task creation timestamp (Unix timestamp in seconds).

finished\_at

String

Timestamp when the task is completed or failed (Unix timestamp in seconds). Returned only when `status` is `completed` or `failed`.

request\_id

String

Unique identifier of this request, which can be used for troubleshooting.

### Result object

When `status` is `completed`, the response contains the `result` object.

**Parameter**

**Type**

**Example**

**Description**

video\_url

String

"https\://example.volcvideo.com/output.mp4?auth\_key=..."

URL of the generated video. It is valid for 24 hours.

### Error object

When `success` is `false` or when `status` is `failed`, an `error` object containing error details is returned.

Parameter

Type

Description

code

String

Error code. See [Error codes](https://www.volcengine.com/docs/6448/2300662?lang=zh) for details.

message

String

Error description information, used for display or logging.

param

String

(Optional) Indicates the specific parameter name that caused the error.

type

String

Error type: For example, `TaskError` indicates a task execution error, and `ApiError` indicates an API call error.

## Response examples

### Example 1: Task is running

```
{
  "success": true,
  "task_id": "amk-tool-ark-erase-video-subtitle-pro-14***24",
  "task_type": "ark-erase-video-subtitle",
  "status": "running",
  "created_at": 1700484518,
  "request_id": "202603252052226AE61BF072A5A596F761"
}
```

### Example 2: Task runs successfully

```
Response：
{
    "success": true,
    "task_id": "amk-tool-ark-erase-video-subtitle-pro-1703200",
    "task_type": "ark-erase-video-subtitle",
    "status": "completed",
    "result": {
        "video_url": "https://example.volcvideo.com/enhanced_output.mp4?auth_key=1775271661-..."
    },
    "expires_at": 1775119556,
    "created_at": 1774946747,
    "finished_at": 1774946756,
    "request_id": "20260415150000******24A6A0D94B7FF1"
}
```

### Example 3: Task execution failed

```
{
  "success": true,
  "task_id": " amk-tool-ark-erase-video-subtitle-pro-14***24",
  "task_type": "ark-erase-video-subtitle",
  "status": "failed",
  "error": {
    "code": "DownloadFailed",
    "message": "Failed to download file from the provided URL: https://example.com/nonexistent.mp4. Please check if the URL is correct and publicly accessible.",
    "param": "video_url",
    "type": "TaskError"
  },
  "created_at": 1700484518,
  "finished_at": 1700484522,
  "request_id": "202603252052226AE61BF072A5A596F761"
}
```



# FAQs

## Question 1: Is the erasure speed slow?

- Without queuing, the task can generally be processed within 20 to 30 minutes.
- If a large number of erasure tasks are submitted in a short period of time, they will enter the queue (limited by the overall resource pool. Too many customers submitting at the same time will also cause queuing). **It is recommended to submit a reasonable amount of tasks each time.** After queuing, tasks can generally be processed within 2 to 3 hours.



## Question 2: Subtitles are not completely erased

Please check against the cases below.

### Supported subtitle erasure scope

**Condition**

**Scope**

**Example**

Vertical position of subtitles

Horizontal subtitles within the bottom half of the video frame will be erased.

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=N2E1NjYxNTM0ZGJkOGFiOGRjNjhkNDM5MTZiNmY4MzBfMDVXWWdxbHBGTmRTQ1A1MWxoUllDamFLT3V2OXF6Tk5fVG9rZW46SDQ1S2JFVGM0bzE1RGJ4czVidmNnUE83bjhIXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

Horizontal position of subtitles

By default, all horizontal subtitles within the bottom half of the video frame are erased.

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=ZjAyZDEzZTVjYTc0NzAyNDM1ZmE4OTEwZDE2MTM3YWJfWU1OSTZpSE5tV09IaG56OEVjczVlYjVOaDliVUFINmdfVG9rZW46VXFoSGJ0U05jbzN2cVV4MjF2Q2Nyd2RMbnRlXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

Subtitle size

Text with a vertical height of 1% to 10% of the video height will be erased.

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=YzQyZjhhMDAxYjYxMWRhMTMyM2EyMThiOTdkZTk2NTBfSmJla0VpeXQwQTNQdmh1dGdMbm5ISXRwMTg4aXBuUGNfVG9rZW46VGlDNmJUeWJPb0xWTVB4OWpDeWNUVTU5bkJoXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=MzgwMWVmYjJmNDgxMzcxN2UwZjljYzg4NDJmNjIwMGVfRjFnMkkxYzI3WHc1TjlhRTdhS3VKdGVKUDJLOTYzeU5fVG9rZW46VlkyVGIwZ0xMb3Y1OXN4VWxuUmNuQXZLbkZnXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

Smallest

Biggest

Subtitle language

<br />

- Chinese
- English



### Unsupported subtitle erasure scope

**Condition**

**Scope**

**Example**

Vertical position of subtitles

Subtitles within the top half of the video frame will not be erased.

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=MjMxZjk1NjkxOTA5NjAxZDU1ZDNhYjk5NmZjNjk1NzBfWlRobXBYTEdsYTJ4UDFOR204dUtLRlhWaTJuSElDNzVfVG9rZW46V3pkY2I1T2xFbzNXT2N4YUp4U2NVM1NjbmFjXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

Subtitle size

Text with a vertical height of 1% to 10% of the video height will be erased.

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=ODI1NTgyMTE5MjcyOGE5NGNjNzdiN2Y5NzBlOWNiZThfaEdGTks1YTRBQkQ4VjlHMFlvcUdpV2FUTzJ0Vlh5UllfVG9rZW46QnB3S2IwdjFYbzlxUHN4YnU1aGNya1BJbkNiXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=YmZjZGVkY2MwM2ZjNjhhMmNkMTlkNmM3OTY1NTJhMGVfWFZvUVFkc2R5bVpiRGg2Q0V1WW1OckgwekVxc3JZRmFfVG9rZW46WEhyM2JPcWRRbzF4WUF4RFg3OWN5Nm1BblplXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

Smallest

Biggest

Subtitle language

Subtitles in languages other than Chinese and English cannot be erased properly.

Subtitles with unrecognizable languages cannot be erased properly.



![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=NzE0MmQ4OTdiOWNhNjQ2NTgyOGYwNGI1N2NmY2FjMjZfZG1Xa0h6S1dJYmU0bHF6MEVXRmYwYnRadU9RVENPNXZfVG9rZW46VjB6bGJ4Ujd4b2tJVkZ4ZW84SGNnNTUybmxlXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

### Scenarios that may not meet expectations

**Scenario**

**Description**

**Example**

Unexpected erasure

Unexpected erasure may occur for text within the target erasure scope.

As shown in the example, the position, size, and color of the banner text meet the erasure conditions, so it is erased.

![](https://bytedance.larkoffice.com/space/api/box/stream/download/asynccode/?code=MjMwMGJhZTVhY2Q5NGY0NTJlYjc5NTMzMjUyYmE1ZDVfd3huT3g0RzNGQnZ6THVGZ0lRdEloYjM1OWt3dlo5c3dfVG9rZW46UXlCMWJMTXJCb2xOaXF4OU15dWNPQlU4bk1oXzE3Nzk1MTg1NTI6MTc3OTUyMjE1Ml9WNA\&add_watermark=true\&scene_type=CCM)

