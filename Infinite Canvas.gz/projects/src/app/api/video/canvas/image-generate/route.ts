import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { normalizeExternalImageModelCode } from "@/shared/image/externalImageModels"
import { stories } from "@/shared/schema/story"
import { enqueueCanvasImageGenerateJob } from "@/server/domains/video/canvas/jobs/canvasImageGenerateWorker"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { listEnabledImageModelsForUser, resolveImageModelForUser } from "@/server/domains/image/imageModelResolver"
import { ensureImageQuotaAllowed } from "@/server/domains/quota/imageQuotaService"
import { QuotaReservationError } from "@/server/domains/quota/quotaReservationService"
import { CANVAS_PROMPT_MAX_LENGTH } from "@/shared/contracts/video/canvas"

export const runtime = "nodejs"

function normalizeModelLookupKey(value: string): string {
  return String(value ?? "").trim().toLowerCase()
}

const bodySchema = z
  .object({
    storyId: z.string().trim().min(1).max(200),
    outlineId: z.string().trim().min(1).max(200),
    nodeId: z.string().trim().min(1).max(200),
    prompt: z.string().trim().min(1).max(CANVAS_PROMPT_MAX_LENGTH),
    model: z.string().trim().min(1).max(100),
    type: z.enum(["single", "four_grid", "nine_grid"]).optional(),
    aspect_ratio: z.enum(["1:1", "16:9", "4:3", "3:4", "9:16", "2:3", "3:2", "21:9"]).optional(),
    watermark: z.boolean().optional(),
    max_images: z.number().int().min(1).max(15).optional(),
    image_list: z
      .array(
        z.object({
          image_name: z.string().trim().min(1).max(200).optional(),
          image_url: z.string().trim().min(1).max(4000)
        })
      )
      .max(10)
      .optional()
  })
  .strict()

/**
 * 创建 Canvas 图片生成异步任务。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  logger.info({
    event: "canvas_api_request",
    module: "video/canvas",
    traceId,
    message: "POST /api/video/canvas/image-generate",
    body: parsed.data
  })

  const imageList = (parsed.data.image_list ?? []).map((it, idx) => ({
    imageName: (it.image_name ?? `ref-${idx + 1}`).trim(),
    imageUrl: it.image_url.trim()
  }))
  const maxImages = parsed.data.max_images ?? 1
  if (imageList.length + maxImages > 15) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参考图数量 + 生成数量 不能超过 15"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ stories })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

  const type = parsed.data.type ?? "single"
  const enabledModels = await listEnabledImageModelsForUser(userId)
  if (enabledModels.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号未配置可用的图片模型"), { status: 400 })
  }
  const requestedModel = String(parsed.data.model ?? "").trim()
  const requestedLookupKey = normalizeModelLookupKey(requestedModel)
  const requestedExternalModelCode = normalizeExternalImageModelCode(requestedModel)
  const matchedModel =
    enabledModels.find((item) => item.modelName === requestedModel) ??
    enabledModels.find((item) => {
      if (item.kind === "external" && requestedExternalModelCode) return item.modelName === requestedExternalModelCode
      return normalizeModelLookupKey(item.modelName) === requestedLookupKey
    })
  if (!matchedModel) {
    logger.warn({
      event: "canvas_image_generate_model_rejected",
      module: "video/canvas",
      traceId,
      message: "图片生成请求的模型未命中可用模型，拒绝入队",
      requestedModel,
      availableModelNames: enabledModels.map((item) => item.modelName)
    })
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号不可使用该图片模型"), { status: 400 })
  }
  const model = matchedModel.modelName
  const aspectRatio = parsed.data.aspect_ratio ?? "1:1"
  const watermark = parsed.data.watermark ?? false

  try {
    const resolvedModel = await resolveImageModelForUser(userId, model)
    await ensureImageQuotaAllowed(db, {
      userId,
      groupId: resolvedModel.groupId,
      modelName: resolvedModel.realModelName,
      quantity: maxImages,
      traceId,
      requestSummary: "画布图片生成"
    })

    const { jobId, snapshot } = await enqueueCanvasImageGenerateJob({
      userId,
      traceId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      nodeId: parsed.data.nodeId,
      prompt: parsed.data.prompt,
      model,
      type,
      aspectRatio,
      watermark,
      maxImages,
      imageList
    })

    kickAllWorkers()
    logger.info({
      event: "canvas_api_response",
      module: "video/canvas",
      traceId,
      message: "POST /api/video/canvas/image-generate accepted",
      jobId
    })
    return NextResponse.json(makeApiOk(traceId, { jobId, snapshot }), { status: 202 })
  } catch (err) {
    const message = err instanceof Error ? err.message : "图片生成请求处理失败"
    const errCode = typeof err === "object" && err !== null && "code" in err ? String((err as { code?: unknown }).code ?? "").trim() : ""
    logger.error({
      event: "canvas_image_generate_api_failed",
      module: "video/canvas",
      traceId,
      message: "POST /api/video/canvas/image-generate failed",
      errorMessage: message
    })
    if (err instanceof QuotaReservationError || errCode === "QUOTA_NOT_ALLOWED" || message.includes("余额不足") || message.includes("额度")) {
      return NextResponse.json(makeApiErr(traceId, "QUOTA_NOT_ALLOWED", message), { status: 400 })
    }
    return NextResponse.json(makeApiErr(traceId, "DB_ERROR", message), { status: 500 })
  }
}
