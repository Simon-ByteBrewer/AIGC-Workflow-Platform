import { NextResponse, type NextRequest } from "next/server"
import { and, eq, isNull } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { virtualAvatars } from "@/shared/schema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const updateSchema = z.object({
  name: z.string().trim().min(1).max(200).optional(),
  assetId: z.string().trim().min(1).max(2000).optional(),
  refImageKey: z.string().trim().min(1).max(5000).optional(),
  refImagePreviewKey: z.string().trim().min(1).max(5000).optional().nullable()
})

function normalizeAssetId(raw: string): string {
  let a = String(raw ?? "").trim()
  if (!a) return ""
  if ((a.startsWith("`") && a.endsWith("`")) || (a.startsWith("\"") && a.endsWith("\"")) || (a.startsWith("'") && a.endsWith("'"))) {
    a = a.slice(1, -1).trim()
  }
  while (a.startsWith("asset://")) a = a.slice("asset://".length).trim()
  return a
}

/**
 * 将虚拟人像记录补齐为前端可用结构（含预签名参考图 URL）。
 */
async function normalizeAvatarRow(row: {
  id: string
  name: string
  uri: string
  refImageKey: string
  refImagePreviewKey: string | null
  createdAt: Date
  updatedAt: Date
}): Promise<Record<string, unknown>> {
  const storage = getS3Storage()
  const key = (row.refImagePreviewKey || row.refImageKey || "").trim()
  const refImageUrl = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
  return {
    id: row.id,
    name: row.name,
    assetId: row.uri,
    refImageKey: row.refImageKey,
    refImagePreviewKey: row.refImagePreviewKey,
    refImageUrl,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const params = await ctx.params
  const id = String(params?.id ?? "").trim()
  if (!id) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = updateSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  if (!Object.keys(parsed.data).length) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少可更新字段"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ virtualAvatars })

  const patch: Record<string, unknown> = { updatedAt: new Date() }
  if (typeof parsed.data.name === "string") patch.name = parsed.data.name
  if (typeof parsed.data.assetId === "string") patch.uri = normalizeAssetId(parsed.data.assetId)
  if (typeof parsed.data.refImageKey === "string") patch.refImageKey = parsed.data.refImageKey
  if (parsed.data.refImagePreviewKey !== undefined) patch.refImagePreviewKey = parsed.data.refImagePreviewKey

  try {
    if (typeof parsed.data.assetId === "string") {
      if (!patch.uri) {
        return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "assetID 不正确"), { status: 400 })
      }
      const dup = await db
        .select({ id: virtualAvatars.id })
        .from(virtualAvatars)
        .where(
          and(
            eq(virtualAvatars.userId, userId),
            eq(virtualAvatars.uri, String(patch.uri)),
            isNull(virtualAvatars.deletedAt)
          )
        )
        .limit(10)
      if (dup.some((item) => item.id !== id)) {
        return NextResponse.json(makeApiErr(traceId, "DUPLICATE_ASSET_ID", "assetID 已存在，请换一个"), { status: 409 })
      }
    }

    const updated = await db
      .update(virtualAvatars)
      .set(patch as any)
      .where(and(eq(virtualAvatars.id, id), eq(virtualAvatars.userId, userId), isNull(virtualAvatars.deletedAt)))
      .returning({
        id: virtualAvatars.id,
        name: virtualAvatars.name,
        uri: virtualAvatars.uri,
        refImageKey: virtualAvatars.refImageKey,
        refImagePreviewKey: virtualAvatars.refImagePreviewKey,
        createdAt: virtualAvatars.createdAt,
        updatedAt: virtualAvatars.updatedAt
      })

    const rec = updated[0]
    if (!rec?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "记录不存在"), { status: 404 })
    const item = await normalizeAvatarRow(rec as any)
    return NextResponse.json(makeApiOk(traceId, { item }), { status: 200 })
  } catch (e: any) {
    const msg = String(e?.message ?? "")
    if (e?.code === "23505" || msg.toLowerCase().includes("unique") || msg.toLowerCase().includes("duplicate")) {
      return NextResponse.json(makeApiErr(traceId, "DUPLICATE_ASSET_ID", "assetID 已存在，请换一个"), { status: 409 })
    }
    return NextResponse.json(makeApiErr(traceId, "UPDATE_FAILED", "更新失败"), { status: 500 })
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const params = await ctx.params
  const id = String(params?.id ?? "").trim()
  if (!id) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ virtualAvatars })

  const updated = await db
    .update(virtualAvatars)
    .set({ deletedAt: new Date(), updatedAt: new Date() } as any)
    .where(and(eq(virtualAvatars.id, id), eq(virtualAvatars.userId, userId), isNull(virtualAvatars.deletedAt)))
    .returning({ id: virtualAvatars.id })

  if (!updated[0]?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "记录不存在"), { status: 404 })
  return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
}
