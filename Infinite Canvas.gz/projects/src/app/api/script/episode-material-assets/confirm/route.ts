import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq, isNull } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { episodeMaterialAssets, episodeMaterialImages, generatedImages, storyAssetLibrary } from "@/shared/schema/generation"
import { publicBackgroundCameras, publicResources } from "@/shared/schema/library"
import { stories } from "@/shared/schema/story"
import { createCozeS3Storage } from "@/server/integrations/storage/s3"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

function normalizeKind(raw: string): "background" | "props" | "character" | null {
  const k = (raw ?? "").trim().toLowerCase()
  if (k === "scene" || k === "background") return "background"
  if (k === "item" || k === "props") return "props"
  if (k === "role" || k === "character") return "character"
  return null
}

async function upsertGeneratedImage(input: {
  db: any
  storyId: string
  category: string
  name: string
  description: string | null
  storageKey: string
  thumbnailStorageKey: string | null
  prompt: string | null
}): Promise<string | null> {
  const name = (input.name ?? "").trim()
  if (!name) return null

  const fileUrl = await resolveAssetUrlByStorageKey(input.storageKey)
  const thumbUrl = input.thumbnailStorageKey ? await resolveAssetUrlByStorageKey(input.thumbnailStorageKey) : fileUrl

  const existed = await input.db
    .select({ id: generatedImages.id })
    .from(generatedImages)
    .where(and(eq(generatedImages.storyId, input.storyId), eq(generatedImages.category, input.category), eq(generatedImages.name, name), isNull(generatedImages.storyboardId)))
    .orderBy(desc(generatedImages.createdAt))
    .limit(1)
  const keepId = existed[0]?.id ?? null

  if (keepId) {
    await input.db
      .update(generatedImages)
      .set({
        storageKey: input.storageKey,
        url: fileUrl,
        thumbnailUrl: thumbUrl,
        thumbnailStorageKey: input.thumbnailStorageKey,
        description: input.description,
        prompt: input.prompt,
        storyboardId: null
      })
      .where(eq(generatedImages.id, keepId))
    return keepId
  }

  const [row] = await input.db
    .insert(generatedImages)
    .values({
      storyId: input.storyId,
      storyboardId: null,
      name,
      description: input.description,
      url: fileUrl,
      storageKey: input.storageKey,
      thumbnailUrl: thumbUrl,
      thumbnailStorageKey: input.thumbnailStorageKey,
      category: input.category,
      prompt: input.prompt
    })
    .returning({ id: generatedImages.id })

  const id = row?.id ?? null
  if (!id) return null
  return id
}

async function resolveAssetUrlByStorageKey(storageKey: string): Promise<string> {
  const key = (storageKey ?? "").trim()
  if (!key) return ""
  const cozeStorage = createCozeS3Storage()
  try {
    return await resolveStorageUrl(cozeStorage, key)
  } catch {
  }
  const publicStorage = getS3Storage()
  return await resolveStorageUrl(publicStorage, key)
}

async function upsertPublicResource(input: {
  db: any
  userId: string
  type: "background" | "props"
  name: string
  storageKey: string
  description: string
}): Promise<string | null> {
  const name = (input.name ?? "").trim()
  const storageKey = (input.storageKey ?? "").trim()
  if (!name || !storageKey) return null

  const existed = await input.db
    .select({ id: publicResources.id })
    .from(publicResources)
    .where(and(eq(publicResources.userId, input.userId), eq(publicResources.originalStorageKey, storageKey), eq(publicResources.type, input.type)))
    .limit(1)
  const keepId = existed[0]?.id ?? null
  if (keepId) return keepId

  const previewUrl = await resolveAssetUrlByStorageKey(storageKey)
  const originalUrl = previewUrl
  const [created] = await input.db
    .insert(publicResources)
    .values({
      userId: input.userId,
      type: input.type,
      source: "ai",
      name,
      description: input.description ?? "",
      previewUrl,
      previewStorageKey: storageKey,
      originalUrl,
      originalStorageKey: storageKey,
      tags: [],
      applicableScenes: []
    })
    .returning({ id: publicResources.id })
  return created?.id ?? null
}

async function upsertPublicBackgroundResource(input: {
  db: any
  userId: string
  name: string
  storageKey: string
  description: string
}): Promise<string | null> {
  const name = (input.name ?? "").trim()
  const storageKey = (input.storageKey ?? "").trim()
  if (!name || !storageKey) return null

  const byName = await input.db
    .select({ id: publicResources.id })
    .from(publicResources)
    .where(and(eq(publicResources.userId, input.userId), eq(publicResources.type, "background"), eq(publicResources.name, name)))
    .orderBy(desc(publicResources.createdAt))
    .limit(1)
  const idByName = byName[0]?.id ?? null

  const previewUrl = await resolveAssetUrlByStorageKey(storageKey)
  const originalUrl = previewUrl

  if (idByName) {
    await input.db
      .update(publicResources)
      .set({
        description: input.description ?? "",
        previewUrl,
        previewStorageKey: storageKey,
        originalUrl,
        originalStorageKey: storageKey
      })
      .where(eq(publicResources.id, idByName))
    return idByName
  }

  const byKey = await input.db
    .select({ id: publicResources.id })
    .from(publicResources)
    .where(and(eq(publicResources.userId, input.userId), eq(publicResources.type, "background"), eq(publicResources.originalStorageKey, storageKey)))
    .limit(1)
  const idByKey = byKey[0]?.id ?? null
  if (idByKey) {
    await input.db
      .update(publicResources)
      .set({
        name,
        description: input.description ?? "",
        previewUrl,
        previewStorageKey: storageKey,
        originalUrl,
        originalStorageKey: storageKey
      })
      .where(eq(publicResources.id, idByKey))
    return idByKey
  }

  const [created] = await input.db
    .insert(publicResources)
    .values({
      userId: input.userId,
      type: "background",
      source: "ai",
      name,
      description: input.description ?? "",
      previewUrl,
      previewStorageKey: storageKey,
      originalUrl,
      originalStorageKey: storageKey,
      tags: [],
      applicableScenes: []
    })
    .returning({ id: publicResources.id })
  return created?.id ?? null
}

async function upsertPublicBackgroundCamera(input: {
  db: any
  backgroundResourceId: string
  camera: "front" | "back"
  storageKey: string
}): Promise<void> {
  const backgroundResourceId = (input.backgroundResourceId ?? "").trim()
  const storageKey = (input.storageKey ?? "").trim()
  if (!backgroundResourceId || !storageKey) return
  const previewUrl = await resolveAssetUrlByStorageKey(storageKey)
  const originalUrl = previewUrl
  const existed = await input.db
    .select({ id: publicBackgroundCameras.id })
    .from(publicBackgroundCameras)
    .where(and(eq(publicBackgroundCameras.backgroundResourceId, backgroundResourceId), eq(publicBackgroundCameras.camera, input.camera)))
    .limit(1)
  const keepId = existed[0]?.id ?? null
  if (keepId) {
    await input.db
      .update(publicBackgroundCameras)
      .set({
        previewUrl,
        previewStorageKey: storageKey,
        originalUrl,
        originalStorageKey: storageKey,
        updatedAt: new Date()
      })
      .where(eq(publicBackgroundCameras.id, keepId))
    return
  }
  await input.db
    .insert(publicBackgroundCameras)
    .values({
      backgroundResourceId,
      camera: input.camera,
      previewUrl,
      previewStorageKey: storageKey,
      originalUrl,
      originalStorageKey: storageKey
    })
}

function buildAssetKey(input: {
  kind: string
  name: string
  roleName: string | null
  makeupName: string | null
  costumeName: string | null
  meta: unknown
}): { key: string; displayName: string } | null {
  const kind = (input.kind ?? "").trim().toLowerCase()
  const rawName = (input.name ?? "").trim()
  if (!rawName) return null

  if (kind === "role" || kind === "character") {
    const roleName = (input.roleName ?? rawName).trim()
    const makeup = (input.makeupName ?? "").trim()
    const costume = (input.costumeName ?? "").trim()
    const metaObj = input.meta && typeof input.meta === "object" && input.meta !== null && !Array.isArray(input.meta) ? (input.meta as any) : null
    const keyFromMeta = metaObj && typeof metaObj.searchKey === "string" ? String(metaObj.searchKey).trim() : ""
    
    // 人物形象名称格式：人名-妆造-服装（相同的也要保留）
    const parts = [roleName]
    if (makeup) parts.push(makeup)
    if (costume) parts.push(costume)
    const key = keyFromMeta || parts.join("-")
    return key ? { key, displayName: roleName } : null
  }

  return { key: rawName, displayName: rawName }
}

async function resolveStoryAssetId(db: any, storyId: string, name: string): Promise<string | null> {
  const sid = (storyId ?? "").trim()
  const keyName = (name ?? "").trim()
  if (!sid || !keyName) return null
  const rows = await db
    .select({ id: storyAssetLibrary.id })
    .from(storyAssetLibrary)
    .where(and(eq(storyAssetLibrary.storyId, sid), eq(storyAssetLibrary.name, keyName)))
    .limit(1)
  return rows[0]?.id ?? null
}

function normalizeBackgroundViewName(input: string): string {
  let s = (input ?? "").trim()
  if (!s) return ""
  s = s.replace(/-后视图$/u, "-背视图")
  s = s.replace(/后视图$/u, "背视图")
  s = s.replace(/-后视$/u, "-背视图")
  s = s.replace(/后视$/u, "背视图")
  s = s.replace(/-背视$/u, "-背视图")
  s = s.replace(/背视$/u, "背视图")
  s = s.replace(/-正视$/u, "-正视图")
  s = s.replace(/正视$/u, "正视图")
  return s
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()

  const sid = parsed.data.storyId
  const db = await getDb({ stories, episodeMaterialImages, episodeMaterialAssets, generatedImages, storyAssetLibrary, publicResources, publicBackgroundCameras })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, sid), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const latestRows = await db
    .select({ id: episodeMaterialImages.id, createdAt: episodeMaterialImages.createdAt })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.storyId, sid))
    .orderBy(desc(episodeMaterialImages.createdAt))
    .limit(1)
  const latestBatchId = latestRows[0]?.id ?? null
  if (!latestBatchId) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "暂无素材批次"), { status: 404 })
  const metaRow = await db
    .select({ meta: episodeMaterialImages.meta })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.id, latestBatchId))
    .limit(1)
  const prevBatchMeta = (metaRow[0]?.meta ?? {}) as any

  const assets = await db
    .select({
      id: episodeMaterialAssets.id,
      kind: episodeMaterialAssets.kind,
      name: episodeMaterialAssets.name,
      roleName: episodeMaterialAssets.roleName,
      makeupName: episodeMaterialAssets.makeupName,
      costumeName: episodeMaterialAssets.costumeName,
      prompt: episodeMaterialAssets.prompt,
      storageKey: episodeMaterialAssets.storageKey,
      meta: episodeMaterialAssets.meta
    })
    .from(episodeMaterialAssets)
    .where(and(eq(episodeMaterialAssets.storyId, sid), eq(episodeMaterialAssets.materialId, latestBatchId)))
    .orderBy(desc(episodeMaterialAssets.createdAt))
    .limit(2000)

  const results: Array<{ assetId: string; storyAssetId: string; generatedImageId: string | null; key: string; libraryType: string }> = []
  for (const a of assets) {
    const libraryType = normalizeKind(a.kind)
    if (!libraryType) continue
    const existedGenId =
      typeof (a.meta as any)?.library?.generatedImageId === "string" ? String((a.meta as any).library.generatedImageId).trim() : ""
    const existedPubId =
      typeof (a.meta as any)?.library?.publicResourceId === "string" ? String((a.meta as any).library.publicResourceId).trim() : ""
    const existedStoryAssetId =
      typeof (a.meta as any)?.library?.storyAssetId === "string" ? String((a.meta as any).library.storyAssetId).trim() : ""
    const key = String(a.storageKey ?? "").trim()
    if (!key) continue

    const keyInfo = buildAssetKey({
      kind: a.kind,
      name: a.name,
      roleName: a.roleName ?? null,
      makeupName: a.makeupName ?? null,
      costumeName: a.costumeName ?? null,
      meta: a.meta
    })
    const keyName = keyInfo?.key ?? ""
    const displayName = keyInfo?.displayName ?? ""
    if (!keyName) continue

    const metaObj =
      a.meta && typeof a.meta === "object" && a.meta !== null && !Array.isArray(a.meta) ? (a.meta as any) : null
    const confirmedAt = metaObj && typeof metaObj.confirmedAt === "number" ? metaObj.confirmedAt : null
    if (existedStoryAssetId && confirmedAt && confirmedAt > 0) {
      results.push({
        assetId: a.id,
        storyAssetId: existedStoryAssetId,
        generatedImageId: existedGenId ? existedGenId : null,
        key: keyName,
        libraryType
      })
      continue
    }

    const category =
      libraryType === "background" ? "background" : libraryType === "props" ? "item" : libraryType === "character" ? "role" : ""
    const viewsRaw = metaObj && Array.isArray(metaObj.views) ? (metaObj.views as any[]) : []
    const bgViews =
      libraryType === "background"
        ? viewsRaw
            .map((v) => {
              if (!v || typeof v !== "object" || Array.isArray(v)) return null
              const cameraName = typeof (v as any).cameraName === "string" ? String((v as any).cameraName).trim() : ""
              const storageKey = typeof (v as any).storageKey === "string" ? String((v as any).storageKey).trim() : ""
              if (!cameraName || !storageKey) return null
              return { cameraName, storageKey }
            })
            .filter(Boolean)
        : []

    if (libraryType === "background" && bgViews.length > 0) {
      const viewList = bgViews as Array<{ cameraName: string; storageKey: string }>
      const normCamera = (name: string): "front" | "back" | null => {
        const s = normalizeBackgroundViewName(name)
        if (s.includes("背视图")) return "back"
        if (s.includes("正视图")) return "front"
        return null
      }
      const frontView = viewList.find((v) => normCamera(v.cameraName) === "front") ?? null
      const backView = viewList.find((v) => normCamera(v.cameraName) === "back") ?? null
      const primaryView = frontView ?? viewList[0] ?? null
      const primaryKey = (primaryView?.storageKey ?? "").trim()
      if (!primaryKey) continue

      // 为背景图的每个视图创建单独的 generated_images 记录
      const generatedImageIds: string[] = []
      
      // 1. 插入正视图
      if (frontView) {
        const frontName = `${keyName}-正视图`
        const frontGenId = await upsertGeneratedImage({
          db: db as any,
          storyId: sid,
          category: "background",
          name: frontName,
          description: (a.prompt ?? null) as any,
          storageKey: frontView.storageKey,
          thumbnailStorageKey: frontView.storageKey,
          prompt: (a.prompt ?? null) as any
        })
        if (frontGenId) generatedImageIds.push(frontGenId)
      }
      
      // 2. 插入背视图
      if (backView) {
        const backName = `${keyName}-背视图`
        const backGenId = await upsertGeneratedImage({
          db: db as any,
          storyId: sid,
          category: "background",
          name: backName,
          description: (a.prompt ?? null) as any,
          storageKey: backView.storageKey,
          thumbnailStorageKey: backView.storageKey,
          prompt: (a.prompt ?? null) as any
        })
        if (backGenId) generatedImageIds.push(backGenId)
      }
      
      const primaryGeneratedImageId = generatedImageIds[0] ?? null
      const fileUrl = primaryGeneratedImageId ? `/api/video-creation/images/file/${primaryGeneratedImageId}?kind=original` : ""
      const thumbUrl = primaryGeneratedImageId ? `/api/video-creation/images/file/${primaryGeneratedImageId}?kind=thumbnail` : ""

      const pubId = existedPubId
        ? existedPubId
        : await upsertPublicBackgroundResource({
            db: db as any,
            userId,
            name: keyName,
            storageKey: primaryKey,
            description: typeof a.prompt === "string" ? a.prompt : ""
          })

      if (pubId) {
        await upsertPublicBackgroundCamera({ db: db as any, backgroundResourceId: pubId, camera: "front", storageKey: primaryKey })
        const backKey = (backView?.storageKey ?? "").trim()
        if (backKey) await upsertPublicBackgroundCamera({ db: db as any, backgroundResourceId: pubId, camera: "back", storageKey: backKey })
      }

      const [stored] = await db
        .insert(storyAssetLibrary)
        .values({
          storyId: sid,
          name: keyName,
          displayName: displayName || null,
          url: fileUrl || "about:blank",
          storageKey: primaryKey,
          thumbnailUrl: thumbUrl || null,
          thumbnailStorageKey: primaryKey,
          meta: {
            kind: String(a.kind ?? "").trim(),
            libraryType,
            roleName: typeof a.roleName === "string" ? String(a.roleName).trim() : null,
            makeupName: typeof a.makeupName === "string" ? String(a.makeupName).trim() : null,
            costumeName: typeof a.costumeName === "string" ? String(a.costumeName).trim() : null,
            prompt: (a.prompt ?? null) as any,
            views: viewList.map((v) => ({ cameraName: v.cameraName, storageKey: v.storageKey })),
            generatedImageIds,
            source: { episodeMaterialAssetId: a.id, generatedImageId: primaryGeneratedImageId || null }
          } as any
        } as any)
        .onConflictDoUpdate({
          target: [storyAssetLibrary.storyId, storyAssetLibrary.name],
          set: {
            displayName: displayName || null,
            url: fileUrl || "about:blank",
            storageKey: primaryKey,
            thumbnailUrl: thumbUrl || null,
            thumbnailStorageKey: primaryKey,
            meta: {
              kind: String(a.kind ?? "").trim(),
              libraryType,
              roleName: typeof a.roleName === "string" ? String(a.roleName).trim() : null,
              makeupName: typeof a.makeupName === "string" ? String(a.makeupName).trim() : null,
              costumeName: typeof a.costumeName === "string" ? String(a.costumeName).trim() : null,
              prompt: (a.prompt ?? null) as any,
              views: viewList.map((v) => ({ cameraName: v.cameraName, storageKey: v.storageKey })),
              generatedImageIds,
              source: { episodeMaterialAssetId: a.id, generatedImageId: primaryGeneratedImageId || null }
            } as any
          } as any
        })
        .returning({ id: storyAssetLibrary.id })

      const storyAssetId = stored?.id ?? existedStoryAssetId ?? (await resolveStoryAssetId(db, sid, keyName))
      if (!storyAssetId) continue

      await db
        .update(episodeMaterialAssets)
        .set({
          meta: {
            ...(typeof a.meta === "object" && a.meta ? (a.meta as any) : {}),
            library: { type: libraryType, storyAssetId, generatedImageId: primaryGeneratedImageId, publicResourceId: pubId || null },
            confirmedAt: Date.now()
          } as any
        })
        .where(eq(episodeMaterialAssets.id, a.id))

      results.push({ assetId: a.id, storyAssetId, generatedImageId: primaryGeneratedImageId, key: keyName, libraryType })
      continue
    }

    const generatedImageId =
      existedGenId ||
      (category
        ? await upsertGeneratedImage({
            db: db as any,
            storyId: sid,
            category,
            name: keyName,
            description: (a.prompt ?? null) as any,
            storageKey: key,
            thumbnailStorageKey: key,
            prompt: (a.prompt ?? null) as any
          })
        : null)

    const fileUrl = generatedImageId ? `/api/video-creation/images/file/${generatedImageId}?kind=original` : ""
    const thumbUrl = generatedImageId ? `/api/video-creation/images/file/${generatedImageId}?kind=thumbnail` : ""
    const pubId =
      existedPubId ||
      (libraryType === "background"
        ? await upsertPublicResource({
            db: db as any,
            userId,
            type: "background",
            name: keyName,
            storageKey: key,
            description: typeof a.prompt === "string" ? a.prompt : ""
          })
        : libraryType === "props"
          ? await upsertPublicResource({
              db: db as any,
              userId,
              type: "props",
              name: keyName,
              storageKey: key,
              description: typeof a.prompt === "string" ? a.prompt : ""
            })
          : null)

    const [stored] = await db
      .insert(storyAssetLibrary)
      .values({
        storyId: sid,
        name: keyName,
        displayName: displayName || null,
        url: fileUrl || "about:blank",
        storageKey: key,
        thumbnailUrl: thumbUrl || null,
        thumbnailStorageKey: key,
        meta: {
          kind: String(a.kind ?? "").trim(),
          libraryType,
          roleName: typeof a.roleName === "string" ? String(a.roleName).trim() : null,
          makeupName: typeof a.makeupName === "string" ? String(a.makeupName).trim() : null,
          costumeName: typeof a.costumeName === "string" ? String(a.costumeName).trim() : null,
          prompt: (a.prompt ?? null) as any,
          source: { episodeMaterialAssetId: a.id, generatedImageId: generatedImageId || null }
        } as any
      } as any)
      .onConflictDoUpdate({
        target: [storyAssetLibrary.storyId, storyAssetLibrary.name],
        set: {
          displayName: displayName || null,
          url: fileUrl || "about:blank",
          storageKey: key,
          thumbnailUrl: thumbUrl || null,
          thumbnailStorageKey: key,
          meta: {
            kind: String(a.kind ?? "").trim(),
            libraryType,
            roleName: typeof a.roleName === "string" ? String(a.roleName).trim() : null,
            makeupName: typeof a.makeupName === "string" ? String(a.makeupName).trim() : null,
            costumeName: typeof a.costumeName === "string" ? String(a.costumeName).trim() : null,
            prompt: (a.prompt ?? null) as any,
            source: { episodeMaterialAssetId: a.id, generatedImageId: generatedImageId || null }
          } as any
        } as any
      })
      .returning({ id: storyAssetLibrary.id })
    const storyAssetId = stored?.id ?? existedStoryAssetId ?? (await resolveStoryAssetId(db, sid, keyName))
    if (!storyAssetId) continue

    await db
      .update(episodeMaterialAssets)
      .set({
        meta: {
          ...(typeof a.meta === "object" && a.meta ? (a.meta as any) : {}),
          library: { type: libraryType, storyAssetId, generatedImageId, publicResourceId: pubId || null },
          confirmedAt: Date.now()
        } as any
      })
      .where(eq(episodeMaterialAssets.id, a.id))

    results.push({ assetId: a.id, storyAssetId, generatedImageId, key: keyName, libraryType })
  }

  await db
    .update(episodeMaterialImages)
    .set({
      meta: {
        ...(typeof prevBatchMeta === "object" && prevBatchMeta ? prevBatchMeta : {}),
        confirmedAt: Date.now()
      } as any
    })
    .where(eq(episodeMaterialImages.id, latestBatchId))

  return NextResponse.json(makeApiOk(traceId, { batchId: latestBatchId, inserted: results }), { status: 200 })
}
