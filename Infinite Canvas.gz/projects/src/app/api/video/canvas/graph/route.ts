import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, inArray, isNull } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { generatedAudios, generatedImages, publicResources, sharedResources, stories, storyOutlines, videoCanvasGraphs, videoCanvasSessions, virtualAvatars } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { canUseCanvasPrivateCopyrightLibrary } from "@/server/domains/video/canvas/copyright/canvasCopyrightCapability"
import { getCanvasCopyrightReviewConfig } from "@/server/domains/video/canvas/copyright/canvasCopyrightAssetStore"
import { sanitizeCanvasGraphViewport } from "@/shared/canvasViewport"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200)
})

const patchSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200),
  expectedVersion: z.number().int().min(1).optional(),
  clientId: z.string().trim().min(1).max(200).optional(),
  graph: z.any(),
  runtime: z.any().optional()
})

function defaultGraph(): Record<string, unknown> {
  return { nodes: [], edges: [], viewport: { x: 0, y: 0, zoom: 1 } }
}

function normalizeGraphForStorage(graph: unknown): Record<string, unknown> {
  if (!graph || typeof graph !== "object") return defaultGraph()
  return sanitizeCanvasGraphViewport(graph as Record<string, unknown>)
}

function getGraphDebugStats(graph: unknown): { nodeCount: number; edgeCount: number; graphBytes: number } {
  const g = graph && typeof graph === "object" ? (graph as Record<string, unknown>) : {}
  const nodes = Array.isArray(g.nodes) ? g.nodes : []
  const edges = Array.isArray(g.edges) ? g.edges : []
  let graphBytes = 0
  try {
    graphBytes = Buffer.byteLength(JSON.stringify(graph ?? {}), "utf8")
  } catch {
    graphBytes = 0
  }
  return { nodeCount: nodes.length, edgeCount: edges.length, graphBytes }
}

function getClientIdTail(clientId: string | undefined): string {
  const value = String(clientId ?? "").trim()
  return value ? value.slice(-8) : ""
}

/**
 * 校验当前 PATCH 请求仍持有画布编辑租约，防止被接管页面继续写入 graph。
 */
async function assertCanvasSessionOwner(input: {
  db: Awaited<ReturnType<typeof getDb>>
  userId: string
  storyId: string
  outlineId: string
  clientId: string | undefined
  traceId: string
  expectedVersion?: number
  graphStats?: { nodeCount: number; edgeCount: number; graphBytes: number }
}): Promise<Response | null> {
  const clientId = (input.clientId ?? "").trim()
  if (!clientId) {
    logger.warn({
      event: "canvas_graph_patch_session_required",
      module: "video/canvas",
      traceId: input.traceId,
      message: "保存画布 graph 缺少 clientId",
      userId: input.userId,
      storyId: input.storyId,
      outlineId: input.outlineId,
      expectedVersion: input.expectedVersion ?? null,
      ...(input.graphStats ?? {})
    })
    return NextResponse.json(makeApiErr(input.traceId, "CANVAS_SESSION_REQUIRED", "画布编辑会话已失效，请重新打开画布"), { status: 423 })
  }

  const rows = await input.db
    .select({ clientId: videoCanvasSessions.clientId })
    .from(videoCanvasSessions)
    .where(
      and(
        eq(videoCanvasSessions.userId, input.userId),
        eq(videoCanvasSessions.storyId, input.storyId),
        eq(videoCanvasSessions.outlineId, input.outlineId)
      )
    )
    .limit(1)
  const ownerClientId = rows[0]?.clientId ?? ""
  if (!ownerClientId) {
    logger.warn({
      event: "canvas_graph_patch_session_lost",
      module: "video/canvas",
      traceId: input.traceId,
      message: "保存画布 graph 时编辑会话不存在",
      userId: input.userId,
      storyId: input.storyId,
      outlineId: input.outlineId,
      clientIdTail: getClientIdTail(clientId),
      expectedVersion: input.expectedVersion ?? null,
      ...(input.graphStats ?? {})
    })
    return NextResponse.json(makeApiErr(input.traceId, "CANVAS_SESSION_LOST", "画布编辑会话已失效，请重新获取编辑权"), { status: 423 })
  }
  if (ownerClientId !== clientId) {
    logger.warn({
      event: "canvas_graph_patch_session_displaced",
      module: "video/canvas",
      traceId: input.traceId,
      message: "保存画布 graph 时页面已被其他会话接管",
      userId: input.userId,
      storyId: input.storyId,
      outlineId: input.outlineId,
      clientIdTail: getClientIdTail(clientId),
      ownerClientIdTail: getClientIdTail(ownerClientId),
      expectedVersion: input.expectedVersion ?? null,
      ...(input.graphStats ?? {})
    })
    return NextResponse.json(makeApiErr(input.traceId, "CANVAS_SESSION_DISPLACED", "当前画布已在其他窗口打开"), { status: 423 })
  }

  return null
}

function parseInternalFileId(rawUrl: string, prefixPath: string): string {
  const trimmed = (rawUrl ?? "").toString().trim()
  if (!trimmed) return ""
  const pathname = (() => {
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
      try {
        return new URL(trimmed).pathname
      } catch {
        return ""
      }
    }
    return trimmed.split("?")[0]?.split("#")[0] ?? ""
  })()
  if (!pathname.startsWith(prefixPath)) return ""
  const rest = pathname.slice(prefixPath.length)
  if (!rest) return ""
  try {
    return decodeURIComponent(rest)
  } catch {
    return rest
  }
}

function normalizeToPathname(rawUrl: string): string {
  const trimmed = (rawUrl ?? "").toString().trim()
  if (!trimmed) return ""
  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
    try {
      return new URL(trimmed).pathname
    } catch {
      return ""
    }
  }
  return trimmed.split("?")[0]?.split("#")[0] ?? ""
}

function getAssetIdTypeAndId(assetId: string): { type: "library" | "shared"; id: string } | null {
  const a = (assetId ?? "").toString().trim()
  if (a.startsWith("library:")) {
    const id = a.slice("library:".length).trim()
    return id ? { type: "library", id } : null
  }
  if (a.startsWith("shared:")) {
    const id = a.slice("shared:".length).trim()
    return id ? { type: "shared", id } : null
  }
  return null
}

function getGeneratedImageId(assetId: string): string {
  const a = (assetId ?? "").toString().trim()
  if (a.startsWith("generated:image_db:")) {
    return a.slice("generated:image_db:".length).trim()
  }
  if (a.startsWith("generated_images:")) {
    return a.slice("generated_images:".length).trim()
  }
  return ""
}

async function hydrateCanvasGraphUrls(input: {
  userId: string
  graph: any
}): Promise<any> {
  const g = input.graph ?? defaultGraph()
  const nodes = Array.isArray(g?.nodes) ? g.nodes : []
  if (nodes.length === 0) return g

  const storage = getS3Storage()
  const db = await getDb({ generatedImages, generatedAudios, publicResources, sharedResources, stories, virtualAvatars })

  const imageIds: string[] = []
  const audioIds: string[] = []
  const publicIds: string[] = []
  const sharedIds: string[] = []
  const avatarIds: string[] = []

  for (const n of nodes) {
    const t = String(n?.type ?? "")
    if (t === "avatar_resource") {
      const params = (n?.params ?? {}) as Record<string, unknown>
      const avatarId = typeof params.avatarId === "string" ? params.avatarId : ""
      if (avatarId) avatarIds.push(avatarId)
      continue
    }
    if (t !== "image_resource" && t !== "audio_resource" && t !== "video_resource") continue
    const params = (n?.params ?? {}) as Record<string, unknown>
    const url = typeof params.url === "string" ? params.url : ""
    const assetId = typeof params.assetId === "string" ? params.assetId : ""

    const m = getAssetIdTypeAndId(assetId)
    if (m?.type === "library") publicIds.push(m.id)
    if (m?.type === "shared") sharedIds.push(m.id)
    const generatedId = getGeneratedImageId(assetId)
    if (generatedId) imageIds.push(generatedId)

    const imageId = parseInternalFileId(url, "/api/video-creation/images/file/")
    if (imageId) imageIds.push(imageId)
    const audioId = parseInternalFileId(url, "/api/video-creation/audios/file/")
    if (audioId) audioIds.push(audioId)
  }

  const uniq = (arr: string[]) => Array.from(new Set(arr.map((s) => s.trim()).filter(Boolean)))
  const uniqImageIds = uniq(imageIds).slice(0, 500)
  const uniqAudioIds = uniq(audioIds).slice(0, 500)
  const uniqPublicIds = uniq(publicIds).slice(0, 500)
  const uniqSharedIds = uniq(sharedIds).slice(0, 500)
  const uniqAvatarIds = uniq(avatarIds).slice(0, 500)

  const imageRows =
    uniqImageIds.length > 0
      ? await db
          .select({ id: generatedImages.id, storageKey: generatedImages.storageKey, url: generatedImages.url })
          .from(generatedImages)
          .innerJoin(stories, eq(generatedImages.storyId, stories.id))
          .where(and(inArray(generatedImages.id, uniqImageIds), eq(stories.userId, input.userId), isNull(generatedImages.deletedAt)))
      : []

  const audioRows =
    uniqAudioIds.length > 0
      ? await db
          .select({ id: generatedAudios.id, storageKey: generatedAudios.storageKey, url: generatedAudios.url })
          .from(generatedAudios)
          .innerJoin(stories, eq(generatedAudios.storyId, stories.id))
          .where(and(inArray(generatedAudios.id, uniqAudioIds), eq(stories.userId, input.userId)))
      : []

  const publicRows =
    uniqPublicIds.length > 0
      ? await db
          .select({
            id: publicResources.id,
            userId: publicResources.userId,
            previewUrl: publicResources.previewUrl,
            originalUrl: publicResources.originalUrl,
            previewStorageKey: publicResources.previewStorageKey,
            originalStorageKey: publicResources.originalStorageKey
          })
          .from(publicResources)
          .where(inArray(publicResources.id, uniqPublicIds))
      : []

  const sharedRows =
    uniqSharedIds.length > 0
      ? await db
          .select({
            id: sharedResources.id,
            previewUrl: sharedResources.previewUrl,
            originalUrl: sharedResources.originalUrl,
            previewStorageKey: sharedResources.previewStorageKey,
            originalStorageKey: sharedResources.originalStorageKey
          })
          .from(sharedResources)
          .where(inArray(sharedResources.id, uniqSharedIds))
      : []

  const avatarRows =
    uniqAvatarIds.length > 0
      ? await db
          .select({
            id: virtualAvatars.id,
            name: virtualAvatars.name,
            uri: virtualAvatars.uri,
            refImageKey: virtualAvatars.refImageKey,
            refImagePreviewKey: virtualAvatars.refImagePreviewKey
          })
          .from(virtualAvatars)
          .where(and(inArray(virtualAvatars.id, uniqAvatarIds), eq(virtualAvatars.userId, input.userId), isNull(virtualAvatars.deletedAt)))
      : []

  const signedByGeneratedImageId = new Map<string, string>()
  for (const r of imageRows) {
    const key = typeof r.storageKey === "string" ? r.storageKey.trim() : ""
    const fallback = typeof r.url === "string" ? r.url.trim() : ""
    const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
    const stable =
      fallback && normalizeToPathname(fallback).startsWith("/api/video-creation/images/file/") ? fallback : ""
    signedByGeneratedImageId.set(r.id, stable || signed || fallback)
  }

  const signedByGeneratedAudioId = new Map<string, string>()
  for (const r of audioRows) {
    const key = typeof r.storageKey === "string" ? r.storageKey.trim() : ""
    const fallback = typeof r.url === "string" ? r.url.trim() : ""
    const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
    const stable = fallback && normalizeToPathname(fallback).startsWith("/api/video-creation/audios/file/") ? fallback : ""
    signedByGeneratedAudioId.set(r.id, stable || signed || fallback)
  }

  const signedByPublicId = new Map<string, string>()
  for (const r of publicRows) {
    if (r.userId !== input.userId) continue
    const key = (r.originalStorageKey || r.previewStorageKey || "").trim()
    const fallback = (r.originalUrl || r.previewUrl || "").trim()
    const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
    signedByPublicId.set(r.id, signed || fallback)
  }

  const signedBySharedId = new Map<string, string>()
  for (const r of sharedRows) {
    const key = (r.originalStorageKey || r.previewStorageKey || "").trim()
    const fallback = (r.originalUrl || r.previewUrl || "").trim()
    const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
    signedBySharedId.set(r.id, signed || fallback)
  }

  const avatarById = new Map<string, { avatarAssetId: string; displayName: string; refImageUrl: string }>()
  for (const r of avatarRows) {
    const key = (r.refImagePreviewKey || r.refImageKey || "").trim()
    const signed = key ? await resolveStorageUrl(storage, key).catch(() => "") : ""
    avatarById.set(r.id, { avatarAssetId: (r.uri ?? "").trim(), displayName: (r.name ?? "").trim(), refImageUrl: signed })
  }

  const nextNodes = nodes.map((n: any) => {
    const t = String(n?.type ?? "")
    if (t === "avatar_resource") {
      const params = (n?.params ?? {}) as Record<string, unknown>
      const avatarId = typeof params.avatarId === "string" ? params.avatarId : ""
      if (!avatarId) return n
      const it = avatarById.get(avatarId)
      if (!it) return n
      const cached = typeof params.refImageUrl === "string" ? params.refImageUrl : ""
      const nextRefImageUrl = it.refImageUrl || cached
      const nextParams: Record<string, unknown> = {
        ...params,
        avatarAssetId: it.avatarAssetId,
        displayName: it.displayName || params.displayName
      }
      if (nextRefImageUrl) nextParams.refImageUrl = nextRefImageUrl
      return { ...n, params: nextParams }
    }
    if (t !== "image_resource" && t !== "audio_resource" && t !== "video_resource") return n
    const params = (n?.params ?? {}) as Record<string, unknown>
    const url = typeof params.url === "string" ? params.url : ""
    const assetId = typeof params.assetId === "string" ? params.assetId : ""
    const m = getAssetIdTypeAndId(assetId)
    const generatedId = getGeneratedImageId(assetId)

    const nextUrl = (() => {
      if (generatedId) return signedByGeneratedImageId.get(generatedId) ?? ""
      if (m?.type === "library") return signedByPublicId.get(m.id) ?? ""
      if (m?.type === "shared") return signedBySharedId.get(m.id) ?? ""

      const pathname = normalizeToPathname(url)
      if (pathname.startsWith("/api/video-creation/images/file/")) {
        const id = parseInternalFileId(url, "/api/video-creation/images/file/")
        return id ? signedByGeneratedImageId.get(id) ?? "" : ""
      }
      if (pathname.startsWith("/api/video-creation/audios/file/")) {
        const id = parseInternalFileId(url, "/api/video-creation/audios/file/")
        return id ? signedByGeneratedAudioId.get(id) ?? "" : ""
      }
      return ""
    })()

    if (!nextUrl) return n
    return { ...n, params: { ...params, url: nextUrl } }
  })

  return { ...g, nodes: nextNodes }
}

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    outlineId: url.searchParams.get("outlineId") ?? ""
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const db = await getDb({ stories, storyOutlines, videoCanvasGraphs, videoCanvasSessions })

    const storyRows = await db
      .select({ id: stories.id })
      .from(stories)
      .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
      .limit(1)
    if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

    const outlineRows = await db
      .select({ id: storyOutlines.id })
      .from(storyOutlines)
      .where(and(eq(storyOutlines.id, parsed.data.outlineId), eq(storyOutlines.storyId, parsed.data.storyId), isNull(storyOutlines.deletedAt)))
      .limit(1)
    if (outlineRows.length === 0) return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "剧集不存在"), { status: 404 })

    const rows = await db
      .select({
        id: videoCanvasGraphs.id,
        version: videoCanvasGraphs.version,
        graphJson: videoCanvasGraphs.graphJson,
        runtimeJson: videoCanvasGraphs.runtimeJson,
        updatedAt: videoCanvasGraphs.updatedAt
      })
      .from(videoCanvasGraphs)
      .where(and(eq(videoCanvasGraphs.storyId, parsed.data.storyId), eq(videoCanvasGraphs.outlineId, parsed.data.outlineId), isNull(videoCanvasGraphs.deletedAt)))
      .limit(1)

    const storyMetaRows = await db
      .select({ metadata: stories.metadata })
      .from(stories)
      .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
      .limit(1)
    const canUseCopyrightLibrary = canUseCanvasPrivateCopyrightLibrary(getCanvasCopyrightReviewConfig(storyMetaRows[0]?.metadata)?.groupId ?? "")

    if (rows.length === 0) {
      const inserted = await db
        .insert(videoCanvasGraphs)
        .values({
          storyId: parsed.data.storyId,
          outlineId: parsed.data.outlineId,
          version: 1,
          graphJson: defaultGraph(),
          runtimeJson: {}
        })
        .returning({
          id: videoCanvasGraphs.id,
          version: videoCanvasGraphs.version,
          graphJson: videoCanvasGraphs.graphJson,
          runtimeJson: videoCanvasGraphs.runtimeJson,
          updatedAt: videoCanvasGraphs.updatedAt
        })

      const rec = inserted[0]
      return NextResponse.json(
        makeApiOk(traceId, {
          id: rec.id,
          storyId: parsed.data.storyId,
          outlineId: parsed.data.outlineId,
          version: rec.version,
          graph: rec.graphJson,
          runtime: rec.runtimeJson,
          updatedAt: rec.updatedAt,
          capabilities: {
            copyrightLibrary: canUseCopyrightLibrary
          }
        }),
        { status: 200 }
      )
    }

    const row = rows[0]
    const hydratedGraph = normalizeGraphForStorage(await hydrateCanvasGraphUrls({ userId, graph: row.graphJson ?? defaultGraph() }))
    return NextResponse.json(
      makeApiOk(traceId, {
        id: row.id,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId,
        version: row.version,
        graph: hydratedGraph,
        runtime: row.runtimeJson ?? {},
        updatedAt: row.updatedAt,
        capabilities: {
          copyrightLibrary: canUseCopyrightLibrary
        }
      }),
      { status: 200 }
    )
  } catch (err) {
    const msg = err instanceof Error ? err.message : "unknown"
    logger.error({ event: "canvas_graph_get_failed", module: "video/canvas", traceId, message: "读取画布 graph 失败", errorMessage: msg })
    return NextResponse.json(makeApiErr(traceId, "DB_ERROR", "数据库不可用，请稍后重试"), { status: 500 })
  }
}

export async function PATCH(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = patchSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const db = await getDb({ stories, storyOutlines, videoCanvasGraphs, videoCanvasSessions })
    const graphStats = getGraphDebugStats(parsed.data.graph)

    const storyRows = await db
      .select({ id: stories.id })
      .from(stories)
      .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
      .limit(1)
    if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

    const outlineRows = await db
      .select({ id: storyOutlines.id })
      .from(storyOutlines)
      .where(and(eq(storyOutlines.id, parsed.data.outlineId), eq(storyOutlines.storyId, parsed.data.storyId), isNull(storyOutlines.deletedAt)))
      .limit(1)
    if (outlineRows.length === 0) return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "剧集不存在"), { status: 404 })

    const sessionError = await assertCanvasSessionOwner({
      db,
      userId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      clientId: parsed.data.clientId,
      traceId,
      expectedVersion: parsed.data.expectedVersion,
      graphStats
    })
    if (sessionError) return sessionError

    const prevRows = await db
      .select({ id: videoCanvasGraphs.id, version: videoCanvasGraphs.version })
      .from(videoCanvasGraphs)
      .where(and(eq(videoCanvasGraphs.storyId, parsed.data.storyId), eq(videoCanvasGraphs.outlineId, parsed.data.outlineId), isNull(videoCanvasGraphs.deletedAt)))
      .limit(1)

    if (prevRows.length === 0) {
      if (typeof parsed.data.expectedVersion === "number" && parsed.data.expectedVersion !== 1) {
        logger.warn({
          event: "canvas_graph_patch_version_conflict",
          module: "video/canvas",
          traceId,
          message: "保存画布 graph 版本冲突：目标 graph 不存在",
          userId,
          storyId: parsed.data.storyId,
          outlineId: parsed.data.outlineId,
          clientIdTail: getClientIdTail(parsed.data.clientId),
          expectedVersion: parsed.data.expectedVersion,
          actualVersion: null,
          ...graphStats
        })
        return NextResponse.json(makeApiErr(traceId, "VERSION_CONFLICT", "版本冲突，请刷新后重试"), { status: 409 })
      }
      const inserted = await db
        .insert(videoCanvasGraphs)
        .values({
          storyId: parsed.data.storyId,
          outlineId: parsed.data.outlineId,
          version: 1,
          graphJson: normalizeGraphForStorage(parsed.data.graph),
          runtimeJson: parsed.data.runtime ?? {}
        })
        .returning({ id: videoCanvasGraphs.id, version: videoCanvasGraphs.version, updatedAt: videoCanvasGraphs.updatedAt })

      const rec = inserted[0]
      logger.info({
        event: "canvas_graph_patch_saved",
        module: "video/canvas",
        traceId,
        message: "保存画布 graph 成功：新建 graph",
        userId,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId,
        clientIdTail: getClientIdTail(parsed.data.clientId),
        expectedVersion: parsed.data.expectedVersion ?? null,
        savedVersion: rec.version,
        ...graphStats
      })
      return NextResponse.json(
        makeApiOk(traceId, {
          id: rec.id,
          storyId: parsed.data.storyId,
          outlineId: parsed.data.outlineId,
          version: rec.version,
          updatedAt: rec.updatedAt
        }),
        { status: 200 }
      )
    }

    const prev = prevRows[0]
    if (typeof parsed.data.expectedVersion === "number" && parsed.data.expectedVersion !== prev.version) {
      logger.warn({
        event: "canvas_graph_patch_version_conflict",
        module: "video/canvas",
        traceId,
        message: "保存画布 graph 版本冲突",
        userId,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId,
        clientIdTail: getClientIdTail(parsed.data.clientId),
        expectedVersion: parsed.data.expectedVersion,
        actualVersion: prev.version,
        ...graphStats
      })
      return NextResponse.json(makeApiErr(traceId, "VERSION_CONFLICT", "版本冲突，请刷新后重试"), { status: 409 })
    }

    const nextVersion = prev.version + 1
    const updated = await db
      .update(videoCanvasGraphs)
      .set({
        graphJson: normalizeGraphForStorage(parsed.data.graph),
        runtimeJson: parsed.data.runtime ?? {},
        version: nextVersion,
        updatedAt: new Date()
      })
      .where(and(eq(videoCanvasGraphs.id, prev.id), eq(videoCanvasGraphs.version, prev.version)))
      .returning({ id: videoCanvasGraphs.id, version: videoCanvasGraphs.version, updatedAt: videoCanvasGraphs.updatedAt })

    if (updated.length === 0) {
      logger.warn({
        event: "canvas_graph_patch_version_conflict",
        module: "video/canvas",
        traceId,
        message: "保存画布 graph 乐观锁更新失败",
        userId,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId,
        clientIdTail: getClientIdTail(parsed.data.clientId),
        expectedVersion: parsed.data.expectedVersion ?? null,
        actualVersion: prev.version,
        ...graphStats
      })
      return NextResponse.json(makeApiErr(traceId, "VERSION_CONFLICT", "版本冲突，请刷新后重试"), { status: 409 })
    }
    const rec = updated[0]
    logger.info({
      event: "canvas_graph_patch_saved",
      module: "video/canvas",
      traceId,
      message: "保存画布 graph 成功",
      userId,
      storyId: parsed.data.storyId,
      outlineId: parsed.data.outlineId,
      clientIdTail: getClientIdTail(parsed.data.clientId),
      expectedVersion: parsed.data.expectedVersion ?? null,
      previousVersion: prev.version,
      savedVersion: rec.version,
      ...graphStats
    })

    return NextResponse.json(
      makeApiOk(traceId, {
        id: rec.id,
        storyId: parsed.data.storyId,
        outlineId: parsed.data.outlineId,
        version: rec.version,
        updatedAt: rec.updatedAt
      }),
      { status: 200 }
    )
  } catch (err) {
    const msg = err instanceof Error ? err.message : "unknown"
    const parsedData = "data" in parsed ? parsed.data : null
    logger.error({
      event: "canvas_graph_patch_failed",
      module: "video/canvas",
      traceId,
      message: "保存画布 graph 失败",
      errorMessage: msg,
      userId,
      storyId: parsedData?.storyId ?? null,
      outlineId: parsedData?.outlineId ?? null,
      clientIdTail: getClientIdTail(parsedData?.clientId),
      expectedVersion: parsedData?.expectedVersion ?? null,
      ...(parsedData ? getGraphDebugStats(parsedData.graph) : {})
    })
    return NextResponse.json(makeApiErr(traceId, "DB_ERROR", "数据库不可用，请稍后重试"), { status: 500 })
  }
}

export async function DELETE(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    outlineId: url.searchParams.get("outlineId") ?? ""
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    await ensurePublicSchema()
    const db = await getDb({ stories, storyOutlines, videoCanvasGraphs })

    const storyRows = await db
      .select({ id: stories.id })
      .from(stories)
      .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
      .limit(1)
    if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

    const outlineRows = await db
      .select({ id: storyOutlines.id })
      .from(storyOutlines)
      .where(and(eq(storyOutlines.id, parsed.data.outlineId), eq(storyOutlines.storyId, parsed.data.storyId), isNull(storyOutlines.deletedAt)))
      .limit(1)
    if (outlineRows.length === 0) return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "剧集不存在"), { status: 404 })

    await db
      .delete(videoCanvasGraphs)
      .where(and(eq(videoCanvasGraphs.storyId, parsed.data.storyId), eq(videoCanvasGraphs.outlineId, parsed.data.outlineId), isNull(videoCanvasGraphs.deletedAt)))

    return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
  } catch (err) {
    const msg = err instanceof Error ? err.message : "unknown"
    logger.error({ event: "canvas_graph_delete_failed", module: "video/canvas", traceId, message: "删除画布 graph 失败", errorMessage: msg })
    return NextResponse.json(makeApiErr(traceId, "DB_ERROR", "数据库不可用，请稍后重试"), { status: 500 })
  }
}
