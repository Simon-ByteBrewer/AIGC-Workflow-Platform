import { normalizeMaterialMatchText, resolveBestLabelMatch } from "@/shared/quickGenerate/materialNameMatch"

export type QuickGenerateMentionKind = "role" | "scene" | "item" | "audio" | "video"

export type QuickGenerateAllowedMention = {
  name: string
  kind: QuickGenerateMentionKind
  previewUrl?: string
}

export type QuickGenerateMentionItem = QuickGenerateAllowedMention & {
  token: string
  label: string
}

export function formatMentionDisplayLabel(name: string, kind: QuickGenerateMentionKind): string {
  const normalizedName = String(name ?? "").trim()
  if (!normalizedName) return ""
  return kind === "audio" ? `${normalizedName}-音频` : normalizedName
}

function getMentionMatchAliases(item: Pick<QuickGenerateMentionItem, "name" | "kind" | "label">): string[] {
  const aliases = [
    String(item.name ?? "").trim(),
    String(item.label ?? "").trim(),
    formatMentionDisplayLabel(item.name, item.kind)
  ].filter(Boolean)
  return Array.from(new Set(aliases))
}

export function buildToken(name: string, kind: QuickGenerateMentionKind): string {
  return `{{${kind}:${name}}}`
}

export function escapeRegExp(text: string): string {
  return String(text ?? "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
}

export function buildMentionItems(allowedMentions: QuickGenerateAllowedMention[]): QuickGenerateMentionItem[] {
  const seen = new Set<string>()
  const items: QuickGenerateMentionItem[] = []
  for (const mention of allowedMentions) {
    const name = String(mention.name ?? "").trim()
    if (!name) continue
    const kind = mention.kind
    const token = buildToken(name, kind)
    if (seen.has(token)) continue
    seen.add(token)
    items.push({
      ...mention,
      name,
      token,
      label: formatMentionDisplayLabel(name, kind)
    })
  }
  return items
}

export function parseValueTokens(
  value: string
): Array<{ kind: "text"; value: string } | { kind: "token"; token: string }> {
  const out: Array<{ kind: "text"; value: string } | { kind: "token"; token: string }> = []
  const re = /\{\{(role|scene|item|audio|video):([^}]+)\}\}/g
  let last = 0
  for (;;) {
    const match = re.exec(value)
    if (!match) break
    const start = match.index
    const end = start + match[0].length
    if (start > last) out.push({ kind: "text", value: value.slice(last, start) })
    out.push({ kind: "token", token: match[0] })
    last = end
  }
  if (last < value.length) out.push({ kind: "text", value: value.slice(last) })
  return out
}

export function parseToken(token: string): { kind: QuickGenerateMentionKind; name: string } | null {
  const match = token.match(/^\{\{(role|scene|item|audio|video):(.+)\}\}$/u)
  if (!match) return null
  const kind = match[1] as QuickGenerateMentionKind
  const name = String(match[2] ?? "").trim()
  if (!name) return null
  return { kind, name }
}

export function tokenToPlainMention(token: string): string {
  const parsed = parseToken(token)
  if (!parsed) return token
  return `@${formatMentionDisplayLabel(parsed.name, parsed.kind)}`
}

export function toDisplayText(text: string): string {
  return parseValueTokens(String(text ?? ""))
    .map((part) => (part.kind === "text" ? part.value : tokenToPlainMention(part.token)))
    .join("")
}

export function normalizePlainMentionsToTokens(value: string, items: QuickGenerateMentionItem[]): string {
  let out = String(value ?? "")
  if (!out.includes("@") || items.length === 0) return out

  const sortedAliases = items
    .flatMap((item) => getMentionMatchAliases(item).map((alias) => ({ alias, token: item.token })))
    .sort((a, b) => b.alias.length - a.alias.length)
  for (const entry of sortedAliases) {
    const pattern = new RegExp(`@${escapeRegExp(entry.alias)}(?=\\s|[，。！？、；：,.!?;:）)】」』]|$|\\n)`, "gu")
    out = out.replace(pattern, entry.token)
  }

  // Fuzzy match fallback:
  // In prod we observed mentions like "@张三" that fail exact match due to hidden chars / brackets / suffixes.
  // This pass extracts plain "@xxx" occurrences and maps them to the closest allowed mention name.
  if (!out.includes("@")) return out
  const candidates = items.flatMap((it) =>
    getMentionMatchAliases(it).map((alias) => ({
      label: alias,
      value: it.token,
      priority: it.kind === "role" ? 1 : it.kind === "scene" ? 2 : it.kind === "item" ? 3 : it.kind === "video" ? 4 : 5
    }))
  )

  // Same boundary rule as exact match: stop at whitespace / punctuation / line breaks.
  const mentionRe = /@([^\s，。！？、；：,.!?;:）)】」』\n]+)/gu
  const matches: Array<{ start: number; end: number; raw: string }> = []
  for (;;) {
    const m = mentionRe.exec(out)
    if (!m) break
    const raw = String(m[1] ?? "")
    const start = m.index
    const end = start + m[0].length
    matches.push({ start, end, raw })
  }
  if (matches.length === 0) return out

  // Replace from right to left to preserve indices.
  for (let i = matches.length - 1; i >= 0; i -= 1) {
    const m = matches[i]
    const rawName = m.raw
    const normalizedRaw = normalizeMaterialMatchText(rawName)
    if (!normalizedRaw) continue
    const best = resolveBestLabelMatch({
      query: normalizedRaw,
      candidates
    })
    if (!best?.candidate.value) continue
    out = out.slice(0, m.start) + best.candidate.value + out.slice(m.end)
  }

  return out
}

/**
 * 从用户输入文本里提取“按出现顺序”的 mention token（未匹配到素材库的会被忽略）。
 * 返回的 item 顺序用于 UI 展示（参考素材一行）。
 */
export function extractMentionItemsFromPrompt(
  value: string,
  items: QuickGenerateMentionItem[]
): QuickGenerateMentionItem[] {
  const byToken = new Map(items.map((it) => [it.token, it]))
  const normalized = normalizePlainMentionsToTokens(value, items)
  const parts = parseValueTokens(normalized)
  const out: QuickGenerateMentionItem[] = []
  const seen = new Set<string>()
  for (const part of parts) {
    if (part.kind !== "token") continue
    const it = byToken.get(part.token)
    if (!it) continue
    if (seen.has(it.token)) continue
    seen.add(it.token)
    out.push(it)
  }
  return out
}

/**
 * 从提示词中提取“按出现顺序”的 mention 项，保留重复项。
 */
export function extractMentionItemOccurrencesFromPrompt(
  value: string,
  items: QuickGenerateMentionItem[]
): QuickGenerateMentionItem[] {
  const byToken = new Map(items.map((it) => [it.token, it]))
  const normalized = normalizePlainMentionsToTokens(value, items)
  const parts = parseValueTokens(normalized)
  const out: QuickGenerateMentionItem[] = []
  for (const part of parts) {
    if (part.kind !== "token") continue
    const it = byToken.get(part.token)
    if (!it) continue
    out.push(it)
  }
  return out
}
