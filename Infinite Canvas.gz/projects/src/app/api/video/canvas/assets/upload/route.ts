import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import crypto from "node:crypto"
import sharp from "sharp"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { stories, videoCanvasAssets } from "@/shared/schema"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { logger } from "@/shared/logger"

export const runtime = "nodejs"

const formSchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

const CANVAS_UPLOAD_CHUNK_SIZE_BYTES = 5 * 1024 * 1024
const CANVAS_UPLOAD_MAX_TOTAL_BYTES = 50 * 1024 * 1024

function inferKindFromMime(mime: string): "image" | "video" | "audio" | null {
  const t = (mime ?? "").toLowerCase()
  if (t.startsWith("image/")) return "image"
  if (t.startsWith("video/")) return "video"
  if (t.startsWith("audio/")) return "audio"
  return null
}

function guessFileExt(fileName: string, mimeType: string): string {
  const fromName = (() => {
    const raw = (fileName ?? "").trim()
    if (!raw) return ""
    const idx = raw.lastIndexOf(".")
    if (idx <= 0 || idx >= raw.length - 1) return ""
    return raw.slice(idx + 1).toLowerCase()
  })()
  if (fromName) return fromName

  const t = (mimeType ?? "").toLowerCase()
  if (t === "image/jpeg") return "jpg"
  if (t === "image/png") return "png"
  if (t === "image/webp") return "webp"
  if (t === "image/gif") return "gif"
  if (t === "video/mp4") return "mp4"
  if (t === "video/webm") return "webm"
  if (t === "audio/mpeg") return "mp3"
  if (t === "audio/wav") return "wav"
  if (t === "audio/ogg") return "ogg"
  return "bin"
}

/**
 * 将任意输入字符串安全化为 S3 key 的一个 segment（避免出现斜杠、空白等）。
 */
function safeKeySegment(input: string, maxLen: number): string {
  const s = (input ?? "").toString().trim()
  if (!s) return "na"
  return s.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, Math.max(1, maxLen)) || "na"
}

function buildCanvasUploadKey(input: { storyId: string; suffix: string; ext: string }): string {
  const ts = Date.now()
  const rand = crypto.randomBytes(4).toString("hex")
  const safeStoryId = safeKeySegment(input.storyId, 64)
  const safeSuffix = safeKeySegment(input.suffix, 64)
  const safeExt = (input.ext ?? "bin").replace(/[^a-zA-Z0-9]/g, "").slice(0, 12) || "bin"
  return `canvas/${safeStoryId}/${ts}-${rand}-${safeSuffix}.${safeExt}`
}

/**
 * 生成分片的临时 key（用于 action=part 上传）。
 * 注意：该 key 仅用于临时分片落地，后续会在 complete 阶段合并为最终对象。
 */
function buildCanvasChunkKey(input: { storyId: string; uploadId: string; chunkIndex: number }): string {
  const safeStoryId = safeKeySegment(input.storyId, 64)
  const safeUploadId = safeKeySegment(input.uploadId, 80)
  const idx = Number.isFinite(input.chunkIndex) ? Math.max(0, Math.trunc(input.chunkIndex)) : 0
  const idxText = String(idx).padStart(6, "0")
  return `tmp/canvas-upload/${safeStoryId}/${safeUploadId}/part-${idxText}.bin`
}

/**
 * 通过 storageKey 获取可访问 URL 并下载为 Buffer。
 * 这里使用 resolveStorageUrl + fetch，避免依赖底层 SDK 是否提供 getObject 能力。
 */
async function downloadStorageKeyAsBuffer(storage: any, storageKey: string, timeoutMs: number): Promise<Buffer> {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), Math.max(1000, Math.floor(timeoutMs)))
  try {
    const signed = await resolveStorageUrl(storage, storageKey)
    const res = await fetch(signed, { signal: controller.signal }).catch(() => null)
    if (!res || !res.ok) throw new Error(`download failed (${res?.status ?? "no-response"})`)
    const ab = await res.arrayBuffer()
    return Buffer.from(ab)
  } finally {
    clearTimeout(timer)
  }
}

/**
 * 尝试删除临时分片对象（若底层 storage SDK 未暴露删除方法，则直接跳过）。
 */
async function tryDeleteStorageKeys(storage: any, keys: string[]): Promise<void> {
  const candidate =
    (storage && typeof storage.deleteFile === "function" ? storage.deleteFile.bind(storage) : null) ||
    (storage && typeof storage.deleteObject === "function" ? storage.deleteObject.bind(storage) : null) ||
    (storage && typeof storage.removeFile === "function" ? storage.removeFile.bind(storage) : null)
  if (!candidate) return
  for (const key of keys) {
    const k = String(key ?? "").trim()
    if (!k) continue
    try {
      await candidate(k)
    } catch {
      // Best-effort cleanup only.
    }
  }
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let form: FormData
  try {
    form = await req.formData()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_FORM", "请求体不是合法表单"), { status: 400 })
  }

  const parsed = formSchema.safeParse({ storyId: form.get("storyId") ?? "" })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, videoCanvasAssets })

  const storyRows = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (storyRows.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的项目"), { status: 404 })

  const storage = getS3Storage()

  const actionRaw = String(form.get("action") ?? "").trim()

  // ----------------------------
  // Chunked upload: part
  // ----------------------------
  if (actionRaw === "part") {
    const partSchema = z.object({
      uploadId: z.string().trim().min(1).max(200),
      chunkIndex: z.coerce.number().int().min(0).max(200_000),
      totalChunks: z.coerce.number().int().min(1).max(200_000),
      fileName: z.string().trim().max(500).optional(),
      mimeType: z.string().trim().max(200).optional(),
      totalSizeBytes: z.coerce.number().int().min(0).max(2_000_000_000).optional()
    })
    const parsedPart = partSchema.safeParse({
      uploadId: form.get("uploadId") ?? "",
      chunkIndex: form.get("chunkIndex") ?? "",
      totalChunks: form.get("totalChunks") ?? "",
      fileName: form.get("fileName") ?? undefined,
      mimeType: form.get("mimeType") ?? undefined,
      totalSizeBytes: form.get("totalSizeBytes") ?? undefined
    })
    if (!parsedPart.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
    if (typeof parsedPart.data.totalSizeBytes === "number" && parsedPart.data.totalSizeBytes > CANVAS_UPLOAD_MAX_TOTAL_BYTES) {
      return NextResponse.json(makeApiErr(traceId, "FILE_TOO_LARGE", `单文件大小不能超过 ${Math.floor(CANVAS_UPLOAD_MAX_TOTAL_BYTES / 1024 / 1024)}MB`), { status: 400 })
    }

    const file = form.get("file")
    if (!(file instanceof File)) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少文件分片"), { status: 400 })
    if (file.size > CANVAS_UPLOAD_CHUNK_SIZE_BYTES) {
      return NextResponse.json(makeApiErr(traceId, "CHUNK_TOO_LARGE", "单个分片不能超过 5MB"), { status: 400 })
    }

    const mimeType = (parsedPart.data.mimeType ?? file.type ?? "").trim().toLowerCase()
    const kind = inferKindFromMime(mimeType)
    if (!kind) return NextResponse.json(makeApiErr(traceId, "INVALID_FILE", "仅支持上传图片 / 视频 / 音频文件"), { status: 400 })

    let bytes: Buffer
    try {
      bytes = Buffer.from(await file.arrayBuffer())
    } catch {
      return NextResponse.json(makeApiErr(traceId, "READ_FAILED", "读取文件失败"), { status: 400 })
    }

    const partKey = buildCanvasChunkKey({
      storyId: parsed.data.storyId,
      uploadId: parsedPart.data.uploadId,
      chunkIndex: parsedPart.data.chunkIndex
    })

    try {
      const uploadedKey = await storage.uploadFile({
        fileContent: bytes,
        fileName: partKey,
        contentType: "application/octet-stream"
      })
      return NextResponse.json(
        makeApiOk(traceId, {
          uploadId: parsedPart.data.uploadId,
          chunkIndex: parsedPart.data.chunkIndex,
          totalChunks: parsedPart.data.totalChunks,
          storageKey: uploadedKey
        }),
        { status: 200 }
      )
    } catch (e) {
      const anyErr = e as { message?: string }
      logger.error({
        event: "canvas_asset_upload_part_failed",
        module: "video/canvas",
        traceId,
        message: "画布资源分片上传失败",
        errorMessage: anyErr?.message ?? "unknown"
      })
      return NextResponse.json(makeApiErr(traceId, "UPLOAD_FAILED", "上传失败，请稍后重试"), { status: 500 })
    }
  }

  // ----------------------------
  // Chunked upload: complete
  // ----------------------------
  if (actionRaw === "complete") {
    const completeSchema = z.object({
      uploadId: z.string().trim().min(1).max(200),
      totalChunks: z.coerce.number().int().min(1).max(200_000),
      fileName: z.string().trim().min(1).max(500),
      mimeType: z.string().trim().min(1).max(200),
      totalSizeBytes: z.coerce.number().int().min(0).max(2_000_000_000).optional(),
      chunkStorageKeys: z.string().trim().max(2_000_000).optional()
    })
    const parsedComplete = completeSchema.safeParse({
      uploadId: form.get("uploadId") ?? "",
      totalChunks: form.get("totalChunks") ?? "",
      fileName: form.get("fileName") ?? "",
      mimeType: form.get("mimeType") ?? "",
      totalSizeBytes: form.get("totalSizeBytes") ?? undefined,
      chunkStorageKeys: form.get("chunkStorageKeys") ?? undefined
    })
    if (!parsedComplete.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
    if (typeof parsedComplete.data.totalSizeBytes === "number" && parsedComplete.data.totalSizeBytes > CANVAS_UPLOAD_MAX_TOTAL_BYTES) {
      return NextResponse.json(makeApiErr(traceId, "FILE_TOO_LARGE", `单文件大小不能超过 ${Math.floor(CANVAS_UPLOAD_MAX_TOTAL_BYTES / 1024 / 1024)}MB`), { status: 400 })
    }

    const mimeType = parsedComplete.data.mimeType.trim().toLowerCase()
    const kind = inferKindFromMime(mimeType)
    if (!kind) return NextResponse.json(makeApiErr(traceId, "INVALID_FILE", "仅支持上传图片 / 视频 / 音频文件"), { status: 400 })

    /**
     * 优先使用前端回传的真实分片 storageKey 列表，避免底层 SDK 对 key 做了重写导致 404。
     * 如果前端未回传，则回退到按 uploadId+chunkIndex 推导的约定 key。
     */
    const partKeys: string[] = (() => {
      const raw = String(parsedComplete.data.chunkStorageKeys ?? "").trim()
      if (!raw) return []
      try {
        const arr = JSON.parse(raw) as unknown
        if (!Array.isArray(arr)) return []
        const keys = arr.map((x) => (typeof x === "string" ? x.trim() : "")).filter(Boolean)
        if (keys.length !== parsedComplete.data.totalChunks) return []
        return keys
      } catch {
        return []
      }
    })()

    const needDerivedKeys = partKeys.length === 0
    const effectivePartKeys: string[] = needDerivedKeys
      ? Array.from({ length: parsedComplete.data.totalChunks }, (_, i) =>
          buildCanvasChunkKey({ storyId: parsed.data.storyId, uploadId: parsedComplete.data.uploadId, chunkIndex: i })
        )
      : partKeys
    const bufs: Buffer[] = []
    let total = 0
    try {
      for (let i = 0; i < effectivePartKeys.length; i += 1) {
        const key = effectivePartKeys[i] ?? ""
        const b = await downloadStorageKeyAsBuffer(storage as any, key, 60_000)
        total += b.length
        if (total > CANVAS_UPLOAD_MAX_TOTAL_BYTES) {
          return NextResponse.json(
            makeApiErr(traceId, "FILE_TOO_LARGE", `单文件大小不能超过 ${Math.floor(CANVAS_UPLOAD_MAX_TOTAL_BYTES / 1024 / 1024)}MB`),
            { status: 400 }
          )
        }
        bufs.push(b)
      }
    } catch (e) {
      const anyErr = e as { message?: string }
      logger.error({
        event: "canvas_asset_upload_complete_download_failed",
        module: "video/canvas",
        traceId,
        message: "画布资源分片合并阶段下载失败",
        errorMessage: anyErr?.message ?? "unknown",
        uploadId: parsedComplete.data.uploadId,
        usedDerivedKeys: needDerivedKeys,
      })
      return NextResponse.json(makeApiErr(traceId, "UPLOAD_FAILED", "上传失败，请稍后重试"), { status: 500 })
    }


    const bytes = Buffer.concat(bufs)
    const expected = typeof parsedComplete.data.totalSizeBytes === "number" ? parsedComplete.data.totalSizeBytes : null
    if (expected != null && expected !== bytes.length) {
      return NextResponse.json(makeApiErr(traceId, "BODY_INCOMPLETE", "分片合并后文件大小不匹配，请重试"), { status: 400 })
    }

    const sha256 = crypto.createHash("sha256").update(bytes).digest("hex")
    const ext = guessFileExt(parsedComplete.data.fileName, mimeType)
    const storageKey = buildCanvasUploadKey({ storyId: parsed.data.storyId, suffix: "original", ext })
    let previewStorageKey: string | null = null

    try {
      const uploadedOriginalKey = await storage.uploadFile({
        fileContent: bytes,
        fileName: storageKey,
        contentType: mimeType || "application/octet-stream"
      })

      let width: number | null = null
      let height: number | null = null
      if (kind === "image") {
        try {
          const meta = await sharp(bytes).metadata()
          width = typeof meta.width === "number" ? meta.width : null
          height = typeof meta.height === "number" ? meta.height : null
        } catch {}

        try {
          const previewBytes = await sharp(bytes)
            .resize({ width: 512, height: 512, fit: "inside", withoutEnlargement: true })
            .jpeg({ quality: 86 })
            .toBuffer()
          const previewKey = buildCanvasUploadKey({ storyId: parsed.data.storyId, suffix: "preview", ext: "jpg" })
          previewStorageKey = await storage.uploadFile({ fileContent: previewBytes, fileName: previewKey, contentType: "image/jpeg" })
        } catch {}
      }

      const inserted = await db
        .insert(videoCanvasAssets)
        .values({
          storyId: parsed.data.storyId,
          kind,
          storageKey: uploadedOriginalKey,
          previewStorageKey,
          mimeType: mimeType || null,
          sizeBytes: bytes.length,
          sha256,
          width,
          height,
          durationMs: null,
          source: "upload",
          sourceRef: { fileName: parsedComplete.data.fileName || null, uploadId: parsedComplete.data.uploadId, chunked: true },
          updatedAt: new Date()
        } as any)
        .returning({ id: videoCanvasAssets.id })

      const id = inserted[0]?.id ? String(inserted[0].id) : ""
      if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "写入资源失败"), { status: 500 })

      const url = await resolveStorageUrl(storage, uploadedOriginalKey)
      const previewUrl = previewStorageKey ? await resolveStorageUrl(storage, previewStorageKey) : ""

      // Best-effort cleanup for temp chunks. If SDK doesn't support deletion, rely on bucket lifecycle.
      void tryDeleteStorageKeys(storage as any, effectivePartKeys)

      return NextResponse.json(
        makeApiOk(traceId, {
          id,
          kind,
          assetId: `canvas:${id}`,
          url,
          previewUrl: previewUrl || undefined,
          storageKey: uploadedOriginalKey,
          previewStorageKey: previewStorageKey || undefined,
          mimeType: mimeType || undefined,
          sizeBytes: bytes.length
        }),
        { status: 200 }
      )
    } catch (e) {
      const anyErr = e as { message?: string }
      logger.error({
        event: "canvas_asset_upload_complete_failed",
        module: "video/canvas",
        traceId,
        message: "画布资源分片合并上传失败",
        errorMessage: anyErr?.message ?? "unknown"
      })
      return NextResponse.json(makeApiErr(traceId, "UPLOAD_FAILED", "上传失败，请稍后重试"), { status: 500 })
    }
  }

  if (actionRaw) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  }

  // ----------------------------
  // Legacy single-file upload
  // ----------------------------
  const file = form.get("file")
  if (!(file instanceof File)) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少文件"), { status: 400 })

  const mimeType = (file.type ?? "").trim().toLowerCase()
  const kind = inferKindFromMime(mimeType)
  if (!kind) return NextResponse.json(makeApiErr(traceId, "INVALID_FILE", "仅支持上传图片 / 视频 / 音频文件"), { status: 400 })

  let bytes: Buffer
  try {
    bytes = Buffer.from(await file.arrayBuffer())
  } catch {
    return NextResponse.json(makeApiErr(traceId, "READ_FAILED", "读取文件失败"), { status: 400 })
  }

  const sha256 = crypto.createHash("sha256").update(bytes).digest("hex")
  const ext = guessFileExt(file.name, mimeType)
  const storageKey = buildCanvasUploadKey({ storyId: parsed.data.storyId, suffix: "original", ext })
  let previewStorageKey: string | null = null

  try {
    const uploadedOriginalKey = await storage.uploadFile({
      fileContent: bytes,
      fileName: storageKey,
      contentType: mimeType || "application/octet-stream"
    })

    let width: number | null = null
    let height: number | null = null
    if (kind === "image") {
      try {
        const meta = await sharp(bytes).metadata()
        width = typeof meta.width === "number" ? meta.width : null
        height = typeof meta.height === "number" ? meta.height : null
      } catch {}

      try {
        const previewBytes = await sharp(bytes).resize({ width: 512, height: 512, fit: "inside", withoutEnlargement: true }).jpeg({ quality: 86 }).toBuffer()
        const previewKey = buildCanvasUploadKey({ storyId: parsed.data.storyId, suffix: "preview", ext: "jpg" })
        previewStorageKey = await storage.uploadFile({ fileContent: previewBytes, fileName: previewKey, contentType: "image/jpeg" })
      } catch {}
    }

    const inserted = await db
      .insert(videoCanvasAssets)
      .values({
        storyId: parsed.data.storyId,
        kind,
        storageKey: uploadedOriginalKey,
        previewStorageKey,
        mimeType: mimeType || null,
        sizeBytes: file.size,
        sha256,
        width,
        height,
        durationMs: null,
        source: "upload",
        sourceRef: { fileName: file.name || null },
        updatedAt: new Date()
      } as any)
      .returning({ id: videoCanvasAssets.id })

    const id = inserted[0]?.id ? String(inserted[0].id) : ""
    if (!id) return NextResponse.json(makeApiErr(traceId, "CREATE_FAILED", "写入资源失败"), { status: 500 })

    const url = await resolveStorageUrl(storage, uploadedOriginalKey)
    const previewUrl = previewStorageKey ? await resolveStorageUrl(storage, previewStorageKey) : ""

    return NextResponse.json(
      makeApiOk(traceId, {
        id,
        kind,
        assetId: `canvas:${id}`,
        url,
        previewUrl: previewUrl || undefined,
        storageKey: uploadedOriginalKey,
        previewStorageKey: previewStorageKey || undefined,
        mimeType: mimeType || undefined,
        sizeBytes: file.size
      }),
      { status: 200 }
    )
  } catch (e) {
    const anyErr = e as { message?: string }
    logger.error({
      event: "canvas_asset_upload_failed",
      module: "video/canvas",
      traceId,
      message: "画布资源上传失败",
      errorMessage: anyErr?.message ?? "unknown"
    })
    return NextResponse.json(makeApiErr(traceId, "UPLOAD_FAILED", "上传失败，请稍后重试"), { status: 500 })
  }
}
