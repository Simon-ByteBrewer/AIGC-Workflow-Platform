import { NextResponse } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { SESSION_COOKIE_NAME } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { AuthService } from "@/server/domains/auth/services/authService"
import { getCurrentUserProfile } from "@/server/domains/auth/services/currentUserProfileService"
import { ServiceError } from "@/server/shared/errors"

export const runtime = "nodejs"

/**
 * 获取当前登录用户的个人中心资料。
 * @param {Request} req - HTTP 请求
 * @returns {Promise<Response>} JSON 响应
 */
export async function GET(req: Request): Promise<Response> {
  const traceId = getTraceId(req.headers)

  logger.info({
    event: "auth_profile_request_start",
    module: "auth",
    traceId,
    message: "开始获取个人中心资料"
  })

  const cookieHeader = req.headers.get("cookie") ?? ""
  const token = cookieHeader
    .split(";")
    .map((value) => value.trim())
    .find((value) => value.startsWith(`${SESSION_COOKIE_NAME}=`))
    ?.slice(`${SESSION_COOKIE_NAME}=`.length)

  try {
    const user = await AuthService.getCurrentUser(token, true, traceId)
    const profile = await getCurrentUserProfile(user.id, traceId)
    return NextResponse.json(makeApiOk(traceId, { profile }))
  } catch (error) {
    if (error instanceof ServiceError) {
      const status = ["AUTH_UNAUTHENTICATED", "AUTH_INVALID_SESSION", "AUTH_USER_NOT_FOUND", "AUTH_DISABLED"].includes(error.code) ? 401 : 500
      return NextResponse.json(makeApiErr(traceId, error.code, error.message), { status })
    }

    const anyErr = error as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "auth_profile_request_failed",
      module: "auth",
      traceId,
      message: "获取个人中心资料失败",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "AUTH_PROFILE_FAILED", "获取个人中心资料失败，请稍后重试"), { status: 500 })
  }
}
