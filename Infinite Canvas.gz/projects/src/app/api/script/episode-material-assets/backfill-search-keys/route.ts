import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq, inArray, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { episodeMaterialAssets } from "@/shared/schema/generation"
import { stories } from "@/shared/schema/story"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200)
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialAssets })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const roleNameExpr = sql`btrim(coalesce(${episodeMaterialAssets.roleName}, ${episodeMaterialAssets.name}))`
  const makeupExpr = sql`btrim(coalesce(${episodeMaterialAssets.makeupName}, ''))`
  const costumeExpr = sql`btrim(coalesce(${episodeMaterialAssets.costumeName}, ''))`
  const keyExpr = sql`concat_ws('-', ${roleNameExpr}, ${makeupExpr}, ${costumeExpr})`

  const touched = await db
    .update(episodeMaterialAssets)
    .set({
      meta: sql`jsonb_set(${episodeMaterialAssets.meta}, '{searchKey}', to_jsonb(${keyExpr}), true)`
    })
    .where(
      and(
        eq(episodeMaterialAssets.storyId, parsed.data.storyId),
        inArray(episodeMaterialAssets.kind, ["role", "character"]),
        sql`coalesce(${episodeMaterialAssets.meta}->>'searchKey', '') = ''`,
        sql`${roleNameExpr} <> ''`
      )
    )
    .returning({ id: episodeMaterialAssets.id })

  return NextResponse.json(makeApiOk(traceId, { storyId: parsed.data.storyId, updated: touched.length }), { status: 200 })
}

