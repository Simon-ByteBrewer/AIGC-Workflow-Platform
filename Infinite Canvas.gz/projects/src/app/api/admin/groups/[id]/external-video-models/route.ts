import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { eq, inArray, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getExternalVideoModelLabel, normalizeExternalVideoModelCode } from "@/shared/video/externalVideoModels"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { auditLogs, groupExternalVideoModels, userGroups } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { isExternalVideoModelEnabled } from "@/server/domains/video/integrations/klingOmniVideoProvider"

export const runtime = "nodejs"

function isRelationMissingError(error: unknown, relationName: string): boolean {
  const anyError = error as { code?: string; message?: string }
  return anyError?.code === "42P01" && String(anyError?.message ?? "").includes(relationName)
}

function toRouteErrorResponse(traceId: string, error: unknown): Response {
  if (isRelationMissingError(error, "group_external_video_models")) {
    return NextResponse.json(
      makeApiErr(traceId, "DB_SCHEMA_NOT_READY", "外部视频模型表尚未创建，请先执行 npm run db:push"),
      { status: 500 }
    )
  }
  const anyError = error as { message?: string }
  return NextResponse.json(makeApiErr(traceId, "DB_ERROR", anyError?.message ?? "外部视频模型接口执行失败"), { status: 500 })
}

function maskApiKey(value: string): string {
  if (!value) return ""
  if (value.length <= 8) return `${value.slice(0, 2)}***${value.slice(-2)}`
  return `${value.slice(0, 4)}***${value.slice(-4)}`
}

const upsertSchema = z.object({
  modelName: z.string().trim().min(1).max(100),
  apiKey: z.string().trim().min(1).max(500),
  enabled: z.boolean().optional()
})

const toggleSchema = z.object({
  modelName: z.string().trim().min(1).max(100),
  enabled: z.boolean()
})

const deleteSchema = z.object({
  modelName: z.string().trim().min(1).max(100)
})

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }
    if (!isExternalVideoModelEnabled()) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部视频模型接入"), { status: 404 })
    }

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })

    await ensurePublicSchema()
    const db = await getDb({ userGroups, groupExternalVideoModels })
    const group = await db.select({ id: userGroups.id }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
    if (!group[0]?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

    const rows = await db
      .select({
        modelName: groupExternalVideoModels.modelName,
        isEnabled: groupExternalVideoModels.isEnabled,
        apiKey: groupExternalVideoModels.apiKey,
        updatedAt: groupExternalVideoModels.updatedAt
      })
      .from(groupExternalVideoModels)
      .where(eq(groupExternalVideoModels.groupId, id))

    const items = Array.from(
      new Map(
        rows
          .sort((a, b) => {
            const at = a.updatedAt instanceof Date ? a.updatedAt.getTime() : 0
            const bt = b.updatedAt instanceof Date ? b.updatedAt.getTime() : 0
            return bt - at
          })
          .map((row) => {
            const canonicalModelName = normalizeExternalVideoModelCode(row.modelName)
            if (!canonicalModelName) return null
            return [
              canonicalModelName,
              {
                modelName: canonicalModelName,
                label: getExternalVideoModelLabel(canonicalModelName),
                enabled: row.isEnabled,
                apiKeyConfigured: Boolean(row.apiKey),
                apiKeyMasked: row.apiKey ? maskApiKey(row.apiKey) : null
              }
            ] as const
          })
          .filter(Boolean) as Array<readonly [string, { modelName: string; label: string; enabled: boolean; apiKeyConfigured: boolean; apiKeyMasked: string | null }]>
      ).values()
    ).sort((a, b) => a.modelName.localeCompare(b.modelName))

    return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
  } catch (error) {
    return toRouteErrorResponse(traceId, error)
  }
}

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }
    if (!isExternalVideoModelEnabled()) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部视频模型接入"), { status: 404 })
    }

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
    const parsed = upsertSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ userGroups, auditLogs, groupExternalVideoModels })
    const group = await db.select({ id: userGroups.id }).from(userGroups).where(eq(userGroups.id, id)).limit(1)
    if (!group[0]?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

    const now = new Date()
    const modelName = normalizeExternalVideoModelCode(parsed.data.modelName)
    if (!modelName) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "不支持的外部视频模型"), { status: 400 })
    }
    const apiKey = parsed.data.apiKey.trim()
    const enabled = parsed.data.enabled ?? true

    await db
      .insert(groupExternalVideoModels)
      .values({
        groupId: id,
        modelName,
        apiKey,
        isEnabled: enabled,
        createdAt: now,
        updatedAt: now,
        createdBy: actor.userId,
        updatedBy: actor.userId
      })
      .onConflictDoUpdate({
        target: [groupExternalVideoModels.groupId, groupExternalVideoModels.modelName],
        set: {
          apiKey,
          isEnabled: enabled,
          updatedAt: now,
          updatedBy: actor.userId
        }
      })

    await db.execute(sql`
      insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
      values (
        ${actor.userId},
        'user_group.external_video_model.upsert',
        'user_group',
        ${id},
        null,
        '{}'::jsonb,
        ${JSON.stringify({ groupId: id, modelName, enabled, apiKeyConfigured: true })}::jsonb,
        ${actor.ip},
        ${actor.userAgent},
        ${traceId}
      )
    `)

    return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
  } catch (error) {
    return toRouteErrorResponse(traceId, error)
  }
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }
    if (!isExternalVideoModelEnabled()) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部视频模型接入"), { status: 404 })
    }

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
    const parsed = toggleSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ groupExternalVideoModels, auditLogs })
    const modelName = normalizeExternalVideoModelCode(parsed.data.modelName)
    if (!modelName) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "不支持的外部视频模型"), { status: 400 })
    }
    const enabled = parsed.data.enabled
    const now = new Date()

    const rows = await db
      .select({ id: groupExternalVideoModels.id, modelName: groupExternalVideoModels.modelName })
      .from(groupExternalVideoModels)
      .where(eq(groupExternalVideoModels.groupId, id))
    const targetIds = rows.filter((item) => normalizeExternalVideoModelCode(item.modelName) === modelName).map((item) => item.id)
    if (targetIds.length === 0) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部视频模型不存在"), { status: 404 })
    }
    const updated = await db
      .update(groupExternalVideoModels)
      .set({ isEnabled: enabled, updatedAt: now, updatedBy: actor.userId })
      .where(inArray(groupExternalVideoModels.id, targetIds))
      .returning({ modelName: groupExternalVideoModels.modelName })

    if (!updated[0]?.modelName) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部视频模型不存在"), { status: 404 })
    }

    await db.execute(sql`
      insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
      values (
        ${actor.userId},
        'user_group.external_video_model.toggle',
        'user_group',
        ${id},
        null,
        ${JSON.stringify({ groupId: id, modelName })}::jsonb,
        ${JSON.stringify({ groupId: id, modelName, enabled })}::jsonb,
        ${actor.ip},
        ${actor.userAgent},
        ${traceId}
      )
    `)

    return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
  } catch (error) {
    return toRouteErrorResponse(traceId, error)
  }
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }
    if (!isExternalVideoModelEnabled()) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未开启外部视频模型接入"), { status: 404 })
    }

    const { id } = await ctx.params
    if (!id?.trim()) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
    const parsed = deleteSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ groupExternalVideoModels, auditLogs })
    const modelName = normalizeExternalVideoModelCode(parsed.data.modelName)
    if (!modelName) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "不支持的外部视频模型"), { status: 400 })
    }

    const rows = await db
      .select({ id: groupExternalVideoModels.id, modelName: groupExternalVideoModels.modelName })
      .from(groupExternalVideoModels)
      .where(eq(groupExternalVideoModels.groupId, id))
    const targetIds = rows.filter((item) => normalizeExternalVideoModelCode(item.modelName) === modelName).map((item) => item.id)
    if (targetIds.length === 0) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部视频模型不存在"), { status: 404 })
    }
    const deleted = await db
      .delete(groupExternalVideoModels)
      .where(inArray(groupExternalVideoModels.id, targetIds))
      .returning({ modelName: groupExternalVideoModels.modelName })

    if (!deleted[0]?.modelName) {
      return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "外部视频模型不存在"), { status: 404 })
    }

    await db.execute(sql`
      insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
      values (
        ${actor.userId},
        'user_group.external_video_model.delete',
        'user_group',
        ${id},
        null,
        ${JSON.stringify({ groupId: id, modelName })}::jsonb,
        '{}'::jsonb,
        ${actor.ip},
        ${actor.userAgent},
        ${traceId}
      )
    `)

    return NextResponse.json(makeApiOk(traceId, { ok: true }), { status: 200 })
  } catch (error) {
    return toRouteErrorResponse(traceId, error)
  }
}
