import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { adminPromptPresets, groupPromptBindings } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { listAdminPromptPresets, replaceAdminPromptPresets } from "@/server/domains/admin/groupPromptAccess"

export const runtime = "nodejs"

const putSchema = z
  .object({
    items: z
      .array(
        z.object({
          id: z.string().trim().min(1).max(200).optional(),
          name: z.string().trim().min(1).max(100),
          content: z.string().trim().min(1).max(20_000)
        })
      )
      .max(200)
  })
  .strict()

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  await ensurePublicSchema()
  const db = await getDb({ adminPromptPresets, groupPromptBindings })
  const items = await listAdminPromptPresets(db)
  return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
}

export async function PUT(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
  }

  const parsed = putSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ adminPromptPresets, groupPromptBindings })
  const items = await replaceAdminPromptPresets({
    db,
    actorUserId: actor.userId,
    items: parsed.data.items
  })
  return NextResponse.json(makeApiOk(traceId, { items }), { status: 200 })
}
