import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { eq, inArray, sql } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { getDb } from "@/server/db/getDb"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { auditLogs, userModelBindings, userModelCredentials, userSecurity, users } from "@/shared/schema"
import { canManageTargetUser, requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { updateUserModelAccess, userModelAccessUpdateSchema } from "@/server/domains/admin/userModelAccess"

export const runtime = "nodejs"

const bodySchema = z.object({
  userIds: z.array(z.string().trim().min(1).max(200)).min(1).max(200),
  modelAccess: userModelAccessUpdateSchema
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "仅超级管理员可批量配置模型"), { status: 403 })
  }

  const parsed = bodySchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
  }

  const userIds = Array.from(new Set(parsed.data.userIds.map((s) => s.trim()).filter(Boolean)))
  if (userIds.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "未选择账号"), { status: 400 })
  }

  await ensurePublicSchema()
  const db = await getDb({ users, userSecurity, auditLogs, userModelCredentials, userModelBindings })

  // Optional guard: filter out non-existent ids to avoid confusing UI.
  const existing = await db.select({ id: users.id }).from(users).where(inArray(users.id, userIds))
  const existingIds = new Set(existing.map((r) => r.id))
  const targetIds = userIds.filter((id) => existingIds.has(id))

  const results: Array<{ userId: string; ok: boolean; error?: { code: string; message: string } }> = []

  const targets = await db
    .select({
      userId: users.id,
      roleKey: userSecurity.roleKey,
      groupId: userSecurity.groupId
    })
    .from(users)
    .leftJoin(userSecurity, eq(userSecurity.userId, users.id))
    .where(inArray(users.id, targetIds))

  for (const userId of targetIds) {
    try {
      const t = targets.find((x) => x.userId === userId)
      const targetGroupId = t?.groupId ?? null

      if (!canManageTargetUser(actor, { groupId: targetGroupId })) {
        results.push({ userId, ok: false, error: { code: "FORBIDDEN", message: "无权限操作该账号" } })
        continue
      }
      const { before, after } = await updateUserModelAccess({
        db,
        userId,
        actorUserId: actor.userId,
        traceId,
        data: parsed.data.modelAccess
      })

      await db.execute(sql`
        insert into public.audit_logs (actor_user_id, action, target_type, target_id, target_user_id, before, after, ip, user_agent, trace_id)
        values (
          ${actor.userId},
          'user.model_access.batch_update',
          'user',
          ${userId},
          ${userId},
          ${JSON.stringify({ id: userId, modelAccess: before })}::jsonb,
          ${JSON.stringify({ id: userId, modelAccess: after })}::jsonb,
          ${actor.ip},
          ${actor.userAgent},
          ${traceId}
        )
      `)

      results.push({ userId, ok: true })
    } catch (e) {
      const anyErr = e as { message?: string }
      results.push({ userId, ok: false, error: { code: "BATCH_UPDATE_FAILED", message: anyErr?.message ?? "批量配置失败" } })
    }
  }

  const unknownIds = userIds.filter((id) => !existingIds.has(id))
  for (const userId of unknownIds) {
    results.push({ userId, ok: false, error: { code: "NOT_FOUND", message: "账号不存在" } })
  }

  const okCount = results.filter((r) => r.ok).length
  const failCount = results.length - okCount

  return NextResponse.json(makeApiOk(traceId, { okCount, failCount, results }), { status: 200 })
}
