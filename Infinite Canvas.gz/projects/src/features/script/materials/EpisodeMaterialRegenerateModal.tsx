"use client"

import { useCallback, useEffect, useMemo, useState, type ReactElement } from "react"
import { readAcceptedJobIdFromStream } from "@/shared/readAcceptedJobIdFromStream"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"
import type { MaterialAsset } from "./types"
import styles from "./EpisodeMaterialGalleryPage.module.css"

type Props = {
  storyId: string
  asset: MaterialAsset
  onClose: () => void
  onSubmitted: () => void
}

function kindLabel(kind: string): string {
  const k = (kind ?? "").trim().toLowerCase()
  if (k === "scene") return "场景"
  if (k === "role" || k === "character") return "人物"
  if (k === "item" || k === "prop" || k === "object") return "物品"
  return kind || "未知"
}

export function EpisodeMaterialRegenerateModal({ storyId, asset, onClose, onSubmitted }: Props): ReactElement {
  const sid = (storyId ?? "").trim()
  const [editPrompt, setEditPrompt] = useState("")
  const [sceneFrontPrompt, setSceneFrontPrompt] = useState("")
  const [sceneBackPrompt, setSceneBackPrompt] = useState("")
  const [editMakeup, setEditMakeup] = useState("")
  const [editCostume, setEditCostume] = useState("")
  const [roleOptions, setRoleOptions] = useState<{ makeup: string[]; costume: string[] }>({ makeup: [], costume: [] })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    const kindLower = String(asset.kind ?? "").trim().toLowerCase()
    if (kindLower === "scene") {
      const meta = asset.meta && typeof asset.meta === "object" && !Array.isArray(asset.meta) ? (asset.meta as any) : null
      const cameraOne = typeof meta?.cameraOne === "string" ? meta.cameraOne.trim() : ""
      const cameraTwo = typeof meta?.cameraTwo === "string" ? meta.cameraTwo.trim() : ""
      const prompt = (asset.prompt ?? "").trim()
      const parts = prompt
        .split("\n")
        .map((s) => s.trim())
        .filter(Boolean)
      const descFront = cameraOne || parts[0] || ""
      const descBack = cameraTwo || parts[1] || ""
      setSceneFrontPrompt(descFront)
      setSceneBackPrompt(descBack)
      setEditPrompt("")
    } else {
      setEditPrompt((asset.prompt ?? "").trim())
      setSceneFrontPrompt("")
      setSceneBackPrompt("")
    }
    setEditMakeup((asset.makeupName ?? "").trim())
    setEditCostume((asset.costumeName ?? "").trim())
    setRoleOptions({ makeup: [], costume: [] })
  }, [asset])

  const isScene = useMemo(() => String(asset.kind ?? "").trim().toLowerCase() === "scene", [asset.kind])
  const isRole = useMemo(() => {
    const k = (asset.kind ?? "").trim().toLowerCase()
    return k === "role" || k === "character"
  }, [asset.kind])

  useEffect(() => {
    if (!sid || !isRole) return
    const roleName = (asset.roleName ?? "").trim()
    if (!roleName) return
    let cancelled = false
    void (async () => {
      try {
        const res = await fetch(
          `/api/script/episode-material-assets/options?storyId=${encodeURIComponent(sid)}&roleName=${encodeURIComponent(roleName)}`,
          { cache: "no-store" }
        )
        const json = (await res.json().catch(() => null)) as { ok: boolean; data?: { makeup?: string[]; costume?: string[] } } | null
        if (!res.ok || !json?.ok) return
        if (cancelled) return
        setRoleOptions({
          makeup: Array.isArray(json.data?.makeup) ? json.data?.makeup : [],
          costume: Array.isArray(json.data?.costume) ? json.data?.costume : []
        })
      } catch {}
    })()
    return () => {
      cancelled = true
    }
  }, [asset.roleName, isRole, sid])

  const submit = useCallback(async () => {
    if (!sid) return
    if (submitting) return
    const prompt = (isScene ? [sceneFrontPrompt, sceneBackPrompt].map((s) => s.trim()).filter(Boolean).join("\n") : editPrompt.trim()).trim()
    if (!prompt) return
    const reqMakeupName = isRole ? (editMakeup.trim() || roleOptions.makeup[0]?.trim() || undefined) : editMakeup.trim() || undefined
    const reqCostumeName = isRole ? (editCostume.trim() || roleOptions.costume[0]?.trim() || undefined) : editCostume.trim() || undefined
    setSubmitting(true)
    try {
      const res = await fetch("/api/script/episode-material-assets/regenerate/stream", {
        method: "POST",
        headers: { "content-type": "application/json", accept: "text/event-stream" },
        body: JSON.stringify({
          storyId: sid,
          assetId: asset.id,
          prompt,
          makeupName: reqMakeupName,
          costumeName: reqCostumeName
        })
      })
      if (!res.ok) {
        const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: { message?: string } } | null
        throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      }
      await readAcceptedJobIdFromStream({ res })
      onSubmitted()
      window.dispatchEvent(new Event("open_task_center"))
    } catch (e) {
      const anyErr = e as { message?: string }
      alert(anyErr?.message ?? "提交失败")
    } finally {
      setSubmitting(false)
    }
  }, [asset.id, asset.kind, asset.roleName, editCostume, editMakeup, editPrompt, isRole, isScene, onSubmitted, roleOptions.costume, roleOptions.makeup, sceneBackPrompt, sceneFrontPrompt, sid, submitting])

  const makeupValue = editMakeup || roleOptions.makeup[0] || ""
  const costumeValue = editCostume || roleOptions.costume[0] || ""
  const promptOk = isScene ? Boolean(sceneFrontPrompt.trim() || sceneBackPrompt.trim()) : Boolean(editPrompt.trim())
  const canSubmit = isRole ? promptOk && Boolean(makeupValue.trim()) && Boolean(costumeValue.trim()) : promptOk

  return (
    <div
      className={styles.modalOverlay}
      role="dialog"
      aria-modal="true"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>
            重制：{kindLabel(asset.kind)} / {asset.name}
          </div>
          <button type="button" className={styles.btn} onClick={onClose}>
            关闭
          </button>
        </div>

        {isRole ? (
          <div className={styles.row}>
            <ListboxSelect
              className={styles.btn}
              value={makeupValue}
              ariaLabel="选择妆容"
              options={roleOptions.makeup.map((v) => ({ value: v, label: v }))}
              onChange={(v) => setEditMakeup(v)}
              disabled={roleOptions.makeup.length === 0}
            />
            <ListboxSelect
              className={styles.btn}
              value={costumeValue}
              ariaLabel="选择服装"
              options={roleOptions.costume.map((v) => ({ value: v, label: v }))}
              onChange={(v) => setEditCostume(v)}
              disabled={roleOptions.costume.length === 0}
            />
          </div>
        ) : null}

        {isScene ? (
          <div className={styles.row}>
            <div className={styles.field}>
              <div className={styles.fieldLabel}>正视图提示词</div>
              <textarea
                className={`${styles.textarea} ${styles.textareaSmall}`}
                value={sceneFrontPrompt}
                onChange={(e) => setSceneFrontPrompt(e.target.value)}
                placeholder="输入正视图提示词"
              />
            </div>
            <div className={styles.field}>
              <div className={styles.fieldLabel}>背视图提示词</div>
              <textarea
                className={`${styles.textarea} ${styles.textareaSmall}`}
                value={sceneBackPrompt}
                onChange={(e) => setSceneBackPrompt(e.target.value)}
                placeholder="输入背视图提示词"
              />
            </div>
          </div>
        ) : (
          <textarea
            className={styles.textarea}
            value={editPrompt}
            onChange={(e) => setEditPrompt(e.target.value)}
            placeholder={isRole ? "输入新的提示词" : "输入新的提示词"}
          />
        )}
        <div className={styles.actions}>
          <button type="button" className={`${styles.btn} ${styles.btnPrimary}`} onClick={() => void submit()} disabled={submitting || !canSubmit}>
            {submitting ? "提交中…" : "提交重制"}
          </button>
        </div>
        <div className={styles.hint}>提交后会进入任务中心队列，完成后刷新即可看到新结果。</div>
      </div>
    </div>
  )
}
