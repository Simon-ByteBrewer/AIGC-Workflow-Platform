import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { getQuotaTree } from "@/server/domains/admin/quotaAdmin"

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    const tree = await getQuotaTree(actor.userId, actor.roleKey === "admin" ? "super_admin" : "group_admin")
    return NextResponse.json(makeApiOk(traceId, tree))
  } catch (error: any) {
    logger.error({
      event: "quota_tree_request_failed",
      module: "admin/quota",
      traceId,
      message: "获取额度树失败",
      errorName: error?.name,
      errorMessage: error?.message,
      stack: error?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "QUOTA_TREE_FAILED", error?.message ?? "获取额度列表失败"), { status: 500 })
  }
}
