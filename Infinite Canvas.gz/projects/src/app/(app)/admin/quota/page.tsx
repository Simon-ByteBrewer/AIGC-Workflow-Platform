import { Suspense } from "react"
import { QuotaPage } from "@/features/admin/quota/QuotaPage"
import { getDb } from "@/server/db/getDb"
import { userSecurity, users } from "@/shared/schema/auth"
import { eq } from "drizzle-orm"
import { cookies } from "next/headers"
import { SESSION_COOKIE_NAME, verifySessionToken } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export default async function Page() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE_NAME)?.value
  const traceId = getTraceId(new Headers())
  let roleKey = "user"
  let userId = ""

  if (token) {
    const payload = await verifySessionToken(token, traceId).catch(() => null)
    if (payload?.userId) userId = payload.userId
  }

  if (userId) {
    const db = await getDb({ userSecurity, users })
    const rows = await db.select({ roleKey: userSecurity.roleKey }).from(userSecurity).where(eq(userSecurity.userId, userId)).limit(1)
    if (rows.length > 0) {
      if (rows[0].roleKey === "admin") {
        roleKey = "super_admin"
      } else {
        roleKey = rows[0].roleKey
      }
    }
  }

  return (
    <Suspense fallback={<div>Loading...</div>}>
      <QuotaPage roleKey={roleKey} userId={userId || ""} />
    </Suspense>
  )
}
