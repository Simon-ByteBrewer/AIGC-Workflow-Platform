[OPEN] quick-generate-shot-parse

## 症状
- `quick_generate_episode_page_prompt_payload_summary` 日志显示 `promptPayloadRowCount=0`
- 同时 `parsedShotCount=11`，但每个 `optimizedTextLength=0`
- 用户预期分镜应为“像 JSON 的字符串”，应能被解析出镜头文本

## 假设
1. `resultPayload` 里的分镜数据是字符串 JSON，但 `parseQuickGenerateEpisodeShots` 没有覆盖该字符串形态。
2. 分镜数据已经成功解析为 `shots`，但字段名与解析器预期不一致，导致 `optimizedText` 全为空。
3. 当前页面打开的是另一条 episode 记录，落库内容与之前完成的 episode 不同，所以表现像“没解析出来”。
4. `videoPromptPayload` 本来就还没生成，因此 `promptPayloadRowCount=0` 是正常现象，真正的问题只在 `resultPayload -> shots` 映射。
5. 最近修改没有直接改动分镜解析逻辑，问题来自旧数据形态或另一条 worker 输出格式。

## 当前状态
- 待取证：读取目标 episode 的 `requestPayload/resultPayload/videoPromptPayload`
- 待取证：阅读 `parseQuickGenerateEpisodeShots` 的字符串 JSON 兼容逻辑
