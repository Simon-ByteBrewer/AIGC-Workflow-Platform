"use client"

import type { ReactElement } from "react"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/shared/ui/shadcn/dialog"
import styles from "./RoleAssetDrawModal.module.css"
import { openImagePreview, useImagePreviewState } from "@/shared/ui/image-preview/store"
import { SHORT_DRAMA_ROLE_ASSET_DRAW_JOB_TYPE } from "@/shared/jobs/jobTypes"
import { useResolvedImageUrl } from "@/shared/hooks/useResolvedImageUrl"
import { readAcceptedJobIdFromStream } from "@/shared/readAcceptedJobIdFromStream"

type VariantSpecItem = { name: string; description: string; tags: string[] }
type CandidateState = {
  candidates: string[]
  selected?: string
  jobStatus?: "queued" | "running" | "done" | "error"
  loading?: boolean
  error?: string | null
}
type VariantKind = "look" | "costume"

function clampInt(v: number, min: number, max: number): number {
  if (!Number.isFinite(v)) return min
  const n = Math.trunc(v)
  if (n < min) return min
  if (n > max) return max
  return n
}

function toTagsText(tags: string[]): string {
  return (Array.isArray(tags) ? tags : []).map((t) => String(t ?? "").trim()).filter(Boolean).slice(0, 20).join(",")
}

function getVariantKey(item: VariantSpecItem, idx: number): string {
  const name = String(item?.name ?? "").trim()
  return name || `idx:${idx}`
}

function getVariantDisplayName(item: VariantSpecItem, idx: number): string {
  const name = String(item?.name ?? "").trim()
  return name || `方案${idx + 1}`
}

function normalizeCandidates(candidates: string[]): string[] {
  return (Array.isArray(candidates) ? candidates : []).map((u) => String(u ?? "").trim()).filter(Boolean).slice(0, 60)
}

function toRoleAssetFileUrl(storageKey: string): string {
  return `/api/script/short-drama/role-assets/file?key=${encodeURIComponent(storageKey)}`
}

function toCandidateSrc(candidate: string): string {
  const raw = String(candidate ?? "").trim()
  if (!raw) return ""
  if (raw.startsWith("public/short-drama/role-assets/")) return toRoleAssetFileUrl(raw)
  return raw
}

function ResolvedImg(props: { src: string; alt: string; className?: string }): ReactElement | null {
  const resolved = useResolvedImageUrl(props.src)
  if (!resolved) return null
  return <img className={props.className} src={resolved} alt={props.alt} />
}

function ResolvedCandidateCard(props: {
  src: string
  alt: string
  topBar?: ReactElement | null
  onPreview?: (src: string) => void
  containerClassName: string
  imageClassName: string
}): ReactElement | null {
  const resolved = useResolvedImageUrl(props.src)
  const usable = resolved || props.src
  if (!usable) return null
  return (
    <div
      className={props.containerClassName}
      role="button"
      tabIndex={0}
      onClick={() => props.onPreview?.(usable)}
      onKeyDown={(e) => {
        if (e.key === "Enter") props.onPreview?.(usable)
      }}
    >
      {props.topBar}
      <img className={props.imageClassName} src={usable} alt={props.alt} />
    </div>
  )
}

function ResolvedThumbButton(props: {
  src: string
  alt: string
  className?: string
  imgClassName?: string
  onPreview?: (src: string) => void
}): ReactElement | null {
  const resolved = useResolvedImageUrl(props.src)
  const usable = resolved || props.src
  if (!usable) return null
  return (
    <button type="button" className={props.className} onClick={() => props.onPreview?.(usable)}>
      <img className={props.imgClassName} src={usable} alt={props.alt} />
    </button>
  )
}

function appendCandidates(prev: string[], incoming: string[], limit = 60): string[] {
  const out: string[] = []
  const seen = new Set<string>()
  const push = (s: string) => {
    const t = String(s ?? "").trim()
    if (!t) return
    if (seen.has(t)) return
    seen.add(t)
    out.push(t)
  }
  for (const s of prev) push(s)
  for (const s of incoming) push(s)
  return out.slice(0, limit)
}

async function resolveLookPreviewUrl(id: string): Promise<string> {
  const res = await fetch(`/api/library/public-character-looks/url/${encodeURIComponent(id)}?kind=preview`, { method: "GET" })
  const json = (await res.json().catch(() => null)) as
    | { ok: true; data?: { url?: string } }
    | { ok: false; error?: { message?: string } }
    | null
  if (!res.ok || !json || (json as any).ok !== true) throw new Error((json as any)?.error?.message ?? `HTTP ${res.status}`)
  const url = String((json as any)?.data?.url ?? "").trim()
  if (!url) throw new Error("未返回图片链接")
  return url
}

async function resolveCostumePreviewUrl(id: string): Promise<string> {
  const res = await fetch(`/api/library/public-character-costumes/url/${encodeURIComponent(id)}?kind=preview`, { method: "GET" })
  const json = (await res.json().catch(() => null)) as
    | { ok: true; data?: { url?: string } }
    | { ok: false; error?: { message?: string } }
    | null
  if (!res.ok || !json || (json as any).ok !== true) throw new Error((json as any)?.error?.message ?? `HTTP ${res.status}`)
  const url = String((json as any)?.data?.url ?? "").trim()
  if (!url) throw new Error("未返回图片链接")
  return url
}

function extractIdFromLibraryFileUrl(input: string, kind: VariantKind): string {
  const raw = String(input ?? "").trim()
  if (!raw) return ""
  const pathname = (() => {
    if (raw.startsWith("http://") || raw.startsWith("https://")) {
      try {
        return new URL(raw).pathname
      } catch {
        return raw
      }
    }
    return raw
  })()

  const re =
    kind === "look"
      ? /\/api\/library\/public-character-looks\/file\/([^/?#]+)(?:[/?#]|$)/u
      : /\/api\/library\/public-character-costumes\/file\/([^/?#]+)(?:[/?#]|$)/u
  const m = pathname.match(re)
  return String(m?.[1] ?? "").trim()
}

async function normalizeImageUrlForImport(input: { kind: VariantKind; imageUrl: string }): Promise<string> {
  const raw = String(input.imageUrl ?? "").trim()
  if (!raw) return ""
  const id = extractIdFromLibraryFileUrl(raw, input.kind)
  if (!id) return raw
  return input.kind === "look" ? resolveLookPreviewUrl(id) : resolveCostumePreviewUrl(id)
}

export function RoleAssetDrawModal(props: {
  open: boolean
  onOpenChange: (open: boolean) => void
  storyId: string
  characterKey: string
  style?: string
  savedSelection?: {
    characterId?: string | null
    frontImageUrl?: string
    lookId?: string | null
    costumeId?: string | null
    lookIdByVariant?: Record<string, string>
    costumeIdByVariant?: Record<string, string>
    lookCandidateStorageKeysByVariant?: Record<string, string[]>
    costumeCandidateStorageKeysByVariant?: Record<string, string[]>
    selectedLookCandidateKeyByVariant?: Record<string, string>
    selectedCostumeCandidateKeyByVariant?: Record<string, string>
    activeDrawJobIds?: string[]
    selectedHairIndex?: number
    selectedClothingIndex?: number
    hairText?: string
    hairTagsText?: string
    clothingText?: string
    clothingTagsText?: string
  }
  onPersistSelection?: (selection: {
    characterId?: string | null
    frontImageUrl?: string
    lookId?: string | null
    costumeId?: string | null
    lookIdByVariant?: Record<string, string>
    costumeIdByVariant?: Record<string, string>
    lookCandidateStorageKeysByVariant?: Record<string, string[]>
    costumeCandidateStorageKeysByVariant?: Record<string, string[]>
    selectedLookCandidateKeyByVariant?: Record<string, string>
    selectedCostumeCandidateKeyByVariant?: Record<string, string>
    activeDrawJobIds?: string[]
    selectedHairIndex?: number
    selectedClothingIndex?: number
    hairText?: string
    hairTagsText?: string
    clothingText?: string
    clothingTagsText?: string
  }) => void
  characterName: string
  characterDescription: string
  frontImageUrl: string
  hairstyleOptions: VariantSpecItem[]
  clothingOptions: VariantSpecItem[]
}): ReactElement {
  const imagePreview = useImagePreviewState()
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [characterAssetId, setCharacterAssetId] = useState<string | null>(null)

  const [tab, setTab] = useState<VariantKind>("look")
  const [drawCountText, setDrawCountText] = useState("3")
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [lookTextByKey, setLookTextByKey] = useState<Record<string, string>>({})
  const [lookTagsByKey, setLookTagsByKey] = useState<Record<string, string>>({})
  const [costumeTextByKey, setCostumeTextByKey] = useState<Record<string, string>>({})
  const [costumeTagsByKey, setCostumeTagsByKey] = useState<Record<string, string>>({})

  const [lookByKey, setLookByKey] = useState<Record<string, CandidateState>>({})
  const [costumeByKey, setCostumeByKey] = useState<Record<string, CandidateState>>({})

  const [activeJobIds, setActiveJobIds] = useState<string[]>([])
  const jobSourcesRef = useRef<Record<string, EventSource>>({})
  const selectionRef = useRef<Record<string, unknown>>({})
  const persistTimerRef = useRef<number | null>(null)
  const pendingLookCandidatesRef = useRef<Record<string, string[]>>({})
  const pendingCostumeCandidatesRef = useRef<Record<string, string[]>>({})

  const [bulkLoading, setBulkLoading] = useState(false)
  const [bulkSubmitting, setBulkSubmitting] = useState(false)
  const [bulkDone, setBulkDone] = useState(0)
  const [bulkTotal, setBulkTotal] = useState(0)

  useEffect(() => {
    if (!props.open) return
    setError(null)
    setSaving(false)
    setCharacterAssetId(null)
    setTab("look")
    setDrawCountText("3")
    setExpanded({})
    setBulkLoading(false)
    setBulkSubmitting(false)
    setBulkDone(0)
    setBulkTotal(0)
    setLookTextByKey({})
    setLookTagsByKey({})
    setCostumeTextByKey({})
    setCostumeTagsByKey({})
    setLookByKey({})
    setCostumeByKey({})
    setActiveJobIds([])
    selectionRef.current = (props.savedSelection ?? {}) as any

    const saved = props.savedSelection
    if (saved) {
      const savedFront = typeof (saved as any).frontImageUrl === "string" ? String((saved as any).frontImageUrl).trim() : ""
      const currentFront = String(props.frontImageUrl ?? "").trim()
      const sameFront = Boolean(savedFront && currentFront && savedFront === currentFront)
      const firstLookKey = (() => {
        const first = props.hairstyleOptions[0] ?? { name: "", description: "", tags: [] }
        const k = getVariantKey(first, 0)
        return k || "default"
      })()
      const firstCostumeKey = (() => {
        const first = props.clothingOptions[0] ?? { name: "", description: "", tags: [] }
        const k = getVariantKey(first, 0)
        return k || "default"
      })()

      const lookIdFromSaved = typeof saved.lookId === "string" ? saved.lookId.trim() : ""
      const costumeIdFromSaved = typeof saved.costumeId === "string" ? saved.costumeId.trim() : ""
      const savedCharacterId = typeof saved.characterId === "string" ? saved.characterId.trim() : ""
      if (savedCharacterId) setCharacterAssetId(savedCharacterId)

      if (typeof saved.hairText === "string") setLookTextByKey((prev) => ({ ...prev, [firstLookKey]: saved.hairText! }))
      if (typeof saved.hairTagsText === "string") setLookTagsByKey((prev) => ({ ...prev, [firstLookKey]: saved.hairTagsText! }))
      if (typeof saved.clothingText === "string") setCostumeTextByKey((prev) => ({ ...prev, [firstCostumeKey]: saved.clothingText! }))
      if (typeof saved.clothingTagsText === "string") setCostumeTagsByKey((prev) => ({ ...prev, [firstCostumeKey]: saved.clothingTagsText! }))

      const activeJobIds = Array.isArray((saved as any)?.activeDrawJobIds)
        ? (saved as any).activeDrawJobIds.map((x: any) => String(x ?? "").trim()).filter(Boolean)
        : []
      if (activeJobIds.length) setActiveJobIds(activeJobIds.slice(0, 20))

      const lookCandidateStorageKeysByVariant = (saved as any)?.lookCandidateStorageKeysByVariant
      const costumeCandidateStorageKeysByVariant = (saved as any)?.costumeCandidateStorageKeysByVariant
      const selectedLookCandidateKeyByVariant = (saved as any)?.selectedLookCandidateKeyByVariant
      const selectedCostumeCandidateKeyByVariant = (saved as any)?.selectedCostumeCandidateKeyByVariant

      if (sameFront && lookCandidateStorageKeysByVariant && typeof lookCandidateStorageKeysByVariant === "object") {
        setLookByKey((prev) => {
          const next = { ...prev }
          for (const [k0, arr0] of Object.entries(lookCandidateStorageKeysByVariant as Record<string, unknown>)) {
            const k = String(k0 ?? "").trim()
            if (!k) continue
            const candidates = normalizeCandidates(Array.isArray(arr0) ? (arr0 as any[]) : [])
            const selected = typeof (selectedLookCandidateKeyByVariant as any)?.[k] === "string" ? String((selectedLookCandidateKeyByVariant as any)[k]).trim() : ""
            next[k] = { candidates, selected: selected || next[k]?.selected }
          }
          return next
        })
      }

      if (sameFront && costumeCandidateStorageKeysByVariant && typeof costumeCandidateStorageKeysByVariant === "object") {
        setCostumeByKey((prev) => {
          const next = { ...prev }
          for (const [k0, arr0] of Object.entries(costumeCandidateStorageKeysByVariant as Record<string, unknown>)) {
            const k = String(k0 ?? "").trim()
            if (!k) continue
            const candidates = normalizeCandidates(Array.isArray(arr0) ? (arr0 as any[]) : [])
            const selected = typeof (selectedCostumeCandidateKeyByVariant as any)?.[k] === "string" ? String((selectedCostumeCandidateKeyByVariant as any)[k]).trim() : ""
            next[k] = { candidates, selected: selected || next[k]?.selected }
          }
          return next
        })
      }

      const lookIdByVariant = (saved as any)?.lookIdByVariant
      if (lookIdByVariant && typeof lookIdByVariant === "object") {
        setLookByKey((prev) => {
          const next = { ...prev }
          for (const [k0, id0] of Object.entries(lookIdByVariant as Record<string, unknown>)) {
            const k = String(k0 ?? "").trim()
            const id = typeof id0 === "string" ? id0.trim() : ""
            if (!k || !id) continue
            const url = `/api/library/public-character-looks/file/${id}?kind=preview`
            const cur = next[k]?.candidates ?? []
            const candidates = appendCandidates(cur, [url], 60)
            const selected = next[k]?.selected ?? url
            next[k] = { ...next[k], candidates, selected }
          }
          return next
        })
      } else if (lookIdFromSaved) {
        const url = `/api/library/public-character-looks/file/${lookIdFromSaved}?kind=preview`
        setLookByKey((prev) => ({ ...prev, [firstLookKey]: { candidates: [url], selected: url } }))
      }

      const costumeIdByVariant = (saved as any)?.costumeIdByVariant
      if (costumeIdByVariant && typeof costumeIdByVariant === "object") {
        setCostumeByKey((prev) => {
          const next = { ...prev }
          for (const [k0, id0] of Object.entries(costumeIdByVariant as Record<string, unknown>)) {
            const k = String(k0 ?? "").trim()
            const id = typeof id0 === "string" ? id0.trim() : ""
            if (!k || !id) continue
            const url = `/api/library/public-character-costumes/file/${id}?kind=preview`
            const cur = next[k]?.candidates ?? []
            const candidates = appendCandidates(cur, [url], 60)
            const selected = next[k]?.selected ?? url
            next[k] = { ...next[k], candidates, selected }
          }
          return next
        })
      } else if (costumeIdFromSaved) {
        const url = `/api/library/public-character-costumes/file/${costumeIdFromSaved}?kind=preview`
        setCostumeByKey((prev) => ({ ...prev, [firstCostumeKey]: { candidates: [url], selected: url } }))
      }
    }
  }, [props.open])

  useEffect(() => {
    if (!props.open) return
    let cancelled = false
    ;(async (): Promise<void> => {
      const storyId = String(props.storyId ?? "").trim()
      const characterKey = String(props.characterKey ?? "").trim()
      if (!storyId || !characterKey) return
      const res = await fetch(`/api/jobs?storyId=${encodeURIComponent(storyId)}&activeOnly=true&limit=50`, { method: "GET" })
      const json = (await res.json().catch(() => null)) as any
      if (!res.ok || !json || json.ok !== true) return
      const jobs = Array.isArray(json?.data?.jobs) ? json.data.jobs : []
      const matched = jobs.filter((j: any) => {
        if (!j || typeof j !== "object") return false
        if (String(j.type ?? "") !== SHORT_DRAMA_ROLE_ASSET_DRAW_JOB_TYPE) return false
        const snap = j.snapshot && typeof j.snapshot === "object" ? j.snapshot : null
        return String((snap as any)?.characterKey ?? "") === characterKey
      })
      if (cancelled) return
      if (!matched.length) return

      const ids = matched.map((j: any) => String(j.jobId ?? "").trim()).filter(Boolean)
      if (ids.length) {
        setActiveJobIds((prev) => Array.from(new Set([...ids, ...prev])).slice(0, 20))
        setBulkLoading(true)
      }

      const snap = matched[0]?.snapshot && typeof matched[0].snapshot === "object" ? matched[0].snapshot : null
      if (!snap) return
      const progress = (snap as any).progress
      if (progress && typeof progress === "object") {
        const total = Number(progress.total)
        const done = Number(progress.done)
        if (Number.isFinite(total)) setBulkTotal(Math.max(0, Math.trunc(total)))
        if (Number.isFinite(done)) setBulkDone(Math.max(0, Math.trunc(done)))
      }

      const items = Array.isArray((snap as any).items) ? (snap as any).items : []
      for (const it of items) {
        const kind: VariantKind = it?.kind === "costume" ? "costume" : "look"
        const variantKey = String(it?.variantKey ?? "").trim()
        if (!variantKey) continue
        const storageKeys = normalizeCandidates(Array.isArray(it?.storageKeys) ? it.storageKeys : [])
        const jobStatus: CandidateState["jobStatus"] =
          it?.status === "queued" || it?.status === "running" || it?.status === "done" || it?.status === "error" ? it.status : undefined
        const err = typeof it?.errorMessage === "string" ? it.errorMessage : null
        if (kind === "look") {
          setLookByKey((prev) => {
            const cur = prev[variantKey] ?? { candidates: [] }
            const candidates = appendCandidates(cur.candidates ?? [], storageKeys, 60)
            return { ...prev, [variantKey]: { ...cur, candidates, jobStatus, loading: jobStatus === "running", error: err } }
          })
        } else {
          setCostumeByKey((prev) => {
            const cur = prev[variantKey] ?? { candidates: [] }
            const candidates = appendCandidates(cur.candidates ?? [], storageKeys, 60)
            return { ...prev, [variantKey]: { ...cur, candidates, jobStatus, loading: jobStatus === "running", error: err } }
          })
        }
      }
    })()
    return () => {
      cancelled = true
    }
  }, [props.characterKey, props.open, props.storyId])

  useEffect(() => {
    if (!props.open) return
    let cancelled = false
    ;(async (): Promise<void> => {
      const storyId = String(props.storyId ?? "").trim()
      const characterKey = String(props.characterKey ?? "").trim()
      const front = String(props.frontImageUrl ?? "").trim()
      if (!storyId || !characterKey || !front) return
      const res = await fetch(
        `/api/script/short-drama/role-assets/library?storyId=${encodeURIComponent(storyId)}&characterKey=${encodeURIComponent(
          characterKey
        )}&frontImageUrl=${encodeURIComponent(front)}`,
        { method: "GET" }
      )
      const json = (await res.json().catch(() => null)) as any
      if (!res.ok || !json || json.ok !== true) return
      const assets = Array.isArray(json?.data?.assets) ? json.data.assets : []
      if (cancelled) return
      const byKindVariant: Record<string, string[]> = {}
      for (const a of assets) {
        const meta = a?.meta && typeof a.meta === "object" ? a.meta : null
        const kind = String((meta as any)?.kind ?? "").trim()
        const variantKey = String((meta as any)?.variantKey ?? "").trim()
        const storageKey = String(a?.storageKey ?? "").trim()
        if (!kind || !variantKey || !storageKey) continue
        const k = `${kind}::${variantKey}`
        byKindVariant[k] = appendCandidates(byKindVariant[k] ?? [], [storageKey], 60)
      }
      for (const [k, arr] of Object.entries(byKindVariant)) {
        const [kind, variantKey] = k.split("::")
        if (kind === "look") {
          setLookByKey((prev) => {
            const cur = prev[variantKey] ?? { candidates: [] }
            const candidates = appendCandidates(cur.candidates ?? [], arr, 60)
            return { ...prev, [variantKey]: { ...cur, candidates } }
          })
        } else if (kind === "costume") {
          setCostumeByKey((prev) => {
            const cur = prev[variantKey] ?? { candidates: [] }
            const candidates = appendCandidates(cur.candidates ?? [], arr, 60)
            return { ...prev, [variantKey]: { ...cur, candidates } }
          })
        }
      }
    })()
    return () => {
      cancelled = true
    }
  }, [props.characterKey, props.frontImageUrl, props.open, props.storyId])

  const lookVariants = useMemo(
    () =>
      props.hairstyleOptions.map((x, idx) => ({
        key: getVariantKey(x, idx),
        name: getVariantDisplayName(x, idx),
        idx,
        item: x
      })),
    [props.hairstyleOptions]
  )

  const costumeVariants = useMemo(
    () =>
      props.clothingOptions.map((x, idx) => ({
        key: getVariantKey(x, idx),
        name: getVariantDisplayName(x, idx),
        idx,
        item: x
      })),
    [props.clothingOptions]
  )

  useEffect(() => {
    if (!props.open) return
    setLookTextByKey((prev) => {
      const next = { ...prev }
      for (const v of lookVariants) {
        if (typeof next[v.key] === "string" && next[v.key].trim()) continue
        const desc = String(v.item?.description ?? "").trim()
        if (desc) next[v.key] = desc
      }
      return next
    })
    setLookTagsByKey((prev) => {
      const next = { ...prev }
      for (const v of lookVariants) {
        if (typeof next[v.key] === "string" && next[v.key].trim()) continue
        const t = toTagsText(Array.isArray(v.item?.tags) ? v.item.tags : [])
        if (t) next[v.key] = t
      }
      return next
    })
    setCostumeTextByKey((prev) => {
      const next = { ...prev }
      for (const v of costumeVariants) {
        if (typeof next[v.key] === "string" && next[v.key].trim()) continue
        const desc = String(v.item?.description ?? "").trim()
        if (desc) next[v.key] = desc
      }
      return next
    })
    setCostumeTagsByKey((prev) => {
      const next = { ...prev }
      for (const v of costumeVariants) {
        if (typeof next[v.key] === "string" && next[v.key].trim()) continue
        const t = toTagsText(Array.isArray(v.item?.tags) ? v.item.tags : [])
        if (t) next[v.key] = t
      }
      return next
    })
  }, [costumeVariants, lookVariants, props.open])

  const selectedLookUrls = useMemo(
    () => lookVariants.map((v) => (lookByKey[v.key]?.selected ? toCandidateSrc(String(lookByKey[v.key]!.selected)) : "")).filter(Boolean).slice(0, 9),
    [lookByKey, lookVariants]
  )
  const selectedCostumeUrls = useMemo(
    () =>
      costumeVariants
        .map((v) => (costumeByKey[v.key]?.selected ? toCandidateSrc(String(costumeByKey[v.key]!.selected)) : ""))
        .filter(Boolean)
        .slice(0, 9),
    [costumeByKey, costumeVariants]
  )
  const selectedLookUrl = selectedLookUrls[0] ?? ""
  const selectedCostumeUrl = selectedCostumeUrls[0] ?? ""

  const promptBase = useMemo(() => {
    const pieces: string[] = []
    const name = props.characterName.trim()
    if (name) pieces.push(`姓名：${name}`)
    const desc = props.characterDescription.trim()
    if (desc) pieces.push(desc)
    return pieces.join("\n").trim()
  }, [props.characterDescription, props.characterName])

  const persistSelectionPatch = useCallback(
    (patch: NonNullable<typeof props.savedSelection>): void => {
      if (!props.onPersistSelection) return
      const base = selectionRef.current ?? {}
      const next = { ...(base as any), ...(patch as any), frontImageUrl: props.frontImageUrl }
      selectionRef.current = next
      props.onPersistSelection(next as any)
    },
    [props]
  )

  const enqueueDrawJob = useCallback(
    async (items: Array<{ kind: VariantKind; variantKey: string; variantName: string }>): Promise<void> => {
      if (!props.frontImageUrl.trim()) return
      const count = clampInt(Number(drawCountText), 1, 5)
      setBulkSubmitting(true)
      setError(null)
      const body = {
        storyId: props.storyId,
        characterKey: props.characterKey,
        characterName: props.characterName,
        frontImageUrl: props.frontImageUrl,
        frontImageStorageKey: props.frontImageUrl.startsWith("public/short-drama/role-assets/") ? props.frontImageUrl : undefined,
        publicCharacterId: characterAssetId || undefined,
        promptBase,
        style: (props.style ?? "").trim() || undefined,
        append: true,
        items: items.map((it) => ({
          kind: it.kind,
          variantKey: it.variantKey,
          variantName: it.variantName,
          text: it.kind === "look" ? String(lookTextByKey[it.variantKey] ?? "").trim() : String(costumeTextByKey[it.variantKey] ?? "").trim(),
          tagsText: it.kind === "look" ? String(lookTagsByKey[it.variantKey] ?? "").trim() : String(costumeTagsByKey[it.variantKey] ?? "").trim(),
          count
        }))
      }

      try {
        const res = await fetch("/api/coze/short-drama-role-assets-draw/stream", {
          method: "POST",
          headers: { "content-type": "application/json", accept: "text/event-stream" },
          body: JSON.stringify(body)
        })
        if (!res.ok) {
          const json = (await res.json().catch(() => null)) as { ok?: boolean; error?: { message?: string } } | null
          throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        }
        const jobId = await readAcceptedJobIdFromStream({ res })
        if (!jobId) throw new Error("未返回任务 ID")

        setBulkLoading(true)
        setBulkDone(0)
        setBulkTotal(Math.max(items.length, bulkTotal))
        for (const it of items) {
          if (it.kind === "look") {
            setLookByKey((prev) => {
              const cur = prev[it.variantKey] ?? { candidates: [] }
              return { ...prev, [it.variantKey]: { ...cur, jobStatus: "queued", loading: false, error: null } }
            })
          } else {
            setCostumeByKey((prev) => {
              const cur = prev[it.variantKey] ?? { candidates: [] }
              return { ...prev, [it.variantKey]: { ...cur, jobStatus: "queued", loading: false, error: null } }
            })
          }
        }

        setActiveJobIds((prev) => {
          const next = Array.from(new Set([jobId, ...prev])).slice(0, 20)
          persistSelectionPatch({ activeDrawJobIds: next } as any)
          return next
        })
      } finally {
        setBulkSubmitting(false)
      }
    },
    [
      bulkTotal,
      costumeTagsByKey,
      costumeTextByKey,
      drawCountText,
      lookTagsByKey,
      lookTextByKey,
      persistSelectionPatch,
      promptBase,
      props
    ]
  )

  useEffect(() => {
    if (!props.open) return
    if (!activeJobIds.length) return
    const sources = jobSourcesRef.current
    const schedulePersist = (): void => {
      if (persistTimerRef.current != null) return
      persistTimerRef.current = window.setTimeout(() => {
        persistTimerRef.current = null

        const baseLook = (((selectionRef.current as any)?.lookCandidateStorageKeysByVariant ?? {}) as Record<string, string[]>)
        const baseCostume = (((selectionRef.current as any)?.costumeCandidateStorageKeysByVariant ?? {}) as Record<string, string[]>)
        const lookPending = pendingLookCandidatesRef.current
        const costumePending = pendingCostumeCandidatesRef.current

        const nextLook: Record<string, string[]> = { ...baseLook }
        const nextCostume: Record<string, string[]> = { ...baseCostume }

        let changed = false
        for (const [k, arr] of Object.entries(lookPending)) {
          if (!k) continue
          const merged = appendCandidates(Array.isArray(nextLook[k]) ? nextLook[k] : [], arr, 60)
          nextLook[k] = merged
          changed = true
        }
        for (const [k, arr] of Object.entries(costumePending)) {
          if (!k) continue
          const merged = appendCandidates(Array.isArray(nextCostume[k]) ? nextCostume[k] : [], arr, 60)
          nextCostume[k] = merged
          changed = true
        }

        pendingLookCandidatesRef.current = {}
        pendingCostumeCandidatesRef.current = {}

        if (changed) {
          persistSelectionPatch({
            lookCandidateStorageKeysByVariant: nextLook,
            costumeCandidateStorageKeysByVariant: nextCostume
          } as any)
        }
      }, 600)
    }

    const subscribe = (jobId: string): void => {
      if (sources[jobId]) return
      const es = new EventSource(`/api/jobs/${encodeURIComponent(jobId)}/events`)
      sources[jobId] = es

      const close = (): void => {
        try {
          es.close()
        } catch {}
        delete sources[jobId]
      }

      es.onmessage = (ev) => {
        const payload = (() => {
          try {
            return JSON.parse(ev.data)
          } catch {
            return null
          }
        })() as any
        const snapshot = payload?.data?.snapshot
        if (!snapshot || typeof snapshot !== "object") return

        const progress = snapshot.progress
        if (progress && typeof progress === "object") {
          const total = Number(progress.total)
          const done = Number(progress.done)
          if (Number.isFinite(total)) setBulkTotal(Math.max(0, Math.trunc(total)))
          if (Number.isFinite(done)) setBulkDone(Math.max(0, Math.trunc(done)))
        }

        setBulkLoading(snapshot.status === "queued" || snapshot.status === "running")

        const itemsArr = Array.isArray(snapshot.items) ? snapshot.items : []
        for (const it of itemsArr) {
          const kind: VariantKind = it?.kind === "costume" ? "costume" : "look"
          const variantKey = String(it?.variantKey ?? "").trim()
          if (!variantKey) continue
          const storageKeys = normalizeCandidates(Array.isArray(it?.storageKeys) ? it.storageKeys : [])
          const persistable = storageKeys.filter((x) => x.startsWith("public/short-drama/role-assets/"))
          const jobStatus: CandidateState["jobStatus"] =
            it?.status === "queued" || it?.status === "running" || it?.status === "done" || it?.status === "error" ? it.status : undefined
          const loading = it?.status === "running"
          const err = typeof it?.errorMessage === "string" ? it.errorMessage : null
          if (kind === "look") {
            setLookByKey((prev) => {
              const cur = prev[variantKey] ?? { candidates: [] }
              const candidates = appendCandidates(cur.candidates ?? [], storageKeys, 60)
              return { ...prev, [variantKey]: { ...cur, candidates, jobStatus, loading, error: err } }
            })
            if (persistable.length) {
              pendingLookCandidatesRef.current[variantKey] = appendCandidates(pendingLookCandidatesRef.current[variantKey] ?? [], persistable, 60)
              schedulePersist()
            }
          } else {
            setCostumeByKey((prev) => {
              const cur = prev[variantKey] ?? { candidates: [] }
              const candidates = appendCandidates(cur.candidates ?? [], storageKeys, 60)
              return { ...prev, [variantKey]: { ...cur, candidates, jobStatus, loading, error: err } }
            })
            if (persistable.length) {
              pendingCostumeCandidatesRef.current[variantKey] = appendCandidates(pendingCostumeCandidatesRef.current[variantKey] ?? [], persistable, 60)
              schedulePersist()
            }
          }
        }

        if (snapshot.status === "done" || snapshot.status === "error") {
          close()
          setActiveJobIds((prev) => {
            const next = prev.filter((x) => x !== jobId)
            persistSelectionPatch({ activeDrawJobIds: next } as any)
            return next
          })
        }
      }

      es.onerror = () => {
        close()
        // SSE 连接失败，改用 HTTP 轮询备选方案
        pollJobStatus(jobId)
      }
    }

    const pollJobStatus = async (jobId: string): Promise<void> => {
      let attempts = 0
      const maxAttempts = 60 // 最多轮询 60 次（约 5 分钟）
      const interval = 5000 // 每 5 秒轮询一次

      const poll = async (): Promise<void> => {
        if (attempts >= maxAttempts) return
        attempts++

        try {
          const res = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`)
          const json = (await res.json().catch(() => null)) as { ok?: boolean; data?: { job?: { status?: string; snapshot?: unknown } } } | null

          if (!res.ok || !json?.ok || !json.data?.job) {
            // 轮询失败，稍后重试
            setTimeout(poll, interval)
            return
          }

          const job = json.data.job
          const snapshot = (job.snapshot as any) ?? null
          const status = job.status

          // 更新进度
          if (snapshot && typeof snapshot === "object") {
            const progress = (snapshot as any).progress
            if (progress && typeof progress === "object") {
              const total = Number((progress as any).total)
              const done = Number((progress as any).done)
              if (Number.isFinite(total)) setBulkTotal(Math.max(0, Math.trunc(total)))
              if (Number.isFinite(done)) setBulkDone(Math.max(0, Math.trunc(done)))
            }

            setBulkLoading(status === "queued" || status === "running")

            const itemsArr = Array.isArray((snapshot as any).items) ? (snapshot as any).items : []
            for (const it of itemsArr) {
              const kind: VariantKind = it?.kind === "costume" ? "costume" : "look"
              const variantKey = String(it?.variantKey ?? "").trim()
              if (!variantKey) continue
              const storageKeys = normalizeCandidates(Array.isArray(it?.storageKeys) ? it.storageKeys : [])
              const persistable = storageKeys.filter((x) => x.startsWith("public/short-drama/role-assets/"))
              const jobStatus: CandidateState["jobStatus"] =
                it?.status === "queued" || it?.status === "running" || it?.status === "done" || it?.status === "error" ? it.status : undefined
              const loading = it?.status === "running"
              const err = typeof it?.errorMessage === "string" ? it.errorMessage : null
              if (kind === "look") {
                setLookByKey((prev) => {
                  const cur = prev[variantKey] ?? { candidates: [] }
                  const candidates = appendCandidates(cur.candidates ?? [], storageKeys, 60)
                  return { ...prev, [variantKey]: { ...cur, candidates, jobStatus, loading, error: err } }
                })
                if (persistable.length) {
                  pendingLookCandidatesRef.current[variantKey] = appendCandidates(pendingLookCandidatesRef.current[variantKey] ?? [], persistable, 60)
                  schedulePersist()
                }
              } else {
                setCostumeByKey((prev) => {
                  const cur = prev[variantKey] ?? { candidates: [] }
                  const candidates = appendCandidates(cur.candidates ?? [], storageKeys, 60)
                  return { ...prev, [variantKey]: { ...cur, candidates, jobStatus, loading, error: err } }
                })
                if (persistable.length) {
                  pendingCostumeCandidatesRef.current[variantKey] = appendCandidates(pendingCostumeCandidatesRef.current[variantKey] ?? [], persistable, 60)
                  schedulePersist()
                }
              }
            }
          }

          // 任务完成或失败，停止轮询
          if (status === "done" || status === "error") {
            setActiveJobIds((prev) => {
              const next = prev.filter((x) => x !== jobId)
              persistSelectionPatch({ activeDrawJobIds: next } as any)
              return next
            })
          } else {
            // 任务仍在进行中，继续轮询
            setTimeout(poll, interval)
          }
        } catch {
          // 轮询失败，稍后重试
          setTimeout(poll, interval)
        }
      }

      await poll()
    }

    for (const jobId of activeJobIds) subscribe(jobId)

    return () => {
      if (persistTimerRef.current != null) {
        clearTimeout(persistTimerRef.current)
        persistTimerRef.current = null
      }
      for (const jobId of activeJobIds) {
        const s = sources[jobId]
        if (!s) continue
        try {
          s.close()
        } catch {}
        delete sources[jobId]
      }
    }
  }, [activeJobIds, persistSelectionPatch, props.open])

  const lookSelectedCount = useMemo(() => lookVariants.filter((v) => Boolean(lookByKey[v.key]?.selected)).length, [lookByKey, lookVariants])
  const costumeSelectedCount = useMemo(
    () => costumeVariants.filter((v) => Boolean(costumeByKey[v.key]?.selected)).length,
    [costumeByKey, costumeVariants]
  )

  const allLooksSelected = lookVariants.length === 0 ? true : lookSelectedCount === lookVariants.length
  const allCostumesSelected = costumeVariants.length === 0 ? true : costumeSelectedCount === costumeVariants.length

  const anyVariantLoading = useMemo(() => {
    for (const v of lookVariants) if (lookByKey[v.key]?.loading) return true
    for (const v of costumeVariants) if (costumeByKey[v.key]?.loading) return true
    return false
  }, [costumeByKey, costumeVariants, lookByKey, lookVariants])

  const canSave = Boolean(props.frontImageUrl && allLooksSelected && allCostumesSelected && !saving && !bulkLoading && !anyVariantLoading)

  const importOne = useCallback(
    async (body: {
      storyId?: string
      characterId?: string | null
      characterName: string
      characterDescription?: string
      frontImageUrl: string
      look?: { name: string; description?: string; imageUrl: string }
      costume?: { name: string; description?: string; imageUrl: string }
    }): Promise<{ characterId: string; lookId: string | null; costumeId: string | null }> => {
      const res = await fetch("/api/library/public-resources/import-short-drama-character", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      })
      const json = (await res.json().catch(() => null)) as
        | { ok: boolean; data?: { characterId?: string; lookId?: string | null; costumeId?: string | null }; error?: { message?: string } }
        | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const cid = String(json.data?.characterId ?? "").trim()
      if (!cid) throw new Error("保存失败：未返回角色资产 ID")
      const lookId = typeof json.data?.lookId === "string" ? json.data!.lookId!.trim() : null
      const costumeId = typeof json.data?.costumeId === "string" ? json.data!.costumeId!.trim() : null
      return { characterId: cid, lookId, costumeId }
    },
    []
  )

  const onSave = useCallback(async () => {
    if (!canSave) return
    setSaving(true)
    setError(null)
    try {
      let cid = characterAssetId?.trim() || ""
      if (!cid) {
        const created = await importOne({
          storyId: props.storyId,
          characterId: props.characterKey,
          characterName: props.characterName,
          characterDescription: props.characterDescription,
          frontImageUrl: props.frontImageUrl.startsWith("public/short-drama/role-assets/") ? toRoleAssetFileUrl(props.frontImageUrl) : props.frontImageUrl
        })
        cid = created.characterId
        setCharacterAssetId(cid)
      }

      const lookOrder = lookVariants.map((v) => v.key)
      const costumeOrder = costumeVariants.map((v) => v.key)

      const nextLookMap: Record<string, string> = {}
      const nextCostumeMap: Record<string, string> = {}

      for (const k of lookOrder) {
        const v = lookVariants.find((x) => x.key === k)
        if (!v) continue
        const st = lookByKey[k] ?? { candidates: [] }
        const picked = String(st.selected ?? "").trim()
        const urlRaw = picked.startsWith("public/short-drama/role-assets/") ? toRoleAssetFileUrl(picked) : picked
        const url = await normalizeImageUrlForImport({ kind: "look", imageUrl: urlRaw }).catch(() => "")
        if (!url) throw new Error(`装造「${v.name}」尚未选择图片`)
        const desc = String(lookTextByKey[k] ?? v.item.description ?? "").trim()
        const ret = await importOne({
          storyId: props.storyId,
          characterId: cid,
          characterName: props.characterName,
          characterDescription: props.characterDescription,
          frontImageUrl: props.frontImageUrl.startsWith("public/short-drama/role-assets/") ? toRoleAssetFileUrl(props.frontImageUrl) : props.frontImageUrl,
          look: { name: String(v.item.name ?? "").trim() || "默认装造", description: desc, imageUrl: url }
        })
        if (ret.lookId) nextLookMap[k] = ret.lookId
      }

      for (const k of costumeOrder) {
        const v = costumeVariants.find((x) => x.key === k)
        if (!v) continue
        const st = costumeByKey[k] ?? { candidates: [] }
        const picked = String(st.selected ?? "").trim()
        const urlRaw = picked.startsWith("public/short-drama/role-assets/") ? toRoleAssetFileUrl(picked) : picked
        const url = await normalizeImageUrlForImport({ kind: "costume", imageUrl: urlRaw }).catch(() => "")
        if (!url) throw new Error(`服装「${v.name}」尚未选择图片`)
        const desc = String(costumeTextByKey[k] ?? v.item.description ?? "").trim()
        const ret = await importOne({
          storyId: props.storyId,
          characterId: cid,
          characterName: props.characterName,
          characterDescription: props.characterDescription,
          frontImageUrl: props.frontImageUrl.startsWith("public/short-drama/role-assets/") ? toRoleAssetFileUrl(props.frontImageUrl) : props.frontImageUrl,
          costume: { name: String(v.item.name ?? "").trim() || "默认服装", description: desc, imageUrl: url }
        })
        if (ret.costumeId) nextCostumeMap[k] = ret.costumeId
      }

      const nextLookId = ""
      const nextCostumeId = ""

      persistSelectionPatch({
        characterId: cid,
        lookId: null,
        costumeId: null,
        lookIdByVariant: nextLookMap,
        costumeIdByVariant: nextCostumeMap,
        selectedHairIndex: 0,
        selectedClothingIndex: 0,
        hairText: "",
        hairTagsText: "",
        clothingText: "",
        clothingTagsText: ""
      } as any)
      props.onOpenChange(false)
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "保存失败")
    } finally {
      setSaving(false)
    }
  }, [
    canSave,
    characterAssetId,
    costumeByKey,
    costumeTagsByKey,
    costumeTextByKey,
    costumeVariants,
    importOne,
    lookByKey,
    lookTagsByKey,
    lookTextByKey,
    lookVariants,
    props
  ])

  return (
    <Dialog
      open={props.open}
      onOpenChange={(open) => {
        if (!open && imagePreview.open) return
        props.onOpenChange(open)
      }}
    >
      <DialogContent
        className={styles.content}
        onPointerDownOutside={(e) => { if (imagePreview.open) e.preventDefault() }}
        onInteractOutside={(e) => { if (imagePreview.open) e.preventDefault() }}
        onEscapeKeyDown={(e) => { if (imagePreview.open) e.preventDefault() }}
      >
        <DialogHeader className={styles.header}>
          <DialogTitle className={styles.title}>{props.characterName} · 抽卡与入库</DialogTitle>
        </DialogHeader>

        {error ? <div className={styles.error}>{error}</div> : null}

        <div className={styles.body}>
          <div className={styles.left}>
            <div className={styles.leftTop}>
              <div className={styles.avatarWrap}>
                {props.frontImageUrl.trim() ? (
                  <ResolvedImg className={styles.avatarImg} src={toCandidateSrc(props.frontImageUrl)} alt={props.characterName} />
                ) : null}
              </div>
            </div>

            <div className={styles.leftPicked}>
              <div className={styles.leftPickedTitle}>
                装造：{lookSelectedCount}/{lookVariants.length} 已选择
              </div>
              {selectedLookUrls.length ? (
                <div className={styles.leftPickedGrid}>
                  {selectedLookUrls.map((u, idx) => (
                    <ResolvedThumbButton
                      key={`look_sel_${idx}`}
                      className={styles.leftPickedThumbBtn}
                      imgClassName={styles.leftPickedThumbImg}
                      src={u}
                      alt={`look_${idx + 1}`}
                      onPreview={(src) => openImagePreview({ src, alt: `装造_${idx + 1}` })}
                    />
                  ))}
                </div>
              ) : (
                <div className={styles.leftPickedEmpty}>未选择装造</div>
              )}
            </div>

            <div className={styles.leftPicked}>
              <div className={styles.leftPickedTitle}>
                服装：{costumeSelectedCount}/{costumeVariants.length} 已选择
              </div>
              {selectedCostumeUrls.length ? (
                <div className={styles.leftPickedGrid}>
                  {selectedCostumeUrls.map((u, idx) => (
                    <ResolvedThumbButton
                      key={`costume_sel_${idx}`}
                      className={styles.leftPickedThumbBtn}
                      imgClassName={styles.leftPickedThumbImg}
                      src={u}
                      alt={`costume_${idx + 1}`}
                      onPreview={(src) => openImagePreview({ src, alt: `服装_${idx + 1}` })}
                    />
                  ))}
                </div>
              ) : (
                <div className={styles.leftPickedEmpty}>未选择服装</div>
              )}
            </div>
          </div>

          <div className={styles.right}>
            <div className={styles.bulkBar}>
              <div className={styles.bulkTitle}>批量抽卡</div>
              <div className={styles.bulkActions}>
                <div className={styles.bulkCount}>
                  <span className={styles.bulkCountLabel}>每项抽</span>
                  <input
                    className={styles.countInput}
                    type="number"
                    min={1}
                    max={5}
                    value={drawCountText}
                    onChange={(e) => setDrawCountText(e.currentTarget.value)}
                    onBlur={() => setDrawCountText(String(clampInt(Number(drawCountText), 1, 5)))}
                  />
                  <span className={styles.bulkCountLabel}>张</span>
                </div>
                <button
                  type="button"
                  className={styles.primaryActionBtn}
                  onClick={() =>
                    void enqueueDrawJob([
                      ...lookVariants.map((v) => ({ kind: "look" as const, variantKey: v.key, variantName: v.name })),
                      ...costumeVariants.map((v) => ({ kind: "costume" as const, variantKey: v.key, variantName: v.name }))
                    ])
                  }
                  disabled={bulkLoading || bulkSubmitting}
                >
                  {bulkSubmitting ? (
                    <span className={styles.btnLoading}>
                      <span className={styles.spinner} />
                      提交中…
                    </span>
                  ) : bulkLoading ? (
                    "抽卡中"
                  ) : (
                    "一键抽全部"
                  )}
                </button>
              </div>
              {bulkTotal > 0 ? (
                <div className={styles.bulkProgress}>
                  <div className={styles.bulkProgressBar}>
                    <div
                      className={styles.bulkProgressInner}
                      style={{ width: `${bulkTotal ? Math.round((bulkDone / bulkTotal) * 100) : 0}%` }}
                    />
                  </div>
                  <div className={styles.bulkProgressText}>
                    {bulkDone}/{bulkTotal}
                  </div>
                </div>
              ) : null}
            </div>

            <div className={styles.tabs}>
              <button
                type="button"
                className={tab === "look" ? `${styles.tabBtn} ${styles.tabBtnActive}` : styles.tabBtn}
                onClick={() => setTab("look")}
              >
                装造（{lookVariants.length}）
              </button>
              <button
                type="button"
                className={tab === "costume" ? `${styles.tabBtn} ${styles.tabBtnActive}` : styles.tabBtn}
                onClick={() => setTab("costume")}
              >
                服装（{costumeVariants.length}）
              </button>
            </div>

            <div className={styles.variantList}>
              {(tab === "look" ? lookVariants : costumeVariants).map((v) => {
                const kind: VariantKind = tab
                const expandKey = `${kind}:${v.key}`
                const isExpanded = Boolean(expanded[expandKey])
                const state = kind === "look" ? lookByKey[v.key] : costumeByKey[v.key]
                const candidates = normalizeCandidates(state?.candidates ?? [])
                const selected = String(state?.selected ?? "").trim()
                const pickedText = selected ? "已选" : "未选"
                const rowError = typeof state?.error === "string" && state.error.trim() ? state.error.trim() : ""
                const isQueued = state?.jobStatus === "queued"
                const isRunning = state?.jobStatus === "running" || Boolean(state?.loading)
                const statusText = isQueued ? "排队中…" : isRunning ? "抽卡中…" : candidates.length ? `已抽${candidates.length}张` : "未抽"

                return (
                  <div key={expandKey} className={styles.variantRow}>
                    <div className={styles.variantRowTop}>
                      <button
                        type="button"
                        className={styles.expandBtn}
                        onClick={() => setExpanded((prev) => ({ ...prev, [expandKey]: !Boolean(prev[expandKey]) }))}
                        aria-label={isExpanded ? "收起" : "展开"}
                      >
                        {isExpanded ? "▾" : "▸"}
                      </button>

                      <div className={styles.variantRowMain}>
                        <div className={styles.variantName}>{v.name}</div>
                        <div className={styles.variantMeta}>
                          <span className={styles.variantStatus}>{statusText}</span>
                          <span className={styles.variantMetaDot}>·</span>
                          <span className={styles.variantPicked}>{pickedText}</span>
                        </div>
                      </div>

                      <div className={styles.variantRowActions}>
                        <button
                          type="button"
                          className={styles.smallBtn}
                          onClick={() => {
                            if (kind === "look") {
                              setLookByKey((prev) => {
                                const cur = prev[v.key] ?? { candidates: [] }
                                return { ...prev, [v.key]: { ...cur, jobStatus: "queued", loading: false, error: null } }
                              })
                            } else {
                              setCostumeByKey((prev) => {
                                const cur = prev[v.key] ?? { candidates: [] }
                                return { ...prev, [v.key]: { ...cur, jobStatus: "queued", loading: false, error: null } }
                              })
                            }
                            void enqueueDrawJob([{ kind, variantKey: v.key, variantName: v.name }])
                          }}
                          disabled={isQueued || isRunning || bulkLoading || bulkSubmitting}
                        >
                          {isQueued ? "排队中…" : isRunning ? "抽卡中…" : "重抽"}
                        </button>
                      </div>
                    </div>

                    {rowError ? <div className={styles.rowError}>{rowError}</div> : null}

                    {isExpanded ? (
                      <div className={styles.variantRowBody}>
                        <div className={styles.inputRow}>
                          <div className={styles.inputLabel}>标签</div>
                          <input
                            className={styles.textInput}
                            value={kind === "look" ? String(lookTagsByKey[v.key] ?? "") : String(costumeTagsByKey[v.key] ?? "")}
                            onChange={(e) => {
                              const value = e.currentTarget.value
                              if (kind === "look") setLookTagsByKey((prev) => ({ ...prev, [v.key]: value }))
                              else setCostumeTagsByKey((prev) => ({ ...prev, [v.key]: value }))
                            }}
                            placeholder="如：日常"
                          />
                        </div>

                        <div className={styles.inputRow}>
                          <div className={styles.inputLabel}>描述</div>
                          <textarea
                            className={styles.textArea}
                            value={kind === "look" ? String(lookTextByKey[v.key] ?? "") : String(costumeTextByKey[v.key] ?? "")}
                            onChange={(e) => {
                              const value = e.currentTarget.value
                              if (kind === "look") setLookTextByKey((prev) => ({ ...prev, [v.key]: value }))
                              else setCostumeTextByKey((prev) => ({ ...prev, [v.key]: value }))
                            }}
                            rows={2}
                          />
                        </div>

                        <div className={styles.candidateGrid}>
                          {candidates.length ? (
                            candidates.map((u: string, imgIdx: number) => (
                              <ResolvedCandidateCard
                                key={`${expandKey}:img:${imgIdx}`}
                                src={toCandidateSrc(u)}
                                alt={`${v.name}_${imgIdx + 1}`}
                                containerClassName={u === selected ? `${styles.candidateBtn} ${styles.candidateBtnActive}` : styles.candidateBtn}
                                imageClassName={styles.candidateImg}
                                onPreview={(src) => openImagePreview({ src, alt: `${v.name}_${imgIdx + 1}` })}
                                topBar={
                                  <div className={styles.candidateTopBar}>
                                    <button
                                      type="button"
                                      className={u === selected ? `${styles.selectBadge} ${styles.selectBadgeActive}` : styles.selectBadge}
                                      aria-label={u === selected ? "取消选中" : "选中"}
                                      onClick={(e) => {
                                        e.stopPropagation()
                                        if (kind === "look") {
                                          setLookByKey((prev) => {
                                            const cur = prev[v.key] ?? { candidates: [] }
                                            return { ...prev, [v.key]: { ...cur, candidates, selected: u } }
                                          })
                                          const base = ((selectionRef.current as any)?.selectedLookCandidateKeyByVariant ?? {}) as Record<string, string>
                                          persistSelectionPatch({ selectedLookCandidateKeyByVariant: { ...base, [v.key]: u } } as any)
                                        } else {
                                          setCostumeByKey((prev) => {
                                            const cur = prev[v.key] ?? { candidates: [] }
                                            return { ...prev, [v.key]: { ...cur, candidates, selected: u } }
                                          })
                                          const base = ((selectionRef.current as any)?.selectedCostumeCandidateKeyByVariant ?? {}) as Record<string, string>
                                          persistSelectionPatch({ selectedCostumeCandidateKeyByVariant: { ...base, [v.key]: u } } as any)
                                        }
                                      }}
                                    >
                                      <span className={u === selected ? `${styles.selectDot} ${styles.selectDotActive}` : styles.selectDot} />
                                    </button>
                                  </div>
                                }
                              />
                            ))
                          ) : (
                            <div className={styles.candidateEmpty}>暂未抽卡</div>
                          )}
                        </div>
                      </div>
                    ) : null}
                  </div>
                )
              })}
            </div>

            <div className={styles.footer}>
              <button type="button" className={styles.saveBtn} disabled={!canSave} onClick={() => void onSave()}>
                {saving ? "保存中…" : "保存到资产库（全部）"}
              </button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
