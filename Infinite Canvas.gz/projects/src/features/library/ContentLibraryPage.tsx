"use client"

import type { ReactElement } from "react"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { ScopeTabs } from "./components/ScopeTabs"
import type { MyContentType } from "./components/MyTypeTabs"
import { CategorySidebar } from "./components/CategorySidebar"
import { LibraryToolbar } from "./components/LibraryToolbar"
import { LibraryGrid } from "./components/LibraryGrid"
import { MyStoriesGroupedGrid } from "./components/MyStoriesGroupedGrid"
import { UploadResourceModal } from "./components/UploadResourceModal"
import { AiGenerateResourceModal } from "./components/AiGenerateResourceModal"
import { BulkActionBar } from "./components/BulkActionBar"
import { PublicResourcePreviewModal } from "./components/PublicResourcePreviewModal"
import { StoryContentModal } from "./components/StoryContentModal"
import { CopyrightReviewFilters } from "./components/CopyrightReviewFilters"
import { CopyrightProjectGrid } from "./components/CopyrightProjectGrid"
import { CopyrightProjectDetail } from "./components/CopyrightProjectDetail"
import { CopyrightLibraryPreviewModal } from "./components/CopyrightLibraryPreviewModal"
import { ConfirmModal } from "@/shared/ui/ConfirmModal"
import { deleteStory } from "@/server/actions/library/library"
import { aiGeneratePublicResource } from "@/server/actions/library/ai-generate"
import type { LibraryItem } from "@/shared/contracts/library/libraryItem"
import type {
  CopyrightLibraryCounts,
  CopyrightLibraryProject,
  CopyrightLibraryReviewFilter,
  CopyrightLibraryItem
} from "@/shared/contracts/library/copyrightLibrary"
import styles from "./ContentLibraryPage.module.css"
import { useLibraryData } from "./hooks/useLibraryData"
import { useLibrarySelection } from "./hooks/useLibrarySelection"
import { COPYRIGHT_CATEGORIES } from "./utils/libraryUtils"
import { postFormDataWithProgress, putBlobWithProgress } from "@/shared/utils/uploadWithProgress"

function createEmptyCopyrightCounts(): CopyrightLibraryCounts {
  return {
    all: 0,
    scene: 0,
    character: 0,
    prop: 0,
    video: 0,
    audio: 0
  }
}

export function ContentLibraryPage(): ReactElement {
  const router = useRouter()
  const searchParams = useSearchParams()
  const gridWrapRef = useRef<HTMLDivElement | null>(null)
  const loadMoreSentinelRef = useRef<HTMLDivElement | null>(null)
  
  const {
    scope, setScope,
    category, setCategory,
    view, setView,
    query, setQuery,
    updateUrl,
    displayItems,
    publicHasMore,
    publicLoadingMore,
    loadMorePublic,
    counts,
    categories,
    loading,
    refreshPublicData,
    loadMyStories
  } = useLibraryData()

  const {
    selectedIds,
    setSelectedIds,
    toggleSelected,
    clearSelected,
    previewItem,
    setPreviewItem,
    bulkDeleting,
    handleBulkDelete
  } = useLibrarySelection(scope, category)

  const [uploadModalOpen, setUploadModalOpen] = useState(false)
  const [aiModalOpen, setAiModalOpen] = useState(false)
  const [myType, setMyType] = useState<MyContentType>("standard")
  const [storyDeleteConfirm, setStoryDeleteConfirm] = useState<{ ids: string[]; tvcCount: number; standardCount: number } | null>(null)
  const [storyDeleting, setStoryDeleting] = useState(false)
  const [publicDeleteConfirm, setPublicDeleteConfirm] = useState<{ ids: string[] } | null>(null)
  const [storyContentItem, setStoryContentItem] = useState<{ id: string; title?: string } | null>(null)
  const [notice, setNotice] = useState<{ type: "info" | "error"; message: string } | null>(null)
  const [pendingLibraryItems, setPendingLibraryItems] = useState<LibraryItem[]>([])
  const [generatingIds, setGeneratingIds] = useState<string[]>([])
  const [activeGenerateJobs, setActiveGenerateJobs] = useState<Array<{ jobId: string; characterId: string }>>([])
  const [copyrightProjects, setCopyrightProjects] = useState<CopyrightLibraryProject[]>([])
  const [copyrightCounts, setCopyrightCounts] = useState<CopyrightLibraryCounts>(() => createEmptyCopyrightCounts())
  const [copyrightLoading, setCopyrightLoading] = useState(false)
  const [copyrightReviewFilter, setCopyrightReviewFilter] = useState<CopyrightLibraryReviewFilter>("all")
  const [copyrightProjectId, setCopyrightProjectId] = useState<string | null>(null)
  const [copyrightPreviewItem, setCopyrightPreviewItem] = useState<CopyrightLibraryItem | null>(null)
  const generateJobSourcesRef = useRef<Record<string, EventSource>>({})

  useEffect(() => {
    if (!notice) return
    const t = window.setTimeout(() => setNotice(null), 4000)
    return () => window.clearTimeout(t)
  }, [notice])

  useEffect(() => {
    if (scope !== "library") return
    if (pendingLibraryItems.length === 0) return
    setPendingLibraryItems((prev) => prev.filter((p) => !displayItems.some((i) => i.id === p.id)))
  }, [displayItems, pendingLibraryItems.length, scope])

  useEffect(() => {
    if (scope !== "my") setMyType("standard")
  }, [scope])

  useEffect(() => {
    if (scope !== "my") return
    clearSelected()
    setStoryDeleteConfirm(null)
  }, [clearSelected, myType, query, scope])

  useEffect(() => {
    if (scope !== "library" && scope !== "shared") return
    if (!publicHasMore) return
    const root = gridWrapRef.current
    const target = loadMoreSentinelRef.current
    if (!root || !target) return
    const observer = new IntersectionObserver(
      (entries) => {
        const entry = entries[0]
        if (!entry?.isIntersecting) return
        if (loading || publicLoadingMore || !publicHasMore) return
        void loadMorePublic()
      },
      { root, rootMargin: "220px 0px" }
    )
    observer.observe(target)
    return () => observer.disconnect()
  }, [loadMorePublic, loading, publicHasMore, publicLoadingMore, scope])

  useEffect(() => {
    if (activeGenerateJobs.length === 0) return
    const sources = generateJobSourcesRef.current

    const closeSource = (jobId: string) => {
      const es = sources[jobId]
      if (!es) return
      try {
        es.close()
      } catch {}
      delete sources[jobId]
    }

    const removeJob = (jobId: string, characterId: string) => {
      setActiveGenerateJobs((prev) => prev.filter((j) => j.jobId !== jobId))
      setGeneratingIds((prev) => prev.filter((id) => id !== characterId))
    }

    const subscribe = (jobId: string, characterId: string) => {
      if (sources[jobId]) return
      const es = new EventSource(`/api/jobs/${encodeURIComponent(jobId)}/events`)
      sources[jobId] = es

      es.onmessage = (ev) => {
        const payload = (() => {
          try {
            return JSON.parse(ev.data)
          } catch {
            return null
          }
        })() as any
        const snapshot = payload?.data?.snapshot
        if (!snapshot || typeof snapshot !== "object") return
        const status = String(snapshot.status ?? "")
        if (status === "done" || status === "error") {
          closeSource(jobId)
          removeJob(jobId, characterId)
          void refreshPublicData()
        }
      }

      es.onerror = async () => {
        closeSource(jobId)
        try {
          const res = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`)
          const json = (await res.json().catch(() => null)) as any
          const status = String(json?.data?.job?.status ?? "")
          if (status === "done" || status === "error") {
            removeJob(jobId, characterId)
            void refreshPublicData()
            return
          }
        } catch {}
      }
    }

    for (const job of activeGenerateJobs) subscribe(job.jobId, job.characterId)

    return () => {
      for (const job of activeGenerateJobs) closeSource(job.jobId)
    }
  }, [activeGenerateJobs, refreshPublicData])

  useEffect(() => {
    if (scope !== "copyright") {
      setCopyrightProjectId(null)
      setCopyrightPreviewItem(null)
      return
    }
    setCopyrightReviewFilter("all")
  }, [scope])

  useEffect(() => {
    if (scope !== "copyright") return
    const nextProjectId = (searchParams.get("projectId") ?? "").trim() || null
    setCopyrightProjectId(nextProjectId)
  }, [scope, searchParams])

  useEffect(() => {
    if (scope !== "copyright") return
    let cancelled = false

    const loadCopyrightProjects = async () => {
      setCopyrightLoading(true)
      try {
        const qs = new URLSearchParams()
        qs.set("category", category)
        qs.set("reviewFilter", copyrightReviewFilter)
        if (query.trim()) qs.set("search", query.trim())
        const res = await fetch(`/api/library/copyright-projects?${qs.toString()}`, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as
          | { ok?: boolean; data?: { projects?: CopyrightLibraryProject[]; counts?: CopyrightLibraryCounts }; error?: { message?: string } }
          | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        if (cancelled) return
        setCopyrightProjects(Array.isArray(json.data?.projects) ? json.data.projects : [])
        setCopyrightCounts(json.data?.counts ?? createEmptyCopyrightCounts())
      } catch (error) {
        if (cancelled) return
        setCopyrightProjects([])
        setCopyrightCounts(createEmptyCopyrightCounts())
        setNotice({ type: "error", message: error instanceof Error ? error.message : "加载版权库失败" })
      } finally {
        if (!cancelled) setCopyrightLoading(false)
      }
    }

    void loadCopyrightProjects()
    return () => {
      cancelled = true
    }
  }, [category, copyrightReviewFilter, query, scope])

  useEffect(() => {
    if (scope !== "copyright") return
    const hasProcessing = copyrightProjects.some((project) =>
      project.items.some((item) => String(item.assetStatus ?? "").trim() === "Processing")
    )
    if (!hasProcessing) return
    const timer = window.setInterval(() => {
      const qs = new URLSearchParams()
      qs.set("category", category)
      qs.set("reviewFilter", copyrightReviewFilter)
      if (query.trim()) qs.set("search", query.trim())
      void fetch(`/api/library/copyright-projects?${qs.toString()}`, { cache: "no-store" })
        .then((res) => res.json())
        .then((json) => {
          if (!json?.ok) return
          setCopyrightProjects(Array.isArray(json.data?.projects) ? json.data.projects : [])
          setCopyrightCounts(json.data?.counts ?? createEmptyCopyrightCounts())
        })
        .catch(() => {})
    }, 5000)
    return () => window.clearInterval(timer)
  }, [category, copyrightProjects, copyrightReviewFilter, query, scope])

  const handleItemClick = useCallback(
    (item: LibraryItem) => {
      if (scope !== "my") return
      if (item.type === "tvc") {
        router.push(`/tvc?projectId=${encodeURIComponent(item.id)}`)
        return
      }
      if (item.storyType === "canvas") {
        const outlineId = (item.outlineId ?? "").trim()
        router.push(`/video/canvas?storyId=${encodeURIComponent(item.id)}&outlineId=${encodeURIComponent(outlineId)}`)
        return
      }
      if (item.storyType === "quick_generate") {
        router.push(`/script/quick-generate/${encodeURIComponent(item.id)}`)
        return
      }
      const stage = item.progressStage ?? "outline"
      if (stage === "outline") {
        router.push(`/script/workspace/${item.id}`)
        return
      }
      router.push(`/video?storyId=${item.id}&tab=list`)
    },
    [router, scope]
  )

  const myFilteredItems = scope !== "my" ? displayItems : displayItems.filter((i) => i.type !== "tvc")

  const generatingIdSet = useMemo(() => new Set(generatingIds), [generatingIds])
  const libraryDisplayItems = useMemo(() => {
    const baseItems =
      scope === "library"
        ? displayItems.map((item) => (generatingIdSet.has(item.id) ? { ...item, status: "generating" as const } : item))
        : displayItems
    if (scope !== "library") return baseItems
    const pending = pendingLibraryItems.filter((p) => !baseItems.some((b) => b.id === p.id))
    return [...pending, ...baseItems]
  }, [displayItems, generatingIdSet, pendingLibraryItems, scope])

  const myItemTypeById = useMemo(() => {
    const map = new Map<string, LibraryItem["type"]>()
    if (scope !== "my") return map
    for (const item of displayItems) map.set(item.id, item.type)
    return map
  }, [displayItems, scope])

  const mySelectedCounts = useMemo(() => {
    if (scope !== "my") return { tvcCount: 0, standardCount: 0 }
    let tvcCount = 0
    let standardCount = 0
    for (const id of selectedIds) {
      const t = myItemTypeById.get(id)
      if (t === "tvc") tvcCount += 1
      else standardCount += 1
    }
    return { tvcCount, standardCount }
  }, [myItemTypeById, scope, selectedIds])

  const myVisibleIds = useMemo(() => {
    if (scope !== "my") return []
    return myFilteredItems.map((i) => i.id)
  }, [myFilteredItems, scope])

  const handleMyStoryRenameSaved = useCallback(async () => {
    await loadMyStories(query)
    setNotice({ type: "info", message: "名称已保存" })
  }, [loadMyStories, query])

  const activeCopyrightProject = useMemo(() => {
    if (scope !== "copyright") return null
    if (!copyrightProjectId) return null
    return copyrightProjects.find((project) => project.storyId === copyrightProjectId) ?? null
  }, [copyrightProjectId, copyrightProjects, scope])
  const isCopyrightProjectDetail = scope === "copyright" && copyrightProjectId != null

  const myAllVisibleSelected = useMemo(() => {
    if (scope !== "my") return false
    if (myVisibleIds.length <= 0) return false
    for (const id of myVisibleIds) {
      if (!selectedIds.has(id)) return false
    }
    return true
  }, [myVisibleIds, scope, selectedIds])

  const toggleSelectAllMyVisible = useCallback(() => {
    if (scope !== "my") return
    if (myVisibleIds.length <= 0) return
    if (myAllVisibleSelected) {
      clearSelected()
      return
    }
    setSelectedIds(new Set(myVisibleIds))
  }, [clearSelected, myAllVisibleSelected, myVisibleIds, scope, setSelectedIds])

  const openMyStoriesDeleteConfirm = useCallback(() => {
    if (selectedIds.size <= 0) return
    const ids = Array.from(selectedIds)
    let tvcCount = 0
    let standardCount = 0
    for (const id of ids) {
      const t = myItemTypeById.get(id)
      if (t === "tvc") tvcCount += 1
      else standardCount += 1
    }
    setStoryDeleteConfirm({ ids, tvcCount, standardCount })
  }, [myItemTypeById, selectedIds])

  const confirmMyStoriesDelete = useCallback(async () => {
    const ids = storyDeleteConfirm?.ids ?? []
    if (ids.length <= 0 || storyDeleting) return
    setStoryDeleting(true)
    try {
      const failedIds: string[] = []
      const concurrency = Math.max(1, Math.min(6, ids.length))
      let cursor = 0
      await Promise.all(
        Array.from({ length: concurrency }).map(async () => {
          while (true) {
            const i = cursor
            cursor += 1
            if (i >= ids.length) return
            const id = ids[i]!
            try {
              const res = await deleteStory(id)
              if (!res.success) throw new Error("DELETE_FAILED")
            } catch {
              failedIds.push(id)
            }
          }
        })
      )
      await loadMyStories(query)
      setSelectedIds(new Set(failedIds))
      setStoryDeleteConfirm(null)
      const okCount = ids.length - failedIds.length
      if (failedIds.length > 0) {
        setNotice({ type: "error", message: `删除完成：成功 ${okCount}/${ids.length}，失败 ${failedIds.length}` })
      } else {
        const tvcCount = storyDeleteConfirm?.tvcCount ?? 0
        const standardCount = storyDeleteConfirm?.standardCount ?? 0
        const title = tvcCount > 0 && standardCount > 0 ? "内容" : tvcCount > 0 ? "项目" : "剧本"
        setNotice({ type: "info", message: `已删除 ${okCount} 个${title}` })
      }
    } finally {
      setStoryDeleting(false)
    }
  }, [loadMyStories, myItemTypeById, query, setSelectedIds, storyDeleteConfirm, storyDeleting])

  const openPublicBulkDeleteConfirm = useCallback(() => {
    if (scope !== "library") return
    if (selectedIds.size <= 0) return
    setPublicDeleteConfirm({ ids: Array.from(selectedIds) })
  }, [scope, selectedIds])

  const confirmPublicBulkDelete = useCallback(async () => {
    const ids = publicDeleteConfirm?.ids ?? []
    if (ids.length <= 0) return
    const deletedCount = await handleBulkDelete(ids, refreshPublicData)
    setPublicDeleteConfirm(null)
    setNotice({ type: "info", message: `已删除 ${deletedCount ?? 0} 项素材` })
  }, [handleBulkDelete, publicDeleteConfirm, refreshPublicData])

  const uploadPublicResource = useCallback(
    async (
      formData: FormData,
      opts?: { onProgress?: (p: { loaded: number; total: number; percent: number | null }) => void; onAbort?: (abort: () => void) => void }
    ): Promise<{ id?: string | null; url?: string | null; storageKey?: string | null } | void> => {
      const file = formData.get("file")
      const type = formData.get("type")
      const name = formData.get("name")
      const description = formData.get("description")
      const tags = formData.get("tags")
      const applicableScenes = formData.get("applicableScenes")
      const durationMsRaw = formData.get("durationMs")
      const durationMsNum =
        typeof durationMsRaw === "string" && Number.isFinite(Number(durationMsRaw)) && Number(durationMsRaw) > 0 ? Math.round(Number(durationMsRaw)) : undefined

      const isLarge = file instanceof File && file.size > 8 * 1024 * 1024
      const canChunk = file instanceof File && typeof type === "string" && type.trim()
      if (isLarge && canChunk) {
        let aborted = false
        let currentAbort: (() => void) | null = null
        let uploadId: string | null = null

        const abortAll = () => {
          aborted = true
          currentAbort?.()
          if (uploadId) {
            void fetch("/api/library/public-resources/upload-abort", {
              method: "POST",
              headers: { "content-type": "application/json" },
              credentials: "include",
              body: JSON.stringify({ uploadId })
            })
          }
        }
        opts?.onAbort?.(abortAll)

        const initRes = await fetch("/api/library/public-resources/upload-init", {
          method: "POST",
          headers: { "content-type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            type,
            fileName: file.name,
            contentType: file.type || "application/octet-stream",
            size: file.size,
            ...(durationMsNum !== undefined ? { durationMs: durationMsNum } : {}),
            name: typeof name === "string" ? name : undefined,
            description: typeof description === "string" ? description : undefined,
            tags: typeof tags === "string" ? tags : undefined,
            applicableScenes: typeof applicableScenes === "string" ? applicableScenes : undefined
          })
        })
        const initJson = (await initRes.json().catch(() => null)) as any
        if (!initRes.ok || !initJson?.ok) throw new Error(initJson?.error?.message ?? `初始化上传失败（${initRes.status}）`)

        uploadId = String(initJson.data?.uploadId ?? "")
        const chunkSize = Number(initJson.data?.chunkSize ?? 0)
        const totalChunks = Number(initJson.data?.totalChunks ?? 0)
        if (!uploadId || !chunkSize || !totalChunks) throw new Error("初始化上传失败：参数缺失")

        for (let i = 0; i < totalChunks; i++) {
          if (aborted) throw new Error("上传已取消")
          const start = i * chunkSize
          const end = Math.min(file.size, start + chunkSize)
          const blob = file.slice(start, end)
          const { promise, abort } = putBlobWithProgress({
            url: `/api/library/public-resources/upload-chunk?uploadId=${encodeURIComponent(uploadId)}&index=${i}`,
            blob,
            onProgress: (p) => {
              const loadedOverall = start + p.loaded
              const percent = file.size > 0 ? Math.round((loadedOverall / file.size) * 100) : null
              opts?.onProgress?.({ loaded: loadedOverall, total: file.size, percent })
            }
          })
          currentAbort = abort
          const { status, json } = await promise
          const anyJson = json as any
          if (!anyJson?.ok) throw new Error(anyJson?.error?.message ?? `上传分片失败（${status}）`)
          opts?.onProgress?.({ loaded: end, total: file.size, percent: Math.round((end / file.size) * 100) })
        }

        const doneRes = await fetch("/api/library/public-resources/upload-complete", {
          method: "POST",
          headers: { "content-type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ uploadId })
        })
        const doneJson = (await doneRes.json().catch(() => null)) as any
        if (!doneRes.ok || !doneJson?.ok) throw new Error(doneJson?.error?.message ?? `完成上传失败（${doneRes.status}）`)
        return doneJson?.data ?? null
      }

      const { promise, abort } = postFormDataWithProgress({
        url: "/api/library/public-resources/upload",
        formData,
        onProgress: opts?.onProgress
      })
      opts?.onAbort?.(abort)
      const { status, json } = await promise
      const anyJson = json as any
      if (!anyJson?.ok) throw new Error(anyJson?.error?.message ?? `上传失败（${status}）`)
      return anyJson?.data ?? null
    },
    []
  )

  const handleAiGenerate = useCallback(
    async (input: {
      file: File
      characterName: string
      characterDescription?: string
      lookItems: Array<{ id: string; text: string; tags: string }>
      costumeItems: Array<{ id: string; text: string; tags: string }>
    }) => {
      const storyId = (() => {
        try {
          return (window.localStorage.getItem("last_story_id") ?? "").trim()
        } catch {
          return ""
        }
      })()
      if (!storyId) throw new Error("请先打开一个剧本，再进行 AI 生成")

      const fd = new FormData()
      fd.append("file", input.file)
      fd.append("type", "character")
      fd.append("name", input.characterName.trim())
      if (input.characterDescription?.trim()) fd.append("description", input.characterDescription.trim())

      let characterId = ""
      try {
        const uploadRes = await uploadPublicResource(fd)
        characterId = String((uploadRes as any)?.id ?? "").trim()
        const frontImageUrl = String((uploadRes as any)?.url ?? "").trim()
        const frontImageStorageKey = String((uploadRes as any)?.storageKey ?? "").trim()
        if (!characterId || !frontImageUrl || !frontImageStorageKey) throw new Error("上传正视图失败")

        const pendingItem: LibraryItem = {
          id: characterId,
          title: input.characterName.trim(),
          type: "material",
          scope: "library",
          publicCategory: "roles",
          subtitle: input.characterDescription?.trim() ?? "",
          thumbnail: frontImageUrl,
          originalUrl: frontImageUrl,
          status: "generating"
        }
        setPendingLibraryItems((prev) => [pendingItem, ...prev.filter((p) => p.id !== characterId)])
        setGeneratingIds((prev) => Array.from(new Set([characterId, ...prev])))
        void refreshPublicData()

        const lookItems = input.lookItems.map((it, idx) => ({
          kind: "look" as const,
          variantKey: it.id,
          variantName: `装造${idx + 1}`,
          text: it.text.trim(),
          tagsText: it.tags.trim(),
          count: 1
        }))
        const costumeItems = input.costumeItems.map((it, idx) => ({
          kind: "costume" as const,
          variantKey: it.id,
          variantName: `服装${idx + 1}`,
          text: it.text.trim(),
          tagsText: it.tags.trim(),
          count: 1
        }))
        const items = [...lookItems, ...costumeItems]
        if (items.length === 0) throw new Error("至少填写一条妆造或服装")
        const requestKey = items.length === 1 ? `${characterId}:${items[0]!.kind}:${items[0]!.variantKey}` : characterId
        const promptBase = [input.characterName.trim(), input.characterDescription?.trim()].filter(Boolean).join("\n")

        const res = await fetch("/api/coze/short-drama-role-assets-draw", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            storyId,
            characterKey: characterId,
            characterName: input.characterName.trim(),
            frontImageUrl,
            frontImageStorageKey,
            promptBase,
            style: "写实",
            append: true,
            requestKey,
            publicCharacterId: characterId,
            publicCharacterDescription: input.characterDescription?.trim() ?? "",
            items
          })
        })
        const json = (await res.json().catch(() => null)) as any
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `生成失败（${res.status}）`)
        const jobId = String(json?.data?.jobId ?? "").trim()
        if (jobId) {
          setActiveGenerateJobs((prev) => {
            if (prev.some((j) => j.jobId === jobId)) return prev
            return [{ jobId, characterId }, ...prev].slice(0, 20)
          })
        }
      } catch (e) {
        if (characterId) {
          setPendingLibraryItems((prev) => prev.filter((p) => p.id !== characterId))
          setGeneratingIds((prev) => prev.filter((id) => id !== characterId))
        }
        throw e
      }
    },
    [refreshPublicData, uploadPublicResource]
  )

  const sidebarCategories = scope === "copyright" ? COPYRIGHT_CATEGORIES : categories
  const sidebarCounts = scope === "copyright" ? copyrightCounts : counts
  const showSidebar = scope === "library" || scope === "shared" || scope === "copyright"

  return (
    <div className={styles.page}>
      <div className={styles.main}>
        <div className={styles.content}>
          <div className={styles.contentWrap}>
            {notice ? (
              <div className={`${styles.notice} ${notice.type === "error" ? styles.noticeError : styles.noticeInfo}`} role="status">
                {notice.message}
              </div>
            ) : null}
            <div className={styles.topRow}>
              <div className={styles.scopeWrap}>
                <ScopeTabs
                  value={scope}
                  onChange={(next) => {
                    setScope(next)
                    const nextCategory = next === "my" ? "draft" : "all"
                    setCategory(nextCategory)
                    updateUrl({ scope: next, category: nextCategory, projectId: null })
                  }}
                />
              </div>
              <LibraryToolbar
                view={view}
                onViewChange={(next) => {
                  setView(next)
                  updateUrl({ view: next })
                }}
                onSearch={(next) => {
                  setQuery(next)
                  updateUrl({ q: next || null })
                }}
                variant={scope}
                onUpload={() => setUploadModalOpen(true)}
                onGenerate={() => setAiModalOpen(true)}
                selectAllLabel={
                  scope === "my"
                    ? myVisibleIds.length > 0
                      ? myAllVisibleSelected
                        ? "取消全选"
                        : "全选"
                      : "全选"
                    : undefined
                }
                selectAllDisabled={scope === "my" ? myVisibleIds.length <= 0 || storyDeleting : undefined}
                onSelectAll={scope === "my" ? toggleSelectAllMyVisible : undefined}
                deleteLabel={
                  scope === "my"
                    ? selectedIds.size > 0
                      ? mySelectedCounts.tvcCount > 0 && mySelectedCounts.standardCount > 0
                        ? `删除内容（${selectedIds.size}）`
                        : mySelectedCounts.tvcCount > 0
                          ? `删除项目（${selectedIds.size}）`
                          : `删除剧本（${selectedIds.size}）`
                      : "删除剧本"
                    : scope === "library"
                      ? selectedIds.size > 0
                        ? `删除素材（${selectedIds.size}）`
                        : "删除素材"
                      : undefined
                }
                deleteDisabled={
                  scope === "my"
                    ? selectedIds.size <= 0 || storyDeleting
                    : scope === "library"
                      ? selectedIds.size <= 0 || bulkDeleting
                      : undefined
                }
                onDelete={scope === "my" ? openMyStoriesDeleteConfirm : scope === "library" ? openPublicBulkDeleteConfirm : undefined}
              />
            </div>

            {scope === "copyright" ? (
              <CopyrightReviewFilters value={copyrightReviewFilter} onChange={setCopyrightReviewFilter} />
            ) : null}

            <div className={styles.bodyRow}>
              {showSidebar ? (
                <CategorySidebar
                  value={category}
                  onChange={(next) => {
                    setCategory(next)
                    updateUrl({ category: next })
                  }}
                  categories={sidebarCategories}
                  counts={sidebarCounts}
                />
              ) : null}

              <div className={styles.contentInner}>
                <div className={styles.gridWrap} ref={gridWrapRef}>
                  {scope === "my" ? (
                    <MyStoriesGroupedGrid
                      items={myFilteredItems}
                      view={view}
                      onItemClick={(item) => handleItemClick(item)}
                      onViewContent={(item) => setStoryContentItem({ id: item.id, title: item.title })}
                      onRenameSaved={handleMyStoryRenameSaved}
                      selectedIds={selectedIds}
                      onToggleSelected={toggleSelected}
                      showStandard={myType === "standard"}
                      showTvc={false}
                    />
                  ) : scope === "copyright" ? (
                    isCopyrightProjectDetail ? (
                      <CopyrightProjectDetail
                        project={activeCopyrightProject}
                        view={view}
                        onBack={() => {
                          setCopyrightProjectId(null)
                          updateUrl({ projectId: null })
                        }}
                        onPreview={setCopyrightPreviewItem}
                      />
                    ) : (
                      <CopyrightProjectGrid
                        projects={copyrightProjects}
                        loading={copyrightLoading}
                        onOpenProject={(projectId) => {
                          setCopyrightProjectId(projectId)
                          updateUrl({ projectId })
                        }}
                      />
                    )
                  ) : (
                    <LibraryGrid
                      items={scope === "library" ? libraryDisplayItems : displayItems}
                      view={view}
                      onItemClick={(item) => setPreviewItem(item)}
                      selectedIds={selectedIds}
                      onToggleSelected={toggleSelected}
                    />
                  )}
                  {scope === "library" || scope === "shared" ? (
                    <div ref={loadMoreSentinelRef} className={styles.loadMoreSentinel} aria-hidden />
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <UploadResourceModal
        open={scope === "library" && uploadModalOpen}
        onClose={() => setUploadModalOpen(false)}
        onUpload={async (formData, opts) => {
          const result = await uploadPublicResource(formData, opts)
          await refreshPublicData()
          return result
        }}
        onAiGenerate={handleAiGenerate}
      />

      <AiGenerateResourceModal
        open={scope === "library" && aiModalOpen}
        onClose={() => setAiModalOpen(false)}
        onGenerateBase={async (input) => {
          if (input.type === "character") {
            const baseRes = await aiGeneratePublicResource({
              type: "character",
              prompt: input.prompt,
              name: input.name,
              description: input.description
            })
            if (!baseRes.success) throw new Error(baseRes.message)

            const characterId = baseRes.resourceId
            const frontImageUrl = baseRes.originalUrl
            const frontImageStorageKey = baseRes.originalStorageKey

            if (!characterId || !frontImageUrl || !frontImageStorageKey) throw new Error("生成正视图失败")
            
            const pendingItem: LibraryItem = {
              id: characterId,
              title: (input.name ?? "").trim(),
              type: "material",
              scope: "library",
              publicCategory: "roles",
              subtitle: input.description?.trim() ?? "",
              thumbnail: frontImageUrl,
              originalUrl: frontImageUrl,
              status: "generating"
            }
            setPendingLibraryItems((prev) => [pendingItem, ...prev.filter((p) => p.id !== characterId)])
            setGeneratingIds((prev) => Array.from(new Set([characterId, ...prev])))
            void refreshPublicData()
            
            return { id: characterId, url: frontImageUrl, storageKey: frontImageStorageKey }
          }
          return null
        }}
        onGenerate={async (input) => {
          if (input.type === "character") {
            const storyId = (() => {
              try {
                return (window.localStorage.getItem("last_story_id") ?? "").trim()
              } catch {
                return ""
              }
            })()
            if (!storyId) throw new Error("请先打开一个剧本，再进行 AI 生成")
            
            const characterId = input.baseCharacterId
            const frontImageUrl = input.baseImageUrl
            const frontImageStorageKey = input.baseImageStorageKey
            
            if (!characterId || !frontImageUrl || !frontImageStorageKey) throw new Error("请先生成基础图像")

            const lookItems = (input.lookItems ?? []).map((it, idx) => ({
              kind: "look" as const,
              variantKey: it.id,
              variantName: `装造${idx + 1}`,
              text: it.text.trim(),
              tagsText: it.tags.trim(),
              count: 1
            }))
            const costumeItems = (input.costumeItems ?? []).map((it, idx) => ({
              kind: "costume" as const,
              variantKey: it.id,
              variantName: `服装${idx + 1}`,
              text: it.text.trim(),
              tagsText: it.tags.trim(),
              count: 1
            }))
            const items = [...lookItems, ...costumeItems]
            if (items.length === 0) throw new Error("至少填写一条妆造或服装")

            let filteredItems = items
            if (input.itemId) {
              filteredItems = items.filter((it) => it.variantKey === input.itemId)
            }
            const requestKey =
              filteredItems.length === 1 ? `${characterId}:${filteredItems[0]!.kind}:${filteredItems[0]!.variantKey}` : characterId
            const promptBase = [(input.name ?? "").trim(), input.description?.trim()].filter(Boolean).join("\n")

            try {
              const res = await fetch("/api/coze/short-drama-role-assets-draw", {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({
                  storyId,
                  characterKey: characterId,
                  characterName: (input.name ?? "").trim(),
                  frontImageUrl,
                  frontImageStorageKey,
                  promptBase,
                  style: "写实",
                  append: true,
                  requestKey,
                  publicCharacterId: characterId,
                  publicCharacterDescription: input.description?.trim() ?? "",
                  items: filteredItems
                })
              })
              const json = (await res.json().catch(() => null)) as any
              if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `生成失败（${res.status}）`)
              
              const jobId = String(json?.data?.jobId ?? "").trim()
              if (jobId) {
                setActiveGenerateJobs((prev) => {
                  if (prev.some((j) => j.jobId === jobId)) return prev
                  return [{ jobId, characterId }, ...prev].slice(0, 20)
                })
              }
            } catch (e) {
              throw e
            }
            return
          }

          if (input.type === "background") {
            const promises: Promise<any>[] = []
            if (input.prompt?.trim()) {
              promises.push(
                aiGeneratePublicResource({
                  type: "background",
                  prompt: input.prompt.trim(),
                  name: input.name?.trim() ? `${input.name.trim()}-正视图` : "场景-正视图",
                  description: input.description,
                  tags: input.tags,
                  applicableScenes: input.applicableScenes
                })
              )
            }
            if (input.backPrompt?.trim()) {
              promises.push(
                aiGeneratePublicResource({
                  type: "background",
                  prompt: input.backPrompt.trim(),
                  name: input.name?.trim() ? `${input.name.trim()}-反视图` : "场景-反视图",
                  description: input.description,
                  tags: input.tags,
                  applicableScenes: input.applicableScenes
                })
              )
            }

            if (promises.length === 0) throw new Error("至少填写一个提示词")

            const results = await Promise.all(promises)
            for (const res of results) {
              if (!res.success) throw new Error(res.message)
            }
            await refreshPublicData()
            return
          }

          const res = await aiGeneratePublicResource({
            type: "props",
            prompt: input.prompt,
            name: input.name,
            description: input.description,
            tags: input.tags,
            applicableScenes: input.applicableScenes
          })
          if (!res.success) throw new Error(res.message)
          await refreshPublicData()
        }}
      />

      <PublicResourcePreviewModal
        open={(scope === "library" || scope === "shared") && previewItem != null}
        item={previewItem}
        onClose={() => setPreviewItem(null)}
      />
      <CopyrightLibraryPreviewModal
        open={scope === "copyright" && copyrightPreviewItem != null}
        item={copyrightPreviewItem}
        onClose={() => setCopyrightPreviewItem(null)}
      />
      <BulkActionBar
        selectedCount={scope === "library" || scope === "my" ? selectedIds.size : 0}
        deleting={scope === "library" ? bulkDeleting : scope === "my" ? storyDeleting : false}
        onClear={clearSelected}
        onDelete={scope === "library" ? openPublicBulkDeleteConfirm : scope === "my" ? openMyStoriesDeleteConfirm : undefined}
      />
      <StoryContentModal
        open={scope === "my" && storyContentItem != null}
        storyId={storyContentItem?.id ?? null}
        storyTitle={storyContentItem?.title}
        onClose={() => setStoryContentItem(null)}
      />
      <ConfirmModal
        open={scope === "my" && storyDeleteConfirm != null}
        title={
          (storyDeleteConfirm?.tvcCount ?? 0) > 0 && (storyDeleteConfirm?.standardCount ?? 0) > 0
            ? "删除内容"
            : (storyDeleteConfirm?.tvcCount ?? 0) > 0
              ? "删除项目"
              : "删除剧本"
        }
        message={
          (storyDeleteConfirm?.tvcCount ?? 0) > 0 && (storyDeleteConfirm?.standardCount ?? 0) > 0
            ? `确定删除选中的 ${storyDeleteConfirm?.ids.length ?? 0} 项内容吗？（剧本 ${storyDeleteConfirm?.standardCount ?? 0}，TVC 项目 ${storyDeleteConfirm?.tvcCount ?? 0}）此操作不可恢复。`
            : (storyDeleteConfirm?.tvcCount ?? 0) > 0
              ? `确定删除选中的 ${storyDeleteConfirm?.ids.length ?? 0} 个项目吗？此操作不可恢复。`
              : `确定删除选中的 ${storyDeleteConfirm?.ids.length ?? 0} 个剧本吗？此操作不可恢复。`
        }
        confirming={storyDeleting}
        onCancel={() => setStoryDeleteConfirm(null)}
        onConfirm={() => void confirmMyStoriesDelete()}
      />
      <ConfirmModal
        open={scope === "library" && publicDeleteConfirm != null}
        title="删除素材"
        message={`确定删除选中的 ${publicDeleteConfirm?.ids.length ?? 0} 项素材吗？此操作不可恢复。`}
        confirming={bulkDeleting}
        onCancel={() => setPublicDeleteConfirm(null)}
        onConfirm={() => void confirmPublicBulkDelete()}
      />
    </div>
  )
}
