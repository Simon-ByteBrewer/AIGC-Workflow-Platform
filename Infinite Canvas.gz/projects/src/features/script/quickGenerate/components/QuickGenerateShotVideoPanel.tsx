"use client"

import { useMemo, useState, type ReactElement } from "react"
import { QUICK_GENERATE_VIDEO_SUBTITLE_ERASE_JOB_TYPE } from "@/shared/jobs/jobTypes"
import type { QuickGenerateShotVideoResolvedItem } from "@/shared/quickGenerate/videoResults"
import { eraseQuickGenerateShotVideoSubtitle, selectQuickGenerateShotVideo } from "../api-client"
import { getQuickGenerateStableMediaSrc, QuickGenerateLazyVideo } from "./QuickGenerateLazyMedia"
import styles from "./QuickGenerateShotVideoPanel.module.css"

export type QuickGenerateShotVideoJobState = {
  jobId: string
  jobType: string
  status: "queued" | "running" | "error"
  stage: string
  errorMessage: string
}

type QuickGenerateShotVideoPanelProps = {
  episodeId: string
  shotNo: number
  videos: QuickGenerateShotVideoResolvedItem[]
  selectedJobId: string
  jobState?: QuickGenerateShotVideoJobState | null
  onSelected?: () => void
  onGenerate?: () => void
  generating?: boolean
}

function formatCreatedAt(value: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  const month = String(date.getMonth() + 1).padStart(2, "0")
  const day = String(date.getDate()).padStart(2, "0")
  const hours = String(date.getHours()).padStart(2, "0")
  const minutes = String(date.getMinutes()).padStart(2, "0")
  return `${month}-${day} ${hours}:${minutes}`
}

/**
 * quick-generate 分镜视频展示面板。
 *
 * 右侧常态展示最新缩略视频；点击后弹窗放大播放，并允许切换最近 10 条历史。
 */
export function QuickGenerateShotVideoPanel(props: QuickGenerateShotVideoPanelProps): ReactElement {
  const [open, setOpen] = useState(false)
  const [selectedJobId, setSelectedJobId] = useState<string>("")
  const [confirmingJobId, setConfirmingJobId] = useState<string>("")
  const [erasingJobId, setErasingJobId] = useState<string>("")
  const [actionError, setActionError] = useState<string>("")
  const latestVideo = props.videos[0] ?? null
  const effectiveSelectedJobId = (props.selectedJobId ?? "").trim()
  const activeJobId = selectedJobId || effectiveSelectedJobId || latestVideo?.jobId || ""
  const activeVideo = useMemo(() => {
    if (activeJobId) {
      return props.videos.find((video) => video.jobId === activeJobId) ?? latestVideo
    }
    return latestVideo
  }, [activeJobId, latestVideo, props.videos])

  const displayJobState = props.jobState ?? null

  const statusText = (() => {
    if (!displayJobState) return ""
    if (displayJobState.jobType === QUICK_GENERATE_VIDEO_SUBTITLE_ERASE_JOB_TYPE) {
      if (displayJobState.status === "queued" || displayJobState.status === "running") return "擦除中"
      if (displayJobState.status === "error") return "擦除失败"
      return ""
    }
    if (displayJobState.status === "queued") return "已入队"
    if (displayJobState.status === "running") return "生成中"
    if (displayJobState.status === "error") return "生成失败"
    return ""
  })()

  const visibleVideos = useMemo(() => props.videos.slice(0, 5), [props.videos])
  const activeVideoSrc = activeVideo
    ? getQuickGenerateStableMediaSrc({ cacheKey: activeVideo.storageKey, src: activeVideo.url })
    : ""
  const primaryPanelDetailMessage = displayJobState?.errorMessage.trim() ?? ""
  const emptyStateText =
    displayJobState?.status === "queued" || displayJobState?.status === "running" ? "视频任务进行中..." : "暂无视频结果"

  const confirmVideo = async (jobId: string) => {
    const episodeId = props.episodeId.trim()
    const picked = String(jobId ?? "").trim()
    if (!episodeId || !picked) return
    if (confirmingJobId) return
    setConfirmingJobId(picked)
    try {
      await selectQuickGenerateShotVideo({ episodeId, shotNo: props.shotNo, selectedJobId: picked })
      props.onSelected?.()
    } catch {
      // Let parent notice area / polling handle error, keep UI simple.
    } finally {
      setConfirmingJobId("")
    }
  }

  const eraseSubtitle = async (jobId: string) => {
    const episodeId = props.episodeId.trim()
    const picked = String(jobId ?? "").trim()
    if (!episodeId || !picked) return
    if (erasingJobId) return
    setActionError("")
    setErasingJobId(picked)
    try {
      await eraseQuickGenerateShotVideoSubtitle({ episodeId, shotNo: props.shotNo, jobId: picked })
    } catch (error) {
      const message = error instanceof Error ? error.message : "提交字幕擦除任务失败"
      setActionError(message)
    } finally {
      setErasingJobId("")
    }
  }

  return (
    <>
      <div className={styles.panel}>
        <div className={styles.statusRow}>
          <div className={styles.statusActionSlot}>
            <button
              type="button"
              className={styles.generateBtn}
              onClick={props.onGenerate}
              disabled={!props.onGenerate || props.generating}
            >
              {props.generating ? "入队中..." : "生成视频"}
            </button>
          </div>
          <div className={styles.statusSpacer} />
          <button type="button" className={styles.historyBtn} onClick={() => setOpen(true)} disabled={props.videos.length === 0}>
            查看全部
          </button>
        </div>

        {statusText ? (
          <div className={styles.statusBlock}>
            <div
              className={`${styles.statusHint} ${
                displayJobState?.status === "error" ? styles.statusError : styles.statusRunning
              }`}
            >
              {statusText}
            </div>
            {primaryPanelDetailMessage ? (
              <div className={styles.statusDetail}>{primaryPanelDetailMessage}</div>
            ) : null}
          </div>
        ) : null}

        {visibleVideos.length > 0 ? (
          <div className={styles.list} aria-label={`分镜 ${props.shotNo} 视频列表`}>
            {visibleVideos.map((video, index) => {
              const isSelected = Boolean(effectiveSelectedJobId) ? video.jobId === effectiveSelectedJobId : index === 0
              return (
                <div key={video.jobId} className={styles.videoCard} data-selected={isSelected ? "true" : "false"}>
                  <div className={styles.videoPoster}>
                    <QuickGenerateLazyVideo
                      src={video.url}
                      cacheKey={video.storageKey}
                      className={styles.videoEl}
                      placeholderClassName={styles.videoPlaceholder}
                      controls
                      playsInline
                      preload="metadata"
                    />
                  </div>
                  <div className={styles.cardLabel}>{`视频 ${video.versionNo}`}</div>
                  <button
                    type="button"
                    className={styles.subtitleEraseBtn}
                    disabled={erasingJobId === video.jobId}
                    onClick={(e) => {
                      e.stopPropagation()
                      void eraseSubtitle(video.jobId)
                    }}
                    aria-label={`为分镜 ${props.shotNo} 的该视频擦除字幕`}
                  >
                    {erasingJobId === video.jobId ? "提交中..." : "擦除字幕"}
                  </button>
                  <button
                    type="button"
                    className={styles.confirmBtn}
                    data-selected={isSelected ? "true" : "false"}
                    disabled={confirmingJobId === video.jobId}
                    onClick={(e) => {
                      e.stopPropagation()
                      void confirmVideo(video.jobId)
                    }}
                    aria-label={`确认分镜 ${props.shotNo} 使用该视频`}
                  >
                    {isSelected ? "已确认" : "确认"}
                  </button>
                  <div className={styles.cardMeta}>
                    <div>{formatCreatedAt(video.createdAt)}</div>
                    <div>{video.durationSeconds > 0 ? `${video.durationSeconds}s` : "未知时长"} · {video.settings.mode || "reference"}</div>
                  </div>
                </div>
              )
            })}
          </div>
        ) : (
          <div className={styles.empty}>{emptyStateText}</div>
        )}

        {latestVideo ? (
          <div className={styles.meta}>
            <div>最新版本 · {formatCreatedAt(latestVideo.createdAt)}</div>
            <div>{latestVideo.durationSeconds > 0 ? `${latestVideo.durationSeconds}s` : "时长待补充"}</div>
          </div>
        ) : null}

        {!displayJobState?.errorMessage && actionError ? <div className={styles.errorText}>{actionError}</div> : null}
      </div>

      {open && activeVideo ? (
        <div className={styles.modal} role="dialog" aria-modal="true" aria-label={`分镜 ${props.shotNo} 视频历史`}>
          <div className={styles.modalCard}>
            <div className={styles.playerWrap}>
              <div className={styles.modalHeader}>
                <div className={styles.modalTitle}>分镜 {String(props.shotNo).padStart(2, "0")} 视频历史</div>
                <button type="button" className={styles.closeBtn} onClick={() => setOpen(false)} aria-label="关闭">
                  ×
                </button>
              </div>
              <video
                key={activeVideo.jobId}
                className={styles.modalVideo}
                src={activeVideoSrc}
                controls
                autoPlay
                playsInline
                preload="metadata"
              />
            </div>

            <div className={styles.historyList}>
              {props.videos.map((video) => (
                <button
                  key={video.jobId}
                  type="button"
                  className={styles.historyItem}
                  data-active={video.jobId === activeVideo.jobId ? "true" : "false"}
                  onClick={() => setSelectedJobId(video.jobId)}
                >
                  <div className={styles.historyTitle}>版本 {video.versionNo}</div>
                  <div className={styles.historyMeta}>{formatCreatedAt(video.createdAt)}</div>
                  <div className={styles.historyMeta}>
                    {video.durationSeconds > 0 ? `${video.durationSeconds}s` : "未知时长"} · {video.settings.mode || "reference"}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : null}
    </>
  )
}
