"use client"

import { useEffect, useMemo, type ReactElement } from "react"
import type { MaterialAsset } from "./types"
import styles from "./EpisodeMaterialGalleryPage.module.css"

type Props = {
  asset: MaterialAsset
  onClose: () => void
  onRegenerate: () => void
}

function parseJsonMeta(meta: unknown): unknown {
  if (typeof meta !== "string") return meta
  const s = meta.trim()
  if (!s) return meta
  if (!(s.startsWith("{") || s.startsWith("["))) return meta
  try {
    return JSON.parse(s)
  } catch {
    return meta
  }
}

function metaObjectFromUnknown(meta: unknown): Record<string, unknown> | null {
  const parsed = parseJsonMeta(meta)
  if (!parsed) return null
  if (typeof parsed !== "object") return null
  if (Array.isArray(parsed)) return null
  return parsed as Record<string, unknown>
}

function kindLabel(kind: string): string {
  const k = (kind ?? "").trim().toLowerCase()
  if (k === "scene") return "场景"
  if (k === "role" || k === "character") return "人物"
  if (k === "item" || k === "prop" || k === "object") return "物品"
  return kind || "未知"
}

function pickText(v: unknown): string {
  return typeof v === "string" ? v : v === null || typeof v === "undefined" ? "" : String(v)
}

/**
 * 将错误信息转换为用户友好的中文提示
 */
function translateErrorMessage(errorMessage: string): string {
  const msg = errorMessage.toLowerCase()
  
  // 网络超时相关错误
  if (/timeout|timed out|请求超时/gi.test(msg)) {
    return "生成超时，请稍后重试"
  }
  
  // 网络连接错误
  if (/network error|connection error|connection refused|连接失败|网络错误/gi.test(msg)) {
    return "网络连接失败，请检查网络后重试"
  }
  
  // API 错误
  if (/api.*fail|api.*error|接口失败|接口错误/gi.test(msg)) {
    return "API 调用失败，请稍后重试"
  }
  
  // HTTP 50x 错误
  if (/50[0-9]|service unavailable|bad gateway|服务器繁忙|服务不可用/gi.test(msg)) {
    return "服务器暂时繁忙，请稍后重试"
  }
  
  // HTTP 401/403 错误
  if (/40[13]|unauthorized|forbidden|未授权|无权限/gi.test(msg)) {
    return "权限验证失败，请重新登录"
  }
  
  // HTTP 404 错误
  if (/404|not found|未找到|不存在/gi.test(msg)) {
    return "请求的资源不存在"
  }
  
  // HTTP 429 错误（请求过多）
  if (/429|too many requests|请求过多|频率限制/gi.test(msg)) {
    return "请求过于频繁，请稍后重试"
  }
  
  // 图片相关错误
  if (/image|picture|photo|图片|照片/gi.test(msg)) {
    if (/not found|missing|缺少|未找到/gi.test(msg)) {
      return "图片资源缺失，请检查素材配置"
    }
    if (/invalid|format|格式|无效/gi.test(msg)) {
      return "图片格式无效"
    }
    if (/download|下载/gi.test(msg)) {
      return "图片下载失败，请检查网络"
    }
  }
  
  // 文件上传错误
  if (/upload|上传/gi.test(msg)) {
    return "文件上传失败，请重试"
  }
  
  // 参数错误
  if (/parameter|argument|参数/gi.test(msg)) {
    return "参数错误，请检查输入内容"
  }
  
  // 验证错误
  if (/validation|verify|验证/gi.test(msg)) {
    return "验证失败，请检查输入"
  }
  
  // 内部错误
  if (/internal|内部/gi.test(msg)) {
    return "系统内部错误，请稍后重试"
  }
  
  // 其他错误，返回原文（如果是英文，尝试简单的提示）
  if (/^[a-z\s\d\.,;:!?'"()-]+$/i.test(errorMessage)) {
    // 纯英文错误，给通用提示
    return "生成失败，请稍后重试"
  }
  
  // 已经是中文或其他情况，返回原文
  return errorMessage
}

export function EpisodeMaterialFailureDetailModal({ asset, onClose, onRegenerate }: Props): ReactElement {
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [onClose])

  const metaObj = useMemo(() => metaObjectFromUnknown(asset.meta), [asset.meta])
  const rawErrorMessage = useMemo(() => pickText(metaObj?.errorMessage).trim(), [metaObj])
  const rawErrorRaw = useMemo(() => pickText(metaObj?.errorRaw).trim(), [metaObj])
  
  // 将错误信息翻译为用户友好的中文
  const errorMessage = useMemo(() => {
    return translateErrorMessage(rawErrorMessage)
  }, [rawErrorMessage])
  
  const errorRaw = useMemo(() => {
    // errorRaw 也需要翻译，但如果和 errorMessage 相同就不再重复
    const translated = translateErrorMessage(rawErrorRaw)
    return translated === errorMessage ? "" : translated
  }, [rawErrorRaw, errorMessage])
  
  const title = useMemo(() => `失败详情：${kindLabel(asset.kind)} / ${asset.name || asset.id}`, [asset.id, asset.kind, asset.name])

  const prompt = (asset.prompt ?? "").trim()
  const contextText = useMemo(() => {
    const lines: string[] = []
    if (asset.roleName) lines.push(`人物：${asset.roleName}`)
    if (asset.makeupName) lines.push(`妆造：${asset.makeupName}`)
    if (asset.costumeName) lines.push(`服装：${asset.costumeName}`)
    return lines.join("\n")
  }, [asset.costumeName, asset.makeupName, asset.roleName])

  const rawText = useMemo(() => {
    const blocks: string[] = []
    if (errorMessage) blocks.push(errorMessage)
    if (errorRaw && errorRaw !== errorMessage) blocks.push(errorRaw)
    return blocks.join("\n\n")
  }, [errorMessage, errorRaw])

  return (
    <div
      className={styles.modalOverlay}
      role="dialog"
      aria-modal="true"
      aria-label="失败详情"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>{title}</div>
          <div className={styles.actions}>
            <button type="button" className={`${styles.btn} ${styles.btnPrimary}`} onClick={onRegenerate}>
              重制
            </button>
            <button type="button" className={styles.btn} onClick={onClose}>
              关闭
            </button>
          </div>
        </div>

        <div className={styles.modalBody}>
          {contextText ? <div className={styles.hint}>{contextText}</div> : null}
          {prompt ? <div className={styles.hint}>提示词：{prompt.length > 320 ? `${prompt.slice(0, 320)}…` : prompt}</div> : null}
          <textarea className={styles.textarea} value={rawText || "（暂无失败详情）"} readOnly />
        </div>
      </div>
    </div>
  )
}

