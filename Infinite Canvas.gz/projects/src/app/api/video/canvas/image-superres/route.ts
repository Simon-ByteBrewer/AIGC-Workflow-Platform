import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { logger } from "@/shared/logger"
import { normalizeExternalImageModelCode } from "@/shared/image/externalImageModels"
import { stories } from "@/shared/schema/story"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { enqueueCanvasImageSuperresJob } from "@/server/domains/video/canvas/jobs/canvasImageSuperresWorker"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { listEnabledImageModelsForUser } from "@/server/domains/image/imageModelResolver"

export const runtime = "nodejs"

const bodySchema = z
  .union([
    z
      .object({
        storyId: z.string().trim().min(1).max(200),
        outlineId: z.string().trim().min(1).max(200),
        nodeId: z.string().trim().min(1).max(200),
        generatedImageId: z.string().trim().min(1).max(200),
        model: z.string().trim().min(1).max(100),
        sharpness: z.enum(["2K", "4K"])
      })
      .strict(),
    z
      .object({
        storyId: z.string().trim().min(1).max(200),
        outlineId: z.string().trim().min(1).max(200),
        nodeId: z.string().trim().min(1).max(200),
        imageUrl: z.string().trim().min(1).max(5000),
        assetId: z.string().trim().max(500).optional(),
        imageName: z.string().trim().max(200).optional(),
        model: z.string().trim().min(1).max(100),
        sharpness: z.enum(["2K", "4K"])
      })
      .strict()
  ])

/**
 * 统一模型名匹配口径，避免大小写或首尾空格差异导致错误回退。
 */
function normalizeModelName(value: string): string {
  return String(value ?? "").trim().toLowerCase()
}

/**
 * 创建 Canvas 图片超分异步任务。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const sanitizeUrlForLog = (url: string) => {
    const raw = (url ?? "").trim()
    if (!raw) return ""
    try {
      const u = new URL(raw)
      u.search = ""
      u.hash = ""
      return u.toString()
    } catch {
      const idx = raw.indexOf("?")
      return idx >= 0 ? raw.slice(0, idx) : raw
    }
  }
  const logBody = (() => {
    const d: any = parsed.data as any
    if ("imageUrl" in d && typeof d.imageUrl === "string") return { ...d, imageUrl: sanitizeUrlForLog(d.imageUrl) }
    return d
  })()
  logger.info({
    event: "canvas_api_request",
    module: "video/canvas",
    traceId,
    message: "POST /api/video/canvas/image-superres",
    body: logBody
  })

  await ensurePublicSchema()
  const db = await getDb({ stories })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "STORY_NOT_FOUND", "未找到可用的剧本"), { status: 404 })

  const enabledModels = await listEnabledImageModelsForUser(userId)
  const availableModels = enabledModels
    .map((item) => ({
      rawModelName: String(item.modelName ?? "").trim(),
      normalizedModelName: normalizeModelName(String(item.modelName ?? ""))
    }))
    .filter((item) => item.rawModelName && item.normalizedModelName)
  if (availableModels.length === 0) {
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号未配置可用的图片模型"), { status: 400 })
  }
  const requestedModel = String(parsed.data.model ?? "").trim()
  const normalizedRequestedModel = normalizeModelName(requestedModel)
  const normalizedRequestedExternalModel = normalizeExternalImageModelCode(requestedModel)
  const matchedModels = availableModels.filter((item) => {
    if (normalizedRequestedExternalModel) return item.rawModelName === normalizedRequestedExternalModel
    return item.normalizedModelName === normalizedRequestedModel
  })
  if (matchedModels.length !== 1) {
    logger.warn({
      event: "canvas_image_superres_model_rejected",
      module: "video/canvas",
      traceId,
      message: "图片超分请求的模型未命中可用模型，拒绝入队",
      requestedModel,
      availableModelNames: availableModels.map((item) => item.rawModelName),
      matchedCount: matchedModels.length
    })
    return NextResponse.json(makeApiErr(traceId, "MODEL_NOT_AVAILABLE", "当前账号不可使用该图片模型"), { status: 400 })
  }
  const model = matchedModels[0]!.rawModelName

  logger.info({
    event: "canvas_image_superres_model_matched",
    module: "video/canvas",
    traceId,
    message: "图片超分请求模型匹配成功",
    requestedModel,
    matchedModel: model
  })

  const { jobId, snapshot } = await enqueueCanvasImageSuperresJob({
    userId,
    traceId,
    storyId: parsed.data.storyId,
    outlineId: parsed.data.outlineId,
    nodeId: parsed.data.nodeId,
    generatedImageId: "generatedImageId" in parsed.data ? parsed.data.generatedImageId : undefined,
    imageUrl: "imageUrl" in parsed.data ? parsed.data.imageUrl : undefined,
    assetId: "assetId" in parsed.data ? parsed.data.assetId : undefined,
    imageName: "imageName" in parsed.data ? parsed.data.imageName : undefined,
    model,
    sharpness: parsed.data.sharpness
  })

  kickAllWorkers()
  logger.info({
    event: "canvas_api_response",
    module: "video/canvas",
    traceId,
    message: "POST /api/video/canvas/image-superres accepted",
    jobId
  })
  return NextResponse.json(makeApiOk(traceId, { jobId, snapshot }), { status: 202 })
}
