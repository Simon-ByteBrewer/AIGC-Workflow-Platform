"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import type { MouseEvent, ReactElement } from "react"
import { X } from "lucide-react"
import { useRouter } from "next/navigation"
import styles from "./ScriptCreationDialog.module.css"
import { ListboxSelect } from "@/shared/ui/ListboxSelect"
import { logger } from "@/shared/logger"
import type { ApiErr, ApiOk } from "@/shared/api"
import { enableScriptSourceEntry } from "../featureFlags"
import { createQuickGenerateProject } from "@/features/script/quickGenerate/api-client"
import {
  callShortDramaPlanning,
  patchStoryShortDramaMetadata,
  submitShortDramaParsingTask,
  submitShortDramaRoleParsingTask
} from "../api/shortDrama"

export type ScriptStartMode = "source" | "brief" | "script" | "quick"

type ScriptCreationDialogProps = {
  open: boolean
  onClose: () => void
  initialMode?: ScriptStartMode
}

export function ScriptCreationDialog({
  open,
  onClose,
  initialMode = "brief"
}: ScriptCreationDialogProps): ReactElement | null {
  const router = useRouter()
  const [mode, setMode] = useState<ScriptStartMode>(() => {
    if (!enableScriptSourceEntry && initialMode === "source") return "brief"
    return initialMode
  })
  const [title, setTitle] = useState("")
  const [ratio, setRatio] = useState("16:9")
  const [resolution, setResolution] = useState("1080p")
  const [shotStyle, setShotStyle] = useState("realistic")
  const [videoCategory, setVideoCategory] = useState("commentary")
  const [content, setContent] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errorText, setErrorText] = useState<string | null>(null)
  const [briefStoryId, setBriefStoryId] = useState<string | null>(null)

  const titleCount = title.length
  const contentCount = content.length

  const contentMaxLength = useMemo(() => {
    return mode === "script" ? 40000 : undefined
  }, [mode])

  const contentLabel = useMemo(() => {
    if (mode === "source") return "故事原文"
    if (mode === "script") return "剧本正文"
    return "剧情简介"
  }, [mode])

  const contentPlaceholder = useMemo(() => {
    return mode === "source"
      ? "粘贴或输入原文，支持长文本与多段落"
      : mode === "script"
        ? "粘贴或输入剧本正文，支持长文本与多段落"
      : "请输入剧情简介，支持多段落"
  }, [mode])
  
  useEffect(() => {
    if (!open) return
    setMode(() => {
      if (!enableScriptSourceEntry && initialMode === "source") return "brief"
      return initialMode
    })
    setBriefStoryId(null)
    setErrorText(null)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    return () => {
      document.body.style.overflow = prevOverflow
    }
  }, [initialMode, open])

  useEffect(() => {
    if (!open) return
    const onKeyDown = (e: KeyboardEvent): void => {
      if (e.key === "Escape") onClose()
    }
    window.addEventListener("keydown", onKeyDown)
    return () => window.removeEventListener("keydown", onKeyDown)
  }, [open, onClose])

  const onBackdropClick = useCallback(
    (e: MouseEvent<HTMLDivElement>): void => {
      if (e.target === e.currentTarget) onClose()
    },
    [onClose]
  )

  const canConfirm = mode === "quick" ? title.trim().length > 0 : content.trim().length > 0

  const onConfirmClick = useCallback(async () => {
    if (!canConfirm) return
    if (isSubmitting) return

    const storyText = content.trim()

    setIsSubmitting(true)
    setErrorText(null)

    const start = performance.now()

    try {
      if (mode === "quick") {
        logger.info({
          event: "quick_generate_project_create_start",
          module: "script",
          traceId: "client",
          message: "开始创建快速生成项目"
        })
        const created = await createQuickGenerateProject({
          title: title.trim(),
          ratio,
          resolution,
          style: shotStyle,
          videoCategory: videoCategory === "commentary" ? "commentary" : "premium"
        })
        logger.info({
          event: "quick_generate_project_create_success",
          module: "script",
          traceId: "client",
          message: "快速生成项目创建成功",
          durationMs: Math.round(performance.now() - start),
          storyId: created.storyId,
          projectId: created.projectId,
          groupId: created.groupId
        })
        router.push(`/script/quick-generate/${encodeURIComponent(created.storyId)}`)
        onClose()
        return
      }

      const inputType = mode === "source" ? "original" : mode === "script" ? "script" : "brief"
      logger.info({
        event: "outline_generate_start",
        module: "script",
        traceId: "client",
        message: "开始调用大纲生成接口",
        inputType
      })

      if (mode === "brief") {
        const storyId = await (async () => {
          if (briefStoryId?.trim()) return briefStoryId.trim()
          const res = await fetch("/api/library/stories", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              storyType: "brief",
              title: title.trim(),
              storyText,
              ratio,
              resolution,
              style: shotStyle,
              videoCategory
            })
          })
          const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
          if (!res.ok || !json || (json as ApiErr).ok === false) {
            const errJson = (json as ApiErr | null) ?? null
            throw new Error(errJson?.error?.message ?? "创建失败，请稍后重试")
          }
          const okJson = json as ApiOk<unknown>
          const data = okJson.data as unknown
          const createdStoryId =
            typeof data === "object" && data !== null && "storyId" in data && typeof (data as { storyId?: unknown }).storyId === "string"
              ? String((data as { storyId: string }).storyId)
              : ""
          if (!createdStoryId) throw new Error("创建成功但未返回 storyId，请稍后重试")
          setBriefStoryId(createdStoryId)
          return createdStoryId
        })()

        const planning = await callShortDramaPlanning(storyText)
        await patchStoryShortDramaMetadata(storyId, {
          planningResult: planning,
          worldSetting: null,
          characterSetting: null
        })

        const next = `/script/workspace/${encodeURIComponent(storyId)}?mode=brief`
        router.push(`/script/short-drama/${encodeURIComponent(storyId)}?next=${encodeURIComponent(next)}`)
        onClose()
        return
      }
      
      if (mode === "script") {
        const storyId = await (async () => {
          if (briefStoryId?.trim()) return briefStoryId.trim()
          const res = await fetch("/api/library/stories", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              storyType: "brief",
              title: title.trim(),
              storyText,
              ratio,
              resolution,
              style: shotStyle,
              videoCategory
            })
          })
          const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
          if (!res.ok || !json || (json as ApiErr).ok === false) {
            const errJson = (json as ApiErr | null) ?? null
            throw new Error(errJson?.error?.message ?? "创建失败，请稍后重试")
          }
          const okJson = json as ApiOk<unknown>
          const data = okJson.data as unknown
          const createdStoryId =
            typeof data === "object" && data !== null && "storyId" in data && typeof (data as { storyId?: unknown }).storyId === "string"
              ? String((data as { storyId: string }).storyId)
              : ""
          if (!createdStoryId) throw new Error("创建成功但未返回 storyId，请稍后重试")
          setBriefStoryId(createdStoryId)
          return createdStoryId
        })()

        await patchStoryShortDramaMetadata(storyId, {
          planningResult: null,
          worldSetting: null,
          characterSetting: null,
          setupSource: "script_body"
        })

        const [planningTask, roleTask] = await Promise.all([
          submitShortDramaParsingTask({ storyId, userRequirement: storyText }),
          submitShortDramaRoleParsingTask({ storyId, novelText: storyText })
        ])

        logger.info({
          event: "short_drama_script_parsing_tasks_submitted",
          module: "script",
          traceId: "client",
          message: "已提交剧本解析与角色解析任务",
          planningJobId: planningTask.jobId,
          roleJobId: roleTask.jobId
        })

        const next = `/script/workspace/${encodeURIComponent(storyId)}?mode=brief`
        router.push(
          `/script/short-drama/${encodeURIComponent(storyId)}?setup=script&next=${encodeURIComponent(next)}`
        )
        onClose()
        return
      }

      const payload = await (async () => {
        if (mode === "source") {
          return {
            input_type: inputType,
            story_text: storyText,
            title: title.trim(),
            ratio,
            resolution,
            style: shotStyle,
            video_category: videoCategory
          }
        }

        return {
          input_type: inputType,
          story_text: storyText,
          title: title.trim(),
          ratio,
          resolution,
          style: shotStyle,
          video_category: videoCategory
        }
      })()

      const { _shortDramaMeta, ...requestBody } = payload as any

      const res = await fetch("/api/coze/storyboard/generate-outline", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(requestBody)
      })

      const durationMs = Math.round(performance.now() - start)
      const json = (await res.json()) as ApiOk<unknown> | ApiErr

      if (!res.ok || !json || (json as ApiErr).ok === false) {
        const errJson = json as ApiErr
        logger.warn({
          event: "outline_generate_failed",
          module: "script",
          traceId: "client",
          message: "大纲生成接口返回失败",
          status: res.status,
          durationMs,
          code: errJson?.error?.code
        })
        setErrorText(errJson?.error?.message ?? "生成失败，请稍后重试")
        return
      }

      const okJson = json as ApiOk<unknown>
      const data = okJson.data as unknown
      const storyId =
        typeof data === "object" && data !== null && "storyId" in data && typeof (data as { storyId?: unknown }).storyId === "string"
          ? String((data as { storyId: string }).storyId)
          : ""

      if (!storyId) {
        logger.warn({
          event: "outline_generate_missing_story_id",
          module: "script",
          traceId: "client",
          message: "大纲生成接口返回缺少 storyId",
          status: res.status,
          durationMs
        })
        setErrorText("生成成功但未返回 storyId，请稍后重试")
        return
      }

      logger.info({
        event: "outline_generate_success",
        module: "script",
        traceId: "client",
        message: "大纲生成接口调用成功",
        status: res.status,
        durationMs
      })

      if (_shortDramaMeta) await patchStoryShortDramaMetadata(storyId, _shortDramaMeta)
      router.push(`/script/workspace/${encodeURIComponent(storyId)}?mode=source`)
      onClose()
      
    } catch (err) {
      const durationMs = Math.round(performance.now() - start)
      const anyErr = err as { name?: string; message?: string }
      logger.error(
        mode === "quick"
          ? {
              event: "quick_generate_project_create_error",
              module: "script",
              traceId: "client",
              message: "快速生成项目创建异常",
              durationMs,
              errorName: anyErr?.name,
              errorMessage: anyErr?.message
            }
          : {
              event: "outline_generate_error",
              module: "script",
              traceId: "client",
              message: "大纲生成接口调用异常",
              durationMs,
              errorName: anyErr?.name,
              errorMessage: anyErr?.message
            }
      )
      setErrorText(anyErr?.message?.trim() ? String(anyErr.message) : "网络异常，请检查网络或稍后重试")
    } finally {
      setIsSubmitting(false)
    }
  }, [briefStoryId, canConfirm, content, isSubmitting, mode, onClose, ratio, resolution, router, shotStyle, title, videoCategory])

  if (!open) return null

  return (
    <div className={styles.backdrop} role="presentation" onMouseDown={onBackdropClick}>
      <div className={styles.dialog} role="dialog" aria-modal="true">
        <div className={styles.header}>
          <div className={styles.headerTitle}>{mode === "quick" ? "快速生成" : "新建创作"}</div>
          <button type="button" className={styles.closeBtn} onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>

        {enableScriptSourceEntry && mode !== "quick" ? (
          <div className={styles.tabs}>
            <button
              type="button"
              className={`${styles.tab} ${mode === "brief" ? styles.tabActive : ""}`}
              onClick={() => setMode("brief")}
            >
              从剧情简介开始
            </button>
            <button
              type="button"
              className={`${styles.tab} ${mode === "script" ? styles.tabActive : ""}`}
              onClick={() => setMode("script")}
            >
              从剧本正文开始
            </button>
            <button
              type="button"
              className={`${styles.tab} ${mode === "source" ? styles.tabActive : ""}`}
              onClick={() => setMode("source")}
            >
              从故事原文开始
            </button>
          </div>
        ) : null}

        <div className={styles.grid}>
          <div className={styles.field}>
            <div className={styles.labelRow}>
              <div className={styles.label}>故事标题</div>
              <div className={styles.counter}>{titleCount}/100</div>
            </div>
            <input
              className={styles.input}
              value={title}
              onChange={(e) => setTitle(e.target.value.slice(0, 100))}
              placeholder={mode === "quick" ? "例如：MarsHub（必填）" : "例如：城市奇遇记（选填）"}
            />
            <div className={styles.hint}>{mode === "quick" ? "快速生成会用项目名称创建素材分组，请务必填写。" : "建议 8–20 字，方便后续管理"}</div>
          </div>

          <div className={styles.row2}>
            <div className={styles.field}>
              <div className={styles.labelRow}>
                <div className={styles.label}>视频比例</div>
              </div>
              <ListboxSelect
                ariaLabel="视频比例"
                value={ratio}
                onChange={setRatio}
                portalZIndex={1100}
                options={[
                  { value: "16:9", label: "16:9（横屏·通用）" },
                  { value: "4:3", label: "4:3（横屏·旧版）" },
                  { value: "1:1", label: "1:1（方形）" },
                  { value: "3:4", label: "3:4（竖屏·旧版）" },
                  { value: "9:16", label: "9:16（竖屏·短视频）" }              
                ]}
              />
            </div>

            <div className={styles.field}>
              <div className={styles.labelRow}>
                <div className={styles.label}>分辨率</div>
              </div>
              <ListboxSelect
                ariaLabel="分辨率"
                value={resolution}
                onChange={setResolution}
                portalZIndex={1100}
                options={[
                  { value: "1080p", label: "1080p（高清）" },
                  { value: "720p", label: "720p（标清）" },
                  { value: "480p", label: "480p（低清）" }
                ]}
              />
            </div>

            <div className={styles.field}>
              <div className={styles.labelRow}>
                <div className={styles.label}>画风</div>
              </div>
              <ListboxSelect
                ariaLabel="画风"
                value={shotStyle}
                onChange={setShotStyle}
                portalZIndex={1100}
                options={[
                  { value: "realistic", label: "真实风" },
                  { value: "anime", label: "动漫风" }
                ]}
              />
            </div>

            <div className={styles.field}>
              <div className={styles.labelRow}>
                <div className={styles.label}>视频类别</div>
              </div>
              <ListboxSelect
                ariaLabel="视频类别"
                value={videoCategory}
                onChange={setVideoCategory}
                portalZIndex={1100}
                options={[
                  { value: "premium", label: "精品剧" },
                  { value: "commentary", label: "解说剧" }
                ]}
              />
            </div>
          </div>

          {mode === "quick" ? (
            <div className={styles.hint}>无需填写剧情简介，先创建项目，后续在剧本策划里补充。</div>
          ) : (
            <div className={styles.field}>
              <div className={styles.labelRow}>
                <div className={styles.label}>{contentLabel}</div>
              </div>
              <textarea
                className={styles.textarea}
                value={content}
                maxLength={contentMaxLength}
                onChange={(e) => {
                  const next = e.target.value
                  if (!contentMaxLength) {
                    setContent(next)
                    return
                  }
                  setContent(next.slice(0, contentMaxLength))
                }}
                placeholder={contentPlaceholder}
              />
              <div className={styles.footerRow}>
                <span>支持换行输入</span>
                <span>{contentCount} 字</span>
              </div>
            </div>
          )}
        </div>

        <div className={styles.actions}>
          <button type="button" className={styles.btnSecondary} onClick={onClose}>
            取消
          </button>
          <button
            type="button"
            className={styles.btnPrimary}
            onClick={onConfirmClick}
            disabled={!canConfirm || isSubmitting}
          >
            {isSubmitting ? "生成中…" : mode === "quick" ? "创建项目 →" : "开始创作 →"}
          </button>
        </div>
        {errorText ? <div className={styles.errorText}>{errorText}</div> : null}
      </div>
    </div>
  )
}
