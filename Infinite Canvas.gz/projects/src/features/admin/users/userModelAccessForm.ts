import type { AdminModelType, AdminUserModelMap } from "@/shared/contracts/adminUserModelAccess"

export type ApiKeyAction = "unchanged" | "replace" | "clear"

export type UserModelDraftRow = {
  id: string
  modelName: string
  realName: string
  ep: string
  enabled: boolean
}

export type UserModelDraftGroups = Record<AdminModelType, UserModelDraftRow[]>

function createRowId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

/**
 * 创建一条新的空白模型配置行。
 */
export function createEmptyModelRow(): UserModelDraftRow {
  return {
    id: createRowId(),
    modelName: "",
    realName: "",
    ep: "",
    enabled: true
  }
}

/**
 * 将服务端返回的对象结构转换为前端易编辑的行结构。
 */
export function modelMapToRows(modelMap: AdminUserModelMap): UserModelDraftRow[] {
  return Object.entries(modelMap)
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([modelName, config]) => ({
      id: createRowId(),
      modelName,
      realName: config.realName || "",
      ep: config.ep,
      enabled: config.enabled
    }))
}

/**
 * 将前端编辑态转换为接口提交结构。
 * 完全空白的行会被忽略；半填状态会抛错，避免保存出脏数据。
 */
export function rowsToModelMap(rows: UserModelDraftRow[]): AdminUserModelMap {
  const result: AdminUserModelMap = {}

  for (const row of rows) {
    const modelName = row.modelName.trim()
    const ep = row.ep.trim()

    if (!modelName && !ep) continue
    if (!modelName) throw new Error("模型名称不能为空")
    if (!ep) throw new Error(`模型 ${modelName} 的 EP 不能为空`)
    if (result[modelName]) throw new Error(`模型 ${modelName} 存在重复配置`)

    result[modelName] = {
      ep,
      realName: row.realName,
      enabled: row.enabled
    }
  }

  return result
}

export function createEmptyModelDraftGroups(): UserModelDraftGroups {
  return {
    video: [],
    language: [],
    image: []
  }
}
