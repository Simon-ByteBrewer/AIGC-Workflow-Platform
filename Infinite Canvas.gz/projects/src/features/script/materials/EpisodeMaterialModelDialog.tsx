"use client"

import type { ReactElement } from "react"
import { ChevronDown, Image as ImageIcon, X } from "lucide-react"
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/shared/ui/shadcn/dialog"
import styles from "./EpisodeMaterialModelDialog.module.css"

type ModelOption = { value: string; label: string }

type Props = {
  open: boolean
  loading?: boolean
  submitting?: boolean
  errorText?: string | null
  options: ModelOption[]
  sceneModelName: string
  roleModelName: string
  itemModelName: string
  onOpenChange: (open: boolean) => void
  onChangeSceneModelName: (value: string) => void
  onChangeRoleModelName: (value: string) => void
  onChangeItemModelName: (value: string) => void
  onConfirm: () => void
}

export function EpisodeMaterialModelDialog(props: Props): ReactElement {
  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className={`!z-[180] ${styles.content}`} overlayClassName="!z-[179] bg-black/70">
        <DialogHeader className={styles.header}>
          <div className={styles.icon}>
            <ImageIcon className="h-[18px] w-[18px]" />
          </div>
          <div className="min-w-0 flex-1">
            <DialogTitle className={styles.title}>选择素材生成模型</DialogTitle>
            <div className={styles.hint}>分别为场景、人物、物品选择本次一键生成要使用的模型</div>
          </div>
          <DialogClose asChild>
            <button type="button" className={styles.closeBtn} aria-label="关闭" disabled={props.submitting}>
              <X className="h-4 w-4" />
            </button>
          </DialogClose>
        </DialogHeader>

        <div className={styles.body}>
          <div>素材生成会按类型分别使用所选模型，原有解析与入库逻辑保持不变。</div>
          <div className={styles.fields}>
            <div className={styles.field}>
              <div className={styles.label}>场景模型</div>
              <div className={styles.selectWrap}>
                <select className={styles.select} value={props.sceneModelName} onChange={(e) => props.onChangeSceneModelName(e.currentTarget.value)} disabled={props.loading || props.submitting || props.options.length === 0}>
                  {props.options.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className={styles.selectChevron} aria-hidden="true" />
              </div>
            </div>

            <div className={styles.field}>
              <div className={styles.label}>人物模型</div>
              <div className={styles.selectWrap}>
                <select className={styles.select} value={props.roleModelName} onChange={(e) => props.onChangeRoleModelName(e.currentTarget.value)} disabled={props.loading || props.submitting || props.options.length === 0}>
                  {props.options.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className={styles.selectChevron} aria-hidden="true" />
              </div>
            </div>

            <div className={styles.field}>
              <div className={styles.label}>物品模型</div>
              <div className={styles.selectWrap}>
                <select className={styles.select} value={props.itemModelName} onChange={(e) => props.onChangeItemModelName(e.currentTarget.value)} disabled={props.loading || props.submitting || props.options.length === 0}>
                  {props.options.map((item) => (
                    <option key={item.value} value={item.value}>
                      {item.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className={styles.selectChevron} aria-hidden="true" />
              </div>
            </div>

            {props.loading ? <div className={styles.helper}>正在加载可用图片模型...</div> : null}
            {!props.loading && props.options.length === 0 ? <div className={styles.helper}>当前账号未配置可用图片模型</div> : null}
            {props.errorText ? <div className={styles.error}>{props.errorText}</div> : null}
          </div>
        </div>

        <div className={styles.footer}>
          <button type="button" className={`${styles.btn} ${styles.btnSecondary}`} onClick={() => props.onOpenChange(false)} disabled={props.submitting}>
            取消
          </button>
          <button
            type="button"
            className={`${styles.btn} ${styles.btnPrimary}`}
            onClick={props.onConfirm}
            disabled={props.loading || props.submitting || !props.sceneModelName || !props.roleModelName || !props.itemModelName}
          >
            {props.submitting ? "提交中..." : "确认生成"}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
