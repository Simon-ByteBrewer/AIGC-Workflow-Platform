import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getDb } from "coze-coding-dev-sdk"
import { and, eq } from "drizzle-orm"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"
import { mergeStoryboardFrames } from "@/server/shared/storyboard/storyboardAssets"

const inputSchema = z.object({
  storyboardId: z.string().trim().min(1).max(200),
  src: z.string().trim().min(1).max(4000)
})

function normalizeFrameImages(input: unknown): Array<{ url: string; thumbnailUrl: string }> {
  if (!Array.isArray(input)) return []
  const out: Array<{ url: string; thumbnailUrl: string }> = []
  for (const row of input) {
    const url = (row && typeof (row as any).url === "string" ? String((row as any).url) : "").trim()
    const thumbnailUrl = (row && typeof (row as any).thumbnailUrl === "string" ? String((row as any).thumbnailUrl) : "").trim()
    if (!url && !thumbnailUrl) continue
    out.push({ url, thumbnailUrl })
  }
  return out
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { storyboardId, src } = parsed.data
  const db = await getDb({ stories, storyOutlines, storyboards })

  const allowed = await db
    .select({ frames: storyboards.frames })
    .from(storyboards)
    .innerJoin(storyOutlines, eq(storyboards.outlineId, storyOutlines.id))
    .innerJoin(stories, eq(storyOutlines.storyId, stories.id))
    .where(and(eq(storyboards.id, storyboardId), eq(stories.userId, userId)))
    .limit(1)

  const row = allowed[0]
  if (!row) return NextResponse.json(makeApiErr(traceId, "STORYBOARD_NOT_FOUND", "未找到可编辑的分镜"), { status: 404 })

  const currentFrames = (row.frames ?? {}) as any
  const currentFirst = (currentFrames?.first && typeof currentFrames.first === "object" ? currentFrames.first : {}) as any

  const images = normalizeFrameImages(currentFirst.images)
  const selectedIdx = images.findIndex((im) => im.url === src || im.thumbnailUrl === src)
  const selected = selectedIdx >= 0 ? images[selectedIdx]! : { url: src, thumbnailUrl: "" }
  const primaryUrl = (selected.url || selected.thumbnailUrl || src).trim()
  const primaryThumb = (selected.thumbnailUrl || "").trim() || null

  const merged = mergeStoryboardFrames(currentFrames as any, {
    first: {
      ...currentFirst,
      url: primaryUrl,
      thumbnailUrl: primaryThumb
    }
  } as any)

  await db
    .update(storyboards)
    .set({ frames: merged as any, updatedAt: new Date() })
    .where(eq(storyboards.id, storyboardId))

  return NextResponse.json(
    makeApiOk(traceId, {
      storyboardId,
      frames: { first: { url: primaryUrl, thumbnailUrl: primaryThumb, images: currentFirst.images ?? images } }
    }),
    { status: 200 }
  )
}
