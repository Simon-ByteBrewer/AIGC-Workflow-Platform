"use client"

import { Upload } from "lucide-react"
import { useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import {
  DEFAULT_QUICK_GENERATE_EPISODE_PARSE_TYPE,
  DEFAULT_QUICK_GENERATE_EPISODE_MAX_DURATION_MINUTES,
  DEFAULT_QUICK_GENERATE_EPISODE_MIN_DURATION_MINUTES,
  QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX,
  QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN,
  MAX_QUICK_GENERATE_EPISODE_CONTENT_LENGTH,
  QUICK_GENERATE_EPISODE_IMPORT_ACCEPT,
  type QuickGenerateEpisodeParseType
} from "@/shared/contracts/quickGenerateEpisode"
import { CanvasSelect } from "@/features/video/canvas/nodes/base/CanvasSelect"
import { Dialog, DialogClose, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/shared/ui/shadcn/dialog"
import { importQuickGenerateEpisodeText } from "../api-client"
import { DEFAULT_QUICK_GENERATE_VIDEO_MODEL, type QuickGenerateVideoModel } from "../videoModel"
import styles from "./QuickGenerateCreateEpisodeDialog.module.css"
import type { VideoModelOption } from "@/shared/contracts/videoModelAccess"
import type { ImageModelOption } from "@/shared/contracts/imageModelAccess"

type ImportedFileMeta = {
  fileName: string
  sourceKind: "pdf" | "docx" | "txt" | "excel"
  charCount: number
}

const PARSE_TYPE_OPTIONS: Array<{
  value: QuickGenerateEpisodeParseType
  label: string
  description: string
  exampleTitle: string
  exampleSourceLabel: string
  exampleTargetLabel: string
  exampleSourceText: string
  exampleTargetText: string
}> = [
  {
    value: "outline",
    label: "整集剧本原文",
    description: "会基于整集剧本原文，由模型拆分镜剧本，再根据拆分的分镜本生成视频提示词。",
    exampleTitle: "整集剧本原文示例",
    exampleSourceLabel: "输入示例",
    exampleTargetLabel: "输出示例",
    exampleSourceText: "输入一整集连续剧本正文，由系统自动识别剧情段落、角色动作和场景变化。",
    exampleTargetText: "输出拆分后的分镜剧本，并继续生成对应的视频提示词。"
  },
  {
    value: "storyboard",
    label: "拆好分镜的整集剧本原文",
    description: "会基于整集剧本中的预设的分镜规则拆分镜剧本，再根据拆分的分镜本生成视频提示词。",
    exampleTitle: "拆好分镜的整集剧本原文示例",
    exampleSourceLabel: "输入示例",
    exampleTargetLabel: "输出示例",
    exampleSourceText: "输入已按分镜规则标注好的整集剧本原文，保留每个分镜对应的内容边界。",
    exampleTargetText: "输出结构化分镜剧本，并基于这些分镜内容生成视频提示词。"
  },
  {
    value: "drama",
    label: "拆好分镜提示词的剧本原文",
    description: "会基于整集剧本中的预设的分镜规则拆分镜剧本，并直接用分镜剧本作为视频提示词。",
    exampleTitle: "拆好分镜提示词的剧本原文示例",
    exampleSourceLabel: "输入示例",
    exampleTargetLabel: "输出示例",
    exampleSourceText: "输入已可直接作为分镜提示词使用的剧本原文，每段文本都对应明确镜头语义。",
    exampleTargetText: "输出拆分后的分镜文本，并直接将这些分镜文本作为视频提示词使用。"
  }
]
type QuickGenerateCreateEpisodeDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  defaultEpisodeNo: number
  onSubmit: (
    input:
      | {
          episodeNo: number
          type: "outline"
          content: string
          videoModel: QuickGenerateVideoModel
          storyboardPanelModel: string
          storyboardPromptPresetId?: string
          videoPromptPresetId?: string
          storyboardPanelPromptPresetId?: string
          minDurationMinutes: number
          maxDurationMinutes: number
          shotsNum?: number
        }
      | {
          episodeNo: number
          type: "storyboard"
          content: string
          videoModel: QuickGenerateVideoModel
          storyboardPanelModel: string
          storyboardPromptPresetId?: string
          videoPromptPresetId?: string
          storyboardPanelPromptPresetId?: string
        }
      | {
          episodeNo: number
          type: "drama"
          prompt: string
          videoModel: QuickGenerateVideoModel
          storyboardPanelModel: string
          storyboardPromptPresetId?: string
          videoPromptPresetId?: string
          storyboardPanelPromptPresetId?: string
        }
  ) => Promise<void>
}

function clampEpisodeNo(raw: unknown): number {
  const n = typeof raw === "number" && Number.isFinite(raw) ? raw : Number(String(raw ?? "").trim())
  if (!Number.isFinite(n)) return 0
  return Math.max(0, Math.min(10_000, Math.trunc(n)))
}

function parseOptionalPositiveInt(raw: unknown): number | undefined {
  const v = String(raw ?? "").trim()
  if (!v) return undefined
  const n = Number(v)
  if (!Number.isFinite(n)) return undefined
  const i = Math.trunc(n)
  if (i <= 0) return undefined
  return Math.min(10_000, i)
}

function clampDurationMinutes(raw: unknown): number {
  const n = typeof raw === "number" && Number.isFinite(raw) ? raw : Number(String(raw ?? "").trim())
  if (!Number.isFinite(n)) return QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN
  const normalized = Math.trunc(n)
  return Math.min(QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX, Math.max(QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN, normalized))
}

/**
 * 创建剧集弹窗（仅做输入收集与校验；实际创建/入队由 onSubmit 执行）。
 */
export function QuickGenerateCreateEpisodeDialog(props: QuickGenerateCreateEpisodeDialogProps): ReactElement | null {
  const [episodeNo, setEpisodeNo] = useState<number>(props.defaultEpisodeNo)
  const [type, setType] = useState<QuickGenerateEpisodeParseType>(DEFAULT_QUICK_GENERATE_EPISODE_PARSE_TYPE)
  const [videoModel, setVideoModel] = useState<QuickGenerateVideoModel>(DEFAULT_QUICK_GENERATE_VIDEO_MODEL)
  const [videoModelOptions, setVideoModelOptions] = useState<Array<{ value: string; label: string }>>([])
  const [imageModelOptions, setImageModelOptions] = useState<Array<{ value: string; label: string }>>([])
  const [storyboardPanelModel, setStoryboardPanelModel] = useState("")
  const [storyboardPromptPresetId, setStoryboardPromptPresetId] = useState("")
  const [videoPromptPresetId, setVideoPromptPresetId] = useState("")
  const [storyboardPanelPromptPresetId, setStoryboardPanelPromptPresetId] = useState("")
  const [storyboardPromptOptions, setStoryboardPromptOptions] = useState<Array<{ value: string; label: string }>>([
    { value: "", label: "默认提示词" }
  ])
  const [videoPromptOptions, setVideoPromptOptions] = useState<Array<{ value: string; label: string }>>([{ value: "", label: "默认提示词" }])
  const [storyboardPanelPromptOptions, setStoryboardPanelPromptOptions] = useState<Array<{ value: string; label: string }>>([{ value: "", label: "默认提示词" }])
  const [content, setContent] = useState<string>("")
  const [shotsNum, setShotsNum] = useState<string>("")
  const [minDurationMinutes, setMinDurationMinutes] = useState<number>(DEFAULT_QUICK_GENERATE_EPISODE_MIN_DURATION_MINUTES)
  const [maxDurationMinutes, setMaxDurationMinutes] = useState<number>(DEFAULT_QUICK_GENERATE_EPISODE_MAX_DURATION_MINUTES)
  const [submitting, setSubmitting] = useState(false)
  const [importing, setImporting] = useState(false)
  const [importedFile, setImportedFile] = useState<ImportedFileMeta | null>(null)
  const [error, setError] = useState<string>("")
  const [exampleType, setExampleType] = useState<QuickGenerateEpisodeParseType | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!props.open) return
    setEpisodeNo(props.defaultEpisodeNo)
    setType(DEFAULT_QUICK_GENERATE_EPISODE_PARSE_TYPE)
    setVideoModel(DEFAULT_QUICK_GENERATE_VIDEO_MODEL)
    setStoryboardPanelModel("")
    setStoryboardPromptPresetId("")
    setVideoPromptPresetId("")
    setStoryboardPanelPromptPresetId("")
    setContent("")
    setShotsNum("")
    setMinDurationMinutes(DEFAULT_QUICK_GENERATE_EPISODE_MIN_DURATION_MINUTES)
    setMaxDurationMinutes(DEFAULT_QUICK_GENERATE_EPISODE_MAX_DURATION_MINUTES)
    setImportedFile(null)
    setError("")
    setExampleType(null)
    setSubmitting(false)
    setImporting(false)
  }, [props.defaultEpisodeNo, props.open])

  useEffect(() => {
    if (!props.open) return
    void (async () => {
      try {
        const [videoRes, imageRes, promptRes] = await Promise.all([
          fetch("/api/video/canvas/video-models", { method: "GET" }),
          fetch("/api/video/canvas/image-models", { method: "GET" }),
          fetch("/api/quick-generate/prompt-options", { method: "GET" })
        ])
        const videoJson = (await videoRes.json().catch(() => null)) as { ok?: boolean; data?: { items?: VideoModelOption[] } } | null
        const imageJson = (await imageRes.json().catch(() => null)) as { ok?: boolean; data?: { items?: ImageModelOption[] } } | null
        const promptJson = (await promptRes.json().catch(() => null)) as
          | { ok?: boolean; data?: { storyboardOptions?: Array<{ value?: string; label?: string }>; videoOptions?: Array<{ value?: string; label?: string }>; storyboardPanelOptions?: Array<{ value?: string; label?: string }> } }
          | null
        if (!videoRes.ok || !videoJson?.ok) {
          setVideoModelOptions([])
        } else {
          const items = Array.isArray(videoJson.data?.items) ? videoJson.data.items : []
          const options = items.map((item) => ({ value: item.modelName, label: item.modelName }))
          setVideoModelOptions(options)
          if (options[0]?.value) setVideoModel((current) => current || options[0]!.value)
        }

        if (!imageRes.ok || !imageJson?.ok) {
          setImageModelOptions([])
        } else {
          const items = Array.isArray(imageJson.data?.items) ? imageJson.data.items : []
          const options = items.map((item) => ({
            value: String(item.modelName ?? "").trim(),
            label: String(item.label ?? "").trim() || String(item.modelName ?? "").trim()
          })).filter((item) => item.value)
          setImageModelOptions(options)
          if (options[0]?.value) setStoryboardPanelModel((current) => current || options[0]!.value)
        }

        if (!promptRes.ok || !promptJson?.ok) {
          setStoryboardPromptOptions([{ value: "", label: "默认提示词" }])
          setVideoPromptOptions([{ value: "", label: "默认提示词" }])
          setStoryboardPanelPromptOptions([{ value: "", label: "默认提示词" }])
          return
        }

        const normalizeOptions = (items: Array<{ value?: string; label?: string }> | undefined) => {
          const defaults = [{ value: "", label: "默认提示词" }]
          const next = Array.isArray(items)
            ? items
                .map((item) => ({
                  value: String(item?.value ?? "").trim(),
                  label: String(item?.label ?? "").trim()
                }))
                .filter((item) => item.label)
            : []
          return next.length > 0 ? next : defaults
        }

        setStoryboardPromptOptions(normalizeOptions(promptJson.data?.storyboardOptions))
        setVideoPromptOptions(normalizeOptions(promptJson.data?.videoOptions))
        setStoryboardPanelPromptOptions(normalizeOptions(promptJson.data?.storyboardPanelOptions))
      } catch {
        setVideoModelOptions([])
        setImageModelOptions([])
        setStoryboardPromptOptions([{ value: "", label: "默认提示词" }])
        setVideoPromptOptions([{ value: "", label: "默认提示词" }])
        setStoryboardPanelPromptOptions([{ value: "", label: "默认提示词" }])
      }
    })()
  }, [props.open])

  const contentLen = content.length
  const remaining = MAX_QUICK_GENERATE_EPISODE_CONTENT_LENGTH - contentLen
  const activeExample = PARSE_TYPE_OPTIONS.find((option) => option.value === exampleType) ?? null

  const canSubmit = useMemo(() => {
    if (submitting) return false
    if (importing) return false
    if (episodeNo <= 0) return false
    if (!videoModel.trim()) return false
    if (!storyboardPanelModel.trim()) return false
    const c = content.trim()
    if (!c) return false
    if (c.length > MAX_QUICK_GENERATE_EPISODE_CONTENT_LENGTH) return false
    if (type === "outline" && minDurationMinutes > maxDurationMinutes) return false
    return true
  }, [content, episodeNo, importing, maxDurationMinutes, minDurationMinutes, storyboardPanelModel, submitting, type, videoModel])

  /**
   * 处理剧集源文件导入：
   * - 仅提取纯文本，不保留原始版式；
   * - 导入成功后仅回填文本，不主动修改用户当前选择的解析类型。
   */
  async function handleImportFile(file: File): Promise<void> {
    setError("")
    setImporting(true)
    try {
      const result = await importQuickGenerateEpisodeText(file)
      setContent(result.content)
      setImportedFile({
        fileName: result.fileName,
        sourceKind: result.sourceKind,
        charCount: result.charCount
      })
    } catch (e) {
      const anyErr = e as { message?: string }
      setImportedFile(null)
      setError(anyErr?.message?.trim() || "导入文件失败，请稍后重试")
    } finally {
      setImporting(false)
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }

  return (
    <Dialog
      open={props.open}
      onOpenChange={(val) => {
        if (submitting || importing) return
        props.onOpenChange(val)
      }}
    >
      <DialogContent className={styles.dialog}>
        <DialogHeader className={styles.header}>
          <DialogTitle className={styles.title}>新增剧集</DialogTitle>
          <div className={styles.subtitle}>支持手动输入或上传文件导入文本，再选择解析类型创建本集工作流任务。</div>
        </DialogHeader>

        <div className={styles.body}>
          <div className={styles.topGrid}>
            <div className={styles.settingsPanel}>
              <div className={styles.field}>
                <div className={styles.labelRow}>
                  <div className={styles.label}>剧集编号</div>
                  <div className={styles.hint}>同项目内必须唯一</div>
                </div>
                <input
                  className={styles.input}
                  type="number"
                  inputMode="numeric"
                  min={1}
                  step={1}
                  value={episodeNo || ""}
                  onChange={(e) => setEpisodeNo(clampEpisodeNo(e.target.value))}
                  disabled={submitting || importing}
                  placeholder="例如：1"
                />
              </div>

              <div className={styles.field}>
                <div className={styles.labelRow}>
                  <div className={styles.label}>解析类型</div>
                  <div className={styles.hint}>{importedFile ? "导入文本后保持当前解析类型不变" : "默认使用整集剧本拆分"}</div>
                </div>
                <div className={styles.optionGroup} role="radiogroup" aria-label="解析类型">
                  {PARSE_TYPE_OPTIONS.map((option) => {
                    const active = type === option.value
                    return (
                      <div
                        key={option.value}
                        role="radio"
                        aria-checked={active}
                        tabIndex={0}
                        className={`${styles.optionCard} ${active ? styles.optionCardActive : ""}`}
                        onClick={() => setType(option.value)}
                        onKeyDown={(event) => {
                          if (event.key === "Enter" || event.key === " ") {
                            event.preventDefault()
                            setType(option.value)
                          }
                        }}
                      >
                        <div className={styles.optionCardHeader}>
                          <span className={styles.optionTitle}>{option.label}</span>
                          <button
                            type="button"
                            className={styles.optionExampleBtn}
                            disabled={submitting || importing}
                            onClick={(event) => {
                              event.stopPropagation()
                              setExampleType(option.value)
                            }}
                          >
                            查看示例
                          </button>
                        </div>
                        <span className={styles.optionDescription}>{option.description}</span>
                      </div>
                    )
                  })}
                </div>
              </div>

              {type === "outline" ? (
                <div className={styles.field}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>单集时长</div>
                    <div className={styles.hint}>仅整集剧本拆分需要，单位为分钟</div>
                  </div>
                  <div className={styles.durationPanel} aria-label="单集时长">
                    <div className={styles.durationTop}>
                      <div className={styles.durationControl}>
                        <button
                          type="button"
                          className={styles.miniBtn}
                          disabled={submitting || importing || minDurationMinutes <= QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN}
                          aria-label="减少最小时长"
                          onClick={() => setMinDurationMinutes((current) => clampDurationMinutes(Math.min(current - 1, maxDurationMinutes)))}
                        >
                          -
                        </button>
                        <div className={styles.valuePill}>{minDurationMinutes}</div>
                        <button
                          type="button"
                          className={styles.miniBtn}
                          disabled={submitting || importing || minDurationMinutes >= maxDurationMinutes}
                          aria-label="增加最小时长"
                          onClick={() => setMinDurationMinutes((current) => clampDurationMinutes(Math.min(current + 1, maxDurationMinutes)))}
                        >
                          +
                        </button>
                        <div className={styles.durationSep} aria-hidden="true">
                          -
                        </div>
                        <button
                          type="button"
                          className={styles.miniBtn}
                          disabled={submitting || importing || maxDurationMinutes <= minDurationMinutes}
                          aria-label="减少最大时长"
                          onClick={() => setMaxDurationMinutes((current) => clampDurationMinutes(Math.max(current - 1, minDurationMinutes)))}
                        >
                          -
                        </button>
                        <div className={styles.valuePill}>{maxDurationMinutes}</div>
                        <button
                          type="button"
                          className={styles.miniBtn}
                          disabled={submitting || importing || maxDurationMinutes >= QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX}
                          aria-label="增加最大时长"
                          onClick={() => setMaxDurationMinutes((current) => clampDurationMinutes(Math.max(current + 1, minDurationMinutes)))}
                        >
                          +
                        </button>
                        <div className={styles.valueUnit}>分钟</div>
                      </div>
                    </div>
                    <div className={styles.durationSliders}>
                      <div className={styles.durationRow}>
                        <div className={styles.durationRowLabel}>最小</div>
                        <input
                          className={styles.range}
                          min={QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN}
                          max={QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX}
                          step={1}
                          type="range"
                          value={minDurationMinutes}
                          disabled={submitting || importing}
                          onChange={(event) =>
                            setMinDurationMinutes(clampDurationMinutes(Math.min(Number(event.target.value), maxDurationMinutes)))
                          }
                        />
                      </div>
                      <div className={styles.durationRow}>
                        <div className={styles.durationRowLabel}>最大</div>
                        <input
                          className={styles.range}
                          min={QUICK_GENERATE_EPISODE_DURATION_MINUTES_MIN}
                          max={QUICK_GENERATE_EPISODE_DURATION_MINUTES_MAX}
                          step={1}
                          type="range"
                          value={maxDurationMinutes}
                          disabled={submitting || importing}
                          onChange={(event) =>
                            setMaxDurationMinutes(clampDurationMinutes(Math.max(Number(event.target.value), minDurationMinutes)))
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}

              {type === "outline" ? (
                <div className={styles.field}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>分镜头数量</div>
                    <div className={styles.hint}>可选，留空则由系统自动推断</div>
                  </div>
                  <input
                    className={styles.input}
                    type="number"
                    inputMode="numeric"
                    min={1}
                    step={1}
                    value={shotsNum}
                    onChange={(e) => setShotsNum(e.target.value)}
                    disabled={submitting || importing}
                    placeholder="例如：20（可不填）"
                  />
                </div>
              ) : null}

              <div className={styles.modelGrid}>
                <div className={`${styles.field} ${styles.modelField}`}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>视频模型</div>
                  </div>
                  <div className={styles.modelSelectWrap}>
                    <CanvasSelect
                      label="视频模型"
                      value={videoModel}
                      options={videoModelOptions}
                      onChange={(next) => setVideoModel(next as QuickGenerateVideoModel)}
                      align="center"
                    />
                  </div>
                </div>

                <div className={`${styles.field} ${styles.modelField}`}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>分镜板生图模型</div>
                  </div>
                  <div className={styles.modelSelectWrap}>
                    <CanvasSelect
                      label="分镜板生图模型"
                      value={storyboardPanelModel}
                      options={imageModelOptions}
                      onChange={(next) => setStoryboardPanelModel(String(next ?? ""))}
                      align="center"
                    />
                  </div>
                </div>

                <div className={`${styles.field} ${styles.modelField}`}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>拆分镜提示词</div>
                  </div>
                  <div className={styles.modelSelectWrap}>
                    <CanvasSelect
                      label="拆分镜提示词"
                      value={storyboardPromptPresetId}
                      options={storyboardPromptOptions}
                      onChange={(next) => setStoryboardPromptPresetId(String(next ?? ""))}
                      align="center"
                    />
                  </div>
                </div>

                <div className={`${styles.field} ${styles.modelField}`}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>分镜板提示词</div>
                  </div>
                  <div className={styles.modelSelectWrap}>
                    <CanvasSelect
                      label="分镜板提示词"
                      value={storyboardPanelPromptPresetId}
                      options={storyboardPanelPromptOptions}
                      onChange={(next) => setStoryboardPanelPromptPresetId(String(next ?? ""))}
                      align="center"
                    />
                  </div>
                </div>

                <div className={`${styles.field} ${styles.modelField}`}>
                  <div className={styles.labelRow}>
                    <div className={styles.label}>视频提示词</div>
                  </div>
                  <div className={styles.modelSelectWrap}>
                    <CanvasSelect
                      label="视频提示词"
                      value={videoPromptPresetId}
                      options={videoPromptOptions}
                      onChange={(next) => setVideoPromptPresetId(String(next ?? ""))}
                      align="center"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className={styles.field}>
            <div className={styles.labelRow}>
              <div className={styles.label}>{type === "drama" ? "输入 Prompt" : "输入剧本内容"}</div>
              <div className={styles.inlineActions}>
                <div className={styles.hint}>{remaining >= 0 ? `剩余 ${remaining}` : `超出 ${-remaining}`}/50000</div>
                <button
                  type="button"
                  className={styles.uploadInlineBtn}
                  disabled={submitting || importing}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload size={14} />
                  <span>{importing ? "解析中..." : importedFile ? "重新上传" : "上传剧本"}</span>
                </button>
              </div>
            </div>
            <div className={styles.inlineHelp}>支持 PDF / DOCX / TXT / Excel，导入后会自动提取纯文本并填入输入框</div>
            {importedFile ? (
              <div className={styles.importedInline}>
                已导入：{importedFile.fileName} · {importedFile.sourceKind.toUpperCase()} · {importedFile.charCount} 字
              </div>
            ) : null}
            <input
              ref={fileInputRef}
              className={styles.hiddenInput}
              type="file"
              accept={QUICK_GENERATE_EPISODE_IMPORT_ACCEPT}
              disabled={submitting || importing}
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (!file) return
                void handleImportFile(file)
              }}
            />
            <textarea
              className={`${styles.input} ${styles.textarea}`}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              disabled={submitting || importing}
              placeholder={type === "drama" ? "请输入 Prompt（例如：集剧提示词拆分要求）" : "请输入本集剧本内容，或先上传文件自动填充文本"}
            />
          </div>

          {error ? <div className={styles.error}>{error}</div> : null}
        </div>

        <DialogFooter className={styles.footer}>
          <DialogClose asChild>
            <button type="button" className={styles.btnSecondary} disabled={submitting || importing}>
              取消
            </button>
          </DialogClose>
          <button
            type="button"
            className={styles.btnPrimary}
            disabled={!canSubmit}
            onClick={async () => {
              if (!canSubmit) return
              setError("")
              setSubmitting(true)
              try {
                const trimmed = content.trim()
                const optionalShotsNum = parseOptionalPositiveInt(shotsNum)
                if (type === "drama") {
                  await props.onSubmit({
                    episodeNo,
                    type,
                    prompt: trimmed,
                    videoModel,
                    storyboardPanelModel,
                    storyboardPromptPresetId,
                    videoPromptPresetId,
                    storyboardPanelPromptPresetId
                  })
                } else if (type === "outline") {
                  await props.onSubmit({
                    episodeNo,
                    type,
                    content: trimmed,
                    shotsNum: optionalShotsNum,
                    videoModel,
                    storyboardPanelModel,
                    storyboardPromptPresetId,
                    videoPromptPresetId,
                    storyboardPanelPromptPresetId,
                    minDurationMinutes,
                    maxDurationMinutes
                  })
                } else {
                  await props.onSubmit({
                    episodeNo,
                    type,
                    content: trimmed,
                    videoModel,
                    storyboardPanelModel,
                    storyboardPromptPresetId,
                    videoPromptPresetId,
                    storyboardPanelPromptPresetId
                  })
                }
                props.onOpenChange(false)
              } catch (e) {
                const anyErr = e as { message?: string }
                setError(anyErr?.message?.trim() || "创建失败，请稍后重试")
              } finally {
                setSubmitting(false)
              }
            }}
          >
            {submitting ? "创建中..." : "开始创作"}
          </button>
        </DialogFooter>
      </DialogContent>

      <Dialog open={Boolean(activeExample)} onOpenChange={(open) => (!open ? setExampleType(null) : undefined)}>
        <DialogContent className={styles.exampleDialog}>
          <DialogHeader className={styles.exampleHeader}>
            <DialogTitle className={styles.exampleTitle}>{activeExample?.exampleTitle ?? "查看示例"}</DialogTitle>
            <div className={styles.exampleSubtitle}>示例仅用于展示解析方式差异，不可在此窗口中编辑。</div>
          </DialogHeader>
          <div className={styles.exampleBody}>
            <div className={styles.exampleFlow}>
              <div className={styles.examplePanel}>
                <div className={styles.examplePanelLabel}>{activeExample?.exampleSourceLabel}</div>
                <div className={styles.examplePanelText}>{activeExample?.exampleSourceText}</div>
              </div>
              <div className={styles.exampleArrows} aria-hidden="true">
                <div className={styles.exampleArrow}>→</div>
                <div className={styles.exampleArrow}>→</div>
              </div>
              <div className={styles.examplePanel}>
                <div className={styles.examplePanelLabel}>{activeExample?.exampleTargetLabel}</div>
                <div className={styles.examplePanelText}>{activeExample?.exampleTargetText}</div>
              </div>
            </div>
          </div>
          <DialogFooter className={styles.exampleFooter}>
            <button type="button" className={styles.btnSecondary} onClick={() => setExampleType(null)}>
              关闭
            </button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Dialog>
  )
}
