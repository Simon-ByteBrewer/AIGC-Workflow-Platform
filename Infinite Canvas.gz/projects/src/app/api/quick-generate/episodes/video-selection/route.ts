import { NextResponse, type NextRequest } from "next/server"
import { eq } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getQuickGenerateEpisodeAccess } from "@/server/domains/quick-generate/access"
import { selectQuickGenerateShotVideo } from "@/shared/quickGenerate/videoResults"
import { quickGenerateEpisodes } from "@/shared/schema"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export const runtime = "nodejs"

const inputSchema = z
  .object({
    episodeId: z.string().trim().min(1).max(200),
    shotNo: z.number().int().min(1).max(10_000),
    selectedJobId: z.string().trim().min(1).max(200)
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const access = await getQuickGenerateEpisodeAccess(userId, parsed.data.episodeId)
    await ensurePublicSchema()
    const db = await getDb({ quickGenerateEpisodes })
    const updatedAt = new Date()

    logger.info({
      event: "quick_generate_video_selection_start",
      module: "quick_generate",
      traceId,
      message: "开始确认 quick-generate 分镜采用视频",
      episodeId: parsed.data.episodeId,
      shotNo: parsed.data.shotNo,
      selectedJobId: parsed.data.selectedJobId
    })

    const result = await db.transaction(async (tx) => {
      const rows = await tx
        .select({
          id: quickGenerateEpisodes.id,
          videoResults: quickGenerateEpisodes.videoResults
        })
        .from(quickGenerateEpisodes)
        .where(eq(quickGenerateEpisodes.id, parsed.data.episodeId))
        .limit(1)

      const row = rows[0]
      if (!access || !row) {
        const err = new Error("未找到可操作的剧集")
        ;(err as Error & { code?: string }).code = "EPISODE_NOT_FOUND"
        throw err
      }

      const nextVideoResults = selectQuickGenerateShotVideo({
        current: row.videoResults,
        shotNo: parsed.data.shotNo,
        selectedJobId: parsed.data.selectedJobId
      })
      const selectedBucket = nextVideoResults[String(parsed.data.shotNo)]
      if (!selectedBucket?.selectedJobId) {
        const err = new Error("未找到可确认的视频版本")
        ;(err as Error & { code?: string }).code = "VIDEO_VERSION_NOT_FOUND"
        throw err
      }

      await tx
        .update(quickGenerateEpisodes)
        .set({
          videoResults: nextVideoResults,
          updatedAt
        })
        .where(eq(quickGenerateEpisodes.id, parsed.data.episodeId))

      return { selectedJobId: selectedBucket.selectedJobId }
    })

    logger.info({
      event: "quick_generate_video_selection_success",
      module: "quick_generate",
      traceId,
      message: "quick-generate 分镜采用视频确认成功",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      shotNo: parsed.data.shotNo,
      selectedJobId: result.selectedJobId
    })

    return NextResponse.json(makeApiOk(traceId, result))
  } catch (e) {
    const err = e as { code?: string; name?: string; message?: string; stack?: string }
    const code = err.code === "EPISODE_NOT_FOUND" || err.code === "VIDEO_VERSION_NOT_FOUND" ? err.code : "UNKNOWN"
    const status = code === "EPISODE_NOT_FOUND" || code === "VIDEO_VERSION_NOT_FOUND" ? 404 : 500
    logger.error({
      event: "quick_generate_video_selection_failed",
      module: "quick_generate",
      traceId,
      message: "quick-generate 分镜采用视频确认失败",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      shotNo: parsed.data.shotNo,
      selectedJobId: parsed.data.selectedJobId,
      errorCode: code,
      errorName: err.name,
      errorMessage: err.message,
      stack: err.stack
    })
    return NextResponse.json(makeApiErr(traceId, code, err.message?.trim() || "确认视频失败"), { status })
  }
}
