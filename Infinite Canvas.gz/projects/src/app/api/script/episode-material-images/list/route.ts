import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { episodeMaterialImages } from "@/shared/schema/generation"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  limit: z.coerce.number().int().min(1).max(50).default(20)
})

export const runtime = "nodejs"

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? "",
    limit: url.searchParams.get("limit") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialImages })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const rows = await db
    .select({
      id: episodeMaterialImages.id,
      outlineId: episodeMaterialImages.outlineId,
      name: episodeMaterialImages.name,
      url: episodeMaterialImages.url,
      createdAt: episodeMaterialImages.createdAt
    })
    .from(episodeMaterialImages)
    .where(eq(episodeMaterialImages.storyId, parsed.data.storyId))
    .orderBy(desc(episodeMaterialImages.createdAt))
    .limit(parsed.data.limit)

  return NextResponse.json(makeApiOk(traceId, { items: rows }), { status: 200 })
}
