"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import styles from "./ShortDramaSetupPage.module.css"
import navStyles from "../workspace/components/shortDrama/ShortDramaStepsNav.module.css"
import { ShortDramaPanel } from "../workspace/components/shortDrama/ShortDramaPanel"
import type { ShortDramaStepKey } from "../workspace/components/shortDrama/ShortDramaStepsNav"
import { ShortDramaStepsNav } from "../workspace/components/shortDrama/ShortDramaStepsNav"
import type { ApiErr, ApiOk } from "@/shared/api"
import { ConfirmModal } from "@/shared/ui/ConfirmModal"
import { ProgressNav } from "@/shared/ui/ProgressNav"
import { useActiveJobs } from "@/features/video/hooks/useActiveJobs"

type ShortDramaSetupPageProps = Readonly<{
  storyId: string
  storyMetadata?: Record<string, unknown>
  hasOutlines?: boolean
  storyConfig: {
    title: string
    ratio: string
    resolution: string
    style: string
    videoCategory: string
  }
}>

function isShortDramaReady(shortDrama: any, opts?: { skipWorldSetting?: boolean }): boolean {
  if (!shortDrama || typeof shortDrama !== "object") return false
  if (!(shortDrama as any).planningResult) return false
  if (!opts?.skipWorldSetting && !(shortDrama as any).worldSetting) return false
  if (!(shortDrama as any).characterSetting) return false
  return true
}

export function ShortDramaSetupPage({ storyId, storyMetadata, hasOutlines: hasOutlinesProp, storyConfig }: ShortDramaSetupPageProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const next = searchParams.get("next") || ""

  const [shortDrama, setShortDrama] = useState<any>(() => (storyMetadata as any)?.shortDrama ?? {})
  const [activeStep, setActiveStep] = useState<ShortDramaStepKey>("planning")
  const shortDramaObj = shortDrama && typeof shortDrama === "object" ? (shortDrama as any) : {}
  const setupParam = (searchParams.get("setup") ?? "").trim()
  const setupSource = typeof shortDramaObj.setupSource === "string" ? shortDramaObj.setupSource.trim() : ""
  const isScriptSetup = setupSource === "script_body" || setupParam === "script"
  const skipWorldSetting = isScriptSetup
  const planningOk = Boolean(shortDramaObj?.planningResult)
  const hasSettings = Boolean(
    skipWorldSetting
      ? Boolean(shortDramaObj?.characterSetting)
      : Boolean(shortDramaObj?.worldSetting) && Boolean(shortDramaObj?.characterSetting)
  )
  const confirmed = Boolean(
    typeof shortDramaObj?.planningConfirmedAt === "number" || isShortDramaReady(shortDramaObj, { skipWorldSetting })
  )
  const worldOk = Boolean(confirmed && shortDramaObj?.worldSetting)
  const characterOk = Boolean(confirmed && shortDramaObj?.characterSetting)
  const planningReady = Boolean(shortDramaObj?.planningResult)
  const worldReady = Boolean(shortDramaObj?.worldSetting)
  const characterReady = Boolean(shortDramaObj?.characterSetting)
  const shouldPoll = skipWorldSetting ? !(planningReady && characterReady) : !(planningReady && worldReady && characterReady)
  const [generating, setGenerating] = useState(false)
  const [confirmGenerating, setConfirmGenerating] = useState(false)
  const [errorText, setErrorText] = useState<string | null>(null)
  const [autoLoading, setAutoLoading] = useState(false)
  const [storyText, setStoryText] = useState("")
  const [outlineJobId, setOutlineJobId] = useState("")
  const [hasOutlines, setHasOutlines] = useState(Boolean(hasOutlinesProp))
  const [confirmOpen, setConfirmOpen] = useState(false)
  const [confirmTitle, setConfirmTitle] = useState("确认操作？")
  const [confirmMessage, setConfirmMessage] = useState("")
  const [confirmConfirmText, setConfirmConfirmText] = useState("确认")
  const confirmActionRef = useRef<null | (() => void)>(null)
  const confirmAndGenerateRef = useRef<null | (() => void)>(null)
  const pendingConfirmRef = useRef(false)

  const workspaceMode = isScriptSetup ? "source" : "brief"
  const workspaceUrl = `/script/workspace/${encodeURIComponent(storyId)}?mode=${workspaceMode}`
  const continueUrl = (() => {
    if (next && next.startsWith("/")) {
      if (!isScriptSetup) return next
      try {
        const url = new URL(next, "http://local")
        if (url.pathname.startsWith(`/script/workspace/${encodeURIComponent(storyId)}`)) {
          url.searchParams.set("mode", "source")
          const qs = url.searchParams.toString()
          return qs ? `${url.pathname}?${qs}` : url.pathname
        }
        return next
      } catch {
        return next
      }
    }
    return workspaceUrl
  })()

  const { jobs: activeJobs } = useActiveJobs({ storyId, enabled: Boolean(storyId) })

  useEffect(() => {
    const jobId = outlineJobId.trim()
    if (!jobId) return
    const job = activeJobs.find((j) => j.jobId === jobId)
    if (!job) return
    if (job.status === "done") {
      setOutlineJobId("")
      setHasOutlines(true)
      router.push(continueUrl)
      return
    }
    if (job.status === "error") {
      const message = typeof (job.snapshot as any)?.errorMessage === "string" ? String((job.snapshot as any).errorMessage).trim() : ""
      setOutlineJobId("")
      setErrorText(message || "生成大纲失败，请稍后重试")
    }
  }, [activeJobs, continueUrl, outlineJobId, router])

  useEffect(() => {
    let cancelled = false
    const fetchDetail = async () => {
      try {
        const res = await fetch(`/api/library/stories/${encodeURIComponent(storyId)}/detail`, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as ApiOk<{ story: { storyText?: unknown } }> | ApiErr | null
        if (!res.ok || !json || (json as ApiErr).ok === false) return
        const data = (json as ApiOk<{ story: { storyText?: unknown } }>).data
        const text = typeof data?.story?.storyText === "string" ? data.story.storyText.trim() : ""
        if (!cancelled && text) setStoryText(text)
      } catch {}
    }
    void fetchDetail()
    return () => {
      cancelled = true
    }
  }, [storyId])

  useEffect(() => {
    if (!shouldPoll) {
      setAutoLoading(false)
      return
    }
    let cancelled = false
    setAutoLoading(true)
    const fetchLatest = async () => {
      try {
        const res = await fetch(`/api/library/stories/${encodeURIComponent(storyId)}/detail`, { cache: "no-store" })
        const json = (await res.json().catch(() => null)) as ApiOk<{ story: { metadata?: unknown; storyText?: unknown } }> | ApiErr | null
        if (!res.ok || !json || (json as ApiErr).ok === false) return
        const data = (json as ApiOk<{ story: { metadata?: unknown } }>).data
        const md = (data?.story?.metadata ?? {}) as Record<string, unknown>
        const nextShortDrama = (md as any)?.shortDrama ?? {}
        if (!cancelled) setShortDrama(nextShortDrama)
        const text = typeof (data as any)?.story?.storyText === "string" ? String((data as any).story.storyText).trim() : ""
        if (!cancelled && text) setStoryText(text)
      } catch {}
    }
    void fetchLatest()
    const timer = window.setInterval(fetchLatest, 4000)
    return () => {
      cancelled = true
      window.clearInterval(timer)
    }
  }, [shouldPoll, storyId])

  const roleAssetsConfirmed = (() => {
    const base = shortDrama && typeof shortDrama === "object" ? (shortDrama as any).roleImageDraws : null
    if (!base || typeof base !== "object" || Array.isArray(base)) return false
    const values = Object.values(base).filter((v) => v && typeof v === "object" && !Array.isArray(v)) as any[]
    if (values.length === 0) return false
    return values.every((v) => {
      // 只要有 selectedUrl 就认为已选择形象图
      const selectedUrl = typeof (v as any).selectedUrl === "string" ? (v as any).selectedUrl.trim() : ""
      if (selectedUrl) return true
      
      // 或者有 assetSelectionByFrontImageUrl 也认为已选择
      const assetSelectionByFrontImageUrl = (v as any).assetSelectionByFrontImageUrl
      if (assetSelectionByFrontImageUrl && typeof assetSelectionByFrontImageUrl === "object") {
        const keys = Object.keys(assetSelectionByFrontImageUrl)
        if (keys.length > 0) return true
      }
      
      return false
    })
  })()

  const openConfirm = (input: { title: string; message: string; confirmText?: string; action: () => void }) => {
    confirmActionRef.current = input.action
    setConfirmTitle(input.title)
    setConfirmMessage(input.message)
    setConfirmConfirmText(input.confirmText?.trim() ? input.confirmText.trim() : "确认")
    setConfirmOpen(true)
  }

  const gotoOutline = async () => {
    if (generating) return
    if (hasOutlines) {
      router.push(continueUrl)
      return
    }
    const hasRunningOutlineJob = activeJobs.some((j) => j.type === "coze_generate_outline" && (j.status === "running" || j.status === "queued"))
    if (hasRunningOutlineJob) {
      router.push(continueUrl)
      return
    }
    if (!hasSettings) return
    setGenerating(true)
    setErrorText(null)
    try {
      const novelText = storyText.trim()
      if (!novelText) {
        setErrorText("小说文本为空，无法生成大纲")
        return
      }
      const res = await fetch("/api/coze/storyboard/generate-outline", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          storyId,
          input_type: "brief",
          planning_result: (shortDrama as any).planningResult ?? null,
          world_setting: novelText,
          character_setting: (shortDrama as any).characterSetting ?? null,
          use_volcano_ark: true,
          title: storyConfig.title,
          ratio: storyConfig.ratio,
          resolution: storyConfig.resolution,
          style: storyConfig.style,
          video_category: storyConfig.videoCategory,
          async: true
        })
      })
      const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
      if (!res.ok || !json || (json as ApiErr).ok === false) {
        const errJson = (json as ApiErr | null) ?? null
        setErrorText(errJson?.error?.message ?? "生成大纲失败，请稍后重试")
        return
      }
      if (res.status === 202) {
        const data = (json as ApiOk<unknown>).data as any
        const jobId = String(data?.jobId ?? "")
        if (jobId) setOutlineJobId(jobId)
        setErrorText("已提交到任务中心，请稍后查看进度")
        return
      }
      setHasOutlines(true)
      router.push(continueUrl)
    } catch (e) {
      const anyErr = e as { message?: string }
      setErrorText(anyErr?.message ?? "网络异常，请稍后重试")
    } finally {
      setGenerating(false)
    }
  }

  const requestGotoOutline = () => {
    if (!hasOutlines && hasSettings && !roleAssetsConfirmed) {
      openConfirm({
        // 文案调整：仅改字，不改判断逻辑
        title: "下一步要生成大纲，开始创作",
        message: "下一步要生成大纲，开始创作",
        confirmText: "继续",
        action: () => void gotoOutline()
      })
      return
    }
    void gotoOutline()
  }

  const onRegenerateOutline = async () => {
    if (!hasSettings || generating) return
    setGenerating(true)
    setErrorText(null)
    try {
      const novelText = storyText.trim()
      if (!novelText) {
        setErrorText("小说文本为空，无法生成大纲")
        return
      }
      const res = await fetch("/api/coze/storyboard/generate-outline", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          storyId,
          input_type: "brief",
          planning_result: (shortDrama as any).planningResult ?? null,
          world_setting: novelText,
          character_setting: (shortDrama as any).characterSetting ?? null,
          use_volcano_ark: true,
          title: storyConfig.title,
          ratio: storyConfig.ratio,
          resolution: storyConfig.resolution,
          style: storyConfig.style,
          video_category: storyConfig.videoCategory,
          async: true
        })
      })
      const json = (await res.json().catch(() => null)) as ApiOk<unknown> | ApiErr | null
      if (!res.ok || !json || (json as ApiErr).ok === false) {
        const errJson = (json as ApiErr | null) ?? null
        setErrorText(errJson?.error?.message ?? "重新生成大纲失败，请稍后重试")
        return
      }
      if (res.status === 202) {
        const data = (json as ApiOk<unknown>).data as any
        const jobId = String(data?.jobId ?? "")
        if (jobId) setOutlineJobId(jobId)
        setErrorText("已提交到任务中心，请稍后查看进度")
        return
      }
      setHasOutlines(true)
      router.push(continueUrl)
    } catch (e) {
      const anyErr = e as { message?: string }
      setErrorText(anyErr?.message ?? "网络异常，请稍后重试")
    } finally {
      setGenerating(false)
    }
  }

  const outlineDisabled = generating || (!hasOutlines && !hasSettings)
  const outlineBadge = generating ? "生成中…" : hasOutlines ? "已生成" : hasSettings ? "未生成" : "待完善"
  const outlineBadgeClass = outlineBadge === "已生成" ? navStyles.badgeOk : navStyles.badgeMuted
  const isBusy = generating || confirmGenerating
  const isParsing = skipWorldSetting && autoLoading
  const primaryLabel = isBusy ? "生成中…" : hasOutlines ? "进入大纲" : hasSettings ? "继续下一步" : skipWorldSetting ? "生成" : "确认策划并生成设定"
  const onPrimaryClick = () => {
    if (isBusy) return
    if (!planningOk) {
      setActiveStep("planning")
      return
    }
    if (skipWorldSetting && !hasSettings && !hasOutlines) {
      setActiveStep("planning")
      return
    }
    if (!hasSettings && !hasOutlines) {
      const fn = confirmAndGenerateRef.current
      if (!fn) {
        pendingConfirmRef.current = true
        setActiveStep("planning")
        return
      }
      setConfirmGenerating(true)
      fn()
      return
    }
    requestGotoOutline()
  }
  const onExposeConfirmAndGenerate = (fn: (() => void) | null) => {
    confirmAndGenerateRef.current = fn
    if (pendingConfirmRef.current && fn) {
      pendingConfirmRef.current = false
      setConfirmGenerating(true)
      fn()
    }
  }

  return (
    <main className={styles.page}>
      <ProgressNav
        activeKey="script_setup"
        steps={[
          { key: "script_setup", label: "剧本设置", href: `/script/short-drama/${encodeURIComponent(storyId)}` },
          { key: "script_body", label: "剧本正文", href: workspaceUrl },
          {
            key: "storyboard_desc",
            label: "分镜描述",
            href: `/video/storyboard/description?${(() => {
              const qs = new URLSearchParams()
              qs.set("storyId", storyId)
              return qs.toString()
            })()}`
          },
          {
            key: "storyboard_frames",
            label: "分镜镜头",
            href: `/video/storyboard/frames?${(() => {
              const qs = new URLSearchParams()
              qs.set("storyId", storyId)
              return qs.toString()
            })()}`
          },
          {
            key: "storyboard_videos",
            label: "分镜视频",
            href: `/video/storyboard/videos?${(() => {
              const qs = new URLSearchParams()
              qs.set("storyId", storyId)
              return qs.toString()
            })()}`
          },
        ]}
      />
      <div className={styles.container}>
        <section className={styles.layout} aria-label="短剧信息布局">
          <aside className={styles.rail} aria-label="创作流程">
            <div className={styles.card}>
              <div className={styles.cardTitle}>剧本信息</div>
              <div className={styles.flowList}>
                <ShortDramaStepsNav
                  shortDrama={shortDrama}
                  active={activeStep}
                  onChange={setActiveStep}
                  hideWorldSetting={skipWorldSetting}
                  extraItems={
                    <button type="button" className={navStyles.navItem} disabled={outlineDisabled} onClick={requestGotoOutline}>
                      <div className={navStyles.navRow}>
                        <div className={navStyles.navTitle}>剧本大纲</div>
                        <div className={outlineBadgeClass}>{outlineBadge}</div>
                      </div>
                      <div className={navStyles.navDesc}>
                        {hasOutlines ? "已生成可查看" : hasSettings ? "生成后进入" : skipWorldSetting ? "需先生成角色设定" : "需先确认策划并生成设定"}
                      </div>
                    </button>
                  }
                />
              </div>
            </div>
          </aside>

          <section className={styles.panelCard} aria-label="短剧信息编辑">
            <ShortDramaPanel
              storyId={storyId}
              videoCategory={storyConfig.videoCategory}
              userTitle={storyConfig.title}
              shotStyle={storyConfig.style}
              isParsing={isParsing}
              shortDrama={shortDrama}
              onShortDramaUpdate={setShortDrama}
              showNav={false}
              active={activeStep}
              onActiveChange={setActiveStep}
              onExposeConfirmAndGenerate={onExposeConfirmAndGenerate}
              onConfirmGeneratingChange={setConfirmGenerating}
              hideWorldSetting={skipWorldSetting}
            />
          </section>

          <aside className={styles.rail} aria-label="检查清单与操作">
            <div className={styles.card}>
              <div className={styles.cardTitle}>前置条件</div>
              <div className={styles.kv}>
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>剧本策划</div>
                  <div className={styles.kvVal}>{planningOk ? "已生成" : "未生成"}</div>
                </div>
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>策划确认</div>
                  <div className={styles.kvVal}>{confirmed ? "已确认" : "未确认"}</div>
                </div>
                {skipWorldSetting ? null : (
                  <div className={styles.kvRow}>
                    <div className={styles.kvKey}>世界观设定</div>
                    <div className={styles.kvVal}>{worldOk ? "已生成" : "未生成"}</div>
                  </div>
                )}
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>角色设定</div>
                  <div className={styles.kvVal}>{characterOk ? "已生成" : "未生成"}</div>
                </div>
              </div>
            </div>

            <div className={styles.card}>
              <div className={styles.cardTitle}>故事配置</div>
              <div className={styles.kv}>
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>标题</div>
                  <div className={styles.kvVal}>{storyConfig.title?.trim() ? storyConfig.title.trim() : "—"}</div>
                </div>
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>比例</div>
                  <div className={styles.kvVal}>{storyConfig.ratio}</div>
                </div>
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>分辨率</div>
                  <div className={styles.kvVal}>{storyConfig.resolution}</div>
                </div>
                <div className={styles.kvRow}>
                  <div className={styles.kvKey}>画风</div>
                  <div className={styles.kvVal}>{storyConfig.style}</div>
                </div>
              </div>
            </div>

            <div className={styles.card}>
              <div className={styles.cardTitle}>操作</div>
              <div className={styles.actionStack}>
                {errorText ? <div className={styles.error}>{errorText}</div> : null}
                <button
                  type="button"
                  className={styles.secondaryBtn}
                  onClick={() => router.push(workspaceUrl)}
                >
                  返回工作台
                </button>
                <button
                  type="button"
                  className={styles.secondaryBtn}
                  disabled={!hasSettings || generating || !hasOutlines}
                  onClick={() => {
                    openConfirm({
                      title: "确认重新生成大纲？",
                      message: "该操作会覆盖现有大纲，并重新生成。",
                      confirmText: "确认",
                      action: () => {
                        void onRegenerateOutline()
                      }
                    })
                  }}
                >
                  重新生成大纲
                </button>
                <button type="button" className={styles.primaryBtn} disabled={isBusy} onClick={onPrimaryClick}>
                  {isBusy ? <span className={styles.spinner} aria-hidden="true" /> : null}
                  <span>{primaryLabel}</span>
                </button>
              </div>
            </div>
          </aside>
        </section>
      </div>

      <ConfirmModal
        open={confirmOpen}
        title={confirmTitle}
        message={confirmMessage}
        confirmText={confirmConfirmText}
        cancelText="取消"
        onCancel={() => {
          setConfirmOpen(false)
          confirmActionRef.current = null
        }}
        onConfirm={() => {
          const act = confirmActionRef.current
          setConfirmOpen(false)
          confirmActionRef.current = null
          act?.()
        }}
      />
    </main>
  )
}
