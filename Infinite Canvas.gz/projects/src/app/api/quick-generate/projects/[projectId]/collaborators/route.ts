import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import {
  getQuickGenerateCollaborators,
  updateQuickGenerateCollaborators
} from "@/server/domains/quick-generate/collaborationService"

export const runtime = "nodejs"

const updateSchema = z
  .object({
    collaboratorUserIds: z.array(z.string().trim().min(1).max(200)).max(200)
  })
  .strict()

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ projectId: string }> }
): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) {
    return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })
  }

  const { projectId } = await context.params
  try {
    const data = await getQuickGenerateCollaborators(userId, projectId.trim())
    return NextResponse.json(makeApiOk(traceId, data))
  } catch (error: any) {
    logger.error({
      event: "quick_generate_collaborators_fetch_failed",
      module: "quick_generate",
      traceId,
      message: "获取协同成员配置失败",
      projectId,
      userId,
      errorName: error?.name,
      errorMessage: error?.message,
      stack: error?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "QUICK_GENERATE_COLLAB_FETCH_FAILED", error?.message ?? "获取协同成员失败"), {
      status: 500
    })
  }
}

export async function PUT(
  req: NextRequest,
  context: { params: Promise<{ projectId: string }> }
): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) {
    return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })
  }

  const { projectId } = await context.params
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = updateSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  }

  try {
    const data = await updateQuickGenerateCollaborators(userId, projectId.trim(), parsed.data)
    return NextResponse.json(makeApiOk(traceId, data))
  } catch (error: any) {
    logger.error({
      event: "quick_generate_collaborators_update_failed",
      module: "quick_generate",
      traceId,
      message: "更新协同成员配置失败",
      projectId,
      userId,
      errorName: error?.name,
      errorMessage: error?.message,
      stack: error?.stack
    })
    return NextResponse.json(
      makeApiErr(traceId, "QUICK_GENERATE_COLLAB_UPDATE_FAILED", error?.message ?? "保存协同成员失败"),
      { status: 500 }
    )
  }
}
