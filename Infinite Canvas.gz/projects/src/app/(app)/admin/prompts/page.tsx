import { Suspense, type ReactElement } from "react"
import { PromptManagementPage } from "@/features/admin"

export default function AdminPromptsRoute(): ReactElement {
  return (
    <Suspense fallback={null}>
      <PromptManagementPage />
    </Suspense>
  )
}
