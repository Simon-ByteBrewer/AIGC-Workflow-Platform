import { NextResponse, type NextRequest } from "next/server"
import { eq } from "drizzle-orm"
import { z } from "zod"
import { getDb } from "coze-coding-dev-sdk"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { kickAllWorkers } from "@/server/framework/jobs/kickWorkers"
import { enqueueQuickGenerateVideoSubtitleEraseJob } from "@/server/domains/quick-generate/jobs/quickGenerateVideoSubtitleEraseWorker"
import { getQuickGenerateEpisodeAccess } from "@/server/domains/quick-generate/access"
import { normalizeQuickGenerateEpisodeVideoResults } from "@/shared/quickGenerate/videoResults"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { quickGenerateEpisodes } from "@/shared/schema"

export const runtime = "nodejs"

const inputSchema = z
  .object({
    episodeId: z.string().trim().min(1).max(200),
    shotNo: z.number().int().min(1).max(10_000),
    jobId: z.string().trim().min(1).max(200)
  })
  .strict()

/**
 * 为 quick-generate 单个视频版本入队字幕擦除任务。
 */
export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    const access = await getQuickGenerateEpisodeAccess(userId, parsed.data.episodeId)
    await ensurePublicSchema()
    const db = await getDb({ quickGenerateEpisodes })
    const rows = await db
      .select({
        storyId: quickGenerateEpisodes.storyId,
        videoResults: quickGenerateEpisodes.videoResults
      })
      .from(quickGenerateEpisodes)
      .where(eq(quickGenerateEpisodes.id, parsed.data.episodeId))
      .limit(1)

    const row = rows[0]
    if (!access || !row) {
      return NextResponse.json(makeApiErr(traceId, "EPISODE_NOT_FOUND", "未找到可操作的剧集"), { status: 404 })
    }

    const normalized = normalizeQuickGenerateEpisodeVideoResults(row.videoResults)
    const bucket = normalized[String(parsed.data.shotNo)]
    const targetVideo = bucket?.videos.find((video) => video.jobId === parsed.data.jobId)
    if (!targetVideo) {
      return NextResponse.json(makeApiErr(traceId, "VIDEO_NOT_FOUND", "未找到要擦除字幕的视频版本"), { status: 404 })
    }

    const originVideoUrl = (targetVideo.originVideoUrl ?? "").trim()
    if (!originVideoUrl) {
      return NextResponse.json(makeApiErr(traceId, "ORIGIN_VIDEO_URL_MISSING", "该视频缺少原始生成链接，无法擦除字幕"), {
        status: 400
      })
    }

    const result = await enqueueQuickGenerateVideoSubtitleEraseJob({
      traceId,
      userId,
      storyId: row.storyId,
      episodeId: parsed.data.episodeId,
      shotNo: parsed.data.shotNo,
      sourceJobId: parsed.data.jobId,
      originVideoUrl,
      durationSeconds: targetVideo.durationSeconds,
      prompt: targetVideo.prompt,
      settings: targetVideo.settings
    })
    kickAllWorkers()

    logger.info({
      event: "quick_generate_video_subtitle_erase_enqueue_success",
      module: "quick_generate",
      traceId,
      message: "字幕擦除任务入队成功",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      shotNo: parsed.data.shotNo,
      sourceJobId: parsed.data.jobId,
      jobId: result.jobId
    })

    return NextResponse.json(makeApiOk(traceId, { jobId: result.jobId }), { status: 202 })
  } catch (error) {
    const err = error as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "quick_generate_video_subtitle_erase_enqueue_failed",
      module: "quick_generate",
      traceId,
      message: "字幕擦除任务入队失败",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      shotNo: parsed.data.shotNo,
      sourceJobId: parsed.data.jobId,
      errorName: err?.name,
      errorMessage: err?.message,
      stack: err?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "UNKNOWN", err?.message?.trim() || "字幕擦除入队失败"), { status: 500 })
  }
}
