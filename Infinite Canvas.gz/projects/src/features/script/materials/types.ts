export type MaterialAsset = {
  id: string
  kind: string
  name: string
  roleName: string | null
  makeupName: string | null
  costumeName: string | null
  prompt: string | null
  url: string
  thumbnailUrl?: string | null
  meta?: unknown
  createdAt?: string
}

export type MaterialSummary = {
  scene: MaterialAsset[]
  role: MaterialAsset[]
  item: MaterialAsset[]
}
