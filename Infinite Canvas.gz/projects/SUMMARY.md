# 压缩摘要

## 用户需求与目标
- 当前目标:
  - 修复Coze异步接口调用，实现真正的异步任务提交和轮询
  - 修复轮询间隔，从 5 秒改为 30 秒
  - 调试Coze接口参数字段名问题（`script_outline` vs `outline_json`）
  - 修复Worker保存剧本正文时的数据结构嵌套问题
  - 修改Coze请求体字段名 `script_planning` 为 `planning_result`
  - 修复Next.js 16动态路由params类型签名问题
  - 将素材生成中ROLE_IMG_API超时时间从 3 分钟调整为 10 分钟
  - 修复`runGenerateScriptBody`函数缺少`asyncMode`参数类型定义的问题
  - 排查"生成全部首帧图"功能无法正确生成的问题

## 项目概览
- 概述: AI视频生成平台，支持短剧创作、分镜管理、素材生成、视频导出等功能
- 技术栈:
  - Next.js 16.1.2
  - React 19.2.3
  - TypeScript 5.9.3
  - pnpm (包管理器)
  - Tailwind CSS 4.2.1
  - Drizzle ORM + PostgreSQL
  - shadcn/ui 组件库
- 编码规范: ESLint + TypeScript

## 关键决策
- 异步接口改造: 使用Coze真正的异步接口`/async/submit`和`/async/status/{taskId}`
- 轮询间隔: 设置为30秒，最大轮询60次（总时长30分钟）
- 字段名兼容: 同时发送`script_outline`和`outline_json`两个字段，满足Coze两处验证
- 数据结构修复: Worker保存结果时直接提取`script_body`字段，避免嵌套
- 请求体字段名: Coze请求体中使用`planning_result`替代`script_planning`
- 首帧图生成超时: ROLE_IMG_API超时时间调整为10分钟（与ROLE_API一致）

## 核心文件修改
- 文件操作:
  - edit: `src/features/coze/asyncTaskClient.ts`, `src/server/domains/storyboard/integrations/cozeScriptBodyTasks.ts`, `src/server/domains/storyboard/jobs/cozeStoryboardWorker.ts`, `src/app/api/coze/storyboard/generate-script-body/tasks/[taskId]/events/route.ts`, `src/app/api/coze/storyboard/generate-script-body/tasks/[taskId]/status/route.ts`, `src/server/domains/storyboard/jobs/episodeMaterialWorker.ts`, `src/server/domains/storyboard/integrations/cozeScriptBodyTasks.ts`

- 关键修改:
  - **asyncTaskClient.ts**:
    - 使用真正的Coze异步接口`/async/submit`提交任务
    - 轮询间隔从5秒改为30秒
    - 最大轮询次数从360次改为60次（保持30分钟总时长）
    - 添加详细的轮询调试日志
  - **cozeScriptBodyTasks.ts**:
    - 同时发送`script_outline`和`outline_json`两个字段
    - 添加请求体调试日志
    - 修改请求体字段名`script_planning`为`planning_result`
    - 添加`asyncMode?: boolean`参数类型定义
    - 当`asyncMode=true`时，使用`submitCozeAsyncTask`提交任务并立即返回`taskId`
    - 当`asyncMode=false`时，保持原有的同步轮询逻辑
  - **cozeStoryboardWorker.ts**:
    - 导入`getCozeAsyncTaskStatus`
    - 在调用`runGenerateScriptBody`时添加`asyncMode: true`参数
    - 添加异步模式的轮询逻辑，间隔30秒，最多轮询60次（30分钟）
    - 正确处理任务完成、失败、超时等状态
    - 优化错误处理逻辑
    - 添加Worker轮询日志
  - **events/route.ts & status/route.ts**:
    - 修改参数类型：`{ params: { taskId: string } }` → `{ params: Promise<{ taskId: string }> }`
    - 添加await：`paramsSchema.safeParse(params)` → `paramsSchema.safeParse(await params)`
  - **episodeMaterialWorker.ts**:
    - 修改ROLE_IMG_API超时时间：`readTimeoutMs("ROLE_IMG_API_TIMEOUT_MS", 600_000)`（10分钟）

## 问题或错误及解决方案
- 问题: Coze异步接口返回404
  - 解决方案: 确认Coze工作流需要配置异步接口支持
- 问题: Coze异步接口返回400，缺少`script_planning`字段
  - 解决方案: 修改字段名从`planning_result`改为`script_planning`
- 问题: Coze异步接口返回400，缺少`script_outline`字段
  - 解决方案: 修改字段名从`outline_json`改为`script_outline`
- 问题: Coze执行时报错，缺少`outline_json`字段
  - 解决方案: 同时发送`script_outline`和`outline_json`两个字段
- 问题: 轮询间隔为5秒，不符合用户期望
  - 解决方案: 修改轮询间隔为30秒
- 问题: Coze任务已完成但Worker未获取到结果
  - 解决方案: Worker轮询逻辑未正确触发，添加详细日志调试
- 问题: Worker保存结果时数据结构嵌套两层
  - 解决方案: 直接提取`script_body`字段：`finalResult?.script_body ?? finalResult`
- 问题: 部署时Next.js 16类型错误：动态路由params类型不兼容
  - 解决方案: 修改params类型为`Promise<{ taskId: string }>`并添加await
- 问题: 部署时TypeScript类型错误：`asyncMode`字段不存在
  - 解决方案: 在`runGenerateScriptBody`函数参数类型中添加`asyncMode?: boolean`
- 问题: 首帧图生成任务报错 "Coze run endpoint 请求失败 | HTTP 504"
  - 分析: 可能是Coze API超时或服务端网关超时（504 Gateway Timeout）

## TODO
- 排查"生成全部首帧图"功能无法正确生成的问题（可能原因：参考图缺失、提示词缺失、Coze API未配置或调用失败、Worker未启动或崩溃、前端任务状态轮询问题、并发限制）

### 解决方案
1. **立即修复**：添加 `COZE_RUN_RETRY_MAX_ATTEMPTS=1`，避免无效重试
   - 将总耗时从 45 分钟降低到 15 分钟
2. **彻底解决**：改造为异步接口
   - 提交任务后立即返回 taskId
   - 后台轮询查询结果
   - 支持 SSE 实时推送进度
   - 避免 HTTP 超时问题

## 🚀 异步接口改造方案

### 核心改动
1. **异步任务客户端** (`src/features/coze/asyncTaskClient.ts`)
   - 提交异步任务到 Coze
   - 后台轮询查询任务状态
   - 内存存储任务状态（生产环境建议使用 Redis）

2. **API 接口改造**
   - `POST /api/coze/storyboard/generate-script-body`
     - 默认使用异步模式（`async: true`）
     - 立即返回 taskId
   - `GET /api/coze/storyboard/generate-script-body/tasks/{taskId}/status`
     - 查询任务状态
   - `GET /api/coze/storyboard/generate-script-body/tasks/{taskId}/events`
     - SSE 实时推送任务事件

3. **前端集成**
   - 支持轮询方式查询任务状态
   - 支持 SSE 方式监听任务事件（推荐）
   - 实时显示任务进度

### 性能对比

| 方案 | 响应时间 | 超时风险 | 用户体验 |
|------|---------|---------|---------|
| 同步模式 | 15 分钟 | ❌ 高（容易超时） | ❌ 差（长时间无反馈） |
| 异步轮询 | 1 秒 + 轮询 | ✅ 低 | ⭐⭐⭐ 中 |
| 异步 SSE | 1 秒 + 实时 | ✅ 低 | ⭐⭐⭐⭐⭐ 优秀 |

## 📚 相关文档

- [剧本正文超时问题诊断报告](./docs/script-body-timeout-diagnosis.md)
- [Coze 异步接口分析报告](./docs/coze-async-api-analysis.md)
- [剧本正文异步接口使用指南](./docs/script-body-async-api-guide.md)
- [日志诊断指南](./docs/log-diagnosis-guide.md)
- [诊断脚本使用指南](./scripts/README.md)
