"use client"

import { useMemo, useState, type ReactElement } from "react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/shared/ui/shadcn/dropdown-menu"
import type { BillingUserOption } from "@/shared/contracts/billing"
import styles from "./BillingUserSelect.module.css"

type BillingUserSelectProps = {
  value: string
  options: BillingUserOption[]
  onChange: (value: string) => void
}

/**
 * 人员筛选单选下拉。
 * 说明：支持组内联动和关键字搜索，避免账单页继续堆叠普通 select 导致选人效率过低。
 */
export function BillingUserSelect({ value, options, onChange }: BillingUserSelectProps): ReactElement {
  const [open, setOpen] = useState(false)
  const [keyword, setKeyword] = useState("")

  const selectedOption = useMemo(() => options.find((item) => item.id === value) ?? null, [options, value])
  const filteredOptions = useMemo(() => {
    const query = keyword.trim().toLowerCase()
    if (!query) return options
    return options.filter((item) => {
      const name = item.name.toLowerCase()
      const groupName = (item.groupName ?? "未分组").toLowerCase()
      return name.includes(query) || groupName.includes(query)
    })
  }, [keyword, options])

  function handleOpenChange(nextOpen: boolean) {
    setOpen(nextOpen)
    if (!nextOpen) setKeyword("")
  }

  function handleSelect(nextValue: string) {
    onChange(nextValue)
    setOpen(false)
    setKeyword("")
  }

  return (
    <DropdownMenu open={open} onOpenChange={handleOpenChange}>
      <DropdownMenuTrigger asChild>
        <button type="button" className={styles.trigger} aria-label="人员筛选">
          <span className={styles.triggerText}>{selectedOption?.name ?? "全部人"}</span>
          <span className={styles.chevron} aria-hidden="true">
            ▼
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className={styles.content} align="start" side="bottom" sideOffset={6}>
        <input
          className={styles.search}
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          onKeyDown={(e) => e.stopPropagation()}
          placeholder="搜索成员"
        />
        <div className={styles.list}>
          <button type="button" className={`${styles.option} ${!value ? styles.optionSelected : ""}`} onClick={() => handleSelect("")}>
            <span className={styles.optionMain}>全部人</span>
            <span className={styles.optionMeta}>显示当前可见范围内全部成员</span>
          </button>
          {filteredOptions.map((item) => {
            const isSelected = item.id === value
            return (
              <button
                key={item.id}
                type="button"
                className={`${styles.option} ${isSelected ? styles.optionSelected : ""}`}
                onClick={() => handleSelect(item.id)}
                title={item.name}
              >
                <span className={styles.optionMain}>{item.name}</span>
                <span className={styles.optionMeta}>{item.groupName ?? "未分组"}</span>
              </button>
            )
          })}
          {filteredOptions.length === 0 ? <div className={styles.empty}>没有匹配成员</div> : null}
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
