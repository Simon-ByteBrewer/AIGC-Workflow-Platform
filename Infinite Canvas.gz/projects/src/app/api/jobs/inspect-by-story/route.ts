import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensureJobsTable } from "@/server/db/ensureJobsTable"
import { jobs } from "@/shared/schema/jobs"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  limit: z.string().trim().optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const raw = Object.fromEntries(req.nextUrl.searchParams.entries())
  const parsed = querySchema.safeParse(raw)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const limitRaw = Number(parsed.data.limit ?? "50")
  const limit = Number.isFinite(limitRaw) ? Math.min(200, Math.max(1, Math.floor(limitRaw))) : 50

  await ensureJobsTable()
  const db = await getDb({ jobs })
  const rows = await db
    .select({
      id: jobs.id,
      type: jobs.type,
      status: jobs.status,
      storyId: jobs.storyId,
      storyboardId: jobs.storyboardId,
      createdAt: jobs.createdAt,
      startedAt: jobs.startedAt,
      updatedAt: jobs.updatedAt,
      finishedAt: jobs.finishedAt,
      errorMessage: jobs.errorMessage,
      progressVersion: jobs.progressVersion,
      snapshot: jobs.snapshot
    })
    .from(jobs)
    .where(and(eq(jobs.userId, userId), eq(jobs.storyId, parsed.data.storyId)))
    .orderBy(desc(jobs.updatedAt))
    .limit(limit)

  const normalized = rows.map((r) => {
    const snap = r.snapshot && typeof r.snapshot === "object" && r.snapshot !== null && !Array.isArray(r.snapshot) ? (r.snapshot as any) : {}
    return {
      jobId: r.id,
      type: r.type,
      status: r.status,
      storyId: r.storyId,
      storyboardId: (r as any).storyboardId ?? null,
      createdAt: r.createdAt,
      startedAt: r.startedAt,
      updatedAt: r.updatedAt,
      finishedAt: r.finishedAt,
      errorMessage: r.errorMessage,
      progressVersion: r.progressVersion,
      stage: typeof snap.stage === "string" ? snap.stage : null,
      done: typeof snap.done === "number" ? snap.done : null,
      total: typeof snap.total === "number" ? snap.total : null,
      currentName: typeof snap.currentName === "string" ? snap.currentName : null
    }
  })

  return NextResponse.json(makeApiOk(traceId, { jobs: normalized }), { status: 200 })
}
