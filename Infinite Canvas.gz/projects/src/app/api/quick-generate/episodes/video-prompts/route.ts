import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { enqueueQuickGenerateEpisodeVideoPromptJob } from "@/server/domains/quick-generate/usecases/enqueueQuickGenerateEpisodeVideoPromptJob"

export const runtime = "nodejs"

const postSchema = z
  .object({
    episodeId: z.string().trim().min(1).max(200),
    shots: z
      .array(
        z
          .object({
            shotNo: z.number().int().min(1).max(10_000),
            shotText: z.string().max(50_000),
            roles: z.array(z.string().trim().max(200)).max(200),
            scenes: z.array(z.string().trim().max(200)).max(200),
            items: z.array(z.string().trim().max(200)).max(200),
            fenjingban_prompt: z.string().max(50_000).optional()
          })
          .strict()
      )
      .min(1)
  })
  .strict()

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = postSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  try {
    logger.info({
      event: "quick_generate_episode_video_prompt_enqueue_start",
      module: "quick_generate",
      traceId,
      message: "开始入队视频提示词生成任务",
      episodeId: parsed.data.episodeId,
      shotCount: parsed.data.shots.length
    })

    const result = await enqueueQuickGenerateEpisodeVideoPromptJob({
      traceId,
      userId,
      episodeId: parsed.data.episodeId,
      shots: parsed.data.shots
    })

    logger.info({
      event: "quick_generate_episode_video_prompt_enqueue_success",
      module: "quick_generate",
      traceId,
      message: "视频提示词批量任务已入队",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      jobId: result.jobId,
      queuedCount: result.queuedCount,
      skippedCount: result.skippedCount
    })

    return NextResponse.json(makeApiOk(traceId, result), { status: 202 })
  } catch (e) {
    const err = e as { name?: string; message?: string; stack?: string; code?: string }
    const code =
      err?.code === "EPISODE_NOT_FOUND" ? "EPISODE_NOT_FOUND" :
      err?.code === "EMPTY_SHOTS" ? "EMPTY_SHOTS" :
      err?.code === "ACTIVE_SHOT_JOBS_EXIST" ? "ACTIVE_SHOT_JOBS_EXIST" :
      "UNKNOWN"
    const status =
      code === "EPISODE_NOT_FOUND" ? 404 :
      code === "EMPTY_SHOTS" || code === "ACTIVE_SHOT_JOBS_EXIST" ? 409 :
      500
    logger.error({
      event: "quick_generate_episode_video_prompt_enqueue_failed",
      module: "quick_generate",
      traceId,
      message: "视频提示词入队失败",
      durationMs: Date.now() - start,
      episodeId: parsed.data.episodeId,
      errorName: err?.name,
      errorCode: code,
      errorMessage: err?.message,
      stack: err?.stack
    })
    return NextResponse.json(makeApiErr(traceId, code, err?.message?.trim() || "生成视频提示词失败"), { status })
  }
}
