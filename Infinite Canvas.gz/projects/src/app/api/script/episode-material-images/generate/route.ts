import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { enqueueEpisodeMaterialJob, kickEpisodeMaterialWorker } from "@/server/domains/storyboard/jobs/episodeMaterialWorker"
import { getDb } from "@/server/db/getDb"
import { stories } from "@/shared/schema/story"
import { and, eq } from "drizzle-orm"
import { logger } from "@/shared/logger"

const inputSchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  outlineId: z.string().trim().min(1).max(200).optional(),
  clearHistory: z.boolean().optional(),
  sceneModelName: z.string().trim().min(1).max(100).optional(),
  roleModelName: z.string().trim().min(1).max(100).optional(),
  itemModelName: z.string().trim().min(1).max(100).optional()
})

export const runtime = "nodejs"

export async function POST(req: NextRequest): Promise<Response> {
  const start = Date.now()
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) {
    logger.warn({ event: "episode_material_generate_api_validation_failed", module: "script", traceId, message: "素材生成接口参数校验失败" })
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })
  }

  logger.info({
    event: "episode_material_generate_api_enter",
    module: "script",
    traceId,
    message: "素材生成接口请求进入",
    userId,
    storyId: parsed.data.storyId,
    outlineId: parsed.data.outlineId ?? null,
    clearHistory: parsed.data.clearHistory ?? true
  })

  await ensurePublicSchema()
  const db = await getDb({ stories })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) {
    logger.warn({
      event: "episode_material_generate_api_forbidden",
      module: "script",
      traceId,
      message: "素材生成接口无权限或未找到剧本",
      userId,
      storyId: parsed.data.storyId
    })
    return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })
  }

  const { jobId } = await enqueueEpisodeMaterialJob({ 
    userId, 
    traceId, 
    storyId: parsed.data.storyId, 
    outlineId: parsed.data.outlineId ?? null,
    clearHistory: parsed.data.clearHistory ?? true,
    sceneModelName: parsed.data.sceneModelName,
    roleModelName: parsed.data.roleModelName,
    itemModelName: parsed.data.itemModelName
  })
  kickEpisodeMaterialWorker()
  logger.info({
    event: "episode_material_generate_api_enqueued",
    module: "script",
    traceId,
    message: "素材生成任务已入队",
    userId,
    storyId: parsed.data.storyId,
    jobId,
    durationMs: Date.now() - start
  })

  return NextResponse.json(makeApiOk(traceId, { jobId }), { status: 200 })
}
