import { NextResponse, type NextRequest } from "next/server"
import { and, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { stories } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"

export const runtime = "nodejs"

const paramsSchema = z.object({
  id: z.string().trim().min(1).max(200)
})

const patchSchema = z.object({
  title: z.string().trim().min(1, "标题不能为空").max(120, "标题不能超过 120 个字符")
})

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const rawParams = await ctx.params
  const parsedParams = paramsSchema.safeParse(rawParams)
  if (!parsedParams.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数不正确"), { status: 400 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsedBody = patchSchema.safeParse(body)
  if (!parsedBody.success) {
    return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", parsedBody.error.issues[0]?.message ?? "参数格式不正确"), { status: 400 })
  }

  const db = await getDb({ stories })
  const now = new Date()
  const updatedRows = await db
    .update(stories)
    .set({
      title: parsedBody.data.title,
      updatedAt: now
    })
    .where(and(eq(stories.id, parsedParams.data.id), eq(stories.userId, userId)))
    .returning({
      id: stories.id,
      title: stories.title,
      updatedAt: stories.updatedAt
    })

  const updated = updatedRows[0]
  if (!updated) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "内容不存在或无权限编辑"), { status: 404 })

  return NextResponse.json(makeApiOk(traceId, { story: updated }), { status: 200 })
}
