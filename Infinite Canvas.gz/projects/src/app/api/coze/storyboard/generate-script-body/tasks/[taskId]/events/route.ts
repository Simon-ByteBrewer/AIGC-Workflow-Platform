import { NextResponse } from "next/server"
import { z } from "zod"
import { getCozeAsyncTaskStatus } from "@/features/coze/asyncTaskClient"
import { makeApiErr } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { getSessionFromRequest } from "@/shared/session"
import type { NextRequest } from "next/server"

const paramsSchema = z.object({
  taskId: z.string().trim().min(1)
})

export const runtime = "nodejs"

export async function GET(
  req: Request,
  { params }: { params: Promise<{ taskId: string }> }
): Promise<Response> {
  const traceId = getTraceId(req.headers)

  // Next.js 16: params 是 Promise，需要 await
  const rawParams = await params

  // 验证任务 ID
  const parsed = paramsSchema.safeParse(rawParams)
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "INVALID_TASK_ID", "任务 ID 格式不正确"), {
      status: 400
    })
  }

  const { taskId } = parsed.data

  try {
    const session = await getSessionFromRequest(req as unknown as NextRequest)
    const userId = session?.userId
    if (!userId) {
      return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), {
        status: 401
      })
    }

    logger.info({
      event: "storyboard_script_body_task_events_start",
      module: "coze",
      traceId,
      taskId,
      message: "开始监听任务事件"
    })

    const encoder = new TextEncoder()

    const stream = new ReadableStream({
      async start(controller) {
        try {
          let lastStatus: string | null = null
          let retryCount = 0
          const maxRetries = 60 // 最多轮询 60 次（30分钟）

          while (retryCount < maxRetries) {
            const task = await getCozeAsyncTaskStatus(taskId)

            // 只在状态变化时发送事件
            if (task.status !== lastStatus) {
              const event = {
                type: "status_update",
                data: {
                  taskId: task.taskId,
                  status: task.status,
                  createdAt: task.createdAt,
                  startedAt: task.startedAt,
                  completedAt: task.completedAt
                }
              }

              controller.enqueue(
                encoder.encode(`event: ${task.status}\n`)
              )
              controller.enqueue(
                encoder.encode(`data: ${JSON.stringify(event)}\n\n`)
              )

              lastStatus = task.status

              logger.info({
                event: "storyboard_script_body_task_event",
                module: "coze",
                traceId,
                taskId,
                status: task.status,
                message: "发送任务事件"
              })
            }

            // 如果任务完成，发送最终结果
            if (task.status === "completed" || task.status === "failed" || task.status === "cancelled") {
              const finalEvent = {
                type: "task_finished",
                data: {
                  taskId: task.taskId,
                  status: task.status,
                  result: task.status === "completed" ? task.result : undefined,
                  error: task.status === "failed" ? task.error : undefined,
                  completedAt: task.completedAt
                }
              }

              controller.enqueue(encoder.encode(`event: done\n`))
              controller.enqueue(encoder.encode(`data: ${JSON.stringify(finalEvent)}\n\n`))

              logger.info({
                event: "storyboard_script_body_task_events_done",
                module: "coze",
                traceId,
                taskId,
                status: task.status,
                message: "任务事件流结束"
              })

              break
            }

            // 等待 30 秒后重试
            await sleep(30000)
            retryCount++
          }

          if (retryCount >= maxRetries) {
            const timeoutEvent = {
              type: "task_timeout",
              data: {
                taskId,
                error: "轮询超时（30分钟）"
              }
            }

            controller.enqueue(encoder.encode(`event: timeout\n`))
            controller.enqueue(encoder.encode(`data: ${JSON.stringify(timeoutEvent)}\n\n`))
          }

          controller.close()
        } catch (error) {
          logger.error({
            event: "storyboard_script_body_task_events_error",
            module: "coze",
            traceId,
            taskId,
            message: "任务事件流发生错误",
            error: error instanceof Error ? error.message : String(error)
          })

          const errorEvent = {
            type: "error",
            data: {
              taskId,
              error: error instanceof Error ? error.message : "未知错误"
            }
          }

          controller.enqueue(encoder.encode(`event: error\n`))
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(errorEvent)}\n\n`))
          controller.close()
        }
      }
    })

    return new NextResponse(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no" // 禁用 nginx 缓冲
      }
    })
  } catch (error) {
    const msg = error instanceof Error ? error.message : String(error)

    logger.error({
      event: "storyboard_script_body_task_events_init_error",
      module: "coze",
      traceId,
      taskId,
      message: "创建事件流失败",
      error: msg
    })

    return NextResponse.json(makeApiErr(traceId, "TASK_EVENTS_ERROR", "创建事件流失败"), {
      status: 500
    })
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
