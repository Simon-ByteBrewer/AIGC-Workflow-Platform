"use client"

import Link from "next/link"
import { useEffect, useMemo, useState } from "react"
import styles from "./QuotaPage.module.css"
import type { ApiErr, ApiOk } from "@/shared/api"
import type { QuotaTreeNode, QuotaUpdateRequest } from "@/shared/contracts/quota"

type TreeResponse = ApiOk<QuotaTreeNode[]> | ApiErr

async function readApiJson<T>(res: Response, fallbackMessage: string): Promise<T> {
  const raw = await res.text()
  if (!raw.trim()) {
    throw new Error(`${fallbackMessage}：接口返回为空 (HTTP ${res.status})`)
  }
  try {
    return JSON.parse(raw) as T
  } catch {
    throw new Error(`${fallbackMessage}：接口返回了非预期格式 (HTTP ${res.status})`)
  }
}

function parseQuotaNumber(value: string | null): number | null {
  if (value === null) return null
  return Number.parseFloat(value)
}

const GROUP_QUOTA_TOOLTIP = "组内所有成员共用分组的总额度"
const GROUP_UNSET_LIMIT_TEXT = "未设限额"
const USER_FOLLOW_GROUP_QUOTA_TEXT = "不设置，跟随分组额度"
const USER_FOLLOW_GROUP_REMAINING_TEXT = "不设置，跟随分组余额"

function getQuotaLimitText(node: Pick<QuotaTreeNode, "type" | "totalQuota">): string {
  if (node.totalQuota !== null) return node.totalQuota
  return node.type === "group" ? GROUP_UNSET_LIMIT_TEXT : USER_FOLLOW_GROUP_QUOTA_TEXT
}

function getRemainingQuotaText(node: Pick<QuotaTreeNode, "type" | "remainingQuota">): string {
  if (node.remainingQuota !== null) return node.remainingQuota
  return node.type === "group" ? GROUP_UNSET_LIMIT_TEXT : USER_FOLLOW_GROUP_REMAINING_TEXT
}

function getUnsetQuotaModeLabel(node: Pick<QuotaTreeNode, "type">): string {
  return node.type === "group" ? "设为未设限额" : USER_FOLLOW_GROUP_QUOTA_TEXT
}

function buildRecordHref(node: Pick<QuotaTreeNode, "id" | "type" | "name">): string {
  const query = new URLSearchParams()
  query.set("scope", "all")
  query.set("targetType", node.type)
  query.set("targetId", node.id)
  query.set("targetName", node.name)
  return `/admin/quota/records?${query.toString()}`
}

/**
 * 超级管理员可操作任意成员；组管理员允许操作自己，但不能操作其他管理员。
 */
function canOperateQuotaNode(params: {
  isSuperAdmin: boolean
  actorUserId: string
  targetUserId: string
  targetRole?: string
}): boolean {
  if (params.isSuperAdmin) return true
  if (params.actorUserId === params.targetUserId) return true
  return params.targetRole !== "group_admin" && params.targetRole !== "admin"
}
export function QuotaPage({ roleKey, userId }: { roleKey: string; userId: string }) {
  const [tree, setTree] = useState<QuotaTreeNode[]>([])
  const [loading, setLoading] = useState(true)
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({})
  const [updateModalOpen, setUpdateModalOpen] = useState(false)
  const [targetNode, setTargetNode] = useState<QuotaTreeNode | null>(null)
  const [updateMode, setUpdateMode] = useState<"add" | "set">("add")
  const [updateAmount, setUpdateAmount] = useState("")
  const [isUnsetQuota, setIsUnsetQuota] = useState(false)
  const isSuperAdmin = roleKey === "super_admin"

  const totalUserCount = useMemo(
    () => tree.reduce((sum, group) => sum + (group.children?.length ?? 0), 0),
    [tree]
  )

  async function fetchTree() {
    setLoading(true)
    try {
      const res = await fetch("/api/admin/quota/tree")
      const json = await readApiJson<TreeResponse>(res, "获取额度列表失败")
      if (json.ok) {
        setTree(json.data)
      } else {
        alert(json.error.message)
      }
    } catch (error: any) {
      alert(error?.message ?? "获取额度列表失败")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTree()
  }, [])

  function toggleGroup(groupId: string) {
    setCollapsedGroups((prev) => ({ ...prev, [groupId]: !prev[groupId] }))
  }

  function openUpdateModal(node: QuotaTreeNode, mode: "add" | "set") {
    setTargetNode(node)
    setUpdateMode(mode)
    setIsUnsetQuota(mode === "set" && node.totalQuota === null)
    setUpdateAmount(mode === "set" && node.remainingQuota !== null ? node.remainingQuota : "")
    setUpdateModalOpen(true)
  }

  async function handleUpdateSubmit() {
    if (!targetNode) return

    const ownerGroup = targetNode.type === "user"
      ? tree.find((group) => group.children?.some((user) => user.id === targetNode.id)) ?? null
      : null

    let amount: number | null = null
    if (!(updateMode === "set" && isUnsetQuota)) {
      amount = Number(updateAmount)
      if (!Number.isFinite(amount) || amount < 0) {
        alert("请输入有效的余额数值")
        return
      }
    }

    if (updateMode === "add" && targetNode.totalQuota === null) {
      alert("无限制余额不能继续增加，请改用修改余额")
      return
    }

    const currentRemainingQuota = parseQuotaNumber(targetNode.remainingQuota) ?? 0
    const nextRemainingQuota = updateMode === "set"
      ? (isUnsetQuota ? null : amount)
      : currentRemainingQuota + (amount ?? 0)

    const groupRemainingQuota = parseQuotaNumber(ownerGroup?.remainingQuota ?? null)
    if (ownerGroup && groupRemainingQuota !== null) {
      if (nextRemainingQuota !== null && nextRemainingQuota > groupRemainingQuota) {
        alert(`用户当前余额不能超过组当前余额 ${groupRemainingQuota.toFixed(4)}`)
        return
      }
    }
    const request: QuotaUpdateRequest = {
      id: targetNode.id,
      type: targetNode.type,
      mode: updateMode,
      amount
    }

    try {
      const res = await fetch("/api/admin/quota/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(request)
      })
      const json = await readApiJson<ApiOk<{ success: true }> | ApiErr>(res, "额度更新失败")
      if (!json.ok) {
        alert(json.error.message)
        return
      }

      setUpdateModalOpen(false)
      await fetchTree()
    } catch (error: any) {
      alert(error?.message ?? "额度更新失败")
    }
  }

  function renderGroup(group: QuotaTreeNode) {
    const collapsed = collapsedGroups[group.id] ?? true

    return (
      <div key={group.id} className={styles.groupSection}>
        <div className={styles.groupHeader} onClick={() => toggleGroup(group.id)} role="button" tabIndex={0}>
          <div className={styles.groupHeaderLeft}>
            <span className={styles.groupChevron}>{collapsed ? "▸" : "▾"}</span>
            <span className={styles.groupName}>{group.name}</span>
          </div>
          <div>分组</div>
          <div>{group.consumedQuota}</div>
          <div className={styles.valueText}>{getQuotaLimitText(group)}</div>
          <div className={styles.valueText}>{getRemainingQuotaText(group)}</div>
          <div className={styles.actions} onClick={(e) => e.stopPropagation()}>
            <button className={styles.btn} disabled={!isSuperAdmin} onClick={() => openUpdateModal(group, "add")}>
              增加余额
            </button>
            <button className={styles.btn} disabled={!isSuperAdmin} onClick={() => openUpdateModal(group, "set")}>
              修改余额
            </button>
            <Link className={styles.btn} href={buildRecordHref(group)}>
              分配记录
            </Link>
          </div>
        </div>
        {!collapsed ? (
          <div className={styles.groupBody}>
            {group.children?.map((user) => {
              const canOperate = canOperateQuotaNode({
                isSuperAdmin,
                actorUserId: userId,
                targetUserId: user.id,
                targetRole: user.role
              })

              return (
                <div key={user.id} className={styles.userRow}>
                  <div className={styles.userName}>{user.name}</div>
                  <div>个人 ({user.role === "group_admin" ? "管理员" : "成员"})</div>
                  <div>{user.consumedQuota}</div>
                  <div className={styles.valueText}>{getQuotaLimitText(user)}</div>
                  <div className={styles.valueText}>{getRemainingQuotaText(user)}</div>
                  <div className={styles.actions}>
                    <button className={styles.btn} disabled={!canOperate} onClick={() => openUpdateModal(user, "add")}>
                      增加余额
                    </button>
                    <button className={styles.btn} disabled={!canOperate} onClick={() => openUpdateModal(user, "set")}>
                      修改余额
                    </button>
                    <Link className={styles.btn} href={buildRecordHref(user)}>
                      分配记录
                    </Link>
                  </div>
                </div>
              )
            })}
          </div>
        ) : null}
      </div>
    )
  }

  const updateOwnerGroup = targetNode?.type === "user"
    ? tree.find((group) => group.children?.some((user) => user.id === targetNode.id)) ?? null
    : null
  const updateOwnerGroupRemainingQuota = parseQuotaNumber(updateOwnerGroup?.remainingQuota ?? null)
  const shouldShowGroupRemainingHint = Boolean(
    targetNode?.type === "user" &&
    updateMode === "set" &&
    updateOwnerGroup &&
    updateOwnerGroupRemainingQuota !== null
  )

  return (
    <div className={styles.page}>
      <div className={styles.topBar}>
        <div>
          <div className={styles.topTitle}>额度分配</div>
          <div className={styles.modalHint}>共 {tree.length} 个分组，{totalUserCount} 个成员</div>
        </div>
      </div>

      {loading ? (
        <div className={styles.modalHint}>加载中...</div>
      ) : (
        <div className={styles.tableContainer}>
          <div className={styles.thead}>
            <div>分组 / 成员</div>
            <div>类型</div>
            <div>历史已消耗总计</div>
            <div className={styles.headerWithHint}>
              <span>总额度</span>
              <span className={styles.hintWrapper}>
                <span className={styles.hintTrigger} aria-label={GROUP_QUOTA_TOOLTIP}>
                  ?
                </span>
                <span className={styles.hintTooltip} role="tooltip">
                  {GROUP_QUOTA_TOOLTIP}
                </span>
              </span>
            </div>
            <div>当前余额</div>
            <div>操作</div>
          </div>
          <div className={styles.tbody}>{tree.map((group) => renderGroup(group))}</div>
        </div>
      )}

      {updateModalOpen && targetNode ? (
        <div className={styles.modalOverlay}>
          <div className={styles.modalContent}>
            <div className={styles.modalTitle}>
              {updateMode === "add" ? "增加余额" : "修改余额"} - {targetNode.name}
            </div>
            <div className={styles.modalHint}>
              当前已使用 {targetNode.consumedQuota}，当前余额 {getRemainingQuotaText(targetNode)}
            </div>
            {updateMode === "set" ? (
              <label className={styles.modalField}>
                <span className={styles.modalLabel}>额度模式</span>
                <div className={styles.userName}>
                  <input type="checkbox" checked={isUnsetQuota} onChange={(e) => setIsUnsetQuota(e.target.checked)} />
                  <span>{getUnsetQuotaModeLabel(targetNode)}</span>
                </div>
              </label>
            ) : null}

            {!isUnsetQuota || updateMode === "add" ? (
              <label className={styles.modalField}>
                <div className={styles.modalLabelRow}>
                  <span className={styles.modalLabel}>余额数值</span>
                  {shouldShowGroupRemainingHint ? (
                    <span className={styles.modalLabelHint}>
                      当前分组余额 {updateOwnerGroupRemainingQuota!.toFixed(4)}，设置的余额不可超过该值
                    </span>
                  ) : null}
                </div>
                <input
                  type="number"
                  min="0"
                  className={styles.modalInput}
                  value={updateAmount}
                  onChange={(e) => setUpdateAmount(e.target.value)}
                  placeholder={updateMode === "add" ? "例如 100" : "例如 500"}
                />
              </label>
            ) : null}

            <div className={styles.modalActions}>
              <button className={styles.btn} onClick={() => setUpdateModalOpen(false)}>
                取消
              </button>
              <button className={styles.btn} onClick={handleUpdateSubmit}>
                保存
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  )
}
