import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { logger } from "@/shared/logger"
import { adminPromptPresets, groupPromptBindings, promptPresetUserBindings, userGroups, userSecurity, users } from "@/shared/schema"
import { listPromptManagementContext, PROMPT_TYPE_VALUES, createManagedPromptPreset } from "@/server/domains/admin/promptManagement"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"

export const runtime = "nodejs"

const RAW_DB_ERROR_PATTERNS = [/failed query:/i, /\binsert into\b/i, /\bupdate\b[\s\S]*\bset\b/i, /\bconstraint\b/i, /\bviolates\b/i]

function toSafePromptErrorMessage(input: unknown, fallback: string): string {
  const message = input instanceof Error ? input.message : String(input ?? "").trim()
  if (!message) return fallback
  if (RAW_DB_ERROR_PATTERNS.some((pattern) => pattern.test(message))) return fallback
  return message
}

const createBodySchema = z
  .object({
    name: z.string().trim().min(1).max(100),
    content: z.string().trim().min(1).max(50_000),
    promptType: z.enum(PROMPT_TYPE_VALUES),
    groupIds: z.array(z.string().trim().min(1).max(200)).max(500).default([]),
    userIds: z.array(z.string().trim().min(1).max(200)).max(500).default([])
  })
  .strict()

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    await ensurePublicSchema()
    const db = await getDb({ users, userSecurity, userGroups, adminPromptPresets, groupPromptBindings, promptPresetUserBindings })
    const data = await listPromptManagementContext({ db, actor })
    return NextResponse.json(makeApiOk(traceId, data), { status: 200 })
  } catch (error) {
    const anyErr = error as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "admin_prompt_management_load_failed",
      module: "admin-prompts",
      traceId,
      message: "加载提示词管理数据失败",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "PROMPT_MANAGEMENT_LOAD_FAILED", toSafePromptErrorMessage(error, "加载提示词管理数据失败")), { status: 500 })
  }
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor

    const parsed = createBodySchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ users, userSecurity, userGroups, adminPromptPresets, groupPromptBindings, promptPresetUserBindings })
    await createManagedPromptPreset({
      db,
      actor,
      name: parsed.data.name,
      content: parsed.data.content,
      promptType: parsed.data.promptType,
      groupIds: parsed.data.groupIds,
      userIds: parsed.data.userIds
    })

    const data = await listPromptManagementContext({ db, actor })
    return NextResponse.json(makeApiOk(traceId, data), { status: 201 })
  } catch (error) {
    const anyErr = error as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "admin_prompt_management_create_failed",
      module: "admin-prompts",
      traceId,
      message: "新增提示词失败",
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "PROMPT_MANAGEMENT_CREATE_FAILED", toSafePromptErrorMessage(error, "保存提示词失败，请稍后重试")), { status: 500 })
  }
}
