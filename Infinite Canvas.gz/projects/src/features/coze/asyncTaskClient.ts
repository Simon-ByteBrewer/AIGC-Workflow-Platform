/**
 * Coze 异步接口支持
 *
 * 用于处理需要长时间执行的任务，避免 HTTP 超时
 */

import { logger } from "@/shared/logger"

/**
 * Coze 异步任务状态
 */
export type CozeAsyncTaskStatus = "pending" | "running" | "completed" | "failed" | "cancelled"

/**
 * Coze 异步任务信息
 */
export interface CozeAsyncTask {
  taskId: string
  status: CozeAsyncTaskStatus
  result?: unknown
  error?: string
  createdAt: number
  startedAt?: number
  completedAt?: number
}

/**
 * 任务存储（内存存储，生产环境建议使用 Redis）
 */
class TaskStorage {
  private tasks: Map<string, CozeAsyncTask> = new Map()

  set(task: CozeAsyncTask): void {
    this.tasks.set(task.taskId, task)
  }

  get(taskId: string): CozeAsyncTask | undefined {
    return this.tasks.get(taskId)
  }

  update(taskId: string, updates: Partial<CozeAsyncTask>): void {
    const task = this.tasks.get(taskId)
    if (task) {
      this.tasks.set(taskId, { ...task, ...updates })
    }
  }

  delete(taskId: string): void {
    this.tasks.delete(taskId)
  }

  list(): CozeAsyncTask[] {
    return Array.from(this.tasks.values())
  }
}

/**
 * 全局任务存储
 */
export const taskStorage = new TaskStorage()

/**
 * 从 URL 中提取 base URL
 */
function extractBaseUrl(url: string): string {
  try {
    const u = new URL(url)
    // 移除路径部分，只保留协议 + 主机 + 端口
    return `${u.protocol}//${u.host}`
  } catch {
    return url
  }
}

/**
 * 提交异步任务到 Coze
 *
 * @param input 提交任务参数
 * @returns 任务 ID
 */
export async function submitCozeAsyncTask(input: {
  traceId: string
  url: string
  token: string
  body: unknown
  module: string
}): Promise<string> {
  const { traceId, url, token, body, module } = input
  const start = Date.now()

  logger.info({
    event: "coze_async_task_submit",
    module,
    traceId,
    message: "提交异步任务到 Coze"
  })

  try {
    // 构建 Coze 异步提交接口 URL
    const baseUrl = extractBaseUrl(url)
    const submitUrl = `${baseUrl}/async/submit`

    logger.info({
      event: "coze_async_submit_url",
      module,
      traceId,
      submitUrl,
      message: "使用 Coze 异步提交接口"
    })

    // 调用 Coze 异步提交接口
    const resp = await fetch(submitUrl, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${token}`
      },
      body: JSON.stringify(body)
    })

    if (!resp.ok) {
      const errorText = await resp.text()
      logger.error({
        event: "coze_async_submit_failed",
        module,
        traceId,
        status: resp.status,
        body: errorText,
        message: "Coze 异步提交接口返回错误"
      })
      throw new Error(`Coze 异步提交接口返回 ${resp.status}: ${errorText}`)
    }

    const data = await resp.json()

    // Coze 应该返回 task_id
    const taskId = data.task_id ?? data.taskId ?? data.id

    if (!taskId) {
      logger.error({
        event: "coze_async_submit_no_task_id",
        module,
        traceId,
        data,
        message: "Coze 异步提交接口未返回 task_id"
      })
      throw new Error("Coze 未返回 task_id")
    }

    // 保存任务信息
    const task: CozeAsyncTask = {
      taskId,
      status: "pending",
      createdAt: Date.now()
    }
    taskStorage.set(task)

    logger.info({
      event: "coze_async_task_submitted",
      module,
      traceId,
      taskId,
      message: "异步任务提交成功",
      durationMs: Date.now() - start
    })

    // 启动后台轮询
    startTaskPolling(taskId, { baseUrl, token, module })

    return taskId
  } catch (error) {
    logger.error({
      event: "coze_async_task_submit_failed",
      module,
      traceId,
      message: "异步任务提交失败",
      error: error instanceof Error ? error.message : String(error)
    })
    throw error
  }
}

/**
 * 获取任务状态
 *
 * @param taskId 任务 ID
 * @returns 任务信息
 */
export async function getCozeAsyncTaskStatus(taskId: string): Promise<CozeAsyncTask> {
  const task = taskStorage.get(taskId)

  if (!task) {
    throw new Error(`任务不存在: ${taskId}`)
  }

  return task
}

/**
 * 启动任务轮询
 */
function startTaskPolling(
  taskId: string,
  params: {
    baseUrl: string
    token: string
    module: string
  }
): void {
  const { baseUrl, token, module } = params

  // 使用 setTimeout 避免阻塞
  setTimeout(async () => {
    let retryCount = 0
    const maxRetries = 60 // 最多轮询 60 次（30分钟，每30秒一次）

    while (retryCount < maxRetries) {
      const task = taskStorage.get(taskId)

      if (!task) {
        logger.warn({
          event: "coze_async_task_not_found",
          module,
          taskId,
          traceId: taskId,
          message: "任务不存在，停止轮询"
        })
        break
      }

      if (task.status === "completed" || task.status === "failed" || task.status === "cancelled") {
        logger.info({
          event: "coze_async_task_finished",
          module,
          taskId,
          traceId: taskId,
          status: task.status,
          message: "任务已完成，停止轮询"
        })
        break
      }

      try {
        // 轮询 Coze 获取任务状态
        const statusUrl = `${baseUrl}/async/status/${taskId}`
        const result = await pollCozeTaskStatus(statusUrl, token, module, taskId)

        if (result.status === "completed") {
          taskStorage.update(taskId, {
            status: "completed",
            result: result.data,
            completedAt: Date.now()
          })
          logger.info({
            event: "coze_async_task_completed",
            module,
            taskId,
            traceId: taskId,
            message: "任务执行完成",
            durationMs: Date.now() - task.createdAt
          })
          break
        } else if (result.status === "failed") {
          taskStorage.update(taskId, {
            status: "failed",
            error: result.error,
            completedAt: Date.now()
          })
          logger.error({
            event: "coze_async_task_failed",
            module,
            taskId,
            traceId: taskId,
            error: result.error,
            message: "任务执行失败"
          })
          break
        } else if (result.status === "running" && task.status === "pending") {
          taskStorage.update(taskId, {
            status: "running",
            startedAt: Date.now()
          })
          logger.info({
            event: "coze_async_task_running",
            module,
            taskId,
            traceId: taskId,
            message: "任务开始执行"
          })
        }

        // 等待 30 秒后重试
        await sleep(30000)
        retryCount++
      } catch (error) {
        logger.error({
          event: "coze_async_task_poll_error",
          module,
          taskId,
          traceId: taskId,
          retryCount,
          message: "轮询任务状态失败",
          error: error instanceof Error ? error.message : String(error)
        })

        // 等待 30 秒后重试
        await sleep(30000)
        retryCount++
      }
    }

    if (retryCount >= maxRetries) {
      taskStorage.update(taskId, {
        status: "failed",
        error: "轮询超时（30分钟）",
        completedAt: Date.now()
      })
      logger.error({
        event: "coze_async_task_timeout",
        module,
        taskId,
        traceId: taskId,
        message: "任务轮询超时"
      })
    }
  }, 1000) // 1 秒后开始轮询
}

/**
 * 轮询 Coze 获取任务状态
 */
async function pollCozeTaskStatus(
  statusUrl: string,
  token: string,
  module: string,
  taskId: string
): Promise<{
  status: "pending" | "running" | "completed" | "failed"
  data?: unknown
  error?: string
}> {
  try {
    logger.info({
      event: "coze_async_task_polling_start",
      module,
      taskId,
      traceId: taskId,
      message: "开始轮询 Coze 任务状态",
      statusUrl,
      hasToken: !!token
    })

    const resp = await fetch(statusUrl, {
      method: "GET",
      headers: {
        authorization: `Bearer ${token}`
      }
    })

    if (!resp.ok) {
      throw new Error(`Coze 查询接口返回 ${resp.status}`)
    }

    // 先读取原始文本，再解析 JSON
    const responseText = await resp.text()
    const data = responseText ? JSON.parse(responseText) : null

    // 详细日志：输出完整的响应数据
    logger.info({
      event: "coze_async_task_polled",
      module,
      taskId,
      traceId: taskId,
      statusUrl,
      responseStatus: resp.status,
      rawData: responseText,
      parsedData: data,
      message: "轮询任务状态"
    })

    // 解析任务状态
    const status = parseCozeTaskStatus(data)

    return {
      status,
      data: data.result ?? data.data ?? data,
      error: data.error ?? data.message ?? data.errorMessage
    }
  } catch (error) {
    logger.error({
      event: "coze_async_task_query_failed",
      module,
      taskId,
      traceId: taskId,
      statusUrl,
      message: "Coze 查询接口调用失败",
      error: error instanceof Error ? error.message : String(error)
    })
    throw error
  }
}

/**
 * 解析 Coze 任务状态
 */
function parseCozeTaskStatus(data: unknown): "pending" | "running" | "completed" | "failed" {
  if (!data || typeof data !== "object") return "pending"
  const obj = data as Record<string, unknown>

  const status = obj.status ?? obj.state ?? obj.task_status

  if (typeof status === "string") {
    if (status === "completed" || status === "success" || status === "done") {
      return "completed"
    }
    if (status === "running" || status === "processing" || status === "in_progress") {
      return "running"
    }
    if (status === "failed" || status === "error") {
      return "failed"
    }
  }

  return "pending"
}

/**
 * 睡眠函数
 */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
