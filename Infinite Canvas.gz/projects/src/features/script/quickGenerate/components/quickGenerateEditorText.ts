/**
 * 统一 quick-generate 文本编辑区的纯文本标准化，确保上游返回的字面量 `\n`
 * 能在编辑器里按真实换行显示。
 */
export function normalizeQuickGenerateEditorText(input: unknown): string {
  return String(input ?? "")
    .replace(/\r\n/g, "\n")
    .replace(/\\r\\n/g, "\n")
    .replace(/\\n/g, "\n")
}
