import fs from "node:fs/promises"
import path from "node:path"

async function loadEnvFile(filePath) {
  try {
    const text = await fs.readFile(filePath, "utf8")
    for (const line of text.split(/\r?\n/)) {
      const s = line.trim()
      if (!s || s.startsWith("#")) continue
      const idx = s.indexOf("=")
      if (idx <= 0) continue
      const k = s.slice(0, idx).trim()
      let v = s.slice(idx + 1).trim()
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1)
      }
      if (process.env[k] == null) process.env[k] = v
    }
  } catch {}
}

async function main() {
  await loadEnvFile(path.join(process.cwd(), ".env.local"))
  await loadEnvFile(path.join(process.cwd(), ".env"))

  const url = process.env.QUICK_VIDEO_PROMPT_API_URL
  const token = process.env.QUICK_VIDEO_PROMPT_API_TOKEN || process.env.QUICK_SCRIPT_API_TOKEN

  console.log("URL:", url)
  console.log("Token length:", token?.length)

  const payload = {
    optimization_type: "outline",
    personal_prompt: null,
    shots: [
      {
        shot_no: 1,
        roles: ["机器人"],
        items: [],
        scenes: [],
        shot_text: "出租屋·夜·内景\n【镜头时长】6秒\n【画面风格】冷蓝灰调，低照度，写实压抑\n【镜头1｜极近特写】手机屏幕震动，裂痕明显。来电备注：杨慧珊\n【音效】震动声低频压迫\n【动作】高言手指悬停——按下。",
        fenjingban_prompt: ""
      }
    ]
  }

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${token}`
    },
    body: JSON.stringify(payload)
  })

  console.log("Status:", res.status)
  console.log("Content-Type:", res.headers.get("content-type"))
  const text = await res.text()
  console.log("Raw Response:")
  console.log(text)
}

main().catch(console.error)
