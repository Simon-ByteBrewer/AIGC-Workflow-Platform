import { NextRequest, NextResponse } from "next/server"
import { z } from "zod"
import { readEnv } from "@/features/coze/env"
import { callCozeRunEndpoint, CozeRunEndpointError } from "@/features/coze/runEndpointClient"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import { getSessionFromRequest } from "@/shared/session"
import { resolveVolcanoImageModelParamsForUser } from "@/server/domains/image/imageModelResolver"

const inputSchema = z.discriminatedUnion("image_type", [
  z.object({
    prompt: z.string().trim().max(60_000).optional(),
    image_type: z.literal("role"),
    style: z.string().trim().max(200).optional()
  }),
  z.object({
    prompt: z.string().trim().max(60_000).optional(),
    image_type: z.literal("makeup"),
    style: z.string().trim().max(200).optional(),
    front_image_url: z.string().trim().min(1).max(4000),
    hairstyle: z.string().trim().max(60_000).optional(),
    clothing: z.string().trim().max(60_000).optional(),
    tags: z.string().trim().max(200).optional()
  }),
  z.object({
    prompt: z.string().trim().max(60_000).optional(),
    image_type: z.literal("background"),
    style: z.string().trim().max(200).optional()
  }),
  z.object({
    prompt: z.string().trim().max(60_000).optional(),
    image_type: z.literal("item"),
    style: z.string().trim().max(200).optional()
  })
])

function extractImageUrls(data: unknown): string[] {
  const out: string[] = []
  const push = (s: unknown) => {
    if (typeof s !== "string") return
    const t = s.trim()
    if (!t) return
    if (!t.startsWith("http") && !t.startsWith("data:")) return
    out.push(t)
  }

  const visit = (v: unknown) => {
    if (!v) return
    if (typeof v === "string") return push(v)
    if (Array.isArray(v)) {
      for (const item of v) visit(item)
      return
    }
    if (typeof v === "object") {
      const obj = v as Record<string, unknown>
      if (Array.isArray(obj.image_urls)) {
        for (const u of obj.image_urls) push(u)
      }
      if (obj.url) push(obj.url)
      if (obj.image) push(obj.image)
      if (obj.image_url) push(obj.image_url)
      if (typeof obj.data === "object") visit(obj.data)
      return
    }
  }

  visit(data)
  return Array.from(new Set(out)).slice(0, 1)
}

function extractFirstImageUrl(data: unknown): string {
  return extractImageUrls(data)[0] ?? ""
}

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let json: unknown
  try {
    json = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "COZE_INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }

  const parsed = inputSchema.safeParse(json)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "COZE_VALIDATION_FAILED", "入参格式不正确"), { status: 400 })

  const url = readEnv("SHORT_DRAMA_CHARACTER_LOOKS_API_URL") || readEnv("SHORT_DRAMA_PLANNING_API_URL")
  const token = readEnv("SHORT_DRAMA_CHARACTER_LOOKS_API_TOKEN") || readEnv("SHORT_DRAMA_PLANNING_API_TOKEN")
  if (!url || !token) {
    return NextResponse.json(makeApiErr(traceId, "COZE_NOT_CONFIGURED", "Coze 未配置，请设置 SHORT_DRAMA_CHARACTER_LOOKS_API_URL 与 SHORT_DRAMA_CHARACTER_LOOKS_API_TOKEN"), {
      status: 500
    })
  }

  try {
    const volcanoParams = await resolveVolcanoImageModelParamsForUser(userId)
    const prompt = typeof (parsed.data as any).prompt === "string" ? (parsed.data as any).prompt : ""
    const coze = await callCozeRunEndpoint({
      traceId,
      url,
      token,
      body: {
        prompt,
        image_type: parsed.data.image_type,
        style: parsed.data.style ?? "写实",
        volcano_ark_api_key: volcanoParams.volcanoArkApiKey,
        volcano_ark_model_ep: volcanoParams.volcanoArkModelEp,
        ...((parsed.data as any).image_type === "makeup"
          ? {
              front_image_url: (parsed.data as any).front_image_url,
              hairstyle: (parsed.data as any).hairstyle ?? "",
              clothing: (parsed.data as any).clothing ?? "",
              tags: (parsed.data as any).tags ?? ""
            }
          : {})
      },
      module: "coze_short_drama_image_draw"
    })

    const urls = extractImageUrls(coze.data)
    const one = extractFirstImageUrl(coze.data)
    const durationMs = Date.now() - start
    logger.info({
      event: "coze_short_drama_image_draw_success",
      module: "coze",
      traceId,
      message: "短剧抽卡生图成功",
      durationMs,
      count: urls.length
    })

    return NextResponse.json(
      makeApiOk(traceId, {
        prompt,
        image_type: parsed.data.image_type,
        style: parsed.data.style ?? "写实",
        image_urls: urls,
        image_url: one,
        ...((parsed.data as any).image_type === "makeup"
          ? {
              hairstyle: (parsed.data as any).hairstyle ?? "",
              clothing: (parsed.data as any).clothing ?? "",
              tags: (parsed.data as any).tags ?? ""
            }
          : {})
      }),
      { status: 200 }
    )
  } catch (err) {
    const durationMs = Date.now() - start
    if (err instanceof CozeRunEndpointError) {
      logger.error({
        event: "coze_short_drama_image_draw_failed",
        module: "coze",
        traceId,
        message: "短剧抽卡生图失败（Coze 调用失败）",
        durationMs,
        status: err.status
      })
      return NextResponse.json(makeApiErr(traceId, "COZE_REQUEST_FAILED", "Coze 调用失败，请稍后重试"), { status: 502 })
    }

    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "coze_short_drama_image_draw_error",
      module: "coze",
      traceId,
      message: "短剧抽卡生图异常",
      durationMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "COZE_UNKNOWN", "生成失败，请稍后重试"), { status: 500 })
  }
}
