"use client"

import { useCallback, useEffect, useMemo, useState, type FormEvent, type ReactElement } from "react"
import type { AdminUserModelAccess } from "@/shared/contracts/adminUserModelAccess"
import { listExternalImageModelDefinitions } from "@/shared/image/externalImageModels"
import { listExternalVideoModelDefinitions } from "@/shared/video/externalVideoModels"
import { GroupModelAccessPanel } from "./GroupModelAccessPanel"
import { GroupAuditCapabilityConfigModal } from "./GroupAuditCapabilityConfigModal"
import { createEmptyModelRow, modelMapToRows, rowsToModelMap, type ApiKeyAction, type UserModelDraftGroups, type UserModelDraftRow } from "../users/userModelAccessForm"
import styles from "./GroupsPage.module.css"

type ApiOk<T> = { ok: true; data: T; traceId: string }
type ApiErr = { ok: false; error: { code: string; message: string }; traceId: string }

type GroupItem = {
  id: string
  name: string
  code: string | null
  isActive: boolean
  createdAt: string
  updatedAt: string
}

type ListResult = ApiOk<{ items: GroupItem[] }> | ApiErr
type CreateResult = ApiOk<{ group: { id: string; name: string; code: string | null } }> | ApiErr
type GroupModelAccessResult = ApiOk<{ group: { id: string; name: string; code: string | null; isActive: boolean }; modelAccess: AdminUserModelAccess }> | ApiErr
type ExternalImageModelItem = { modelName: string; label: string; enabled: boolean; apiKeyConfigured: boolean; apiKeyMasked: string | null }
type ExternalImageModelsResult = ApiOk<{ items: ExternalImageModelItem[] }> | ApiErr
type ExternalVideoModelItem = { modelName: string; label: string; enabled: boolean; apiKeyConfigured: boolean; apiKeyMasked: string | null }
type ExternalVideoModelsResult = ApiOk<{ items: ExternalVideoModelItem[] }> | ApiErr
type PromptPresetItem = { id: string; name: string; content: string }
type PromptPresetListResult = ApiOk<{ items: PromptPresetItem[] }> | ApiErr
type GroupPromptConfigResult = ApiOk<{
  group: { id: string; name: string }
  config: { groupId: string; storyboardPromptPresetIds: string[]; videoPromptPresetIds: string[] }
  promptPresets?: PromptPresetItem[]
}> | ApiErr
type GroupAuditCapabilityConfigResult = ApiOk<{
  group: { id: string; name: string }
  config: { groupId: string; accessKey: string; projectName: string; secretKeyConfigured: boolean } | null
}> | ApiErr

function fmtTime(v: string | null): string {
  if (!v) return "-"
  const d = new Date(v)
  if (!Number.isFinite(d.getTime())) return v
  return d.toLocaleString()
}

function makeLocalDraftId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID()
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`
}

function toggleSelectedId(current: string[], value: string, checked: boolean): string[] {
  const normalized = String(value ?? "").trim()
  if (!normalized) return current
  if (checked) return current.includes(normalized) ? current : [...current, normalized]
  return current.filter((item) => item !== normalized)
}

async function readApiJson<T>(res: Response, fallbackMessage: string): Promise<T> {
  const raw = await res.text()
  if (!raw.trim()) {
    throw new Error(`${fallbackMessage}：接口返回为空`)
  }
  try {
    return JSON.parse(raw) as T
  } catch {
    const contentType = (res.headers.get("content-type") ?? "").toLowerCase()
    const trimmed = raw.trim().toLowerCase()
    const isHtmlResponse = contentType.includes("text/html") || trimmed.startsWith("<!doctype html") || trimmed.startsWith("<html")
    if (res.status === 404 && isHtmlResponse) {
      throw new Error(`${fallbackMessage}：接口未命中当前运行服务的路由 (HTTP 404)，请重启 Next 开发服务或确认当前部署版本已包含该管理接口`)
    }
    throw new Error(`${fallbackMessage}：接口返回了非预期的格式 (HTTP ${res.status})`)
  }
}

export function GroupsPage(): ReactElement {
  const externalImageEnabled = process.env.NEXT_PUBLIC_EXTERNAL_IMAGE_MODEL_ENABLED === "1"
  const externalVideoEnabled = process.env.NEXT_PUBLIC_EXTERNAL_VIDEO_MODEL_ENABLED === "1"
  const externalImageModelOptions = useMemo(() => listExternalImageModelDefinitions(), [])
  const externalVideoModelOptions = useMemo(() => listExternalVideoModelDefinitions(), [])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [items, setItems] = useState<GroupItem[]>([])

  const [createOpen, setCreateOpen] = useState(false)
  const [creating, setCreating] = useState(false)
  const [nameDraft, setNameDraft] = useState("")
  const [codeDraft, setCodeDraft] = useState("")
  const [configGroup, setConfigGroup] = useState<GroupItem | null>(null)
  const [configLoading, setConfigLoading] = useState(false)
  const [configSaving, setConfigSaving] = useState(false)
  const [apiKeyDraft, setApiKeyDraft] = useState("")
  const [apiKeyAction, setApiKeyAction] = useState<ApiKeyAction>("unchanged")
  const [apiKeyConfigured, setApiKeyConfigured] = useState(false)
  const [apiKeyMasked, setApiKeyMasked] = useState<string | null>(null)
  const [modelRows, setModelRows] = useState<UserModelDraftGroups>({ video: [], language: [], image: [] })

  const [externalImageItems, setExternalImageItems] = useState<ExternalImageModelItem[]>([])
  const [externalImageOpen, setExternalImageOpen] = useState(false)
  const [externalImageDraftModelName, setExternalImageDraftModelName] = useState("")
  const [externalImageDraftApiKey, setExternalImageDraftApiKey] = useState("")
  const [externalImageSaving, setExternalImageSaving] = useState(false)
  const [externalVideoItems, setExternalVideoItems] = useState<ExternalVideoModelItem[]>([])
  const [externalVideoOpen, setExternalVideoOpen] = useState(false)
  const [externalVideoDraftModelName, setExternalVideoDraftModelName] = useState("")
  const [externalVideoDraftApiKey, setExternalVideoDraftApiKey] = useState("")
  const [externalVideoSaving, setExternalVideoSaving] = useState(false)
  const [promptPresetOpen, setPromptPresetOpen] = useState(false)
  const [promptPresetLoading, setPromptPresetLoading] = useState(false)
  const [promptPresetSaving, setPromptPresetSaving] = useState(false)
  const [promptPresetItems, setPromptPresetItems] = useState<Array<{ localId: string; id?: string; name: string; content: string }>>([])
  const [promptConfigGroup, setPromptConfigGroup] = useState<GroupItem | null>(null)
  const [promptConfigLoading, setPromptConfigLoading] = useState(false)
  const [promptConfigSaving, setPromptConfigSaving] = useState(false)
  const [storyboardPromptPresetIds, setStoryboardPromptPresetIds] = useState<string[]>([])
  const [videoPromptPresetIds, setVideoPromptPresetIds] = useState<string[]>([])
  const [promptConfigOptions, setPromptConfigOptions] = useState<PromptPresetItem[]>([])
  const [auditConfigGroup, setAuditConfigGroup] = useState<GroupItem | null>(null)
  const [auditConfigLoading, setAuditConfigLoading] = useState(false)
  const [auditConfigSaving, setAuditConfigSaving] = useState(false)
  const [auditAccessKeyDraft, setAuditAccessKeyDraft] = useState("")
  const [auditSecretKeyDraft, setAuditSecretKeyDraft] = useState("")
  const [auditProjectNameDraft, setAuditProjectNameDraft] = useState("")
  const [auditSecretKeyConfigured, setAuditSecretKeyConfigured] = useState(false)

  const title = useMemo(() => `用户组管理（${items.length}）`, [items.length])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/admin/groups", { method: "GET" })
      const json = await readApiJson<ListResult>(res, "加载组列表失败")
      if (!json.ok) throw new Error(json.error.message)
      setItems(json.data.items ?? [])
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载失败")
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    void load()
  }, [load])

  const updateModelRow = useCallback((type: keyof UserModelDraftGroups, rowId: string, patch: Partial<UserModelDraftRow>) => {
    setModelRows((current) => ({
      ...current,
      [type]: current[type].map((row) => (row.id === rowId ? { ...row, ...patch } : row))
    }))
  }, [])

  const addModelRow = useCallback((type: keyof UserModelDraftGroups) => {
    setModelRows((current) => ({
      ...current,
      [type]: [...current[type], createEmptyModelRow()]
    }))
  }, [])

  const removeModelRow = useCallback((type: keyof UserModelDraftGroups, rowId: string) => {
    setModelRows((current) => ({
      ...current,
      [type]: current[type].filter((row) => row.id !== rowId)
    }))
  }, [])

  const openConfig = useCallback(async (group: GroupItem) => {
    setConfigGroup(group)
    setConfigLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(group.id)}/model-access`, { method: "GET" })
      const json = await readApiJson<GroupModelAccessResult>(res, "加载模型配置失败")
      if (!json.ok) throw new Error(json.error.message)
      setApiKeyDraft("")
      setApiKeyAction("unchanged")
      setApiKeyConfigured(json.data.modelAccess.apiKeyConfigured)
      setApiKeyMasked(json.data.modelAccess.apiKeyMasked)
      setModelRows({
        video: modelMapToRows(json.data.modelAccess.videoModels),
        language: modelMapToRows(json.data.modelAccess.languageModels),
        image: modelMapToRows(json.data.modelAccess.imageModels)
      })

      if (externalImageEnabled) {
        const exRes = await fetch(`/api/admin/groups/${encodeURIComponent(group.id)}/external-image-models`, { method: "GET" })
        const exJson = await readApiJson<ExternalImageModelsResult>(exRes, "加载外部图片模型失败")
        if (exJson.ok) setExternalImageItems(exJson.data.items ?? [])
        else setExternalImageItems([])
      } else {
        setExternalImageItems([])
      }

      if (externalVideoEnabled) {
        const exVideoRes = await fetch(`/api/admin/groups/${encodeURIComponent(group.id)}/external-video-models`, { method: "GET" })
        const exVideoJson = await readApiJson<ExternalVideoModelsResult>(exVideoRes, "加载外部视频模型失败")
        if (exVideoJson.ok) setExternalVideoItems(exVideoJson.data.items ?? [])
        else setExternalVideoItems([])
      } else {
        setExternalVideoItems([])
      }
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载模型配置失败")
      setConfigGroup(null)
    } finally {
      setConfigLoading(false)
    }
  }, [externalImageEnabled, externalVideoEnabled])

  const reloadExternalImage = useCallback(async () => {
    if (!externalImageEnabled || !configGroup) return
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-image-models`, { method: "GET" })
      const json = await readApiJson<ExternalImageModelsResult>(res, "加载外部图片模型失败")
      if (json.ok) setExternalImageItems(json.data.items ?? [])
    } catch {}
  }, [configGroup, externalImageEnabled])

  const reloadExternalVideo = useCallback(async () => {
    if (!externalVideoEnabled || !configGroup) return
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-video-models`, { method: "GET" })
      const json = await readApiJson<ExternalVideoModelsResult>(res, "加载外部视频模型失败")
      if (json.ok) setExternalVideoItems(json.data.items ?? [])
    } catch {}
  }, [configGroup, externalVideoEnabled])

  const onCreateExternalImage = useCallback(async () => {
    if (!configGroup || !externalImageEnabled || externalImageSaving) return
    setExternalImageSaving(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-image-models`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ modelName: externalImageDraftModelName.trim(), apiKey: externalImageDraftApiKey.trim(), enabled: true })
      })
      const json = (await res.json()) as ApiOk<any> | ApiErr
      if (!json.ok) throw new Error(json.error.message)
      setExternalImageOpen(false)
      setExternalImageDraftModelName("")
      setExternalImageDraftApiKey("")
      await reloadExternalImage()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "新增外部图片模型失败")
    } finally {
      setExternalImageSaving(false)
    }
  }, [configGroup, externalImageDraftApiKey, externalImageDraftModelName, externalImageEnabled, externalImageSaving, reloadExternalImage])

  const onCreateExternalVideo = useCallback(async () => {
    if (!configGroup || !externalVideoEnabled || externalVideoSaving) return
    setExternalVideoSaving(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-video-models`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ modelName: externalVideoDraftModelName.trim(), apiKey: externalVideoDraftApiKey.trim(), enabled: true })
      })
      const json = (await res.json()) as ApiOk<any> | ApiErr
      if (!json.ok) throw new Error(json.error.message)
      setExternalVideoOpen(false)
      setExternalVideoDraftModelName("")
      setExternalVideoDraftApiKey("")
      await reloadExternalVideo()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "新增外部视频模型失败")
    } finally {
      setExternalVideoSaving(false)
    }
  }, [configGroup, externalVideoDraftApiKey, externalVideoDraftModelName, externalVideoEnabled, externalVideoSaving, reloadExternalVideo])

  const onToggleExternalImage = useCallback(
    async (modelName: string, enabled: boolean) => {
      if (!configGroup || !externalImageEnabled) return
      try {
        const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-image-models`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ modelName, enabled })
        })
        const json = (await res.json()) as ApiOk<any> | ApiErr
        if (!json.ok) throw new Error(json.error.message)
        await reloadExternalImage()
      } catch (e) {
        const anyErr = e as { message?: string }
        setError(anyErr?.message ?? "更新外部图片模型失败")
      }
    },
    [configGroup, externalImageEnabled, reloadExternalImage]
  )

  const onToggleExternalVideo = useCallback(
    async (modelName: string, enabled: boolean) => {
      if (!configGroup || !externalVideoEnabled) return
      try {
        const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-video-models`, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ modelName, enabled })
        })
        const json = (await res.json()) as ApiOk<any> | ApiErr
        if (!json.ok) throw new Error(json.error.message)
        await reloadExternalVideo()
      } catch (e) {
        const anyErr = e as { message?: string }
        setError(anyErr?.message ?? "更新外部视频模型失败")
      }
    },
    [configGroup, externalVideoEnabled, reloadExternalVideo]
  )

  const onDeleteExternalImage = useCallback(
    async (modelName: string) => {
      if (!configGroup || !externalImageEnabled) return
      try {
        const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-image-models`, {
          method: "DELETE",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ modelName })
        })
        const json = (await res.json()) as ApiOk<any> | ApiErr
        if (!json.ok) throw new Error(json.error.message)
        await reloadExternalImage()
      } catch (e) {
        const anyErr = e as { message?: string }
        setError(anyErr?.message ?? "删除外部图片模型失败")
      }
    },
    [configGroup, externalImageEnabled, reloadExternalImage]
  )

  const onDeleteExternalVideo = useCallback(
    async (modelName: string) => {
      if (!configGroup || !externalVideoEnabled) return
      try {
        const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/external-video-models`, {
          method: "DELETE",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ modelName })
        })
        const json = (await res.json()) as ApiOk<any> | ApiErr
        if (!json.ok) throw new Error(json.error.message)
        await reloadExternalVideo()
      } catch (e) {
        const anyErr = e as { message?: string }
        setError(anyErr?.message ?? "删除外部视频模型失败")
      }
    },
    [configGroup, externalVideoEnabled, reloadExternalVideo]
  )

  const onSaveConfig = useCallback(async () => {
    if (!configGroup || configSaving) return
    setConfigSaving(true)
    setError(null)
    try {
      const payload: {
        apiKey?: string | null
        videoModels: AdminUserModelAccess["videoModels"]
        languageModels: AdminUserModelAccess["languageModels"]
        imageModels: AdminUserModelAccess["imageModels"]
      } = {
        videoModels: rowsToModelMap(modelRows.video),
        languageModels: rowsToModelMap(modelRows.language),
        imageModels: rowsToModelMap(modelRows.image)
      }

      if (apiKeyAction === "replace") payload.apiKey = apiKeyDraft.trim()
      else if (apiKeyAction === "clear") payload.apiKey = null

      const res = await fetch(`/api/admin/groups/${encodeURIComponent(configGroup.id)}/model-access`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      })
      const json = await readApiJson<GroupModelAccessResult>(res, "保存模型配置失败")
      if (!json.ok) throw new Error(json.error.message)
      setApiKeyConfigured(json.data.modelAccess.apiKeyConfigured)
      setApiKeyMasked(json.data.modelAccess.apiKeyMasked)
      setApiKeyDraft("")
      setApiKeyAction("unchanged")
      setConfigGroup(null)
      await load()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "保存模型配置失败")
    } finally {
      setConfigSaving(false)
    }
  }, [apiKeyAction, apiKeyDraft, configGroup, configSaving, load, modelRows.image, modelRows.language, modelRows.video])

  const onCreate = useCallback(
    async (e: FormEvent) => {
      e.preventDefault()
      if (creating) return
      setCreating(true)
      setError(null)
      try {
        const res = await fetch("/api/admin/groups", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ name: nameDraft.trim(), code: codeDraft.trim() || undefined })
        })
        const json = (await res.json()) as CreateResult
        if (!json.ok) throw new Error(json.error.message)
        setCreateOpen(false)
        setNameDraft("")
        setCodeDraft("")
        await load()
      } catch (e2) {
        const anyErr = e2 as { message?: string }
        setError(anyErr?.message ?? "创建失败")
      } finally {
        setCreating(false)
      }
    },
    [codeDraft, creating, load, nameDraft]
  )

  const openPromptPresetModal = useCallback(async () => {
    window.location.href = "/admin/prompts"
  }, [])

  const addPromptPresetDraft = useCallback(() => {
    setPromptPresetItems((current) => [...current, { localId: makeLocalDraftId(), name: "", content: "" }])
  }, [])

  const updatePromptPresetDraft = useCallback((localId: string, patch: Partial<{ name: string; content: string }>) => {
    setPromptPresetItems((current) => current.map((item) => (item.localId === localId ? { ...item, ...patch } : item)))
  }, [])

  const removePromptPresetDraft = useCallback((localId: string) => {
    setPromptPresetItems((current) => current.filter((item) => item.localId !== localId))
  }, [])

  const savePromptPresets = useCallback(async () => {
    if (promptPresetSaving) return
    setPromptPresetSaving(true)
    setError(null)
    try {
      const items = promptPresetItems
        .map((item) => ({
          ...(item.id ? { id: item.id } : {}),
          name: item.name.trim(),
          content: item.content.trim()
        }))
        .filter((item) => item.name && item.content)
      const res = await fetch("/api/admin/prompt-presets", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ items })
      })
      const json = await readApiJson<PromptPresetListResult>(res, "保存自定义提示词失败")
      if (!json.ok) throw new Error(json.error.message)
      setPromptPresetItems(
        (json.data.items ?? []).map((item) => ({
          localId: item.id || makeLocalDraftId(),
          id: item.id,
          name: item.name,
          content: item.content
        }))
      )
      setPromptPresetOpen(false)
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "保存自定义提示词失败")
    } finally {
      setPromptPresetSaving(false)
    }
  }, [promptPresetItems, promptPresetSaving])

  const openPromptConfig = useCallback(async (group: GroupItem) => {
    void group
    window.location.href = "/admin/prompts"
  }, [])

  const savePromptConfig = useCallback(async () => {
    if (!promptConfigGroup || promptConfigSaving) return
    setPromptConfigSaving(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(promptConfigGroup.id)}/prompt-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          storyboardPromptPresetIds,
          videoPromptPresetIds
        })
      })
      const json = await readApiJson<GroupPromptConfigResult>(res, "保存提示词配置失败")
      if (!json.ok) throw new Error(json.error.message)
      setStoryboardPromptPresetIds(Array.isArray(json.data.config.storyboardPromptPresetIds) ? json.data.config.storyboardPromptPresetIds : [])
      setVideoPromptPresetIds(Array.isArray(json.data.config.videoPromptPresetIds) ? json.data.config.videoPromptPresetIds : [])
      setPromptConfigGroup(null)
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "保存提示词配置失败")
    } finally {
      setPromptConfigSaving(false)
    }
  }, [promptConfigGroup, promptConfigSaving, storyboardPromptPresetIds, videoPromptPresetIds])

  const openAuditConfig = useCallback(async (group: GroupItem) => {
    setAuditConfigGroup(group)
    setAuditConfigLoading(true)
    setError(null)
    try {
      const res = await fetch(`/api/admin/groups/${encodeURIComponent(group.id)}/audit-capability-config`, { method: "GET" })
      const json = await readApiJson<GroupAuditCapabilityConfigResult>(res, "加载审核能力配置失败")
      if (!json.ok) throw new Error(json.error.message)
      setAuditAccessKeyDraft(json.data.config?.accessKey ?? "")
      setAuditProjectNameDraft(json.data.config?.projectName ?? "")
      setAuditSecretKeyDraft("")
      setAuditSecretKeyConfigured(Boolean(json.data.config?.secretKeyConfigured))
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载审核能力配置失败")
      setAuditConfigGroup(null)
    } finally {
      setAuditConfigLoading(false)
    }
  }, [])

  const saveAuditConfig = useCallback(async () => {
    if (!auditConfigGroup || auditConfigSaving) return
    if (!auditAccessKeyDraft.trim()) {
      setError("请填写 AK")
      return
    }
    if (!auditProjectNameDraft.trim()) {
      setError("请填写项目名称")
      return
    }
    if (!auditSecretKeyConfigured && !auditSecretKeyDraft.trim()) {
      setError("请填写 SK")
      return
    }

    setAuditConfigSaving(true)
    setError(null)
    try {
      const payload: { accessKey: string; projectName: string; secretKey?: string } = {
        accessKey: auditAccessKeyDraft.trim(),
        projectName: auditProjectNameDraft.trim()
      }
      if (auditSecretKeyDraft.trim()) payload.secretKey = auditSecretKeyDraft.trim()

      const res = await fetch(`/api/admin/groups/${encodeURIComponent(auditConfigGroup.id)}/audit-capability-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload)
      })
      const json = await readApiJson<GroupAuditCapabilityConfigResult>(res, "保存审核能力配置失败")
      if (!json.ok) throw new Error(json.error.message)
      setAuditAccessKeyDraft(json.data.config?.accessKey ?? "")
      setAuditProjectNameDraft(json.data.config?.projectName ?? "")
      setAuditSecretKeyDraft("")
      setAuditSecretKeyConfigured(Boolean(json.data.config?.secretKeyConfigured))
      setAuditConfigGroup(null)
      await load()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "保存审核能力配置失败")
    } finally {
      setAuditConfigSaving(false)
    }
  }, [
    auditAccessKeyDraft,
    auditConfigGroup,
    auditConfigSaving,
    auditProjectNameDraft,
    auditSecretKeyConfigured,
    auditSecretKeyDraft,
    load
  ])

  return (
    <main className={styles.page}>
      <div className={styles.topBar}>
        <div className={styles.topTitle}>{title}</div>
        <div className={styles.topActions}>
          <button type="button" className={styles.topBtn} onClick={() => void load()} disabled={loading || creating}>
            刷新
          </button>
          <button type="button" className={styles.topBtn} onClick={() => void openPromptPresetModal()} disabled={loading || creating}>
            前往提示词管理
          </button>
          <button type="button" className={styles.topBtnPrimary} onClick={() => setCreateOpen(true)} disabled={loading || creating}>
            新建用户组
          </button>
        </div>
      </div>

      {error ? <div className={styles.error}>{error}</div> : null}

      <section className={styles.panel} aria-label="用户组列表">
        <div className={styles.table}>
          <div className={`${styles.tr} ${styles.th}`}>
            <div>名称</div>
            <div>编码</div>
            <div>状态</div>
            <div>创建时间</div>
            <div>更新时间</div>
          </div>
          {items.map((g) => (
            <div key={g.id} className={`${styles.tr} ${styles.row}`}>
              <div>{g.name}</div>
              <div className={`${styles.mono} ${styles.muted}`}>{g.code ?? "-"}</div>
              <div className={g.isActive ? styles.ok : styles.bad}>{g.isActive ? "启用" : "禁用"}</div>
              <div className={styles.muted}>{fmtTime(g.createdAt)}</div>
              <div className={styles.rowActions}>
                <span className={styles.muted}>{fmtTime(g.updatedAt)}</span>
                <div className={styles.rowActionButtons}>
                  <button type="button" className={styles.topBtn} onClick={() => void openAuditConfig(g)} disabled={loading || creating}>
                    审核能力配置
                  </button>
                  <button type="button" className={styles.topBtn} onClick={() => void openPromptConfig(g)} disabled={loading || creating}>
                    前往提示词管理
                  </button>
                  <button type="button" className={styles.topBtnPrimary} onClick={() => void openConfig(g)} disabled={loading || creating}>
                    配置模型
                  </button>
                </div>
              </div>
            </div>
          ))}
          {items.length === 0 && !loading ? <div className={styles.muted}>暂无用户组</div> : null}
        </div>
      </section>

      {createOpen ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="新建用户组" onMouseDown={() => setCreateOpen(false)}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>新建用户组</div>
              <button type="button" className={styles.modalClose} onClick={() => setCreateOpen(false)} aria-label="关闭">
                ×
              </button>
            </div>
            <form className={styles.modalBody} onSubmit={onCreate}>
              <label className={styles.field}>
                <div className={styles.label}>名称</div>
                <input className={styles.input} value={nameDraft} onChange={(e) => setNameDraft(e.target.value)} required />
              </label>
              <label className={styles.field}>
                <div className={styles.label}>编码（可选）</div>
                <input className={styles.input} value={codeDraft} onChange={(e) => setCodeDraft(e.target.value)} placeholder="用于稳定识别，例如 team_a" />
              </label>
              <div className={styles.modalActions}>
                <button type="button" className={styles.topBtn} onClick={() => setCreateOpen(false)} disabled={creating}>
                  取消
                </button>
                <button type="submit" className={styles.topBtnPrimary} disabled={creating || !nameDraft.trim()}>
                  {creating ? "创建中…" : "创建"}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : null}

      {promptPresetOpen ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="自定义提示词" onMouseDown={() => setPromptPresetOpen(false)}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>自定义提示词</div>
              <button type="button" className={styles.modalClose} onClick={() => setPromptPresetOpen(false)} aria-label="关闭">
                ×
              </button>
            </div>
            <div className={`${styles.modalBody} ${styles.scrollBody}`}>
              <div className={styles.groupHint}>维护全局提示词池。名称用于下拉展示，内容会在工作流中作为 `personal_prompt` 传入。</div>
              {promptPresetLoading ? <div className={styles.muted}>加载中…</div> : null}
              {!promptPresetLoading && promptPresetItems.length === 0 ? <div className={styles.muted}>暂无自定义提示词，点击下方新增一条。</div> : null}
              {!promptPresetLoading ? (
                <div className={styles.promptList}>
                  {promptPresetItems.map((item, index) => (
                    <div key={item.localId} className={styles.promptCard}>
                      <div className={styles.promptCardHeader}>
                        <div className={styles.promptCardTitle}>提示词 {index + 1}</div>
                        <button type="button" className={styles.topBtn} onClick={() => removePromptPresetDraft(item.localId)} disabled={promptPresetSaving}>
                          删除
                        </button>
                      </div>
                      <label className={styles.field}>
                        <div className={styles.label}>名称</div>
                        <input
                          className={styles.input}
                          value={item.name}
                          onChange={(e) => updatePromptPresetDraft(item.localId, { name: e.target.value })}
                          placeholder="例如：剧情强化版"
                        />
                      </label>
                      <label className={styles.field}>
                        <div className={styles.label}>内容</div>
                        <textarea
                          className={`${styles.input} ${styles.textarea}`}
                          value={item.content}
                          onChange={(e) => updatePromptPresetDraft(item.localId, { content: e.target.value })}
                          placeholder="输入这条自定义提示词的完整内容"
                        />
                      </label>
                    </div>
                  ))}
                </div>
              ) : null}
              <div className={styles.modalActions}>
                <button type="button" className={styles.topBtn} onClick={addPromptPresetDraft} disabled={promptPresetSaving || promptPresetLoading}>
                  新增一条
                </button>
                <button type="button" className={styles.topBtn} onClick={() => setPromptPresetOpen(false)} disabled={promptPresetSaving}>
                  取消
                </button>
                <button type="button" className={styles.topBtnPrimary} onClick={() => void savePromptPresets()} disabled={promptPresetSaving || promptPresetLoading}>
                  {promptPresetSaving ? "保存中…" : "保存全部"}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {configGroup ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="配置组模型" onMouseDown={() => setConfigGroup(null)}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>配置组模型：{configGroup.name}</div>
              <button type="button" className={styles.modalClose} onClick={() => setConfigGroup(null)} aria-label="关闭">
                ×
              </button>
            </div>
            <div className={`${styles.modalBody} ${styles.modalBodyWithFooter}`}>
              <div className={styles.modalScrollArea}>
                {configLoading ? (
                  <div className={styles.muted}>加载中…</div>
                ) : (
                  <GroupModelAccessPanel
                    apiKeyConfigured={apiKeyConfigured}
                    apiKeyMasked={apiKeyMasked}
                    apiKeyDraft={apiKeyDraft}
                    apiKeyAction={apiKeyAction}
                    modelRows={modelRows}
                    showExternalImageModelButton={externalImageEnabled}
                    onAddExternalImageModel={() => {
                      setExternalImageDraftModelName(externalImageModelOptions[0]?.code ?? "")
                      setExternalImageDraftApiKey("")
                      setExternalImageOpen(true)
                    }}
                    disabled={configSaving}
                    onApiKeyDraftChange={(value) => {
                      setApiKeyDraft(value)
                      setApiKeyAction(value.trim() ? "replace" : "unchanged")
                    }}
                    onClearApiKey={() => {
                      setApiKeyDraft("")
                      setApiKeyAction("clear")
                    }}
                    onUndoClearApiKey={() => {
                      setApiKeyDraft("")
                      setApiKeyAction("unchanged")
                    }}
                    onAddRow={addModelRow}
                    onRemoveRow={removeModelRow}
                    onUpdateRow={updateModelRow}
                  />
                )}

                {externalImageEnabled ? (
                  <div className={styles.panel} aria-label="外部图片模型">
                    <div className={styles.groupHint}>外部图片模型（组级）：模型名 + key。key 不会回显明文。</div>
                    {externalImageItems.length === 0 ? <div className={styles.muted}>暂无外部图片模型</div> : null}
                    {externalImageItems.map((item) => (
                      <div key={item.modelName} className={styles.modelRow}>
                        <div className={styles.muted}>{item.label}</div>
                        <div className={styles.muted}>{item.apiKeyMasked ? `Key: ${item.apiKeyMasked}` : item.apiKeyConfigured ? "Key: 已配置" : "Key: 未配置"}</div>
                        <label className={styles.switchLabel}>
                          <input type="checkbox" checked={item.enabled} onChange={(e) => void onToggleExternalImage(item.modelName, e.target.checked)} />
                          <span>{item.enabled ? "启用" : "禁用"}</span>
                        </label>
                        <button type="button" className={styles.topBtn} onClick={() => void onDeleteExternalImage(item.modelName)}>
                          删除
                        </button>
                      </div>
                    ))}
                  </div>
                ) : null}

                {externalVideoEnabled ? (
                  <div className={styles.panel} aria-label="外部视频模型">
                    <div className={styles.groupHint}>外部视频模型（组级）：模型名 + key。key 不会回显明文。</div>
                    <div className={styles.modalActions}>
                      <button
                        type="button"
                        className={styles.topBtnPrimary}
                        onClick={() => {
                          setExternalVideoDraftModelName(externalVideoModelOptions[0]?.code ?? "")
                          setExternalVideoDraftApiKey("")
                          setExternalVideoOpen(true)
                        }}
                        disabled={configSaving}
                      >
                        新增外部视频模型
                      </button>
                    </div>
                    {externalVideoItems.length === 0 ? <div className={styles.muted}>暂无外部视频模型</div> : null}
                    {externalVideoItems.map((item) => (
                      <div key={item.modelName} className={styles.modelRow}>
                        <div className={styles.muted}>{item.label}</div>
                        <div className={styles.muted}>{item.apiKeyMasked ? `Key: ${item.apiKeyMasked}` : item.apiKeyConfigured ? "Key: 已配置" : "Key: 未配置"}</div>
                        <label className={styles.switchLabel}>
                          <input type="checkbox" checked={item.enabled} onChange={(e) => void onToggleExternalVideo(item.modelName, e.target.checked)} />
                          <span>{item.enabled ? "启用" : "禁用"}</span>
                        </label>
                        <button type="button" className={styles.topBtn} onClick={() => void onDeleteExternalVideo(item.modelName)}>
                          删除
                        </button>
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>

              <div className={`${styles.modalActions} ${styles.modalFooterActions}`}>
                <button type="button" className={styles.topBtn} onClick={() => setConfigGroup(null)} disabled={configSaving}>
                  取消
                </button>
                <button type="button" className={styles.topBtnPrimary} onClick={() => void onSaveConfig()} disabled={configSaving || configLoading}>
                  {configSaving ? "保存中…" : "保存并关闭"}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {promptConfigGroup ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="配置组提示词" onMouseDown={() => setPromptConfigGroup(null)}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>提示词配置：{promptConfigGroup.name}</div>
              <button type="button" className={styles.modalClose} onClick={() => setPromptConfigGroup(null)} aria-label="关闭">
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              <div className={styles.groupHint}>这里为当前用户组分别绑定“拆分镜提示词”和“视频提示词”。账号侧只会看到默认提示词和这里配置的可用项。</div>
              {promptConfigLoading ? (
                <div className={styles.muted}>加载中…</div>
              ) : (
                <>
                  <div className={styles.field}>
                    <div className={styles.label}>拆分镜提示词</div>
                    <div className={styles.promptCheckList}>
                      {promptConfigOptions.length === 0 ? <div className={styles.muted}>暂无可选提示词，请先到“自定义提示词”中新增。</div> : null}
                      {promptConfigOptions.map((item) => (
                        <label key={`storyboard-${item.id}`} className={styles.promptCheckItem}>
                          <input
                            type="checkbox"
                            checked={storyboardPromptPresetIds.includes(item.id)}
                            onChange={(e) => setStoryboardPromptPresetIds((current) => toggleSelectedId(current, item.id, e.target.checked))}
                          />
                          <span>{item.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className={styles.field}>
                    <div className={styles.label}>视频提示词</div>
                    <div className={styles.promptCheckList}>
                      {promptConfigOptions.length === 0 ? <div className={styles.muted}>暂无可选提示词，请先到“自定义提示词”中新增。</div> : null}
                      {promptConfigOptions.map((item) => (
                        <label key={`video-${item.id}`} className={styles.promptCheckItem}>
                          <input
                            type="checkbox"
                            checked={videoPromptPresetIds.includes(item.id)}
                            onChange={(e) => setVideoPromptPresetIds((current) => toggleSelectedId(current, item.id, e.target.checked))}
                          />
                          <span>{item.name}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </>
              )}
              <div className={styles.modalActions}>
                <button type="button" className={styles.topBtn} onClick={() => setPromptConfigGroup(null)} disabled={promptConfigSaving}>
                  取消
                </button>
                <button type="button" className={styles.topBtnPrimary} onClick={() => void savePromptConfig()} disabled={promptConfigSaving || promptConfigLoading}>
                  {promptConfigSaving ? "保存中…" : "保存"}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {auditConfigGroup ? (
        <GroupAuditCapabilityConfigModal
          groupName={auditConfigGroup.name}
          loading={auditConfigLoading}
          saving={auditConfigSaving}
          accessKeyDraft={auditAccessKeyDraft}
          secretKeyDraft={auditSecretKeyDraft}
          projectNameDraft={auditProjectNameDraft}
          secretKeyConfigured={auditSecretKeyConfigured}
          onAccessKeyChange={setAuditAccessKeyDraft}
          onSecretKeyChange={setAuditSecretKeyDraft}
          onProjectNameChange={setAuditProjectNameDraft}
          onClose={() => {
            if (auditConfigSaving) return
            setAuditConfigGroup(null)
          }}
          onSave={() => void saveAuditConfig()}
        />
      ) : null}

      {externalImageOpen ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="新增外部模型接入" onMouseDown={() => setExternalImageOpen(false)}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>新增外部模型接入（图片模型）</div>
              <button type="button" className={styles.modalClose} onClick={() => setExternalImageOpen(false)} aria-label="关闭">
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              <label className={styles.field}>
                <div className={styles.label}>模型名称</div>
                <select className={styles.select} value={externalImageDraftModelName} onChange={(e) => setExternalImageDraftModelName(e.target.value)}>
                  {externalImageModelOptions.map((item) => (
                    <option key={item.code} value={item.code}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className={styles.field}>
                <div className={styles.label}>Key</div>
                <input className={styles.input} value={externalImageDraftApiKey} onChange={(e) => setExternalImageDraftApiKey(e.target.value)} placeholder="输入外部图片模型 key（不会回显明文）" />
              </label>
              <div className={styles.modalActions}>
                <button type="button" className={styles.topBtn} onClick={() => setExternalImageOpen(false)} disabled={externalImageSaving}>
                  取消
                </button>
                <button
                  type="button"
                  className={styles.topBtnPrimary}
                  onClick={() => void onCreateExternalImage()}
                  disabled={externalImageSaving || !externalImageDraftModelName.trim() || !externalImageDraftApiKey.trim()}
                >
                  {externalImageSaving ? "保存中…" : "保存"}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {externalVideoOpen ? (
        <div className={styles.overlay} role="dialog" aria-modal="true" aria-label="新增外部视频模型接入" onMouseDown={() => setExternalVideoOpen(false)}>
          <div className={styles.modal} onMouseDown={(e) => e.stopPropagation()}>
            <div className={styles.modalHeader}>
              <div className={styles.modalTitle}>新增外部模型接入（视频模型）</div>
              <button type="button" className={styles.modalClose} onClick={() => setExternalVideoOpen(false)} aria-label="关闭">
                ×
              </button>
            </div>
            <div className={styles.modalBody}>
              <label className={styles.field}>
                <div className={styles.label}>模型名称</div>
                <select className={styles.select} value={externalVideoDraftModelName} onChange={(e) => setExternalVideoDraftModelName(e.target.value)}>
                  {externalVideoModelOptions.map((item) => (
                    <option key={item.code} value={item.code}>
                      {item.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className={styles.field}>
                <div className={styles.label}>Key</div>
                <input className={styles.input} value={externalVideoDraftApiKey} onChange={(e) => setExternalVideoDraftApiKey(e.target.value)} placeholder="输入外部视频模型 key（不会回显明文）" />
              </label>
              <div className={styles.modalActions}>
                <button type="button" className={styles.topBtn} onClick={() => setExternalVideoOpen(false)} disabled={externalVideoSaving}>
                  取消
                </button>
                <button
                  type="button"
                  className={styles.topBtnPrimary}
                  onClick={() => void onCreateExternalVideo()}
                  disabled={externalVideoSaving || !externalVideoDraftModelName.trim() || !externalVideoDraftApiKey.trim()}
                >
                  {externalVideoSaving ? "保存中…" : "保存"}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </main>
  )
}
