import { asc, eq } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { notFound, redirect } from "next/navigation"
import type { ReactElement } from "react"
import { ScriptWorkspacePage } from "@/features/script/workspace/ScriptWorkspacePage"
import { stories, storyOutlines } from "@/shared/schema"
import { hydrateShortDramaScriptBodyIfNeeded } from "@/server/shared/story/shortDramaScriptBodyStorage"

type ScriptWorkspaceStoryRouteProps = Readonly<{
  params:
    | Readonly<{
        storyId: string
      }>
    | Promise<
        Readonly<{
          storyId: string
        }>
      >
  searchParams?:
    | Readonly<{
        mode?: string | string[]
        outline?: string | string[]
        view?: string | string[]
      }>
    | Promise<
        Readonly<{
          mode?: string | string[]
          outline?: string | string[]
          view?: string | string[]
        }>
      >
}>

export const dynamic = "force-dynamic"

function isShortDramaReady(metadata: Record<string, unknown>): boolean {
  const shortDrama = (metadata as any)?.shortDrama
  if (!shortDrama || typeof shortDrama !== "object") return false
  const setupSource = typeof (shortDrama as any).setupSource === "string" ? (shortDrama as any).setupSource.trim() : ""
  const skipWorldSetting = setupSource === "script_body"
  if (!(shortDrama as any).planningResult) return false
  if (!skipWorldSetting && !(shortDrama as any).worldSetting) return false
  if (!(shortDrama as any).characterSetting) return false
  return true
}

export default async function ScriptWorkspaceStoryRoutePage({
  params,
  searchParams
}: ScriptWorkspaceStoryRouteProps): Promise<ReactElement> {
  const resolvedParams = await Promise.resolve(params)
  const resolvedSearchParams = await Promise.resolve(searchParams)

  const storyId = resolvedParams.storyId?.trim()
  if (!storyId) notFound()

  const modeValue = resolvedSearchParams?.mode
  const mode = Array.isArray(modeValue) ? modeValue[0] : modeValue

  const outlineValue = resolvedSearchParams?.outline
  const outline = Array.isArray(outlineValue) ? outlineValue[0] : outlineValue

  const viewValue = resolvedSearchParams?.view
  const view = Array.isArray(viewValue) ? viewValue[0] : viewValue

  const db = await getDb({ storyOutlines, stories })
  const storyRows = await db
    .select({ metadata: stories.metadata, videoCategory: stories.videoCategory })
    .from(stories)
    .where(eq(stories.id, storyId))
    .limit(1)
  const storyMetadataBase = (storyRows[0]?.metadata ?? {}) as Record<string, unknown>
  const storyMetadata = (await hydrateShortDramaScriptBodyIfNeeded({ metadata: storyMetadataBase })).metadata
  const storyVideoCategory = storyRows[0]?.videoCategory === "commentary" ? "commentary" : "premium"
  if (mode !== "source" && !isShortDramaReady(storyMetadata)) {
    const qs = new URLSearchParams()
    const next = `/script/workspace/${encodeURIComponent(storyId)}${outline ? `?mode=brief&outline=${encodeURIComponent(outline)}` : "?mode=brief"}`
    qs.set("next", next)
    redirect(`/script/short-drama/${encodeURIComponent(storyId)}?${qs.toString()}`)
  }
  const rows = await db
    .select()
    .from(storyOutlines)
    .where(eq(storyOutlines.storyId, storyId))
    .orderBy(asc(storyOutlines.sequence))

  if (mode !== "source" && isShortDramaReady(storyMetadata) && rows.length === 0) {
    const qs = new URLSearchParams()
    const next = `/script/workspace/${encodeURIComponent(storyId)}${outline ? `?mode=brief&outline=${encodeURIComponent(outline)}` : "?mode=brief"}`
    qs.set("next", next)
    redirect(`/script/short-drama/${encodeURIComponent(storyId)}?${qs.toString()}`)
  }

  const outlines = rows.map((row) => {
    return {
      outlineId: row.id,
      sequence: row.sequence,
      outlineText: row.outlineText,
      originalText: row.originalText,
      outlineDrafts: (row as any).outlineDrafts ?? [],
      activeOutlineDraftId: (row as any).activeOutlineDraftId ?? null
    }
  })

  return (
    <ScriptWorkspacePage
      mode={mode === "source" ? "source" : "brief"}
      storyId={storyId}
      outline={outline}
      view={view}
      outlines={outlines}
      storyMetadata={storyMetadata}
      videoCategory={storyVideoCategory}
    />
  )
}
