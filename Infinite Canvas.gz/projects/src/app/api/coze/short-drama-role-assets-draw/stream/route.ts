import { and, eq } from "drizzle-orm"
import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr } from "@/shared/api"
import { SHORT_DRAMA_ROLE_ASSET_DRAW_JOB_TYPE } from "@/shared/jobs/jobTypes"
import { getSessionFromRequest } from "@/shared/session"
import { stories } from "@/shared/schema"
import { getTraceId } from "@/shared/trace"
import { getDb } from "coze-coding-dev-sdk"
import { enqueueShortDramaRoleAssetDrawJob, kickShortDramaRoleAssetDrawWorker } from "@/server/domains/short-drama/jobs/shortDramaRoleAssetDrawWorker"
import { createStartedJobEventStreamResponse } from "@/server/framework/jobs/createStartedJobEventStreamResponse"
import { findActiveJobByStoryTypeAndSnapshotField } from "@/server/framework/jobs/jobDb"

export const runtime = "nodejs"

const bodySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  characterKey: z.string().trim().min(1).max(200),
  characterName: z.string().trim().min(1).max(200),
  frontImageUrl: z.string().trim().min(1).max(20_000_000),
  frontImageStorageKey: z.string().trim().min(1).max(1000).optional(),
  promptBase: z.string().trim().max(60_000),
  style: z.string().trim().max(200).optional(),
  append: z.boolean().optional(),
  requestKey: z.string().trim().min(1).max(200).optional(),
  publicCharacterId: z.string().trim().min(1).max(200).optional(),
  publicCharacterDescription: z.string().trim().max(60_000).optional(),
  items: z
    .array(
      z.object({
        kind: z.union([z.literal("look"), z.literal("costume")]),
        variantKey: z.string().trim().min(1).max(200),
        variantName: z.string().trim().min(1).max(200),
        text: z.string().trim().max(60_000),
        tagsText: z.string().trim().max(500).optional(),
        count: z.coerce.number().int().min(1).max(5)
      })
    )
    .min(1)
    .max(200)
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "INVALID_JSON", "请求体不是合法 JSON"), { status: 400 })
  }
  const parsed = bodySchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const db = await getDb({ stories })
  const allowed = await db
    .select({ id: stories.id })
    .from(stories)
    .where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId)))
    .limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const requestKey = parsed.data.requestKey?.trim() || parsed.data.characterKey
  return createStartedJobEventStreamResponse({
    req,
    traceId,
    userId,
    startJob: async () => {
      const existed = await findActiveJobByStoryTypeAndSnapshotField({
        userId,
        storyId: parsed.data.storyId,
        type: SHORT_DRAMA_ROLE_ASSET_DRAW_JOB_TYPE,
        field: "requestKey",
        value: requestKey
      })
      if (existed) {
        kickShortDramaRoleAssetDrawWorker()
        return { jobId: existed.jobId }
      }

      const { jobId } = await enqueueShortDramaRoleAssetDrawJob({
        userId,
        traceId,
        storyId: parsed.data.storyId,
        characterKey: parsed.data.characterKey,
        characterName: parsed.data.characterName,
        frontImageUrl: parsed.data.frontImageUrl,
        frontImageStorageKey: parsed.data.frontImageStorageKey,
        style: parsed.data.style,
        promptBase: parsed.data.promptBase,
        append: parsed.data.append ?? true,
        requestKey,
        publicCharacterId: parsed.data.publicCharacterId,
        publicCharacterDescription: parsed.data.publicCharacterDescription,
        items: parsed.data.items.map((x) => ({
          kind: x.kind,
          variantKey: x.variantKey,
          variantName: x.variantName,
          text: x.text,
          tagsText: x.tagsText ?? "",
          count: x.count
        }))
      })
      kickShortDramaRoleAssetDrawWorker()
      return { jobId }
    }
  })
}
