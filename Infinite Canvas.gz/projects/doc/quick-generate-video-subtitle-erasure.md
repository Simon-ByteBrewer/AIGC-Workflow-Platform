# Quick Generate 视频字幕擦除功能说明

## 1. 功能概述

本次新增的是 `quick-generate` 场景下的“视频字幕擦除”能力。

接入方式如下：

1. 在现有分镜视频卡片区域增加“擦除字幕”按钮。
2. 视频生成成功时，额外把上游返回的原始视频链接 `originVideoUrl` 写入当前分镜的视频历史。
3. 用户点击“擦除字幕”后，前端调用新的入队接口。
4. 服务端创建新的字幕擦除异步任务。
5. worker 调用字幕擦除接口、轮询结果、下载结果视频、上传到现有存储。
6. 擦除后的视频作为“新的视频版本”追加回当前分镜的现有视频历史中。
7. 页面通过现有 jobs 轮询机制自动刷新，把新视频显示到原视频区域。

本次改造遵循“旁路增强”原则：

- 不改原有视频生成主链路
- 不改原有存桶和播放主链路
- 不改原有确认视频逻辑
- 只额外增加字幕擦除能力所需的数据与任务链路

## 2. 新增文件

本次一共新增了 2 个核心文件。

### 2.1 字幕擦除 worker

文件路径：

- `src/server/domains/quick-generate/jobs/quickGenerateVideoSubtitleEraseWorker.ts`

职责：

- 定义新的字幕擦除 job payload / snapshot
- 调用字幕擦除提交接口
- 轮询字幕擦除任务结果
- 下载擦除后的视频
- 上传到现有对象存储
- 把擦除后的视频作为新版本写回 `quick_generate_episodes.video_results`
- 通过 jobs 系统与现有轮询机制集成

这是字幕擦除能力的核心执行文件。

### 2.2 字幕擦除入队接口

文件路径：

- `src/app/api/quick-generate/episodes/video-subtitle-erasure/route.ts`

职责：

- 校验登录态和用户权限
- 读取指定剧集 / 指定分镜 / 指定视频版本对应的历史记录
- 从历史记录中读取 `originVideoUrl`
- 创建字幕擦除异步任务并入队

这个文件是前端点击“擦除字幕”按钮后的服务端入口。

## 3. 改造文件

### 3.1 视频历史结构

文件路径：

- `src/shared/quickGenerate/videoResults.ts`

改动内容：

- 在 `QuickGenerateShotVideoHistoryItem` 上新增可选字段：
  - `originVideoUrl?: string`
- 更新归一化逻辑 `normalizeHistoryItem()`，保证老数据没有这个字段时也能兼容读取

作用：

- 为每个视频历史版本保存“原始生成链接”
- 后续字幕擦除直接读取这个字段，不再依赖当前 web 持久化后的播放链接

### 3.2 视频生成成功后的额外落库

文件路径：

- `src/server/domains/video/canvas/jobs/canvasVideoGenerateWorker.ts`

改动内容：

- 在 quick-generate 分镜视频持久化函数 `persistQuickGenerateEpisodeVideoResult()` 的输入中新增：
  - `originVideoUrl?: string`
- 在写入 `video_results` 时，把 `originVideoUrl` 一起写进对应历史项
- 在视频生成成功后调用持久化函数时，把上游返回的原始 `videoUrl` 传进去

作用：

- 原来只会落 `storageKey`
- 现在会在不影响原有逻辑的前提下，额外把原始链接落进历史数据

### 3.3 新增字幕擦除 job type

文件路径：

- `src/shared/jobs/jobTypes.ts`

改动内容：

- 新增：
  - `QUICK_GENERATE_VIDEO_SUBTITLE_ERASE_JOB_TYPE = "quick_generate_video_subtitle_erase"`

作用：

- 让字幕擦除任务纳入现有 jobs 体系

### 3.4 注册 worker 唤醒链路

文件路径：

- `src/server/framework/jobs/kickWorkers.ts`

改动内容：

- 引入：
  - `kickQuickGenerateVideoSubtitleEraseWorker`
- 在 `kickWorkersOnce()` 中加入该 worker 的唤醒逻辑

作用：

- 保证新任务能被现有 jobs 自动轮询和执行

### 3.5 前端 API client

文件路径：

- `src/features/script/quickGenerate/api-client.ts`

改动内容：

- 新增：
  - `eraseQuickGenerateShotVideoSubtitle()`

作用：

- 封装前端对 `/api/quick-generate/episodes/video-subtitle-erasure` 的调用

### 3.6 视频卡片按钮与状态

文件路径：

- `src/features/script/quickGenerate/components/QuickGenerateShotVideoPanel.tsx`

改动内容：

- 在单个视频卡片上新增“擦除字幕”按钮
- 新增本地状态：
  - `erasingJobId`
  - `actionError`
- 接入字幕擦除提交逻辑
- 支持显示：
  - `擦除中`
  - `擦除失败`
- 保留原有“确认视频”按钮和逻辑不变

作用：

- 为用户提供字幕擦除入口
- 在现有视频卡片区域直接展示状态和错误

### 3.7 视频卡片样式

文件路径：

- `src/features/script/quickGenerate/components/QuickGenerateShotVideoPanel.module.css`

改动内容：

- 新增 `subtitleEraseBtn` 样式

作用：

- 为“擦除字幕”按钮提供独立样式

### 3.8 页面 jobs 轮询接入

文件路径：

- `src/features/script/quickGenerate/components/QuickGenerateEpisodeResultPage.tsx`

改动内容：

- 把 `QUICK_GENERATE_VIDEO_SUBTITLE_ERASE_JOB_TYPE` 纳入现有视频任务轮询逻辑
- 当字幕擦除任务完成并生成新视频后，复用现有 `router.refresh()` 机制刷新页面

作用：

- 让字幕擦除结果自动回流到现有视频区域

## 4. 数据结构变化

### 4.1 没有新增数据库表

本次没有新增新的数据库表。

### 4.2 没有新增物理列 migration

本次没有改 SQL schema，没有做新的数据库 migration。

### 4.3 实际新增的数据字段

新增的是 `quick_generate_episodes.video_results` 这个 `jsonb` 结构中的历史项字段：

- `originVideoUrl?: string`

对应结构位置：

- `QuickGenerateShotVideoHistoryItem`

字段含义：

- 记录视频生成成功时上游返回的原始视频链接
- 该字段只用于后续字幕擦除
- 原有播放、存桶、确认版本逻辑都不依赖它

### 4.4 现有历史项现在的主要字段

每条历史项当前主要包含：

- `jobId`
- `storageKey`
- `originVideoUrl`
- `createdAt`
- `durationSeconds`
- `prompt`
- `settings`

其中：

- 播放仍依赖 `storageKey`
- 字幕擦除依赖 `originVideoUrl`

## 5. 组级 API Key 取值逻辑

最终方案不是用全局环境变量，也不是按模型取 key，而是“组级 API Key 直取”。

具体逻辑：

1. 根据当前任务的 `userId`
2. 调用管理员个人组兜底逻辑，拿到当前账号所属 `groupId`
3. 读取 `group_model_credentials.apiKey`
4. 用这把组级 API Key 调字幕擦除接口

相关文件：

- `src/server/domains/admin/services/adminPersonalGroup.ts`
- `src/shared/schema/groupModelAccess.ts`
- `src/server/domains/quick-generate/jobs/quickGenerateVideoSubtitleEraseWorker.ts`

注意：

- 前期曾尝试过“按模型解析 key”
- 但根据后台 UI 确认，真实业务配置是“组级 API Key”
- 所以后续实现已经收敛为“按组直取”，并去掉了字幕擦除链路对 `modelName` 的依赖

## 6. 字幕擦除接入流程

### 6.1 视频生成阶段

现有视频生成成功后，仍然保持原逻辑：

1. 获取上游视频链接
2. 下载视频
3. 上传到现有存储
4. 把 `storageKey` 写入 `video_results`

新增逻辑只有一项：

5. 额外把原始视频链接 `originVideoUrl` 写入同一条历史项

### 6.2 用户点击擦除字幕

前端在当前视频卡片点击“擦除字幕”后：

1. 调用 `/api/quick-generate/episodes/video-subtitle-erasure`
2. 服务端校验用户权限
3. 找到对应视频历史项
4. 读取 `originVideoUrl`
5. 创建字幕擦除 job 并入队

### 6.3 worker 执行阶段

字幕擦除 worker 执行步骤：

1. 按组读取 API Key
2. 提交字幕擦除任务
3. 轮询字幕擦除状态
4. 获取结果视频 URL
5. 下载结果视频
6. 上传现有对象存储
7. 作为新版本追加回 `video_results`

### 6.4 页面回流

页面本来就有 jobs 轮询：

1. jobs 轮询发现字幕擦除任务处于 `queued/running/error`
2. 右侧视频区域显示“擦除中 / 擦除失败”
3. 任务完成后，通过现有 `router.refresh()` 刷新页面
4. 新视频版本自动显示在当前分镜视频列表里

## 7. 当前限制

### 7.1 老数据限制

老视频如果历史项里没有 `originVideoUrl`，则无法执行字幕擦除。

当前表现：

- 点击后接口会返回：
  - `该视频缺少原始生成链接，无法擦除字幕`

### 7.2 不做过期预判

按当前需求约束：

- 不预先判断原始链接是否过期
- 如果原始链接过期，字幕擦除接口自然失败
- 失败信息会透传给前端展示

### 7.3 擦除结果不会继续保存新的 originVideoUrl

当前实现中，字幕擦除后生成的新视频历史项：

- `originVideoUrl` 会写空字符串

因此：

- 新生成的“擦除结果视频”默认不能继续再做一次字幕擦除

这是当前设计选择，不是异常。

## 8. 当前实现的边界

### 8.1 没有改动的现有业务

以下逻辑没有被改变：

- 视频生成主链路
- 原有对象存储上传逻辑
- 页面播放逻辑
- 视频历史展示逻辑
- 视频确认逻辑

### 8.2 实际属于新增或扩展的部分

只新增或扩展了：

- 原始链接额外落库
- 字幕擦除入队接口
- 字幕擦除异步 worker
- 前端视频卡片入口
- jobs 轮询接入

## 9. 后续可以继续优化的点

后续可以在这个基础上继续做：

1. 没有 `originVideoUrl` 时，前端直接置灰按钮
2. 给历史项增加 `sourceType` 区分：
   - `generated`
   - `subtitle-erased`
3. 细化任务阶段显示：
   - 提交中
   - 轮询中
   - 下载中
   - 上传中
4. 把字幕擦除接口 base URL 改成可配置
5. 如果业务需要，支持“擦除结果视频再次处理”

## 10. 给下一个 AI 的交接重点

如果后续继续改造，请优先关注以下文件：

- 新 worker：
  - `src/server/domains/quick-generate/jobs/quickGenerateVideoSubtitleEraseWorker.ts`
- 新入队接口：
  - `src/app/api/quick-generate/episodes/video-subtitle-erasure/route.ts`
- 视频历史结构：
  - `src/shared/quickGenerate/videoResults.ts`
- 视频生成额外落库：
  - `src/server/domains/video/canvas/jobs/canvasVideoGenerateWorker.ts`
- 前端按钮：
  - `src/features/script/quickGenerate/components/QuickGenerateShotVideoPanel.tsx`
- 页面轮询：
  - `src/features/script/quickGenerate/components/QuickGenerateEpisodeResultPage.tsx`

一句话总结：

> 这次字幕擦除功能是以“现有 quick-generate 视频历史为中心”接入的，核心依赖是 `video_results` 中新增的 `originVideoUrl`，以及 jobs 系统中新加的一条字幕擦除异步执行链路。
