import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq, sql } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { sharedCharacterCostumes, sharedResources } from "@/shared/schema"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensureSmoothLibraryMigration } from "@/shared/libraryMigration"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"

const querySchema = z.object({
  characterId: z.string().trim().min(1).max(200),
  limit: z.coerce.number().int().min(0).max(200).optional(),
  offset: z.coerce.number().int().min(0).max(10_000).optional()
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  await ensurePublicSchema()
  await ensureSmoothLibraryMigration(userId, traceId)

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    characterId: url.searchParams.get("characterId") ?? undefined,
    limit: url.searchParams.get("limit") ?? undefined,
    offset: url.searchParams.get("offset") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const limit = parsed.data.limit ?? 100
  const offset = parsed.data.offset ?? 0

  const db = await getDb({ sharedResources, sharedCharacterCostumes })
  const character = await db
    .select({ id: sharedResources.id })
    .from(sharedResources)
    .where(and(eq(sharedResources.id, parsed.data.characterId), eq(sharedResources.type, "character")))
    .limit(1)
  if (character.length === 0) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "角色不存在"), { status: 404 })

  const whereClause = eq(sharedCharacterCostumes.characterResourceId, parsed.data.characterId)

  const countRows = await db
    .select({ count: sql<number>`count(*)`.mapWith(Number) })
    .from(sharedCharacterCostumes)
    .where(whereClause as any)
  const total = Number(countRows?.[0]?.count || 0)

  const items =
    limit <= 0
      ? []
      : await db
          .select()
          .from(sharedCharacterCostumes)
          .where(whereClause as any)
          .orderBy(desc(sharedCharacterCostumes.version))
          .limit(limit)
          .offset(offset)

  return NextResponse.json(makeApiOk(traceId, { items, total }), { status: 200 })
}

