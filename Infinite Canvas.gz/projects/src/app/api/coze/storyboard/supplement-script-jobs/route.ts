import { NextResponse } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { logger } from "@/shared/logger"
import { getTraceId } from "@/shared/trace"
import type { NextRequest } from "next/server"
import { getSessionFromRequest } from "@/shared/session"
import { enqueueCozeGenerateScriptJob, kickCozeStoryboardWorker } from "@/server/domains/storyboard/jobs/cozeStoryboardWorker"
import { and, eq, isNull, or } from "drizzle-orm"
import { getDb } from "coze-coding-dev-sdk"
import { stories, storyOutlines, storyboards } from "@/shared/schema/story"

const inputSchema = z.object({
  storyId: z.string().min(1),
  outlineId: z.string().min(1).optional() // 如果不传，则处理该 story 下所有 outline
})

/**
 * 补充创建缺失的脚本任务
 * 检查缺失脚本内容的分镜，为其创建脚本任务
 */
export async function POST(req: Request): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const start = Date.now()

  logger.info({
    event: "supplement_script_jobs_start",
    module: "coze",
    traceId,
    message: "开始补充缺失的脚本任务"
  })

  // 验证登录
  const session = await getSessionFromRequest(req as unknown as NextRequest)
  const userId = session?.userId
  if (!userId) {
    return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), {
      status: 401
    })
  }

  // 解析请求体
  let json: unknown
  try {
    json = await req.json()
  } catch {
    return NextResponse.json(makeApiErr(traceId, "COZE_INVALID_JSON", "请求体不是合法 JSON"), {
      status: 400
    })
  }

  const parsed = inputSchema.safeParse(json)
  if (!parsed.success) {
    return NextResponse.json(makeApiErr(traceId, "COZE_VALIDATION_FAILED", "入参格式不正确"), {
      status: 400
    })
  }

  const { storyId, outlineId } = parsed.data

  try {
    const db = await getDb({ stories, storyOutlines, storyboards })

    // 验证 story 归属
    const [storyRow] = await db
      .select({ userId: stories.userId, shotStyle: stories.shotStyle })
      .from(stories)
      .where(eq(stories.id, storyId))
      .limit(1)

    if (!storyRow || storyRow.userId !== userId) {
      return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限操作此故事"), {
        status: 403
      })
    }

    const style = typeof storyRow.shotStyle === "string" && storyRow.shotStyle.trim() ? storyRow.shotStyle.trim() : "realistic"

    // 查找缺失脚本的分镜
    let pendingStoryboards: Array<{ id: string; shotCut: boolean | null; storyboardText: string | null; outlineId: string }> = []

    if (outlineId) {
      // 如果指定了 outlineId，只处理该 outline 下的分镜
      // 先验证 outline 归属
      const [outlineRow] = await db
        .select({ storyId: storyOutlines.storyId })
        .from(storyOutlines)
        .where(eq(storyOutlines.id, outlineId))
        .limit(1)

      if (!outlineRow || outlineRow.storyId !== storyId) {
        return NextResponse.json(makeApiErr(traceId, "OUTLINE_NOT_FOUND", "大纲不存在或不属于此故事"), {
          status: 404
        })
      }

      pendingStoryboards = await db
        .select({
          id: storyboards.id,
          shotCut: storyboards.shotCut,
          storyboardText: storyboards.storyboardText,
          outlineId: storyboards.outlineId
        })
        .from(storyboards)
        .where(
          and(
            eq(storyboards.outlineId, outlineId),
            or(isNull(storyboards.isScriptGenerated), eq(storyboards.isScriptGenerated, false), isNull(storyboards.scriptContent))
          )
        )
    } else {
      // 处理该 story 下所有 outline
      pendingStoryboards = await db
        .select({
          id: storyboards.id,
          shotCut: storyboards.shotCut,
          storyboardText: storyboards.storyboardText,
          outlineId: storyboards.outlineId
        })
        .from(storyboards)
        .innerJoin(storyOutlines, eq(storyboards.outlineId, storyOutlines.id))
        .where(
          and(
            eq(storyOutlines.storyId, storyId),
            or(isNull(storyboards.isScriptGenerated), eq(storyboards.isScriptGenerated, false), isNull(storyboards.scriptContent))
          )
        )
    }

    if (pendingStoryboards.length === 0) {
      logger.info({
        event: "supplement_script_jobs_no_pending",
        module: "coze",
        traceId,
        storyId,
        outlineId,
        message: "没有需要补充的脚本任务"
      })
      return NextResponse.json(makeApiOk(traceId, { createdCount: 0, message: "没有需要补充的脚本任务" }), { status: 200 })
    }

    // 批量创建任务
    const jobCreations = pendingStoryboards.map(async (storyboard) => {
      const demand = `风格：${style}\n是否切镜：${Boolean(storyboard.shotCut) ? "需要切镜" : "无需切镜"}`
      const raw_script = storyboard.storyboardText || `生成分镜脚本，基于以下分镜文本内容。`

      await enqueueCozeGenerateScriptJob({
        userId,
        traceId,
        raw_script,
        demand,
        storyId,
        storyboardId: storyboard.id
      })
    })

    await Promise.all(jobCreations)

    // 唤醒 Worker
    kickCozeStoryboardWorker()

    const durationMs = Date.now() - start
    logger.info({
      event: "supplement_script_jobs_success",
      module: "coze",
      traceId,
      storyId,
      outlineId,
      createdCount: pendingStoryboards.length,
      durationMs,
      message: `成功补充创建 ${pendingStoryboards.length} 个脚本任务`
    })

    return NextResponse.json(
      makeApiOk(traceId, {
        createdCount: pendingStoryboards.length,
        message: `成功创建 ${pendingStoryboards.length} 个脚本任务`
      }),
      { status: 200 }
    )
  } catch (err) {
    const durationMs = Date.now() - start
    const anyErr = err as { name?: string; message?: string; stack?: string }
    logger.error({
      event: "supplement_script_jobs_error",
      module: "coze",
      traceId,
      storyId,
      outlineId,
      message: "补充脚本任务失败",
      durationMs,
      errorName: anyErr?.name,
      errorMessage: anyErr?.message,
      stack: anyErr?.stack
    })
    return NextResponse.json(makeApiErr(traceId, "SUPPLEMENT_FAILED", "补充脚本任务失败，请稍后重试"), {
      status: 500
    })
  }
}
