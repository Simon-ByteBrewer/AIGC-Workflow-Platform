import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { resumeEpisodeMaterialJob } from "@/server/domains/storyboard/jobs/episodeMaterialWorker"

export async function POST(req: NextRequest, { params }: { params: Promise<{ jobId: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const { jobId } = await params
  const result = await resumeEpisodeMaterialJob(jobId)
  
  if (!result.success) {
    return NextResponse.json(makeApiErr(traceId, "RESUME_FAILED", result.message), { status: 400 })
  }
  
  return NextResponse.json(makeApiOk(traceId, { message: result.message }), { status: 200 })
}
