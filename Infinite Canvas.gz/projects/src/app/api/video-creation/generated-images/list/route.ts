import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { and, desc, eq, sql } from "drizzle-orm"
import { getDb } from "@/server/db/getDb"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { getS3Storage } from "@/shared/storage"
import { resolveStorageUrl } from "@/shared/storageUrl"
import { generatedImages, stories } from "@/shared/schema"

export const runtime = "nodejs"

const querySchema = z.object({
  storyId: z.string().trim().min(1).max(200),
  category: z.string().trim().min(1).max(50).default("background"),
  search: z.string().trim().max(200).optional(),
  limit: z.coerce.number().int().min(0).max(200).optional(),
  offset: z.coerce.number().int().min(0).max(10_000).optional(),
  includeGlobal: z.string().optional().default("false")
})

export async function GET(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const url = new URL(req.url)
  const parsed = querySchema.safeParse({
    storyId: url.searchParams.get("storyId") ?? undefined,
    category: url.searchParams.get("category") ?? "background",
    search: url.searchParams.get("search") ?? undefined,
    limit: url.searchParams.get("limit") ?? undefined,
    offset: url.searchParams.get("offset") ?? undefined
  })
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  const { storyId, category, search, limit = 100, offset = 0 } = parsed.data

  const db = await getDb({ generatedImages, stories })

  // 验证用户是否有权限访问该故事
  const storyRow = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, storyId), eq(stories.userId, userId))).limit(1)
  if (!storyRow[0]?.id) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到故事"), { status: 403 })

  // 构建查询条件
  const whereParts: any[] = [eq(generatedImages.storyId, storyId), eq(generatedImages.category, category)]

  // 如果有搜索关键词，则搜索 name 或 description 字段
  if (search) {
    const likeValue = `%${search}%`
    whereParts.push(
      sql`(${generatedImages.name} ILIKE ${likeValue} OR ${generatedImages.description} ILIKE ${likeValue})`
    )
  }

  const whereClause = whereParts.length > 0 ? and(...whereParts) : undefined

  // 查询数据
  const items =
    limit <= 0
      ? []
      : await db
          .select({
            id: generatedImages.id,
            name: generatedImages.name,
            description: generatedImages.description,
            url: generatedImages.url,
            storageKey: generatedImages.storageKey,
            thumbnailUrl: generatedImages.thumbnailUrl,
            thumbnailStorageKey: generatedImages.thumbnailStorageKey,
            category: generatedImages.category,
            prompt: generatedImages.prompt,
            createdAt: generatedImages.createdAt
          })
          .from(generatedImages)
          .where(whereClause as any)
          .orderBy(desc(generatedImages.createdAt))
          .limit(limit)
          .offset(offset)

  // 统计总数
  const totalResult = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(generatedImages)
    .where(whereClause as any)

  const total = totalResult[0]?.count ?? 0

  // 将 storageKey 转换为真实的 URL
  const storage = getS3Storage()
  const resolvedItems = await Promise.all(
    items.map(async (item) => ({
      ...item,
      url: await resolveStorageUrl(storage, item.storageKey),
      thumbnailUrl: item.thumbnailStorageKey ? await resolveStorageUrl(storage, item.thumbnailStorageKey) : item.thumbnailUrl
    }))
  )

  return NextResponse.json(makeApiOk(traceId, { items: resolvedItems, total }), { status: 200 })
}
