import { and, eq } from "drizzle-orm"
import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr } from "@/shared/api"
import { getSessionFromRequest } from "@/shared/session"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { enqueueEpisodeMaterialAssetRegenerateJob, kickEpisodeMaterialWorker } from "@/server/domains/storyboard/jobs/episodeMaterialWorker"
import { createStartedJobEventStreamResponse } from "@/server/framework/jobs/createStartedJobEventStreamResponse"
import { episodeMaterialAssets } from "@/shared/schema/generation"
import { stories } from "@/shared/schema/story"

export const runtime = "nodejs"

const inputSchema = z.object({
  assetId: z.string().trim().min(1).max(200),
  storyId: z.string().trim().min(1).max(200),
  prompt: z.string().trim().min(1).max(20_000).optional(),
  makeupName: z.string().trim().max(200).optional(),
  costumeName: z.string().trim().max(200).optional()
})

export async function POST(req: NextRequest): Promise<Response> {
  const traceId = getTraceId(req.headers)
  const session = await getSessionFromRequest(req)
  const userId = session?.userId
  if (!userId) return NextResponse.json(makeApiErr(traceId, "AUTH_REQUIRED", "未登录或登录已过期"), { status: 401 })

  const body = await req.json().catch(() => null)
  const parsed = inputSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "参数格式不正确"), { status: 400 })

  await ensurePublicSchema()
  const db = await getDb({ stories, episodeMaterialAssets })
  const allowed = await db.select({ id: stories.id }).from(stories).where(and(eq(stories.id, parsed.data.storyId), eq(stories.userId, userId))).limit(1)
  if (allowed.length === 0) return NextResponse.json(makeApiErr(traceId, "FORBIDDEN", "无权限或未找到剧本"), { status: 403 })

  const assetRow = await db
    .select({
      id: episodeMaterialAssets.id,
      prompt: episodeMaterialAssets.prompt,
      makeupName: episodeMaterialAssets.makeupName,
      costumeName: episodeMaterialAssets.costumeName
    })
    .from(episodeMaterialAssets)
    .where(and(eq(episodeMaterialAssets.id, parsed.data.assetId), eq(episodeMaterialAssets.storyId, parsed.data.storyId)))
    .limit(1)

  const asset = assetRow[0]
  if (!asset) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "未找到素材条目"), { status: 404 })

  return createStartedJobEventStreamResponse({
    req,
    traceId,
    userId,
    startJob: async () => {
      const { jobId } = await enqueueEpisodeMaterialAssetRegenerateJob({
        userId,
        traceId,
        storyId: parsed.data.storyId,
        assetId: asset.id,
        prompt: parsed.data.prompt ?? asset.prompt ?? "",
        makeupName: parsed.data.makeupName ?? asset.makeupName ?? null,
        costumeName: parsed.data.costumeName ?? asset.costumeName ?? null
      })
      kickEpisodeMaterialWorker()
      return { jobId }
    }
  })
}
