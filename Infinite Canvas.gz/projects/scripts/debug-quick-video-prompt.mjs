import path from "node:path"
import { getDb } from "coze-coding-dev-sdk"
import { desc, eq } from "drizzle-orm"
import { jsonb, pgTable, text, timestamp, integer } from "drizzle-orm/pg-core"

function stripQuotes(v) {
  const s = String(v ?? "")
  if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1)
  return s
}

async function loadEnvFile(filePath) {
  try {
    const fs = await import("node:fs/promises")
    const text = await fs.readFile(filePath, "utf8")
    for (const line of text.split(/\r?\n/)) {
      const s = line.trim()
      if (!s || s.startsWith("#")) continue
      const idx = s.indexOf("=")
      if (idx <= 0) continue
      const k = s.slice(0, idx).trim()
      const v = stripQuotes(s.slice(idx + 1).trim())
      if (!k) continue
      if (process.env[k] == null) process.env[k] = v
    }
  } catch {
    // ignore
  }
}

function normalizePgEnv() {
  const keys = ["PGDATABASE_URL", "DATABASE_URL", "POSTGRES_URL"]
  for (const key of keys) {
    const raw = process.env[key]
    if (!raw) continue
    const trimmed = raw.trim()
    if (!trimmed) continue
    process.env[key] = trimmed
  }
}

function truncate(text, max = 160) {
  const value = String(text ?? "").trim()
  if (value.length <= max) return value
  return `${value.slice(0, max)}...`
}

function summarizePromptPayload(payload) {
  const obj = payload && typeof payload === "object" && !Array.isArray(payload) ? payload : {}
  const rows = Array.isArray(obj.optimization_result) ? obj.optimization_result : []
  return rows.map((row, index) => {
    const item = row && typeof row === "object" && !Array.isArray(row) ? row : {}
    const optimizedText = String(item.optimized_text ?? "").trim()
    return {
      index,
      shotNo: Number(item.shot_no ?? 0) || 0,
      optimizedTextLength: optimizedText.length,
      optimizedTextSnippet: truncate(optimizedText, 120),
      storyboardPanelPromptLength: String(item.storyboard_panel_prompt ?? "").trim().length
    }
  })
}

const jobs = pgTable("jobs", {
  id: text("id").primaryKey(),
  type: text("type").notNull(),
  status: text("status").notNull(),
  storyId: text("story_id"),
  payload: jsonb("payload").notNull(),
  snapshot: jsonb("snapshot").notNull(),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull()
})

const quickGenerateEpisodes = pgTable("quick_generate_episodes", {
  id: text("id").primaryKey(),
  storyId: text("story_id").notNull(),
  episodeNo: integer("episode_no").notNull(),
  requestPayload: jsonb("request_payload").notNull(),
  resultPayload: jsonb("result_payload").notNull(),
  videoPromptPayload: jsonb("video_prompt_payload").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull()
})

async function main() {
  await loadEnvFile(path.join(process.cwd(), ".env.local"))
  await loadEnvFile(path.join(process.cwd(), ".env"))
  normalizePgEnv()

  const db = await getDb({ jobs, quickGenerateEpisodes })

  const latestJobs = await db
    .select({
      id: jobs.id,
      type: jobs.type,
      status: jobs.status,
      storyId: jobs.storyId,
      payload: jobs.payload,
      snapshot: jobs.snapshot,
      errorMessage: jobs.errorMessage,
      createdAt: jobs.createdAt
    })
    .from(jobs)
    .where(eq(jobs.type, "quick_generate_video_prompt"))
    .orderBy(desc(jobs.createdAt))
    .limit(5)

  console.log("=== Latest quick_generate_video_prompt jobs ===")
  for (const job of latestJobs) {
    const payload = job.payload && typeof job.payload === "object" && !Array.isArray(job.payload) ? job.payload : {}
    const snapshot = job.snapshot && typeof job.snapshot === "object" && !Array.isArray(job.snapshot) ? job.snapshot : {}
    const shots = Array.isArray(payload.shots) ? payload.shots : []
    console.log({
      jobId: job.id,
      status: job.status,
      createdAt: job.createdAt,
      storyId: job.storyId,
      episodeId: String(payload.episodeId ?? ""),
      shotCount: shots.length,
      shotNos: shots.map((shot) => Number(shot?.shotNo ?? 0)).filter(Boolean),
      snapshotShots: Array.isArray(snapshot.shots) ? snapshot.shots : [],
      errorMessage: job.errorMessage ?? ""
    })
  }

  const targetJob = latestJobs[0]
  if (!targetJob) return
  const targetPayload =
    targetJob.payload && typeof targetJob.payload === "object" && !Array.isArray(targetJob.payload)
      ? targetJob.payload
      : {}
  const episodeId = String(targetPayload.episodeId ?? "").trim()
  if (!episodeId) {
    console.log("No episodeId found on latest job payload")
    return
  }

  const rows = await db
    .select({
      id: quickGenerateEpisodes.id,
      episodeNo: quickGenerateEpisodes.episodeNo,
      requestPayload: quickGenerateEpisodes.requestPayload,
      resultPayload: quickGenerateEpisodes.resultPayload,
      videoPromptPayload: quickGenerateEpisodes.videoPromptPayload,
      updatedAt: quickGenerateEpisodes.updatedAt
    })
    .from(quickGenerateEpisodes)
    .where(eq(quickGenerateEpisodes.id, episodeId))
    .limit(1)

  const row = rows[0]
  if (!row) {
    console.log("Episode not found for latest job", { episodeId })
    return
  }

  const workflowShots =
    row.resultPayload &&
    typeof row.resultPayload === "object" &&
    !Array.isArray(row.resultPayload) &&
    row.resultPayload.workflowResponse &&
    typeof row.resultPayload.workflowResponse === "object" &&
    !Array.isArray(row.resultPayload.workflowResponse) &&
    Array.isArray(row.resultPayload.workflowResponse.shots)
      ? row.resultPayload.workflowResponse.shots
      : []

  console.log("=== Episode prompt payload summary ===")
  console.log({
    episodeId: row.id,
    episodeNo: row.episodeNo,
    updatedAt: row.updatedAt,
    workflowShotCount: workflowShots.length,
    promptRows: summarizePromptPayload(row.videoPromptPayload)
  })
}

main().catch((err) => {
  console.error(err)
  process.exit(1)
})
