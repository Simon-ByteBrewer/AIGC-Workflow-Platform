import type { ReactElement } from "react"
import { LibraryCard, type LibraryItem } from "./LibraryCard"
import styles from "./LibraryGrid.module.css"

interface LibraryGridProps {
  items: LibraryItem[]
  view: "grid" | "list"
  onItemClick?: (item: LibraryItem) => void
  onViewContent?: (item: LibraryItem) => void
  onRenameSaved?: () => void | Promise<void>
  selectedIds?: Set<string>
  onToggleSelected?: (id: string) => void
}

export function LibraryGrid({
  items,
  view,
  onItemClick,
  onViewContent,
  onRenameSaved,
  selectedIds,
  onToggleSelected,
}: LibraryGridProps): ReactElement {
  return (
    <div className={view === "grid" ? styles.grid : styles.list}>
      {items.map((item) => (
        <LibraryCard 
          key={item.id} 
          item={item} 
          view={view} 
          onClick={() => onItemClick?.(item)}
          selected={selectedIds?.has(item.id)}
          onToggleSelected={onToggleSelected ? () => onToggleSelected(item.id) : undefined}
          onViewContent={onViewContent ? () => onViewContent(item) : undefined}
          onRenameSaved={onRenameSaved}
        />
      ))}
    </div>
  )
}
