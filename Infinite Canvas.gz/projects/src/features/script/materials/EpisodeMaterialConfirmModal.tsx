"use client"

import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react"
import type { MaterialAsset, MaterialSummary } from "./types"
import { EpisodeMaterialSection } from "./EpisodeMaterialSection"
import { EpisodeMaterialRegenerateModal } from "./EpisodeMaterialRegenerateModal"
import { EpisodeMaterialFailureDetailModal } from "./EpisodeMaterialFailureDetailModal"
import { EpisodeMaterialCreateModal } from "./EpisodeMaterialCreateModal"
import styles from "./EpisodeMaterialGalleryPage.module.css"

type Props = {
  storyId: string
  onClose: () => void
}

function parseJsonMeta(meta: unknown): unknown {
  if (typeof meta !== "string") return meta
  const s = meta.trim()
  if (!s) return meta
  if (!(s.startsWith("{") || s.startsWith("["))) return meta
  try {
    return JSON.parse(s)
  } catch {
    return meta
  }
}

function materialMetaObject(meta: unknown): any | null {
  const parsed = parseJsonMeta(meta)
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null
  return parsed as any
}

export function EpisodeMaterialConfirmModal({ storyId, onClose }: Props): ReactElement {
  const sid = (storyId ?? "").trim()
  const [loading, setLoading] = useState(false)
  const [confirming, setConfirming] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [summary, setSummary] = useState<MaterialSummary>({ scene: [], role: [], item: [] })
  const [editing, setEditing] = useState<MaterialAsset | null>(null)
  const [failed, setFailed] = useState<MaterialAsset | null>(null)
  const [creating, setCreating] = useState<"scene" | "role" | "item" | null>(null)
  const loadInFlightRef = useRef(false)

  const load = useCallback(async () => {
    if (!sid) return
    if (loadInFlightRef.current) return
    loadInFlightRef.current = true
    setLoading(true)
    setError(null)
    try {
      const res = await fetch(
        `/api/script/episode-material-assets/summary?storyId=${encodeURIComponent(sid)}&limit=800&latestOnly=true`,
        { cache: "no-store" }
      )
      const json = (await res.json().catch(() => null)) as
        | { ok: boolean; data?: { scene?: any[]; role?: any[]; item?: any[] }; error?: { message?: string } }
        | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      const mapOne = (it: any): MaterialAsset => ({
        id: String(it?.id ?? ""),
        kind: String(it?.kind ?? ""),
        name: String(it?.name ?? ""),
        roleName: typeof it?.roleName === "string" ? it.roleName : it?.roleName ?? null,
        makeupName: typeof it?.makeupName === "string" ? it.makeupName : it?.makeupName ?? null,
        costumeName: typeof it?.costumeName === "string" ? it.costumeName : it?.costumeName ?? null,
        prompt: typeof it?.prompt === "string" ? it.prompt : it?.prompt ?? null,
        url: String(it?.url ?? ""),
        meta: it?.meta ?? undefined,
        createdAt: typeof it?.createdAt === "string" ? it.createdAt : undefined
      })
      const scene = (Array.isArray(json.data?.scene) ? json.data?.scene : []).map(mapOne).filter((x) => x.id)
      const role = (Array.isArray(json.data?.role) ? json.data?.role : []).map(mapOne).filter((x) => x.id)
      const item = (Array.isArray(json.data?.item) ? json.data?.item : []).map(mapOne).filter((x) => x.id)
      setSummary({ scene, role, item })
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "加载失败")
      setSummary({ scene: [], role: [], item: [] })
    } finally {
      setLoading(false)
      loadInFlightRef.current = false
    }
  }, [sid])

  useEffect(() => {
    void load()
  }, [load])

  const total = summary.scene.length + summary.role.length + summary.item.length
  const emptyHint = useMemo(() => (loading ? "加载中…" : "暂无图片素材结果"), [loading])
  const roleNameOptions = useMemo(() => {
    const names = summary.role.map((r) => String(r.roleName ?? r.name ?? "").trim()).filter(Boolean)
    const unique = Array.from(new Set(names))
    unique.sort((a, b) => a.localeCompare(b))
    return unique
  }, [summary.role])
  const allAssets = useMemo(() => [...summary.scene, ...summary.role, ...summary.item], [summary.item, summary.role, summary.scene])
  const allConfirmed = useMemo(() => {
    if (allAssets.length === 0) return false
    return allAssets.every((asset) => {
      const metaObj = materialMetaObject(asset.meta)
      const confirmedAt = typeof metaObj?.confirmedAt === "number" ? metaObj.confirmedAt : 0
      const storyAssetId = typeof metaObj?.library?.storyAssetId === "string" ? metaObj.library.storyAssetId.trim() : ""
      return confirmedAt > 0 || Boolean(storyAssetId)
    })
  }, [allAssets])

  const shouldAutoRefresh = useMemo(() => {
    const isPending = (a: MaterialAsset): boolean => {
      const m = materialMetaObject(a.meta)
      const status = String(m?.generationStatus ?? "").trim().toLowerCase()
      const err = typeof m?.errorMessage === "string" ? m.errorMessage.trim() : ""
      if (status === "failed" || status === "error" || err) return false
      if (status === "pending" || status === "running") return true
      return !String(a.url ?? "").trim()
    }
    return allAssets.some(isPending)
  }, [allAssets])

  useEffect(() => {
    if (!sid) return
    if (!shouldAutoRefresh) return
    const timer = window.setInterval(() => {
      void load()
    }, 2500)
    return () => window.clearInterval(timer)
  }, [load, shouldAutoRefresh, sid])

  const onConfirmToLibrary = useCallback(async () => {
    if (!sid || confirming) return
    setConfirming(true)
    setError(null)
    try {
      const res = await fetch("/api/script/episode-material-assets/confirm", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ storyId: sid })
      })
      const json = (await res.json().catch(() => null)) as { ok: boolean; error?: { message?: string } } | null
      if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
      await load()
    } catch (e) {
      const anyErr = e as { message?: string }
      setError(anyErr?.message ?? "入库失败")
    } finally {
      setConfirming(false)
    }
  }, [confirming, load, sid])

  const onDeleteAsset = useCallback(
    async (asset: MaterialAsset) => {
      if (!sid) return
      const ok = window.confirm(`确认删除「${asset.name || asset.id}」？将同时删除已入库记录。`)
      if (!ok) return
      setError(null)
      try {
        const res = await fetch("/api/script/episode-material-assets/delete", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ storyId: sid, assetId: asset.id })
        })
        const json = (await res.json().catch(() => null)) as { ok: boolean; error?: { message?: string } } | null
        if (!res.ok || !json?.ok) throw new Error(json?.error?.message ?? `HTTP ${res.status}`)
        await load()
      } catch (e) {
        const anyErr = e as { message?: string }
        setError(anyErr?.message ?? "删除失败")
      }
    },
    [load, sid]
  )

  return (
    <div
      className={styles.modalOverlay}
      role="dialog"
      aria-modal="true"
      aria-label="图片素材确认"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className={styles.modal} style={{ width: "min(1100px, 94vw)" }}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>图片素材确认（场景 / 人物 / 物品）</div>
          <div className={styles.actions}>
            <button type="button" className={`${styles.btn} ${styles.btnPrimary}`} onClick={() => void onConfirmToLibrary()} disabled={loading || confirming}>
              {confirming ? "入库中…" : "确认入库"}
            </button>
            <button type="button" className={styles.btn} onClick={() => void load()} disabled={loading}>
              {loading ? "刷新中…" : "刷新"}
            </button>
            <button type="button" className={styles.btn} onClick={onClose}>
              关闭
            </button>
          </div>
        </div>

        {error ? <div className={styles.hint}>{error}</div> : null}
        {allConfirmed ? (
          <div className={styles.pageStatusBanner} role="status" aria-live="polite">
            <div className={styles.pageStatusTitle}>已全部入库完成</div>
            <div className={styles.pageStatusDesc}>当前批次素材都已成功入库，用户可以直接离开页面继续后续创作。</div>
          </div>
        ) : null}
        {total === 0 ? <div className={styles.hint}>{emptyHint}</div> : null}

        <div className={styles.modalBody}>
          <div className={styles.main} style={{ padding: 0 }}>
            <EpisodeMaterialSection
              title="场景"
              items={summary.scene}
              onRegenerate={(a) => setEditing(a)}
              onDelete={(a) => void onDeleteAsset(a)}
              onShowFailure={(a) => setFailed(a)}
              onAdd={() => setCreating("scene")}
            />
            <EpisodeMaterialSection
              title="人物"
              items={summary.role}
              onRegenerate={(a) => setEditing(a)}
              onDelete={(a) => void onDeleteAsset(a)}
              onShowFailure={(a) => setFailed(a)}
              onAdd={() => setCreating("role")}
            />
            <EpisodeMaterialSection
              title="物品"
              items={summary.item}
              onRegenerate={(a) => setEditing(a)}
              onDelete={(a) => void onDeleteAsset(a)}
              onShowFailure={(a) => setFailed(a)}
              onAdd={() => setCreating("item")}
            />
          </div>
        </div>

        {editing ? (
          <EpisodeMaterialRegenerateModal
            storyId={sid}
            asset={editing}
            onClose={() => setEditing(null)}
            onSubmitted={() => {
              setEditing(null)
              void load()
            }}
          />
        ) : null}
        {failed ? (
          <EpisodeMaterialFailureDetailModal
            asset={failed}
            onClose={() => setFailed(null)}
            onRegenerate={() => {
              setFailed(null)
              setEditing(failed)
            }}
          />
        ) : null}
        {creating ? (
          <EpisodeMaterialCreateModal
            storyId={sid}
            kind={creating}
            roleNameOptions={roleNameOptions}
            onClose={() => setCreating(null)}
            onSubmitted={() => {
              setCreating(null)
              void load()
            }}
          />
        ) : null}
      </div>
    </div>
  )
}
