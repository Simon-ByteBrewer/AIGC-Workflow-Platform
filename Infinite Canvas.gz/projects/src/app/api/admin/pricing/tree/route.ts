import { NextResponse, type NextRequest } from "next/server"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { getPricingTree } from "@/server/domains/admin/pricingAdmin"

export async function GET(req: NextRequest) {
  const traceId = getTraceId(req.headers)
  const actor = await requireAdminActor(req, traceId)
  if (actor instanceof Response) return actor
  if (actor.roleKey !== "admin") {
    return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "仅平台管理员可查看价格管理"), { status: 403 })
  }

  try {
    const groups = await getPricingTree(actor.userId, actor.roleKey)
    return NextResponse.json(makeApiOk(traceId, { groups }))
  } catch (error: any) {
    return NextResponse.json(makeApiErr(traceId, "PRICING_TREE_FAILED", error?.message ?? "获取价格列表失败"), { status: 500 })
  }
}
