import { NextResponse, type NextRequest } from "next/server"
import { z } from "zod"
import { makeApiErr, makeApiOk } from "@/shared/api"
import { getTraceId } from "@/shared/trace"
import { ensurePublicSchema } from "@/server/db/ensurePublicSchema"
import { getDb } from "@/server/db/getDb"
import { adminPromptPresets, groupPromptBindings, userGroups } from "@/shared/schema"
import { requireAdminActor } from "@/server/domains/admin/services/adminRole"
import { ensureGroupExists, getGroupPromptConfig, listAdminPromptPresets, updateGroupPromptConfig } from "@/server/domains/admin/groupPromptAccess"

export const runtime = "nodejs"

const putSchema = z
  .object({
    storyboardPromptPresetIds: z.array(z.string().trim().min(1).max(200)).max(200).optional(),
    videoPromptPresetIds: z.array(z.string().trim().min(1).max(200)).max(200).optional()
  })
  .strict()

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }

    const { id } = await ctx.params
    if (!String(id ?? "").trim()) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ userGroups, adminPromptPresets, groupPromptBindings })
    const group = await ensureGroupExists(db, id)
    if (!group?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

    const [config, promptPresets] = await Promise.all([getGroupPromptConfig(db, id), listAdminPromptPresets(db)])
    return NextResponse.json(makeApiOk(traceId, { group, config, promptPresets }), { status: 200 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "加载提示词配置失败"
    return NextResponse.json(makeApiErr(traceId, "PROMPT_CONFIG_LOAD_FAILED", message), { status: 500 })
  }
}

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const traceId = getTraceId(req.headers)
  try {
    const actor = await requireAdminActor(req, traceId)
    if (actor instanceof Response) return actor
    if (actor.roleKey !== "admin") {
      return NextResponse.json(makeApiErr(traceId, "ADMIN_REQUIRED", "需要超级管理员权限"), { status: 403 })
    }

    const { id } = await ctx.params
    if (!String(id ?? "").trim()) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "缺少用户组 ID"), { status: 400 })
    }

    const parsed = putSchema.safeParse(await req.json().catch(() => null))
    if (!parsed.success) {
      return NextResponse.json(makeApiErr(traceId, "VALIDATION_FAILED", "请求参数不正确"), { status: 400 })
    }

    await ensurePublicSchema()
    const db = await getDb({ userGroups, adminPromptPresets, groupPromptBindings })
    const group = await ensureGroupExists(db, id)
    if (!group?.id) return NextResponse.json(makeApiErr(traceId, "NOT_FOUND", "用户组不存在"), { status: 404 })

    const config = await updateGroupPromptConfig({
      db,
      groupId: id,
      actorUserId: actor.userId,
      storyboardPromptPresetIds: Array.from(new Set((parsed.data.storyboardPromptPresetIds ?? []).map((item) => item.trim()).filter(Boolean))),
      videoPromptPresetIds: Array.from(new Set((parsed.data.videoPromptPresetIds ?? []).map((item) => item.trim()).filter(Boolean)))
    })

    return NextResponse.json(makeApiOk(traceId, { group, config }), { status: 200 })
  } catch (error) {
    const message = error instanceof Error ? error.message : "保存提示词配置失败"
    return NextResponse.json(makeApiErr(traceId, "PROMPT_CONFIG_SAVE_FAILED", message), { status: 500 })
  }
}
